<?php

/**
 * Enter description here ...
 * @author emikwae
 *
 */
class Template {
	private $idTemplate = -1;
	private $chrName = '';
	private $chrUserID = '';
	private $chrCountryCode = '';
	private $chrTitle = '';
	/**
	 * Enter description here ...
	 * @param unknown_type $idUser
	 */
	public function Template($idTemplate = -1, $arrData = array()){
		if ($idTemplate == -1){#create new template
			$fields = array();
			$values = array();
			if(isset($arrData['name']) && $arrData['name'] != ""){
					$fields[] = "name";
					$values[] = safeDatabase($arrData['name']);
			}
			if(isset($arrData['uid']) && $arrData['uid'] != ""){
					$fields[] = "uid";
					$values[] = $arrData['uid'];
			}
			if(isset($arrData['erelation']) && $arrData['erelation'] != ""){
					$fields[] = "erelation";
					$values[] = $arrData['erelation'];
			}
			$fields[] = "dn";
			$values[] = "t";
			
			$fields[] = "title";
			$values[] = "Template";

			#instead of auto_increment
			$q1 = "SELECT max(iduser) from dbatn_userslist WHERE iduser < 100"; 
			$rs1 = mazDb_query_params($q1, array());
			$arrResult = mazDb_fetch_array($rs1);
			$intIdOfFirstTemplate = 11; #Defines what id in dbatn_userslist the first template should be placed at.
			$newId = ($arrResult['max'] == 0)? $intIdOfFirstTemplate : $arrResult['max'] + 1; # if max = 0, the first template needs to be created. place it at 11, leaving the first 10 places.
			#what to do if $newID exceeds 100? No place left to handle templates. Place them among the rest of the users?
			if(isset($newId)){
					$fields[] = "iduser";
					$values[] = $newId;
			}
			$f = implode(",", $fields);
			$v = implode("','", $values);
			
			$q2 = "INSERT INTO dbatn_userslist (".$f.") VALUES ('".$v."')"; 
			
			mazDb_query_params($q2, array());

			$this->idTemplate = $newId;
			#$this->chrUserID = $arrData['uid'];
			#$this->blnExternal = ($arrData ['erelation'] != 'E') ? true: false;
			#$this->blnVisible = $arrData['visible'];#(isset($arrData['visible']) && $arrData['visible'] != false) ? true: false;
			#$this->chrName = $arrData['name'];
		}
		else{
			$this->idTemplate = $idTemplate;
		}
		$this->loadFromArray($arrData);		
	}

	/**
	 * Enter description here ...
	 * @param unknown_type $arrData
	 */
	private function loadFromArray($arrData){
		if (isset($arrData['name'])){
			$this->chrName = $arrData['name'];
		}
		if (isset($arrData['uid'])){
			$this->chrUserID = $arrData['uid'];
		}
		if (isset($arrData['erelation'])){
			$this->chrCountryCode = $arrData['erelation'];
		}
		if (isset($arrData['title'])){
			$this->chrTitle = $arrData['title'];
		}
		
	}

	/**
	 * Enter description here ...
	 * @return string
	 */
	public function getTemplateName(){
		return $this->chrName;
	}

	/**
	 * Enter description here ...
	 * @return string
	 */
	public function getTemplateAbbr(){
		return $this->chrUserID;
	}

	/**
	 * Enter description here ...
	 * @return boolean
	 */
	public function getTemplateCountryCode(){
		return $this->chrCountryCode;
	}

	/**
	 * Enter description here ...
	 * @return boolean
	 */
	public function getTemplateTitle(){
		return $this->chrTitle;
	}
	/**
	 * Enter description here ...
	 * @return number
	 */
	public function getID(){
		return $this->idTemplate;
	}

	/**
	 * 
	 * Synchronizes all userdata from LDAP. external users doesn't update departments, $visible sets the visible flag in AMdb
	 * @param boolean $external indicates whether the user should be handled as an external user or not
	 * @param boolean $visible tells whether the user is visible or not
	 */

	
}

/**
 * Enter description here ...
 * @param int $idUser integer that holds the primary-key-field iduser in AM database 
 * @return User
 */
function getTemplate($idTemplate){
	$q = "SELECT iduser,name,uid,erelation,title FROM dbatn_userslist WHERE iduser = $1";
	$rs = mazDb_query_params($q, array($idTemplate));
	if (mazDb_num_rows($rs) > 0){
		$template = mazDb_fetch_array($rs);
		return new Template($template['iduser'], $template);
	}
	return NULL;
}

function updateTemplate($idTemplate, $arrTemplateData){
	$q = "UPDATE dbatn_userslist SET 
		name = $1, 
		uid = $2,
		erelation = $3 
		WHERE iduser = $4";
	$rs = mazDb_query_params($q, array(safeDatabase($arrTemplateData['name']), $arrTemplateData['uid'], $arrTemplateData['erelation'], $idTemplate));
	if (mazDb_num_rows($rs) > 0){
		$template = mazDb_fetch_array($rs);
		return new Template($template['iduser'], $template);
	}
	return NULL;
}

/**
 * Enter description here ...
 * @param string $chrUserID the users userID, often a string consisting of 7 characters.
 * @return User
 */
function getTemplateByAbbr($chrTemplateID){ 
	$q = "SELECT iduser,name,uid,erelation,title FROM dbatn_userslist WHERE uid = $1";
	$rs = mazDb_query_params($q, array($chrTemplateID));
	if (mazDb_num_rows($rs) > 0){
		$template = mazDb_fetch_array($rs);
		return new Template($template['iduser'], $template);
	}
	return NULL;
}

/**
 * Enter description here ...
 * @param unknown_type $chrUserID
 * @return User
 */

function deleteTemplate($idTemplate){
	$q = "DELETE FROM dbatn_userslist WHERE userid = $1";
	$rs = mazDb_query_params($q, array($idTemplate));
}

function getTemplateDays( $idUserLogin, $intYear ){ # ETORHUN
	if (!is_numeric($idUserLogin)|| $idUserLogin < 1){
		return array();
	}
	$chrQuery = "SELECT ud.* 
	FROM dbatn_userslist ul1 
		JOIN dbatn_department_holidaytemplate dh ON ul1.department = dh.chrdepartment 
		JOIN dbatn_userslist ul2 ON dh.iduser = ul2.iduser 
		JOIN dbatn_userdays ud ON dh.iduser = ud.\"idUser\"
		WHERE ul1.iduser = $1 AND ud.\"intYear\" = $2";  	
	$rs = mazDb_query_params($chrQuery, array($idUserLogin, $intYear));
	$arrUserDays = array();
	if (mazDb_num_rows($rs))
	{
		while($arr = mazDb_fetch_array($rs)){
			#display($arr);
			#$arrUserDays = $arr;
			$arrUserDays[$arr["intMonth"]][$arr["intDay"]] = array("chrCharacter"=>$arr["chrCharacter"], "chrComments"=>safeHTML($arr["chrComments"]),"chrComments2"=>safeHTML($arr["chrComments2"]),"blnApproved"=>$arr["blnapproved"]);
		}
	}
	return $arrUserDays;
}

function getArrTemplates(){ #ETORHUN
	$arrTemplates = array();
	$q = "SELECT name, erelation, iduser, title, dn FROM dbatn_userslist WHERE title = 'Template' ORDER BY name";
	$rs = mazDb_query_params($q, array());
	while($arr = mazDb_fetch_array($rs)){
			$arrTemplates[] = $arr;
	}
	return $arrTemplates;
}

function getTemplateNameFromId($id){ # what happens when no template is present? ..fails when recently updated... check out later!
	$q = "SELECT name FROM dbatn_userslist WHERE iduser = $1";
	$rs = mazDb_query_params($q, array($id));
	if (mazDb_num_rows($rs) > 0){
		while($arr = mazDb_fetch_array($rs)){
			$name = $arr['name'];
		}
	}
	return $name;
}
function getTemplateDaysFromId( $idTemplate, $intYear ){ # ETORHUN
	if (!is_numeric($idTemplate)|| $idTemplate < 1){
		return array();
	}
	$chrQuery = "SELECT * FROM dbatn_userdays WHERE \"idUser\" = $1 AND \"intYear\" = $2";  	
	$rs = mazDb_query_params($chrQuery, array($idTemplate, $intYear));
	$arrTemplateDays = array();
	if (mazDb_num_rows($rs))
	{
		while($arr = mazDb_fetch_array($rs)){
			#display($arr);
			#$arrUserDays = $arr;
			$arrTemplateDays[$arr["intMonth"]][$arr["intDay"]] = array("chrCharacter"=>$arr["chrCharacter"], "chrComments"=>$arr["chrComments"],"chrComments2"=>$arr["chrComments2"],"blnApproved"=>$arr["blnapproved"]);
		}
	}
	return $arrTemplateDays;
}


/**
 * 
 * R
 * @param int $idSelectedUser the iduser-integer that represents the user for which we want to get the days
 * @param int $intYear the year for which to collect days
 * @return $arrMerged array of days, merged from both user's individual days and days from template
 */

function getUserAndTemplateDays($idSelectedUser, $intYear){
	$arrUserDays = array();
	$arrMerged = array();
	$arrUserDays = getUserDays($idSelectedUser, $intYear);
	$arrTemplateDays = getTemplateDays($idSelectedUser, $intYear);
	for ($month = 1; $month <= 12; $month++) {
		$arrMonth = array();
		for ($day = 1; $day <= 31; $day++) { #this setup shows template-reddays over userdefined reddays. Futurewise, no overlapping should be necessary (exchange #1 and #2 to change)
			if (isset($arrUserDays[$month][$day])){
				$arrMonth[$day] = $arrUserDays[$month][$day];#1
			}
			if (isset($arrTemplateDays[$month][$day])) {
				$arrMonth[$day] = $arrTemplateDays[$month][$day];#2
			}
		}
		$arrMerged[$month] = $arrMonth;
	}
return $arrMerged;	
	
}



?>
