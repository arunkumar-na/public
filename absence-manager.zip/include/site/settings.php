<?php
error_reporting(E_ALL & ~E_NOTICE);
# all kind of variables etc can come here

define("VERSION", "1.0.8");

define("DEVELOPER",1); # on Production must be zero

define("RELATION_TYPE_E","Ericsson");
define("RELATION_TYPE_N","Non-Ericsson");

define("CALENDAR_HEIGHT", "100%");
define("UTF8_CHARSET",false);
define("UTF8_CONFLICT",true); #on real working server it should be true;

define("LINK_ESS","https://sso.ericsson.se/EricssonLoginForm/?TYPE=33554433&REALMOID=06-876cee46-3948-454e-a722-7dcaae1123a3&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=-SM-86eTriYEoGCMk%2bxQYjwL64UwHAUGerumB2AdSyWzskRYQIlH%2bDkNQp6t72hw1%2f9v&TARGET=-SM-https%3a%2f%2fep6%2eal%2esw%2eericsson%2ese%2firj%2fportal");
define("LINK_PEOPLE_FINDER","http://internal.ericsson.com/wps/portal/yasper/pf");
define("PEOPLE_FINDER_FORMAT", "http://internal.ericsson.com/wps/portal/yasper/?action=search&srchCID=%s");
define("LINK_OUTLOOK","outlook:today");
# define("TUT_START","docs/absencemanager-overview.pdf");
define("TUT_START","docs/TUTORIAL.htm");

# LDAP Configuration
define("IMPORT_FROM_LDAP", true);
define("LDAP_UID_CAPS", true);



#ECD
define("LDAP_ADDRESS","ecd.ericsson.se");
define("LDAP_PORT","389");
define("LDAP_CONNECT_USERNAME","uid=EABSCTOOL,ou=users,ou=internal,o=ericsson");

define("LDAP_CONNECT_PASSWORD","IxaiYFWZixfHvF35");
define("LDAP_BASE_DN", "ou=Users,ou=Internal,o=ericsson");
define("LDAP_BASE_DN_PARTNER", "ou=partners,ou=external,o=ericsson");

#LDAP attributes
define("LDAP_DN","dn"); #Distinguished Name
define("LDAP_FIRST_NAME","givenname");
define("LDAP_LAST_NAME","sn");
define("LDAP_DEPARTMENTNUMBER","erioporgunitname");
define("LDAP_TELEPHONENUMBER","telephonenumber");
define("LDAP_EMAIL","mail");
define("LDAP_USER_ID","uid");
define("LDAP_JOB_TITLE","title");
define("LDAP_RELATION_FIELD","ericonnection");
define("LDAP_CITY","physicaldeliveryofficename"); #City coded with ISO-8859-1
define("LDAP_DISPLAY_NAME","eridisplayname"); #Full name coded with ISO-8859-1
define("LDAP_MANAGERSIGNUM","erioperationalmanager");
define("LDAP_ISLEGALMANAGER","eriisopmgr");
define("LDAP_UNITNAME","erioporgunitname");
define("LDAP_UNITABBREVIATION","erioporgunitabbreviation");
define("LDAP_UNITIDENTIFIER","erioporgunitidentifier");


# Attributes for external employees are different
define("LDAP_XDISPLAY_NAME","ericn");
define("LDAP_XDEPARTMENTNUMBER","ou");

# Some external partners (for example XJI) has their departmentNumber set to "N/A" and
# their org unit set to what departmentNumber should have been.
# Using this filter together with sprintf when searching the LDAP directory,
# we can get around this.
define("LDAP_DEPARTMENT_FILTER", '(| ('.LDAP_DEPARTMENTNUMBER.'=%1$s) (& ('.LDAP_DEPARTMENTNUMBER.'=N/A) ('.LDAP_XDEPARTMENTNUMBER.'=%1$s)))')
?>
