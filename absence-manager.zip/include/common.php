<?php
/**
	Few Error constants
**/

define("NOTICE_NOT_IN_SYSTEM",101);
define("NOTICE_NO_DEPARTMENT_MANAGER",102);

#date_default_timezone_set('Europe/Paris');

/*** ########################################################
*	Get Total number of days between the passed param range
*
* 	@param int $sm : Starting month
* 	@param int $sy : Starting Year
* 	@param int $em : Ending month
* 	@param int $ey : Ending Year
* 	@return int
*____________________________________________________________*/
function getTotalDays( $sm,$sy,$em,$ey){
	$intEndMonth = ($sy == $ey) ? $em : $em+12;
										$intDays = 0;
										for($i = $sm; $i <= $intEndMonth ; $i++)
										{
											$intSelectedMonth = $i;
											$intSelectedYear = $sy;

											if ($i > 12) {
												$intSelectedMonth = $i-12;
												$intSelectedYear = $ey;
											}


											$intDays += date("t",mktime(1,1,1,$intMonth,1,$intYear));
										}

return $intDays;
}

/*** ########################################################
*	Get All Members of Department
*
* 	@param String $chrDepartment : Starting month
* 	@return array
*____________________________________________________________*/
function getMemebersOfDepartment( $chrDepartment ){
	$chrQuery = "SELECT iduser FROM dbatn_userslist where department=$1";
	$rs = mazDb_query_params($chrQuery, array($chrDepartment));
	$arrUsers = array();
	if (mazDb_num_rows($rs)>0)
	{
		while($arr = mazDb_fetch_array($rs)){
			$arrUsers[] = $arr["iduser"];
		}
	}
	return $arrUsers;
}

/*** ########################################################
*	Get All Cities we have users in, in our localdatabase
*
* 	@return array
*____________________________________________________________*/
function get_cities_from_db(){
	$chrQuery = "SELECT city FROM dbatn_userslist";
	$rs = mazDb_query_params($chrQuery, array());
	$arrCities = array();
	if (mazDb_num_rows($rs)>0)
	{
		while($arr = mazDb_fetch_array($rs)){
			$arrCities[($arr[0])] = ($arr[0]);
		}
	}
	return $arrCities;
}

/*** ########################################################
*	Delete all links of a specific user
*
* 	@param int $iduser :
*____________________________________________________________*/
function deleteUserLinks($iduser){
	$chrQuery = "DELETE FROM dbatn_department_owner WHERE iduser=$1";
	mazDb_query_params($chrQuery, array($iduser));

	$chrQuery = "DELETE FROM dbatn_department_manager WHERE iduser=$1";
	mazDb_query_params($chrQuery, array($iduser));

	$chrQuery = "DELETE FROM dbatn_project_owner WHERE iduser=$1";
	mazDb_query_params($chrQuery, array($iduser));

	# delete user setting for view on department page (selected deprtments)
	$chrQuery = "DELETE FROM dbatn_department_settings1 WHERE iduser=$1";
	mazDb_query_params($chrQuery, array($iduser));

	# delete user setting for view on department page (selected columns)
	$chrQuery = "DELETE FROM dbatn_department_settings2 WHERE iduser=$1";
	mazDb_query_params($chrQuery, array($iduser));

	# delete user personal settings
	$chrQuery = "DELETE FROM dbatn_personal_settings WHERE iduser=$1";
	mazDb_query_params($chrQuery, array($iduser));

	# delete user setting for view on project page (selected projects)
	$chrQuery = "DELETE FROM dbatn_project_settings1 WHERE iduser=$1";
	mazDb_query_params($chrQuery, array($iduser));

	# delete user setting for view on project page (selected columns)
	$chrQuery = "DELETE FROM dbatn_project_settings2 WHERE iduser=$1";
	mazDb_query_params($chrQuery, array($iduser));

	# delete user marked days
	$chrQuery = "DELETE FROM dbatn_userdays WHERE \"idUser\"=$1"; #\"idUser\" changed to without escaped quotes
	mazDb_query_params($chrQuery, array($iduser));


}

/*** ########################################################
*	Delete all links of a users specified in bulk
*	@param String $chrUsersCommaSeprated : users ids provieded as comma seprated
* 	@param int $iduser :
*____________________________________________________________*/
function deleteUserLinksInBulk($chrUsersCommaSeprated){
	#delete links if user is owner of any department
	$chrQuery = "DELETE FROM dbatn_department_owner WHERE iduser IN ($chrUsersCommaSeprated)";
	mazDb_query_params($chrQuery, array());

	#delete links if user is manager of any department
	$chrQuery = "DELETE FROM dbatn_department_manager WHERE iduser IN ($chrUsersCommaSeprated)";
	mazDb_query_params($chrQuery, array());

	#delete links if user is owner of any project
	$chrQuery = "DELETE FROM dbatn_project_owner WHERE iduser IN ($chrUsersCommaSeprated)";
	mazDb_query_params($chrQuery, array());

	# delete user setting for view on department page (selected deprtments)
	$chrQuery = "DELETE FROM dbatn_department_settings1 WHERE iduser IN ($chrUsersCommaSeprated)";
	mazDb_query_params($chrQuery, array());

	# delete user setting for view on department page (selected columns)
	$chrQuery = "DELETE FROM dbatn_department_settings2 WHERE iduser IN ($chrUsersCommaSeprated)";
	mazDb_query_params($chrQuery, array());

	# delete user personal settings
	$chrQuery = "DELETE FROM dbatn_personal_settings WHERE iduser IN ($chrUsersCommaSeprated)";
	mazDb_query_params($chrQuery, array());

	# delete user setting for view on project page (selected projects)
	$chrQuery = "DELETE FROM dbatn_project_settings1 WHERE iduser IN ($chrUsersCommaSeprated)";
	mazDb_query_params($chrQuery, array());

	# delete user setting for view on project page (selected columns)
	$chrQuery = "DELETE FROM dbatn_project_settings2 WHERE iduser IN ($chrUsersCommaSeprated)";
	mazDb_query_params($chrQuery, array());

	# delete user marked days
	$chrQuery = "DELETE FROM dbatn_userdays WHERE \"idUser\" IN ($chrUsersCommaSeprated)";
	mazDb_query_params($chrQuery, array());
}
/*** ########################################################
*	Get iduser from uid
*
* 	@param String $uid
* 	@return int
*____________________________________________________________*/
function getIdUserFromUid($uid){
	$chrQuery = "SELECT iduser FROM dbatn_userslist WHERE uid=$1";
	$rs = mazDb_query_params($chrQuery, array($uid));
	$arrRecord = array();
	if (mazDb_num_rows($rs)>0)
	{
		$arr = mazDb_fetch_array($rs);
		return $arr["iduser"];
	}
	return -1;
}
/*** ########################################################
*	Get users Department
*
* 	@param String $uid : User id
* 	@return String
*____________________________________________________________*/
function getUserDepartment($idUser){
	$userDepartment = "";
	$chrQuery = "SELECT department FROM dbatn_userslist WHERE \"iduser\"=$1";
	$arrParams = array($idUser);
	$rs = mazDb_query_params($chrQuery, $arrParams);
	if (mazDb_num_rows($rs) > 0){
		$resultArray = pg_fetch_all($rs);
		$userDepartment = $resultArray[0]['department'];
	}
	return $userDepartment;
}
/*** ########################################################
*	Get All department in our local database
*
* 	@return Array
*____________________________________________________________*/

function get_departments_from_db(){
	$chrQuery = "SELECT department FROM dbatn_userslist where department is not null ORDER BY department";
	$rs = mazDb_query_params($chrQuery, array());
	$arrRecord = array();
	if (mazDb_num_rows($rs)>0)
	{
		while($arr = mazDb_fetch_array($rs)){
			if($arr[0] != ""){ #to exclude the null-string department that is created when a user doesn't belong to a department
				$arrRecord[$arr[0]] = $arr[0];
			}
		}
	}
	return $arrRecord;
}
/*** ########################################################
*	Get All holiday templates from DB

* 	@return array
*____________________________________________________________*/

function get_templates_from_db(){
	$chrQuery = "SELECT name FROM dbatn_userslist where name is not null AND dn='t' ORDER BY department";
	$rs = mazDb_query_params($chrQuery, array());
	$arrRecord = array();
	if (mazDb_num_rows($rs)>0)
	{
		while($arr = mazDb_fetch_array($rs)){
			$arrRecord[$arr[0]] = $arr[0];
		}
	}
	return $arrRecord;
}
/*** ########################################################
*	Get All groups
*	@param string $projchr
* 	@return array
*____________________________________________________________*/

function get_groups_from_db(){

	//for finding all the projects from db
	$chrQuery = "SELECT chrproject FROM dbatn_projects WHERE isGroup = true ORDER BY chrproject";
	$rs = mazDb_query_params($chrQuery, array());
	$arrRecord = array();
	if (mazDb_num_rows($rs)>0)
	{
		while($arr = mazDb_fetch_array($rs)){
			$arrRecord[$arr[0]] = $arr[0];
		}
	}
	return $arrRecord;
}
/*** ########################################################
*	Get All projects and sub projects of a particular project 
*	@param string $projchr
* 	@return array
*____________________________________________________________*/

function get_projects_from_db($projchr=-1){

	//for finding all the projects from db
	if($projchr==-1)
		$chrQuery = "SELECT chrproject FROM dbatn_projects ORDER BY chrproject";
	//for finding subprojects
	else
		$chrQuery = "SELECT dbatn_projects.chrproject as chrsubproj
					FROM dbatn_projects
					RIGHT JOIN (SELECT dbatn_projectlist.chrproject, dbatn_projectlist.idproject, dbatn_projectlist.iduser, dbatn_project_subprojects.idsubproject, dbatn_userslist.*
					FROM dbatn_projectlist
					LEFT JOIN dbatn_project_subprojects
					ON dbatn_projectlist.idproject=dbatn_project_subprojects.idproject
					AND dbatn_projectlist.iduser IN (SELECT dbatn_projectlist.iduser FROM dbatn_projectlist WHERE dbatn_project_subprojects.idsubproject=dbatn_projectlist.idproject)
					INNER JOIN dbatn_userslist
					ON dbatn_projectlist.iduser=dbatn_userslist.iduser) AS t
					ON dbatn_projects.idproject=t.idsubproject
					WHERE t.chrproject IN ($projchr)
					ORDER BY t.idproject DESC, t.idsubproject ASC";
	$rs = mazDb_query_params($chrQuery, array());
	$arrRecord = array();
	if (mazDb_num_rows($rs)>0)
	{
		while($arr = mazDb_fetch_array($rs)){
			$arrRecord[$arr[0]] = $arr[0];
		}
	}
	return $arrRecord;
}
/************************ PROJECT BASEd FUNCTIONS (*****************************/
/*** ########################################################
*	Get User settings that he has made on department page, e.g visible columns, selected departemnt for viewing
*
* 	@param int $idUser
* 	@return array
*____________________________________________________________*/

function getDepartmentSettings($idUser){
	$chrQuery = "SELECT department FROM dbatn_department_settings1 WHERE iduser=$1";
	$rs = mazDb_query_params($chrQuery, array($idUser));
	$arrDeptSettings = array();
	if (mazDb_num_rows($rs)){
		while($arr = mazDb_fetch_array($rs)){
			$arrDeptSettings[] = $arr["department"];
		}
	}
	/** Get column settings **/
	$chrQuery = "SELECT intcol FROM dbatn_department_settings2 WHERE iduser=$1";
	$rs = mazDb_query_params($chrQuery, array($idUser));
	$arrColSettings = array();
	if (mazDb_num_rows($rs)){
		while($arr = mazDb_fetch_array($rs)){
			$arrColSettings[] = $arr["intcol"];
		}
	}
	return array("dept"=>$arrDeptSettings,"col"=>$arrColSettings);
}
/*******************************************************************/
/*** ########################################################
*	Get User settings that he has made on Project page, e.g visible columns, selected projects for viewing
*
* 	@param String $uid
* 	@return int
*____________________________________________________________*/

function getProjectSettings($idUser){
	$chrQuery = "SELECT project FROM dbatn_project_settings1 WHERE iduser=$1";
	$rs = mazDb_query_params($chrQuery, array($idUser));
	$arrDeptSettings = array();
	if (mazDb_num_rows($rs)){
		while($arr = mazDb_fetch_array($rs)){
			$arrDeptSettings[] = $arr["project"];
		}
	}
	/** Get solumn settings **/

	$chrQuery = "SELECT intcol FROM dbatn_project_settings2 WHERE iduser=$1";
	$rs = mazDb_query_params($chrQuery, array($idUser));
	$arrColSettings = array();
	if (mazDb_num_rows($rs)){
		while($arr = mazDb_fetch_array($rs)){
			$arrColSettings[] = $arr["intcol"];
		}
	}
	return array("proj"=>$arrDeptSettings,"col"=>$arrColSettings);
}
/*****************************************************************************/
/*** ########################################################
*	Get Project id from project name
*
* 	@param String $chrProject
* 	@return int
*____________________________________________________________*/

function getIdProject($chrProject){
	$chrQuery = "SELECT idproject FROM dbatn_projects where chrproject=$1";
	$rs = mazDb_query_params($chrQuery, array($chrProject));
	if (mazDb_num_rows($rs) > 0){
		$arr = mazDb_fetch_array($rs);
		return $arr['idproject'];
	}
	return -1;
}
/*******************************************************************************/
/*** ########################################################
*	Get All projects (whos user can) can view this project
*
* 	@param int $idProject
* 	@return Array
*____________________________________________________________*/

function getAllowedProjectsForProject($idProject){
	$flag = false;
	$chrQuery = "SELECT chrprojectallowed FROM dbatn_project_project where idproject=$1";
	$rs = mazDb_query_params($chrQuery, array($idProject));
	$arrResults = array();
	if (mazDb_num_rows($rs) > 0){		
		while($arr = mazDb_fetch_array($rs))
		{
			if($arr['chrprojectallowed'] == "AllProjectsCanView"){		//TD That means this project is visible to all projects so no need to continue like this
				$flag = true;
				break;
			}
			$arrResults[$arr['chrprojectallowed']] = $arr['chrprojectallowed'];
		}
	}
	if($flag) {			//TD If visible to all other projects then get the list of all projects from project database
		unset($arrResults);
		$arrResults = array();
		$arrResults = get_projects_from_db();
	}
	return $arrResults;
}
/***************************************************************************************/
/*** ########################################################
*	Get All departments (whos users) can view this project
*
* 	@param int $idProject
* 	@return Array
*____________________________________________________________*/

function getAllowedDepartmentsForProject($idProject){
	$flag = false;
	$chrQuery = "SELECT chrdepartmentallwoed FROM dbatn_project_department where idproject=$1";
	$rs = mazDb_query_params($chrQuery, array($idProject));
	$arrResults = array();
	if (mazDb_num_rows($rs) > 0){
		while($arr = mazDb_fetch_array($rs)) {
			if($arr['chrdepartmentallwoed'] == "AllDepartmentsCanView"){		//TD That means this project is visible to all departments so no need to continue like this
				$flag = true;
				break;
			}
			$arrResults[$arr['chrdepartmentallwoed']] = $arr['chrdepartmentallwoed'];
		}
	}
	if($flag) {			//TD If visible to all departments then get the list of all departments from department database
		unset($arrResults);
		$arrResults = array();
		$arrResults = get_departments_from_db();		
	}
	return $arrResults;
}
/*******************************************************************************/
/*** ########################################################
*	Get All projects that can view this department
*
* 	@param String $chrDepartment
* 	@return array
*____________________________________________________________*/

function getAllowedProjectsForDepartment($chrDepartment){

	$chrQuery = "SELECT chrprojectallowed FROM dbatn_department_project where chrdepartment=$1";
	$rs = mazDb_query_params($chrQuery, array($chrDepartment));
	$arrResults = array();
	if (mazDb_num_rows($rs) > 0){
		while($arr = mazDb_fetch_array($rs))
		{
			$arrResults[$arr['chrprojectallowed']] = $arr['chrprojectallowed'];
		}
	}
	return $arrResults;
}
/***************************************************************************************/
/*** ########################################################
*	Get All departments that can view this department
*
* 	@param String $chrDepartment
* 	@return array
*____________________________________________________________*/

function getAllowedDepartmentsForDepartment($chrDepartment){

	$chrQuery = "SELECT chrdepartmentallwoed FROM dbatn_department_department where chrdepartment=$1";
	$rs = mazDb_query_params($chrQuery, array($chrDepartment));
	$arrResults = array();
	if (mazDb_num_rows($rs) > 0){
		while($arr = mazDb_fetch_array($rs))
		{
			$arrResults[$arr['chrdepartmentallwoed']] = $arr['chrdepartmentallwoed'];
		}
	}
	return $arrResults;
}
/***************************************************************************************/
/*** ########################################################
*	will get those project where i am added as a member
*
* 	@param int $iduser
* 	@return Array
*____________________________________________________________*/

/* will get those project where i am added as a member */
function getMyProjects($iduser) {

	$chrQuery = "SELECT idproject,chrproject FROM dbatn_projectlist WHERE iduser=$1";
	$rs = mazDb_query_params($chrQuery, array($iduser));
	$arrResult = array();
	if (mazDb_num_rows($rs) > 0) {
		while($arr = mazDb_fetch_array($rs)){
			$arrResult[$arr["idproject"]]= $arr["chrproject"];
		}
	}
	return $arrResult;
}
/***************************************************************************************/
/*** ########################################################
*	get all Projects that are Visible To This Department
*
* 	@param String $chrDepartment
* 	@return array
*____________________________________________________________*/

function getProjectsVisibleToThisDepartment( $chrDepartment ){

	$chrQuery = "SELECT idproject FROM dbatn_project_department WHERE chrdepartmentallwoed=$1";
	$rs = mazDb_query_params($chrQuery, array($chrDepartment));
	$arrResult = array();
	if (mazDb_num_rows($rs) > 0) {
		while($arr = mazDb_fetch_array($rs)){
			$arrResult[$arr["idproject"]]= $arr["idproject"];
		}
	}
	
	//TD Adding those projects which are visible to all departments
	$chrQuery = "SELECT idproject FROM dbatn_project_department WHERE chrdepartmentallwoed='AllDepartmentsCanView'";
	$rs = mazDb_query_params($chrQuery, array());
	if (mazDb_num_rows($rs) > 0) {
		while($arr = mazDb_fetch_array($rs)){
			$arrResult[]= $arr["idproject"];
		}
	}
	
	return $arrResult;
}
/****************************************************************************************/
/*** ########################################################
*	get alll Projects in whom's owener field i am added as an owner
*
* 	@param int $iduser
* 	@return Array
*____________________________________________________________*/

function getProjectWhosOwnerIam( $iduser){

	$chrQuery = "SELECT idproject FROM dbatn_project_owner WHERE iduser=$1";
	$rs = mazDb_query_params($chrQuery, array($iduser));
	$arrResult = array();
	if (mazDb_num_rows($rs) > 0) {
		while($arr = mazDb_fetch_array($rs)){
			$arrResult[$arr["idproject"]]= $arr["idproject"];
		}
	}
	return $arrResult;
}
/*** ########################################################
*	Get All type of rights i have on project
*	will get the list of all projects that i can only view / manage / or own

* 	@param String $uid
* 	@return Array
*____________________________________________________________*/
function getProjectRights($uid){
	$iduser = 0;
	$chrMyDepartment = "";
	$chrQuery = "SELECT department,iduser FROM dbatn_userslist WHERE uid=$1";
	$rs = mazDb_query_params($chrQuery, array($uid));
	$arrRights = array();
	if (mazDb_num_rows($rs) > 0) {
		$arr = mazDb_fetch_array($rs);
		$iduser = $arr["iduser"];
		$chrMyDepartment = $arr["department"];

		$arrProjectOwnerShip = getProjectWhosOwnerIam($iduser);

		$arrMemberOf = getMyProjects($iduser);

		$arrAllwoedProjectsByProjects = getProjectsAllowingTheseProjects($arrMemberOf);

		$arrRights["view"] = array_unique(array_merge(getProjectsVisibleToThisDepartment($chrMyDepartment),$arrProjectOwnerShip,$arrAllwoedProjectsByProjects));
		$arrRights["owner"] = $arrProjectOwnerShip;
	}
	else {
		#nothing user not in system
		$arrRights["view"] = array();
		$arrRights["owner"] = array();
	}
	return $arrRights;
}
/*** ########################################################
*	get all those Departments that are Visible To This Department
*
* 	@param String $chrDepartment
* 	@return Array
*____________________________________________________________*/
function getDepartmentsVisibleToThisDepartment($chrDepartment) {
	$chrQuery = "SELECT chrdepartment FROM dbatn_department_department WHERE chrdepartmentallwoed=$1";
	$rs = mazDb_query_params($chrQuery, array($chrDepartment));
	$arrResult = array();
	if (mazDb_num_rows($rs) > 0) {
		while($arr = mazDb_fetch_array($rs)){
			$arrResult[]= $arr["chrdepartment"];
		}
	}
	return $arrResult;
}

/*** ########################################################
*	get all those Departments Whos Owner is passed iduser
*
* 	@param int $iduser
* 	@return Array
*____________________________________________________________*/
function getDepartmentsWhosOwnerIam($iduser){

	$chrQuery = "SELECT chrdepartment FROM dbatn_department_owner WHERE iduser=$1";
	$rs = mazDb_query_params($chrQuery, array($iduser));
	$arrResult = array();
	if (mazDb_num_rows($rs) > 0) {
		while($arr = mazDb_fetch_array($rs)){
			$arrResult[]= $arr["chrdepartment"];
		}
	}
	return $arrResult;
}
/*** ########################################################
*	get all those Departments Whos Manager is passed iduser
*
* 	@param String $uid
* 	@return int
*____________________________________________________________*/
function getDepartmentsWhosManagerIam($iduser){

	$chrQuery = "SELECT chrdepartment FROM dbatn_department_manager WHERE iduser=$1";
	$rs = mazDb_query_params($chrQuery, array($iduser));
	$arrResult = array();
	if (mazDb_num_rows($rs) > 0) {
		while($arr = mazDb_fetch_array($rs)){
			$arrResult[]= $arr["chrdepartment"];
		}
	}
	return $arrResult;
}
/*** ########################################################
*	get all Projects that are Allowed by passed list  of Projects
*
* 	@param Array $arrProjects
* 	@return Array
*____________________________________________________________*/
function getProjectsAllowingTheseProjects( $arrProjects = array()){
	if (!is_array($arrProjects) || sizeof($arrProjects) < 1) {
		return array();
	}

	$chrProjects = "'".implode("','",$arrProjects)."'";

	$chrQuery = "SELECT idproject FROM dbatn_project_project WHERE chrprojectallowed IN ($chrProjects)";
	$rs = mazDb_query_params($chrQuery, array());
	$arrResult = array();
	if (mazDb_num_rows($rs) > 0) {
		while($arr = mazDb_fetch_array($rs)){
			$arrResult[]= $arr["idproject"];
		}
	}
	//TD Adding those projects which are visible to all other projects
	$chrQuery = "SELECT idproject FROM dbatn_project_project WHERE chrprojectallowed='AllProjectsCanView'";
	$rs = mazDb_query_params($chrQuery, array());
	if (mazDb_num_rows($rs) > 0) {
		while($arr = mazDb_fetch_array($rs)){
			$arrResult[]= $arr["idproject"];
		}
	}
	
	return $arrResult;

}
/*** ########################################################
*	Get all Departments that allow list of passed Projects
*
* 	@param Array $arrProjects
* 	@return Array
*____________________________________________________________*/
function getDepartmentAllowingTheseProjects( $arrProjects = array()){
	if (!is_array($arrProjects) || sizeof($arrProjects) < 1) {
		return array();
	}

	$chrProjects = "'".implode("','",$arrProjects)."'";

	$chrQuery = "SELECT chrdepartment FROM dbatn_department_project WHERE chrprojectallowed IN ($chrProjects)";
	$rs = mazDb_query_params($chrQuery, array());
	$arrResult = array();
	if (mazDb_num_rows($rs) > 0) {
		while($arr = mazDb_fetch_array($rs)){
			$arrResult[]= $arr["chrdepartment"];
		}
	}
	
	return $arrResult;

}
/*** ########################################################
*	get All types of rights i have on different Departments
*	view / manage / own
*
* 	@param String $uid
* 	@return int
*____________________________________________________________*/
function getDepartmentRights($uid){
	$iduser = 0;
	$chrMyDepartment = "";
	$chrQuery = "SELECT department,iduser FROM dbatn_userslist WHERE uid=$1";
	$rs = mazDb_query_params($chrQuery, array($uid));
	$arrRights = array();
	if (mazDb_num_rows($rs) > 0) {
		$arr = mazDb_fetch_array($rs);
		$iduser = $arr["iduser"];
		$chrMyDepartment = $arr["department"];
		$arrOwnerOf   = getDepartmentsWhosOwnerIam($iduser);
		$arrManagerOf = getDepartmentsWhosManagerIam($iduser);
		$arrMyProjects = getMyProjects($iduser);
		$arrViewByProject = getDepartmentAllowingTheseProjects($arrMyProjects);
		$arrRights["view"] = array_unique(array_merge(array($chrMyDepartment), getDepartmentsVisibleToThisDepartment($chrMyDepartment),$arrViewByProject, $arrOwnerOf,$arrManagerOf));
		$arrRights["owner"] = $arrOwnerOf;
		$arrRights["manager"] = $arrManagerOf;
	}
	else {
		#nothing user not in system
		$arrRights["view"] = array();
		$arrRights["owner"] = array();
		$arrRights["manager"] = array();
	}
	return $arrRights;
}
/*** ########################################################
*	Import user from ldap into local database
*
* 	@param String $uid
* 	@return Array
*____________________________________________________________*/
function importUserIntoTheSystem( $uid ){
	$idUser = getIdUserFromUid($uid);
	if ($idUser == -1)
	{
		$arrInfo = import_from_ldap("(uid=$uid)", "getusers", true);

		if (sizeof($arrInfo) > 0 )
		{
			foreach($arrInfo as $chrProject=>$arrUsers)
			{

				$objRecord = $arrUsers[0];

				$dn 			= safeDatabase($objRecord["dn"]);
				$name 			= safeDatabase($objRecord["name"]);
				$dept 			= safeDatabase($objRecord["department"]);
				$city 			= safeDatabase($objRecord["city"]);
				$erelation		= safeDatabase($objRecord["relationship"]);
				$phone 			= safeDatabase($objRecord["phone"]);
				$title 			= safeDatabase($objRecord["title"]);
				$email 			= safeDatabase($objRecord["mail"]);
				$uid 			= safeDatabase($objRecord["uid"]);
				$mdept 			= safeDatabase($objRecord["mdept"]);
				$sdept 			= safeDatabase($objRecord["sdept"]);
				if (UTF8_CHARSET == true) {
					$name = utf8_encode($name);
					$city = utf8_encode($city);
				}
				 $chrQuery = "INSERT INTO dbatn_userslist(iduser,dn,name,department,city,erelation,phone,title,email,mdept,sdept,uid)
								values(nextval('seq_idlist_lists'),'$dn','$name','$dept','$city','$erelation','$phone','$title','$email','$mdept','$sdept','$uid') ";
				mazDb_query_params($chrQuery, array());
				$idUser = getIdUserFromUid($uid);
				break;
			}#end for loop
		}#endif array size
	}#endif useralready exsist
	return $idUser;
}
/*** ########################################################
*	Get All owners against each project
*
* 	@return Array
*____________________________________________________________*/
function getAllProjectsOwners(  ) {
	$chrQuery = "SELECT dbatn_userslist.name,dbatn_project_owner.idproject
	FROM dbatn_userslist LEFT JOIN dbatn_project_owner ON dbatn_userslist.iduser = dbatn_project_owner.iduser";
	$arrResult = array();
	$rs = mazDb_query_params($chrQuery, array());
	while($arr = mazDb_fetch_array($rs)){
		$arrResult[ $arr["idproject"] ][] = $arr["name"] ;
	}
	return $arrResult;
}
/*** ########################################################
*	Get owner for a project
*
* 	@return Array
*____________________________________________________________*/
function getAllProjectsOwnerString($id) {
	$chrQuery = "SELECT dbatn_userslist.name
	FROM dbatn_userslist
	INNER JOIN dbatn_project_owner
	ON
	dbatn_userslist.iduser = dbatn_project_owner.iduser
	WHERE dbatn_project_owner.idproject = $id";
	$arrResult = array();
	$rs = mazDb_query_params($chrQuery, array());
	$ownerString = "";
	while($arr = mazDb_fetch_array($rs)){
		$ownerString .= $arr["name"]."_";
	}
	$ownerString = substr_replace($ownerString ,"",-1);
	$ownerString = (preg_replace("/_/", ", ", $ownerString));
	return $ownerString;
}
/*** ########################################################
*	Get all owners against each department
*
* 	@param String $uid
* 	@return Array
*____________________________________________________________*/
function getAllDepartmentOwners(  ) {
	$chrQuery = " SELECT dbatn_userslist.name,dbatn_department_owner.chrdepartment
	FROM dbatn_userslist LEFT JOIN dbatn_department_owner ON dbatn_userslist.iduser = dbatn_department_owner.iduser";
	$arrResult = array();
	$rs = mazDb_query_params($chrQuery, array());
	while($arr = mazDb_fetch_array($rs)){
		$arrResult[ $arr["chrdepartment"] ][] = $arr["name"] ;
	}
	return $arrResult;
}
/*** ########################################################
*	Create the date rows above the user list in project calendar
*
* 	@param int $groupId
*	@param int $intFromMonth
*	@param int $intEndMonth
*	@param int $intYear
*	@param int $intYear2
*	@param int $nrIOfTabs
* 	@return String
*____________________________________________________________*/
function createDateRowsHtml($groupId, $intFromMonth, $intEndMonth, $intYear, $intYear2, $nrOfTabs = 0, $hierarchyClass = ""){
	global $objSession, $arrRights, $tabSize, $csvData;

	$html = "";															

	$blnWasProjectNotAllowed = false;

	$blnWeekNumbersNotDisplayed= false;
	$chrMonths = "";
	$chrWeeks = "";
	$chrDays = "";
	$csvMonth = "";
	$csvWeek = "";
	$csvDay = "";
	$tabbedInStyle = "margin-left:".($nrOfTabs*$tabSize+10)."px;";

	for($i = $intFromMonth; $i <= $intEndMonth ; $i++){
		$intSelectedMonth = $i;
		$intSelectedYear = $intYear;
		if ($i > 12) {
			$intSelectedMonth = $i-12;
			$intSelectedYear = $intYear2;
		}
		$arrHd = drawMonthHeader($intSelectedMonth, $intSelectedYear);
		$chrMonths .= $arrHd["month"];
		$chrWeeks .= $arrHd["weeks"];
		$chrDays .= $arrHd["days"];
		$csvMonth .= $arrHd["csv_month"];
		$csvWeek .= $arrHd["csv_week"];
		$csvDay .= $arrHd["csv_day"];
	}
	# display month names, weeks and days columns
	$csvData .= "Month,".$csvMonth."\n";
	$csvData .= "Week,".$csvWeek."\n";
	$csvData .= "Days,".$csvDay."\n";
	$html .= "<tr class='$hierarchyClass'> <td class='fixedTd'><div class='personname' style='".$tabbedInStyle."'></div></td><td class='firstTd'></td> $chrMonths </tr>";															
	$html .= "<tr class='$hierarchyClass'> <td class='fixedTd'><div class='personname' style='".$tabbedInStyle."'></div></td><td class='firstTd'></td> $chrWeeks </tr>";															
	$html .= "<tr class='$hierarchyClass'> <td class='fixedTd'><div class='personname' style='".$tabbedInStyle."'></div></td><td class='firstTd'></td> $chrDays </tr>";
	
	return $html;
}
/*** ########################################################
*	Returns header for a project or a group in the group calendar, with $nrOfTabs tabs
*
* 	@param String $name
*	@param String $idProject
*	@param String $isGroup
*	@param int $permissionToView
*	@param int $nrOfTabs
*	@param boolean $fixedHeader
*	@return String
*____________________________________________________________*/
function getProjectHeader($name, $parentProjects, $isGroup, $permissionToView, $fixedHeader, $nrOfTabs) {
	global $intColSpan, $tabSize;

	$html="";
	$idProject = end($parentProjects);
	$hierarchyClass = "";//Class name with all parent project id's. Separated with spaces
	for($i = 0 ; $i<sizeof($parentProjects)-1 ; $i++) {
		$hierarchyClass .= $parentProjects[$i]." ";
	}
	$ownerString = getAllProjectsOwnerString($idProject);	
	$background = "tableHeading1";
	$style = "margin-left:".($nrOfTabs*$tabSize)."px;";
	$permissionText = "";	
	$fixedHeaderClass=""; //Should header be fixed (horizontal scrolling)
	$chrCalLink=""; // Link to calendarView (if in listview)
	$hideHtmlArrow = '<span title="hide" id="minimize" class="'.$idProject.'"onClick="hideProject(\''.$idProject.'\')">&#9660;</span>';
	if($isGroup == "f") {
		$ownerString = "Project owner(s): ".$ownerString;
		$background = "tableHeading1";
	} else {
		$ownerString = "Group owner(s): ".$ownerString;
		$background = "tableHeading2";
		if($permissionToView != 1) {
			$permissionText = "<p class='critical'> You are not allowed to view this group</p>";
		}
	}
	if($fixedHeader) {
		$fixedHeaderClass = "class='fixedHeader'";
	} else {
		$chrCalLink = "<a href='view_project_calendar.php?chrAction=single&chrProject=$name'><img src=\"media/images/cal.jpg\" border=0 /></a>";
	}														
	
	$html.='
			<tr id="projHeader" bgcolor="#FFFFFF" class="'.$hierarchyClass.'">
				<td style="padding:5px" colspan="'.$intColSpan.'">
					<div style="'.$style.'"class="'.$background.'">
						<div '.$fixedHeaderClass.' style="'.$style.' padding-left:20px; padding-top:5px;">
							&nbsp;'.$hideHtmlArrow.'&nbsp;'.$chrCalLink.'&nbsp;'.$name."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$ownerString.'&nbsp;'.$permissionText.'
						</div>
					</div>
				</td>
			</tr>';
	return $html;
}
function drawMonthUserDaysTemplates($intMonth, $intYear, $arrUserDays=array(), $chrExtraParam = "", $blnAllowEditing=true)
{
$chrMonth			= date("M",mktime(1,1,1,$intMonth,1,$intYear));

	$intWeekNumber 		= date("W",mktime(1,1,1,$intMonth,1,$intYear));
	$intWeekNumber 		= intval($intWeekNumber);
	$intFirstWeekDay 	= date("N",mktime(1,1,1,$intMonth,1,$intYear));
	$intTotalDays 		= date("t",mktime(1,1,1,$intMonth,1,$intYear));
	$blnFirstPad = false;
	$csvData = "";

	#Patch for week no
	#Info: January Week 1 according to swedish rules is the week
	#with the first thursday in jan
	if(($intMonth == 1 && $intFirstWeekDay <= 4)){
		$intWeekNumber  = 1;
	}

  	for($intDay = 1; $intDay <= $intTotalDays; $intDay++)
	{
		
		$intWeekDay = date("N",mktime(1,1,1,$intMonth,$intDay,$intYear));
		#You are *required* to use the date.timezone setting or the date_default_timezone_set() function.
		
		$chrDayBoxClass = "daybox";
		if ($intWeekDay == 7 || $intWeekDay == 6)
		{
			#sat and sunday
			$chrDayBoxClass = "dayboxholiday";
		}

		$chrValue = "<img src='media/images/spacer.gif' width=20px >";
		$chrComments = "";
		$chrCharacter = "";

		$chrComments = "";
		$chrMouseEvents = "";
		if ($arrUserDays[$intDay]){

			$chrCharacter = $arrUserDays[$intDay]["chrCharacter"];
			$chrValue = $chrCharacter;
			$chrComments = $arrUserDays[$intDay]["chrComments"];
			$chrDayBoxClass = "noteadded";


			$chrComments = $arrUserDays[$intDay]["chrComments"];
			$chrComments2 = $arrUserDays[$intDay]["chrComments2"];
			if ( strlen(trim($chrComments2)) > 0){
				$chrComments .="Manager: ".$chrComments2;
			}
			if ($chrCharacter == "R"){
				$chrDayBoxClass = "redday";
			}
			if (trim($chrComments)){
				$chrDayBoxClass = "noteaddedi"; #if there are comments then show some respect
				if ($chrCharacter == "R"){
					$chrDayBoxClass = "reddayi";
				}
			}

			if ($arrUserDays[$intDay]["blnApproved"] == 1){
				$chrDayBoxClass = "approved";
			}

			$chrMouseEvents = "";
			if (trim($chrCharacter) == "" || empty($chrCharacter) || $chrCharacter == "R") {
				$chrMouseEvents = "";
			}
			else if ($blnAllowEditing == true) {
				$chrMouseEvents = "onClick='selectbox(this)'";
			}
			else {
				$chrComments = "";
				#$chrMouseEvents = "onMouseMove='showToolTip(this)'";
				$chrMouseEvents = "onClick='showToolTip(this)'";
			}

			$csvData .= $chrCharacter.",";
		}
		else {
			$csvData .=",";
		}
		$htmlDay .= "<td class='$chrDayBoxClass' class2='$chrDayBoxClass' $chrExtraParam title='$intDay\n$chrComments' chrComments='$chrComments2' chrCharacter='$chrCharacter' dayValue='$intDay' monthValue='$intMonth' yearValue='$intYear' $chrMouseEvents>$chrValue</td>";
		if ($intWeekDay == 7 || $intDay == $intTotalDays)
		{
				$intColSpan=$intWeekDay;
				if ($intFirstWeekDay != 1 && $intDay < 7) {
					$intColSpan = 8 - $intFirstWeekDay;
				}
				$intWeekNumber++;

				#Patch for week number
				#Info: January Week 1 according to swedish rules is the week
				#with the first thursday in jan
				if ($intMonth == 1 && $intWeekNumber > 50){
					$intWeekNumber  = 1;
				}
				if($intMonth == 12 && ($intTotalDays - $intDay) < 4){
					$intWeekNumber  = 1;
				}
		}
	}#end for
	$arrData = array("html"=>$htmlDay, "csv"=>$csvData);
	return $arrData ;
}#end func
/********************************************************/
/*** ########################################################
*	Get TDs(table cell) for specified month of the year.
*
* 	@param int $intMonth
* 	@param int $intYear
* 	@param Array $arrUserDays : user applied days, so that the can be mapped on the calendar days
* 	@param String $chrExtraParam : Making a special attribute for TD
* 	@param Boolean $blnAllowEditing : IF user is allowed to select days or not for changing there status
*____________________________________________________________*/
/********************************************************/
function drawMonthUserDays($idUser, $intMonth, $intYear, $arrUserDays=array(), $chrExtraParam = "", $blnAllowEditing=true)
{
	$chrMonth 			= date("M",mktime(1,1,1,$intMonth,1,$intYear));
	$intWeekNumber 		= date("W",mktime(1,1,1,$intMonth,1,$intYear));
	$intWeekNumber 		= intval($intWeekNumber);
	$intFirstWeekDay 	= date("N",mktime(1,1,1,$intMonth,1,$intYear));
	$intTotalDays 		= date("t",mktime(1,1,1,$intMonth,1,$intYear));
	$blnFirstPad = false;
	$csvData = "";
	$useridarray=explode("=",$chrExtraParam);
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();
		
	#Patch for week no
	#Info: January Week 1 according to swedish rules is the week
	#with the first thursday in jan
	if(($intMonth == 1 && $intFirstWeekDay <= 4)){
		$intWeekNumber  = 1;
	}

  	for($intDay = 1; $intDay <= $intTotalDays; $intDay++)
	{
		
		$intWeekDay = date("N",mktime(1,1,1,$intMonth,$intDay,$intYear));
		#You are *required* to use the date.timezone setting or the date_default_timezone_set() function.
		
		$chrDayBoxClass = "daybox";
		if ($intWeekDay == 7 || $intWeekDay == 6)
		{
			#sat and sunday
			$chrDayBoxClass = "dayboxholiday";
		}

		$chrValue = "<img src='media/images/spacer.gif' width=20px >";
		$chrComments = "";
		$chrCharacter = "";
		$name = $idUser.'_'.intval($intYear).'_'.intval($intMonth).'_'.intval($intDay); 
		$chrComments = "";
		if ($blnAllowEditing == true) {
			$chrComments .= "\nRight click for alternatives";				
		}
		$chrMouseEvents = "";
		if ($arrUserDays[$intDay]){

			$chrCharacter = $arrUserDays[$intDay]["chrCharacter"];
			$chrValue = $chrCharacter;
			$chrComments = $arrUserDays[$intDay]["chrComments"];
			$chrDayBoxClass = "noteadded";


			$chrComments = $arrUserDays[$intDay]["chrComments"];
			$chrComment = $arrUserDays[$intDay]["chrComments"];
			$chrComments2 = $arrUserDays[$intDay]["chrComments2"];
			if ( strlen(trim($chrComments2)) > 0){				
				if ($arrUserDays[$intDay]["blnApproved"] == 1){
					$chrComments .="\nManager Approved: ".$chrComments2;
				}
				else if ($chrCharacter == "D"){
					$chrComments .="\nManager Denied: ".$chrComments2;
				}
				else {
					$chrComments .="\nManager: ".$chrComments2;
				}
			}
			
			if ($chrCharacter == "R"){
				$chrDayBoxClass = "redday";
			}
						
			if (trim($chrComments)){
				$chrDayBoxClass = "noteaddedi"; #if there are comments then show some respect
				if ($chrCharacter == "R"){
					$chrDayBoxClass = "reddayi";
				}
			}
			
			if ($chrCharacter == "D"){
				$chrDayBoxClass = "daybox";
				$chrCharacter="";
				$chrValue="";
				$chrComments = "";
			}
			if ($arrUserDays[$intDay]["blnApproved"] == 1){
				$chrDayBoxClass = "approved";
			}

			$chrMouseEvents = "";
			if (trim($chrCharacter) == "" || empty($chrCharacter) || $chrCharacter == "R") {
				$chrMouseEvents = "";
			}
			else if ($blnAllowEditing == true) {
				$chrMouseEvents = "onClick='selectbox(this)'";				
			}
			else {
				$chrComments = "";
				#$chrMouseEvents = "onMouseMove='showToolTip(this)'";
				$chrMouseEvents = "onClick='showToolTip(this)'";
			}
			$excelData = "";
			if($chrDayBoxClass == "approved") {
				$excelData="A";
			}
			$csvData .= $chrCharacter.$excelData.",";
		}
		else {
			$csvData .=",";
			//To able to select days for manager in the calendar for the employees of his/her dept.
			if ($blnAllowEditing == true) {
				$chrMouseEvents = "onClick='selectbox(this)'";
			}
			
		}
		if($useridarray[1]==$objSession->getIdUser())
			$htmlDay .= "<td class='$chrDayBoxClass' class2='$chrDayBoxClass' $chrExtraParam title='$intDay\n$chrComments' chrComments='$chrComment' chrCharacter='$chrCharacter' dayValue='$intDay' monthValue='$intMonth' yearValue='$intYear' $chrMouseEvents name='$name'>$chrValue</td>";
		else
			$htmlDay .= "<td class='$chrDayBoxClass' class2='$chrDayBoxClass' $chrExtraParam title='$intDay\n$chrComments' chrComments='$chrComments2' chrCharacter='$chrCharacter' dayValue='$intDay' monthValue='$intMonth' yearValue='$intYear' $chrMouseEvents name='$name'>$chrValue</td>";
		if ($intWeekDay == 7 || $intDay == $intTotalDays)
		{
				$intColSpan=$intWeekDay;
				if ($intFirstWeekDay != 1 && $intDay < 7) {
					$intColSpan = 8 - $intFirstWeekDay;
				}
				$intWeekNumber++;

				#Patch for week number
				#Info: January Week 1 according to swedish rules is the week
				#with the first thursday in jan
				if ($intMonth == 1 && $intWeekNumber > 50){
					$intWeekNumber  = 1;
				}
				if($intMonth == 12 && ($intTotalDays - $intDay) < 4){
					$intWeekNumber  = 1;
				}
		}
	}#end for
	$arrData = array("html"=>$htmlDay, "csv"=>$csvData);
	return $arrData ;
}#end func
/*** ########################################################
*	Get TDs(table cell) for Month name bar, week bar, and days bar
*	no user info
* 	@param int $intMonth
* 	@param int $intYear
*____________________________________________________________*/
function drawMonthHeader($intMonth, $intYear)
{

	$chrMonth			= date("M",mktime(1,1,1,$intMonth,1,$intYear));
	$intWeekNumber 		= date("W",mktime(1,1,1,$intMonth,1,$intYear));
	$intWeekNumber 		= intval($intWeekNumber);
	$intFirstWeekDay 	= date("N",mktime(1,1,1,$intMonth,1,$intYear));
	$intTotalDays 		= date("t",mktime(1,1,1,$intMonth,1,$intYear));
	$htmlDay = "";
	$blnFirstPad = false;
	$csvWeek = "";
	$csvDay = "";
	$oldWeek = -1;

	#Patch for week no
	#Info: January Week 1 according to swedish rules is the week
	#with the first thursday in jan
	if(($intMonth == 1 && $intFirstWeekDay <= 4)){
		$intWeekNumber  = 1;
	}

  	for($intDay = 1; $intDay <= $intTotalDays; $intDay++)
	{
		$intWeekDay = date("N",mktime(1,1,1,$intMonth,$intDay,$intYear));
		$chrDayBoxClass = "daybox";
		$htmlDay .= "<td class='$chrDayBoxClass'>$intDay</td>";
		$csvDay .= $intDay.",";

		if ($oldWeek != $intWeekNumber){
			$csvWeek .= $intWeekNumber.",";
			$oldWeek = $intWeekNumber;
		}
		else {
			$csvWeek .= ",";
		}


		if ($intWeekDay == 7 || $intDay == $intTotalDays)
		{
				$intColSpan=$intWeekDay;
				if ($intFirstWeekDay != 1 && $intDay < 7) {
					$intColSpan = 8 - $intFirstWeekDay;
				}
				$htmlDay2 .="<td class=weeknumber colspan=$intColSpan>{$intWeekNumber}</td>";
				$intWeekNumber++;

				#Patch for week number
				#Info: January Week 1 according to swedish rules is the week
				#with the first thursday in jan
				if ($intMonth == 1 && $intWeekNumber > 50){
					$intWeekNumber  = 1;
				}
				if($intMonth == 12 && ($intTotalDays - $intDay) < 4){
					$intWeekNumber  = 1;
				}
		}
	}#end for

	$arrMonth["month"] = "<td colspan=$intTotalDays class=weeknumber>{$chrMonth}</td>";
	$arrMonth["weeks"] = $htmlDay2;
	$arrMonth["days"] = $htmlDay;
	# CSV Information
	$arrMonth["csv_month"] = $chrMonth.str_repeat(",",$intTotalDays);
	$arrMonth["csv_week"] = $csvWeek;
	$arrMonth["csv_day"] = $csvDay;
	return $arrMonth;
}#end func

/*** ########################################################
*	Get user's applied days holidays for specified year
*
* 	@param int $idUserLogin
* 	@param int $intYear
*	@return Array
*____________________________________________________________*/
function getUserDays( $idUserLogin, $intYear ){
	if (!is_numeric($idUserLogin)|| $idUserLogin < 1){
		return array();
	}
	$chrQuery = "select * FROM dbatn_userdays WHERE \"idUser\"=$1 AND \"intYear\"=$2"; #possible cause of error tisdag
	$rs = mazDb_query_params($chrQuery, array($idUserLogin, $intYear));
	$arrUserDays = array();
	if (mazDb_num_rows($rs))
	{
		while($arr = mazDb_fetch_array($rs)){
			$arrUserDays[$arr["intMonth"]][$arr["intDay"]] = array("chrCharacter"=>$arr["chrCharacter"], "chrComments"=>$arr["chrComments"],"chrComments2"=>$arr["chrComments2"],"blnApproved"=>$arr["blnapproved"]);
		}
	}
	return $arrUserDays;
}




/*** ########################################################
*	Get Manager of this user
* 	@param int $uid
*	@return Array
*____________________________________________________________*/
function getUserManager($uid, $userIsManager = false, $modifiedSelf=true){
	$chrQuery = "SELECT department, \"legalManager\" FROM dbatn_userslist WHERE uid=$1";
	$rs = mazDb_query_params($chrQuery, array($uid));
	$chrDepartment = "";
	$legalManagerUid = "";
	$arrManagers = array();

	if (mazDb_num_rows($rs) > 0)
	{
		while($arr = mazDb_fetch_array($rs)){
			$chrDepartment = $arr["department"];
			$legalManagerUid = $arr["legalManager"];
		}
	}
	if(!$userIsManager) {
		//Get department managers
		$chrQuery = "SELECT name,email FROM dbatn_department_manager,dbatn_userslist
			WHERE dbatn_department_manager.chrdepartment=$1
			AND dbatn_userslist.iduser=dbatn_department_manager.iduser";
		$rs = mazDb_query_params($chrQuery, array($chrDepartment)); #Possible cause of error tisdag
		
		if (mazDb_num_rows($rs) > 0)
		{
			while($arr = mazDb_fetch_array($rs)){
				$arrManagers[$arr["email"]] = $arr["name"];
			}
		}
	}
	if($modifiedSelf) {
		//Add legal manager email info
		$legalManager = getUserLegalManagerEmail($legalManagerUid);
		//Only send to legal manager if he has set so in his settings
		if($legalManager) {
			$arrManagers[$legalManager["email"]] = $legalManager["name"];
		}
	}

	return $arrManagers;
}

/*** ########################################################
*	Get Legal Manager of this user
* 	@param int $uid
*	@return Array
*____________________________________________________________*/
function getUserLegalManagerEmail($uid){	
	$legalManager = null;
	$legalManagerUid = $uid;
	if($legalManagerUid) {
		//Get legal manager
		$chrQuery = "SELECT name,email, blnlegalmanageremail FROM dbatn_userslist
					INNER JOIN dbatn_personal_settings
					ON
					dbatn_personal_settings.iduser = dbatn_userslist.iduser
					WHERE uid =$1";
		$rs = mazDb_query_params($chrQuery, array($legalManagerUid));
		if (mazDb_num_rows($rs) > 0)
		{
			while($arr = mazDb_fetch_array($rs)){
				if($arr['blnlegalmanageremail'] == 't') {
					$legalManager = array();
					$legalManager["name"] = $arr["name"];
					$legalManager["email"] = $arr["email"];					
				}
			}
		}
	}
	return $legalManager;
}
/***********************************/
function getEmailFromLoginId($arrLoginIds) {
	$chrQuery = "SELECT iduser,email,name from
				dbatn_userslist
				WHERE iduser IN (".implode(",",$arrLoginIds).")";

	$rs = mazDb_query_params($chrQuery, array());
	$arrEmails = array();
	if (mazDb_num_rows($rs) > 0)
	{
		while($arr = mazDb_fetch_array($rs)){
			$arrEmails[$arr["iduser"]]["email"] = $arr["email"];
			$arrEmails[$arr["iduser"]]["name"] = $arr["name"];
		}
	}
	return $arrEmails;
}
/*** ########################################################
*	Get Department Mail Settings . made by owner/manager
* 	@param String $chrDepartment
*	@return Array
*____________________________________________________________*/
function getDepartmentMailSettings($chrDepartment){
	$arrSettings = array();
	if ($chrDepartment)
	{
		$chrQuery = "SELECT intemailrequired,chrconfirmationmsg,chrreplymsg,intautoapprove FROM dbatn_department_email_settings where chrdepartment=$1";
		$rs = mazDb_query_params($chrQuery, array($chrDepartment));
		if (mazDb_num_rows($rs) > 0)
		{
			$arr = mazDb_fetch_array($rs);
			$arrSettings["blnEmailRequired"] = $arr["intemailrequired"];
			$arrSettings["chrConfirmationMsg"] = $arr["chrconfirmationmsg"];
			$arrSettings["chrReplayMsg"] = $arr["chrreplymsg"];
			$arrSettings["blnAutoApprove"] = $arr["intautoapprove"];
		}
	}
	return $arrSettings;
}
/*** ########################################################
*	Get Department Mail Settings . made by owner/manager
*		retrun in bulk, for multiple departments
* 	@param Array $arrDepartments
*	@return Array
*____________________________________________________________*/
function getDepartmentBulkMailSettings($arrDepartments){
	if (!is_array($arrDepartments) || sizeof($arrDepartments) < 1){
		return array();
	}

	$chrDepartments = "('".implode("', '",$arrDepartments)."')";


	$arrSettings = array();
	if ($chrDepartments)
	{
		$chrQuery = "SELECT chrdepartment,intemailrequired,chrconfirmationmsg,chrreplymsg,intautoapprove FROM dbatn_department_email_settings where chrdepartment IN $chrDepartments";
		$rs = mazDb_query_params($chrQuery, array());
		if (mazDb_num_rows($rs) > 0)
		{
			$arr = mazDb_fetch_array($rs);
			$arrSettings[$arr["chrdepartment"]]["blnEmailRequired"] = $arr["intemailrequired"];
			$arrSettings[$arr["chrdepartment"]]["chrConfirmationMsg"] = $arr["chrconfirmationmsg"];
			$arrSettings[$arr["chrdepartment"]]["chrReplayMsg"] = $arr["chrreplymsg"];
			$arrSettings[$arr["chrdepartment"]]["blnAutoApprove"] = $arr["intautoapprove"];
		}
	}
	return $arrSettings;
}
/*** ########################################################
*	Get Mail Settings of Department in which this user exists
* 	@param String $uid
*	@return Array
*____________________________________________________________*/
function getUserDepartmentMailSettings($uid){
	$chrQuery = "SELECT department FROM dbatn_userslist WHERE uid=$1";
	$rs = mazDb_query_params($chrQuery, array($uid));
	$chrDepartment = "";
	$arrSettings = array();
	if (mazDb_num_rows($rs) > 0)
	{
		while($arr = mazDb_fetch_array($rs)){
			$chrDepartment = $arr["department"];
		}
	}
	if ($chrDepartment){
		$arrSettings =  getDepartmentMailSettings($chrDepartment);
	}
	return $arrSettings;
}
/*** ########################################################
*	Get Mail Settings of Department in which this user exists
* 	@param String $uid
*	@return Array
*____________________________________________________________*/
function getUserOwnEmailSettings( $idUser ){

	$chrQuery = "SELECT blnconfirm,blnresponse FROM dbatn_personal_settings WHERE idUser = $1";
	$rs = mazDb_query_params($chrQuery, array($idUser));
	$arrSettings = array();
	if (mazDb_num_rows($rs) > 0)
	{
		$arr = mazDb_fetch_array($rs);
		$arrSettings["blnConfirmation"] = $arr["blnconfirm"];
		$arrSettings["blnResponse"] = $arr["blnresponse"];
	}
	return $arrSettings;
}
/*** ########################################################
*	Get Mail Settings of Department in which this user exists FOR MULTIPLE USERES
* 	@param Array $arrIdUsers
*	@return Array
*____________________________________________________________*/

function getUsersBulkEmailSettings( $arrIdUsers ){
if (!is_array($arrIdUsers) || sizeof($arrIdUsers) < 1){
	return false;
}
$chrUserIds = implode(",",$arrIdUsers);
	$chrQuery = "SELECT dbatn_personal_settings.iduser,blnconfirm,blnresponse,department
				 FROM dbatn_personal_settings, dbatn_userslist
				 WHERE dbatn_personal_settings.iduser IN ($chrUserIds)
				 AND dbatn_userslist.iduser = dbatn_personal_settings.iduser
				";
	$rs = mazDb_query_params($chrQuery, array());
	$arrSettings = array();
	if (mazDb_num_rows($rs) > 0)
	{
		while($arr = mazDb_fetch_array($rs)){
			$arrSettings[$arr["iduser"]]["blnConfirmation"] = $arr["blnconfirm"];
			$arrSettings[$arr["iduser"]]["blnResponse"] = $arr["blnresponse"];
			$arrSettings[$arr["iduser"]]["department"] = $arr["department"];
		}

	}
	return $arrSettings;
}
/*** ########################################################
*	Get User Personal Settings
* 	@param int $idUser
*	@return Array
*____________________________________________________________*/

function getPersonalSettings($idUser) {
	$arrReturn = array();
	$chrQuery = "SELECT *
				 FROM dbatn_personal_settings
				 WHERE iduser = $1";

	$rs = mazDb_query_params($chrQuery, array($idUser));
	if (mazDb_num_rows($rs) > 0)
	{
		$arr = mazDb_fetch_array($rs);
		$arrReturn['blnadvanceuser'] = $arr['blnadvanceuser'];
		$arrReturn['blnconfirm'] 	 = $arr['blnconfirm'];
		$arrReturn['blnresponse'] 	 = $arr['blnresponse'];
		$arrReturn['intstartpage'] 		= $arr['intstartpage'];
	}else {
		$arrReturn['blnadvanceuser'] = 0;
		$arrReturn['blnconfirm'] 	 = 1;
		$arrReturn['blnresponse'] 	 = 1;
		$arrReturn['intstartpage'] 	 = 1; #index.php page
	}
	return $arrReturn;
}
/*** ########################################################
*	Draw Full detailed month in matrix form ( used this function for my calendar page)
* 	@param int $intMonth
* 	@param int $intYear
* 	@param Array $arrUserDays : user applied holidays info
*____________________________________________________________*/
function drawMonth($intMonth, $intYear, $arrUserDays=array())
{
$chrMonth			= date("F",mktime(1,1,1,$intMonth,1,$intYear));
?>
<table border="0" cellspacing="3" cellpadding="3" class="monthtable">
  <tr>
    <td colspan="8" class="monthname"><?php echo $chrMonth ?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="weekday">Mon</td>
    <td class="weekday">Tue</td>
    <td class="weekday">Wed</td>
    <td class="weekday">Thr</td>
    <td class="weekday">Fri</td>
    <td class="weekholiday">Sat</td>
    <td class="weekholiday">Sun</td>
  </tr>
  <?php
    #The number for the first day of the month
	$intFirstWeekDay 	= date("N",mktime(1,1,1,$intMonth,1,$intYear));
	#Number of days in given month
	$intTotalDays 		= date("t",mktime(1,1,1,$intMonth,1,$intYear));

	$blnFirstPad = false;

  	for($intDay = 1; $intDay <= $intTotalDays; $intDay++)
	{
		$intWeekNumber 		= date("W",mktime(1,1,1,$intMonth,$intDay,$intYear)); #generates warning as below:
		$intWeekNumber 		= intval($intWeekNumber);

		$intWeekDay = date("N",mktime(1,1,1,$intMonth,$intDay,$intYear)); #generates warning		

		#Monday or first day of a month, display weeknumber
		if (($intWeekDay == 1) || ($intDay == 1)){
			$htmlDay .= "<tr>";
			$htmlDay .="<td class=weeknumber month='$intMonth' monthDay='$intDay' firstWeekDay='$intWeekDay' onClick='selectbox(this)'>$intWeekNumber</td>";
		}

		#If the month doesn't begin at a Monday add empty cells
		while ($blnFirstPad == false){
			for($i = 1; $i < $intFirstWeekDay; $i++){
				$htmlDay .= "<td>&nbsp;</td>";
			}
			$blnFirstPad = true;
		}

		$chrDayBoxClass = "daybox";

		#Saturday or sunday shall be marked with red color
		if ($intWeekDay == 7 || $intWeekDay == 6)
		{
			$chrDayBoxClass = "dayboxholiday";
		}

		$chrValue = $intDay;
		$chrComments = "";
		$chrCharacter = "";
		$chrComments = "";		
		if ($arrUserDays[$intDay]) {
			$chrValue = $intDay."<br><b>".$arrUserDays[$intDay]["chrCharacter"]."</b>";
			$chrComments = $arrUserDays[$intDay]["chrComments"];
			$chrDayBoxClass = "noteadded";
			$chrCharacter = $arrUserDays[$intDay]["chrCharacter"];
			$chrCommentsMine = $chrComments;
			if ($arrUserDays[$intDay]["chrComments2"]){
				if ($arrUserDays[$intDay]["blnApproved"] == 1){
					$chrComments.= "\nManager Approved: ".$arrUserDays[$intDay]["chrComments2"];
				}
				else if ($chrCharacter == "D"){
					$chrComments.= "\nManager Denied: ".$arrUserDays[$intDay]["chrComments2"];
				}			
				else {
					$chrComments.= "\nManager: ".$arrUserDays[$intDay]["chrComments2"];
				}
			}
			if ($chrCharacter == "R"){
				$chrDayBoxClass = "redday";
			}
			if (trim($chrComments)){
				$chrDayBoxClass = "noteaddedi"; #if there are comments then show some respect
				if ($chrCharacter == "R"){
					$chrDayBoxClass = "reddayi";
				}
			}
			
			if ($chrCharacter == "D"){
				$chrDayBoxClass = "daybox";
				$chrComments = "";
				$chrCharacter = "";
				$chrComments2 = "";
			}
			if ($arrUserDays[$intDay]["blnApproved"] == 1){
				$chrDayBoxClass = "approved";
			}
		}
		$intM = $intMonth;	/* begin month and day string with "0" if less than 10 */
		if ($intM < "10"){
			$intM = "0".$intM;
		}
		$intD = $intDay;
		if ($intD < "10"){
			$intD = "0".$intD;
		}

		//Add right click info
		$chrComments .= "\nRight click for alternatives";

		$id = $intM.$intD; 		/* This id will uniquely define a day in the calendar which makes it possible to address a day in the index.php file */
		$name = 'NOTNEEDED_'.$intYear.'_'.intval($intMonth).'_'.intval($intDay); 
		$htmlDay .= "<td id='$id' class='$chrDayBoxClass' class2='$chrDayBoxClass' title='$chrComments' chrComments='$chrCommentsMine' chrCharacter='$chrCharacter' dayValue='$intDay' monthValue='$intMonth' yearValue='$intYear' name='$name' onClick='selectbox(this)'>$chrValue</td>";

		#Sunday, time to end week row
		if ($intWeekDay == 7){
			$htmlDay .="</tr>";
		}
	}#end for

	echo $htmlDay;

  ?>
</table>
<?php

}#end func
/**
 * This function will get Array of all users id exisst in the system
 *
 * @return Array
 */
function getArrAllUserIds(  )
{
	$arrReturn = array();
	$chrQuery = "SELECT iduser FROM dbatn_userslist";
	$rs = mazDb_query_params($chrQuery, array());
	if (mazDb_num_rows($rs) > 0)
	{
			while($arr = mazDb_fetch_array($rs))
			{
				$arrReturn[] = $arr["iduser"];
			}
	}
	return $arrReturn;
}
/**
 * This function is basically get the query either it will be insert or update query
 * as in postgress there is no such query typr REPLACE INTO
 *
 * @param int $idUser
 * @param int $intDay
 * @param int $intMonth
 * @param int $intYear
 * @param int $chrCharacter
 * @param int $inttime
 * @param int $chrComments
 * @return String
 */
function getQueryForADayRecord( $idUser, $intDay, $intMonth, $intYear,$chrCharacter,$inttime,$chrComments )
{
		$chrQuery = "SELECT \"idUser\" FROM dbatn_userdays WHERE \"idUser\"=$1 AND \"intDay\"=$2  AND \"intYear\"=$3  AND \"intMonth\"=$4";
		$chrReturn = "";
		$arrQueryParams = array($idUser, $intDay, $intYear, $intMonth);  
		$rs = mazDb_query_params($chrQuery, $arrQueryParams);
		$chrComments = safeDatabase(safeHTML($chrComments)); 

		if (mazDb_num_rows($rs) > 0)
		{
			$chrTmp = $chrCharacter;
			if ($chrCharacter == 'B' || $chrCharacter == 'C')
			{
				$chrCharacter = "A";
			}
			$chrReturn = "UPDATE dbatn_userdays SET \"chrCharacter\"='$chrCharacter',\"chrComments\"='$chrComments' WHERE \"idUser\"=$idUser AND \"intDay\"=$intDay  AND \"intYear\"=$intYear  AND \"intMonth\"=$intMonth";
			$chrCharacter = $chrTmp;
		}
		else
		{
			$chrTmp = $chrCharacter;
			if ($chrCharacter == 'B' || $chrCharacter == 'C'){
				$chrCharacter = "A";
			}

			$chrReturn = "INSERT INTO dbatn_userdays(\"idUser\",\"intDay\",\"intMonth\",\"intYear\",\"chrCharacter\",\"chrComments\",inttime) values ($idUser,$intDay,$intMonth,$intYear,'$chrCharacter','$chrComments',$inttime)";
	  	}
		return $chrReturn;
}

/**
 * Redirects the user to the given address and exits the script
 * @param string $chrAddress adress to redirect to
 */
function redirect($chrAddress) {
	header('location: '.$chrAddress);
	exit();
}

/*
Recursive function to find subgroups to the node level of a group
@param integer $parent which must be a group id.
*/
function findsubtree($parent){
	$children = array();
	$subquery = "SELECT idsubproject FROM dbatn_project_subprojects WHERE idproject = $parent";
	$rs = mazDb_query_params($subquery, array());
	if (mazdb_num_rows($rs) > 0) {
		
		while($arr = mazDb_fetch_array($rs)) {
			$child = $arr['idsubproject'];
			$namequery = "SELECT chrproject FROM dbatn_projects WHERE idproject = $child";
			$rs2 = mazDb_query_params($namequery, array());
			$arr2 = mazDb_fetch_array($rs2);
			echo '<li class="tree">';
			echo '<div class="closed"><img src="media/images/buttonDown_On.png" /></div>';
			echo '<div class="open"><img src="media/images/buttonUp_On.png" /></div>';
			echo "<div class='name'>";
			echo '<a href="#" onclick="submitProjStructForm(\''.$arr2['chrproject'].'\')"><u>'.$arr2['chrproject'].'</u></font></a>';
			echo '</div>';
			echo "<div class='child_projects'>";
			echo '<ul>';
			findsubtree($child);
			echo '</ul>';
			echo "</div>";
			echo '</li>';
			
		}
		
	}
}
/*
* Gets the free access flag of a department
* This flag (if set to true) gives everyone permission to view that department
* @param string $chrDepartment name of the department
*/
function freeAccess($chrDepartment){
	$query = "SELECT freeaccess FROM dbatn_department_free_access WHERE chrDepartment = '$chrDepartment'";
	$rs = mazDb_query_params($query, array());
	if (mazdb_num_rows($rs) > 0) {
		
		while($arr = mazDb_fetch_array($rs)) {
			$freeaccess = $arr['freeaccess'];
		}
	}
	if($freeaccess == 't'){
		return true;
	}
	else {
		return false;
	}
}

function getParentProjects($id, $childProjects) {
	$childProjects[] = $id;
	$query = "SELECT * FROM dbatn_projects
			inner join dbatn_project_subprojects 
			on 
			dbatn_projects.idproject = dbatn_project_subprojects.idproject
			where dbatn_project_subprojects.idsubproject= $id;";
	$rs = mazDb_query_params($query, array());
	if (mazdb_num_rows($rs) > 0) {		
		while($arr = mazDb_fetch_array($rs)) {
			$parentProjects[] = $arr;
			if(!in_array($arr['idproject'], $childProjects)) {
				$parents = getParentProjects($arr['idproject'], $childProjects);
				$parentProjects = array_merge($parentProjects, $parents);
			}
		}
	} else {
		return array();
	}
	return $parentProjects;
}

function deleteProject($chrProject, $objSession) {
	$msg = "";

	$chrQuery = "SELECT idcreatedby,idproject FROM dbatn_projects WHERE chrproject=$1";
	$rs = mazDb_query_params($chrQuery, array(trim(safeDatabase($chrProject))));
	
	# if project exist
	if (mazDb_num_rows($rs) > 0 ){
		$arr = mazDb_fetch_array($rs);

		$arrRights = getProjectRights($objSession->getUid());
		# if logged in user is not admin user or dont have rights then show error
		if ($objSession->isAdminUser() == false && !in_array($arr["idproject"],$arrRights["owner"])){
			$msg = urlencode("Deletion failed, You are not owner of this group");
		} else {

			# OTHERES VISIBILITY ON THIS PROJECT
			# delete project visbility to other projects
			$chrQuery = "DELETE FROM dbatn_project_project WHERE idProject=$1";
			mazDb_query_params($chrQuery, array($arr["idproject"]));

			# delete project visbility to other departments
			$chrQuery = "DELETE FROM dbatn_project_department WHERE idproject=$1";
			mazDb_query_params($chrQuery, array($arr["idproject"]));
			# THIS PROJECT VISIBILTY ON OTHERS

			# delete link that tells where this project can view other departments
			$chrQuery = "DELETE FROM dbatn_department_project WHERE chrprojectallowed=$1";
			mazDb_query_params($chrQuery, array(trim(safeDatabase($chrProject))));


			# delete link that tells where this project can view on other project
			$chrQuery = "DELETE FROM dbatn_project_project WHERE chrprojectallowed=$1";
			mazDb_query_params($chrQuery, array(trim(safeDatabase($chrProject))));

			# RESPONSIBILITIES
			#delete links, that specifiy user as owner of this project
			$chrQuery = "DELETE FROM dbatn_project_owner WHERE idproject=$1";
			mazDb_query_params($chrQuery, array($arr["idproject"]));
			
			# SUBPROJECTS
			#delete the subprojects of the project and also where the group is a subproject of another group
			$chrQuery = "DELETE FROM dbatn_project_subprojects WHERE idproject=$1 OR idsubproject=$1";
			mazDb_query_params($chrQuery, array($arr["idproject"]));

			#PROEJCT ITSELF
			# delete members-ship link of the users to this project
			$chrQuery = "DELETE FROM dbatn_projectlist WHERE idProject=$1";
			mazDb_query_params($chrQuery, array($arr["idproject"]));

			# now delete the actual project
			$chrQuery = "DELETE FROM dbatn_projects WHERE idProject=$1";
			mazDb_query_params($chrQuery, array($arr["idproject"]));

			$msg = urlencode("Group deleted successfully");
		}
	}
	return $msg;
}

function getViewProjectsForm($self, $objSession, $type, $intYear, $intYear2, $intFromMonth, $intToMonth, $isDep = false, $onlyDisplayDatePicker = false, $uids = "") {

	$datePickerHTML = "";
	$viewCalendarButtonHTML = "";
	$heading;

	if($isDep) {
		$formName = "viewDeptsForm";
		$heading = "Departments/Sections";
	} else {
		$formName = "viewProjsForm";
		$heading = "Groups/Projects";
	}

	if($type=="calendar") {
		$datePickerClass = "datePicker";
		if($onlyDisplayDatePicker) {
			$datePickerClass="pickDate";
		}
		$datePickerHTML = '<div class="'.$datePickerClass.'">
								<div class="caption">From:</div>
								<div>'
									.monthsCombo("fromMonth", $intFromMonth)
									.yearsComboX("intYear",2000,date("Y",time())+10,$intYear)
								.'</div>
								<div class="caption">To:</div>
								<div>'
									.monthsCombo("toMonth", $intToMonth)
									.yearsComboX("intYear2",2000,date("Y",time())+10,$intYear2)
								.'</div>
							</div>';
	} else if ($type != "calendar" && !$isDep) {
		$viewCalendarButtonHTML = '<input type="button" value="View Calendar" onclick="show_calendar()" style="float:right" />';
	}
	if(!$onlyDisplayDatePicker){
		$projectFormHTML = '
		<form id="'.$formName.'" name="'.$formName.'" action="'.$self.'" method="post">
			<input type="button" value="Show/Hide Settings" name="settingsButton" onclick="toggleSettingsArea()" />
			'.$viewCalendarButtonHTML.'
			<div id ="settingsArea">								
				<h2>'.$heading.'</h2>
				<div class="chooseBox">
					<div class="left">
						<input type="hidden" name="chrAction" id="chrAction" value="view_new_list" />
						<input type="hidden" name="chrParam" id="chrParam" value="" />
						<label for="projFilter">Available Groups:</label>
						<input type="text" id="projFilter" autocomplete="off"/>
						<select id="projsAll" multiple="multiple" size="6">
							<option value="-1">Loading...</option>
						</select>
					</div>
					<div class="center">
						<input type="button" value="&gt;" onclick="javascript:addItems(\'projsAll\', \'projsSelected\');" /><br />
						<br />
						<input type="button" value="&lt;" onclick="javascript:removeItems(\'projsSelected\');"/><br />
						<input type="button" value="&lt;&lt;" onclick="javascript:removeAll(\'projsSelected\');"/><br />
					</div>
					<div class="right">
						<label for="projsSelected">Groups to view:</label><br />
						<select name="projsSelected[]" id="projsSelected" multiple="multiple" size="8">
							<option value="-1">Loading...</option>
						</select>
					</div>
					<div>
					'.$datePickerHTML.'
					</div>
					<!-- <br class="hard" /> -->
						<div class="right">
						<input type="button" value="Save as Default" onclick="saveNewList()" /> <br />
						<input type="hidden" name="chrProject" id="chrProject" value="" />
						<input type="hidden" name="chrDepartment" id="chrDepartment" value="" /> 
						<input type="hidden" name="orderBy" id="orderBy" value="name" />

							<br />
							<input type="button" class="viewSelectedBtn" value="View Selected Groups" onclick="viewNewList()" />
					</div>
					
				</div>
			</div>
		</form>';
	} else {
		$projectFormHTML .= '<form id="viewDeptsForm" name="viewDeptsForm" action="'.$self.'" method="post">
								<input type="hidden" name="chrAction" id="chrAction" value="user_search" />	
								<input type="hidden" name="chrParam" id="chrParam" value="" />						
								<div class="right">									
									'.$datePickerHTML.'
								</div>
								<input type="hidden" name="uids" id="uids" value="'.$uids.'" />
								<input style="height:80px" type="submit" class="viewSelectedBtn" value="Search"/>
							</form>';
	}
	return $projectFormHTML;
}

function createJSArray($arrSource){
	$arrItems = array();
	foreach ($arrSource as $key => $value) {
		if ($value) {
			$chrSafe = $value;  #removed safeHTML() from $value
			$arrItems[] = "'".$chrSafe."': '".$chrSafe."'";
		}
	}
	$result .= '{'.join(',', $arrItems).'}';
	return $result;
}

function saveUserDays($arrParam, $objSession, $arrDepartmentRights) {
	$arrQueries = array();
	$userIsManager = false;
	$daysModified = array();
	if($arrDepartmentRights["manager"]) {
		$managerArr = $arrDepartmentRights["manager"];
	} else {
		$managerArr = array();
	}
	foreach($arrParam as $eachRec){
		#if any record
		if ($eachRec){
			#split day information into array from a plain string
			$arrDay = explode("-_-",$eachRec);
			$intDay = $arrDay[0];
			$intMonth = $arrDay[1];
			$intYear = $arrDay[2];
			$chrCharacter = $arrDay[3];
			$chrComments = safeDatabase(safeHTML($arrDay[4]));
			$idUser = $arrDay[5];

			$user = new User($idUser, array());
			
			$chrColumn = "chrComments";

			# check if user has marked this day,
			# if found update it other wise insert this day information
			$chrQuery = "SELECT * FROM dbatn_userdays WHERE \"idUser\"=$1 AND \"intDay\"=$2 AND \"intYear\"=$3  AND \"intMonth\"=$4";
			$arrParams = array($idUser, $intDay, $intYear, $intMonth);
			$rs = mazDb_query_params($chrQuery, $arrParams);
			#if approval is selected
			$blnApproved = 0; #false

			//Check if the user is manager. If so, set the column to check the manager comments instead.
			$isUsersManager = false;
			if (in_array($user->getDepartment(), $managerArr) || $user->getLegalManager() == $objSession->getUid()){
				$chrColumn = "chrComments2";
				$isUsersManager = true;	//The logged in user is the absence seeking person's manager
				$userIsManager = true; //Used later to check if the user is a manager
			}
			if (mazDb_num_rows($rs) > 0){			
				
				$resultArray = pg_fetch_all($rs);
				#Check if the request is to be approved, or is already approved
				if ( ($chrCharacter == "A" && $isUsersManager) || (isset($resultArray[0][blnapproved]) && $resultArray[0][blnapproved] == 1)){
					$blnApproved = 1; #true							
				}
				# Make sure the value for approval is kept unchanged in case of edit comment
				if(isset($resultArray[0][blnapproved]) && $chrCharacter != "A" && $chrCharacter != "D") { 		//that means it is edit comment on a valid box
					$blnApproved = $resultArray[0][blnapproved];
				}

				# compare the current values to the values in the database, if things have changed then send update (else spams were sent to everyone)
				if($resultArray[0][chrCharacter]!= $chrCharacter || $resultArray[0][$chrColumn]!= $chrComments) {
					if($objSession->getIdUser() == $idUser || $isUsersManager) {				
						if( $chrCharacter == "D") {
							if($isUsersManager){
								$arrQueries[] = "DELETE FROM dbatn_userdays WHERE \"idUser\"=$idUser AND \"intDay\"=$intDay  AND \"intYear\"=$intYear  AND \"intMonth\"=$intMonth";
								$arrUserDaysApproved[$idUser] .= "[denied]".date("d M,Y",mktime(0,0,0,$intMonth,$intDay,$intYear))." ".$chrComments."<br>\n";
								$daysModified[$idUser][] = array("day" => $intDay, "month" => $intMonth, "year" => $intYear, "chrCharacter" => $chrCharacter, "chrComments" => $chrComments);
							}
						}					
						else {
							if($chrCharacter != "A" && $isUsersManager){
								$updatedCharacter="\"chrCharacter\"='$chrCharacter',";
							}
							$arrQueries[] = "UPDATE dbatn_userdays SET ".$updatedCharacter."blnapproved = $blnApproved,\"$chrColumn\"='$chrComments' WHERE \"idUser\"=$idUser AND \"intDay\"=$intDay  AND \"intYear\"=$intYear  AND \"intMonth\"=$intMonth";												
							$arrUserDaysApproved[$idUser] .= "[updated]".date("d M,Y",mktime(0,0,0,$intMonth,$intDay,$intYear))." ".$chrComments."<br>\n";
							$daysModified[$idUser][] = array("day" => $intDay, "month" => $intMonth, "year" => $intYear, "chrCharacter" => $chrCharacter, "chrComments" => $chrComments);
						}						
					}
				}
			}
			else {
				if ($isUsersManager){
					$blnApproved = 1; #true
				}
				if($chrCharacter == "V" || $chrCharacter == "H" || $chrCharacter == "B" || $chrCharacter == "C" || $chrCharacter == "P") {						
					$arrQueries[] = "INSERT INTO dbatn_userdays(\"idUser\",\"intDay\",\"intMonth\",\"intYear\",\"blnapproved\",\"$chrColumn\",\"chrCharacter\") values ($idUser,$intDay,$intMonth,$intYear,$blnApproved,'$chrComments','$chrCharacter')";
					$daysModified[$idUser][] = array("day" => $intDay, "month" => $intMonth, "year" => $intYear, "chrCharacter" => $chrCharacter, "chrComments" => $chrComments);
				}
				else if($chrCharacter == "A" || $chrCharacter == "D") {
				}
				else {					
					$arrQueries[] = "INSERT INTO dbatn_userdays(\"idUser\",\"intDay\",\"intMonth\",\"intYear\",\"blnapproved\",\"$chrColumn\") values ($idUser,$intDay,$intMonth,$intYear,$blnApproved,'$chrComments')";						
				}
				$arrUserDaysApproved[$idUser] .= "[added]".date("d M,Y",mktime(0,0,0,$intMonth,$intDay,$intYear))." ".$chrComments."<br>\n";
			}
		}#if there is record
	}#endforeach

	#execute the genrated quries
	foreach($arrQueries as $chrQuery){
		mazDb_query_params($chrQuery, array());
	}

	$returnVal = array();
	$returnVal['arrUserDaysApproved'] = $arrUserDaysApproved;
	$returnVal['daysModified'] = $daysModified;
	$returnVal['isManager'] = $userIsManager;
	return $returnVal;
}