<?php
	error_reporting(0);

	$chrPresentFileName = time().$ext;
	$arrMimeType = array(
		".gif"=>"image/gif",
		".jpg"=>"image/jpg",
		".jpeg"=>"image/jpeg",
		".bmp"=>"image/bmp",
		".txt"=>"text/plain",
		".pdf"=>"application/pdf",
		".zip"=>"application/zip",
		".doc"=>"application/doc",
		".docx"=>"application/docx"
	);

	header('Content-type: text/csv; charset=utf-8');
	$chrOrignalFileName = rand(9999,99999).".txt";

	// It will be called downloaded.pdf
	header('Content-Disposition: attachment; filename="'.$chrOrignalFileName.'"');
	$mixContent = preg_replace("[\n\r]", "", $_POST['csvData']); // remove empty lines so that excel macro works
	echo $mixContent; #throw on browser
?>
