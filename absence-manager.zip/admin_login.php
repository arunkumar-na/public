<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");

	/** Create session object and try to load user info (id name etc from session) **/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
		exit();
	}

	if ($_REQUEST["chrAction"] == "admin_login"){
		$uid = pg_escape_string(trim($_POST["uid"]));
		$pwd = pg_escape_string(trim($_POST["pwd"]));

		if ($uid && $pwd){
			# check admin username password validity
			$chrQuery = "SELECT 1 FROM dbatn_admin WHERE uid=$1 AND pwd=$2";
			$rs =  mazDb_query_params($chrQuery, array($uid, $pwd));
			if (mazDb_num_rows($rs) > 0 ){
				$objSession->setAdministratorUser(true);
				header("location: admin_reddays.php");
				exit();
			}
			else{
				$msg = "Invalid username or password.";
			}
		}
		else {
			$msg = "All fields are required.";
		}
	}
	header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("Admin Login"); ?></title>
		<?php echo generateScripts(); ?>
	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar"><span class="pageheading">Admin Login</span></div>
		                            					<form name="frm1" method="post" action="admin_login.php">
		                            						<input type="hidden" name="chrAction" id="chrAction" value="admin_login" />
		                            						<table cellspacing="0" width="100%" bgcolor="#FFFFFF" cellpadding="1">
		             
		                             							<tr>
		                               								<td class="caption">&nbsp;</td>
		                               								<td colspan="2" class="critical"><?php echo $msg ?></td>
		                              							</tr>
		                             							<tr>
		                               								<td class="caption">&nbsp;</td>
		                             								<td class="caption">Username:</td>
		                                							<td><input type="text" name="uid" id="uid" value="" /></td>
		                             							</tr>
		                                						<tr>
		                                  							<td class="caption">&nbsp;</td>
		                                  							<td class="caption">Password:</td>
		                                							<td><input type="password" name="pwd" id="pwd" value="" /></td>
		                             							</tr>
		                             							<tr>
		                               								<td width="24%">&nbsp;</td>
		                              								<td width="11%">&nbsp;</td>
		                              								<td width="65%"><input type="submit" value="Login" /></td>
		                              							</tr>
		                              							<tr>
		                                							<td></td>
		                              								<td><p>&nbsp;</p>
										                                <p>&nbsp;</p>
										                                <p>&nbsp;</p>
										                            </td>
		                              							</tr>
		                            						</table>
		                            					</form>
		               
			</div>
		</div>
		<?php echo generateFooter(); ?>
	</body>
</html>
