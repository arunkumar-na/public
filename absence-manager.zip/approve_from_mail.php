<?php
session_start();

include_once 'include/utilfunc.php';
include_once 'include/user.php';
	$int = 0;
	$chrDays = $_GET['days'];
	$session = $_GET['session'];
	$requestingUser = $_GET['requestingUser'];
	echo "Approved:<br />"; 
	foreach ($chrDays as $chrDay){
		print_r(utf8_decode($chrDay));
	}
#	echo "for<br />"; 
#	print_r($requestingUser);

?>
