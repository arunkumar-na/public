<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");

	/** Create session object and try to load user info (id name etc from session) **/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		if ($_REQUEST["ldaplogin"]==1){
			echo "Session has timed out";
			header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
			exit();
		}
		#header("location: ldap_do_login.php?loginid=".$_REQUEST["loginid"]."&requrl=".$_SERVER['REQUEST_URI']);
		#exit();
	}

	if (isset($_POST['bkmAction']) && $_POST['bkmAction'] == "add_bookmark"){
		$title = 'Add Bookmark';
	}
	else {
		$title = 'Manage Bookmarks';
	}

	header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle($title); ?></title>
		<?php echo generateScripts(); ?>
	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar">
					<img src="media/images/search.png" />&nbsp;
					<span class="pageheading"><?php echo safeHTML($title); ?></span>
				</div>
<table width="50%" border="0" cellspacing="0" cellpadding="0" height="100%">
  	<tr>
    	<td valign="top" bgcolor="#505050" height="100%" >
    		<table cellpadding="0" cellspacing="" width="100%">
        		<tr>
          			<td bgcolor="#505050">&nbsp;</td>
            		<td class="workareaBox" valign="top">
					<!-- ##################################	Working Area START ################################# -->
        				<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="1">
        					<!-- InstanceBeginEditable name="subheader section" -->
				  			<!-- InstanceEndEditable -->
      						<tr>
        						<td height="100%">				<!-- _____Contents START_____ -->
								<?php 
								if (isset($_POST['bkmAction']) && $_POST['bkmAction'] == "add_bookmark") {
								?>
            						<div id="workingDiv" style="width:100%;height:<?php echo CALENDAR_HEIGHT ?>">
                					<table bgcolor="#505050" width="100%" height="100%" >
                    					<tr>
                        					<td style="padding-top:5px;"><!-- InstanceBeginEditable name="working-area" -->
                            					<form name="frm1" method="post" action="manage_bookmarks.php">
													<p style="color:white; font-size:14px" >Bookmark name:&nbsp;&nbsp;&nbsp;&nbsp;
                            						<input type="hidden" name="bkmAction" id="bkmAction" value="bookmark_added" />													
													<input type="hidden" name="strUid" value="<?php echo $_REQUEST["strUid"] ?>" />
													<input type="hidden" name="strName" value="<?php echo $_REQUEST["strName"] ?>" />
													<input type="hidden" name="strEmail" value="<?php echo $_REQUEST["strEmail"] ?>" />
													<input type="hidden" name="strContact" value="<?php echo $_REQUEST["strContact"] ?>" />
													<input type="hidden" name="blnRelationE" value="<?php echo $_REQUEST["blnRelationE"] ?>" />
													<input type="hidden" name="blnRelationN" value="<?php echo $_REQUEST["blnRelationN"] ?>" />
													<input type="hidden" name="cityStatement" value="<?php echo $_REQUEST["cityStatement"] ?>" />
													<input type="hidden" name="deptStatement" value="<?php echo $_REQUEST["deptStatement"] ?>" />
													<input type="hidden" name="projStatement" value="<?php echo $_REQUEST["projStatement"] ?>" />
													<input type="hidden" name="query" value= "<?php echo $_POST['query'] ?>" />
													<input name="bmName" type="text" id="bmName" />
													<input type="submit" value="Add to Bookmarks" />
													</p>
												</form>
											</td>
										</tr>
									</table>
									</div>
								<?php } 
								else if(isset($_POST['rename']))	{
								?>
									<div id="workingDiv" style="width:100%;height:<?php echo CALENDAR_HEIGHT ?>">
                					<table bgcolor="#505050" width="100%" height="100%" >
                    					<tr>
                        					<td style="padding-top:5px;"><!-- InstanceBeginEditable name="working-area" -->
                            					<form name="frm1" method="post" action="manage_bookmarks.php">
													<p style="color:white; font-size:14px" >Bookmark name:&nbsp;&nbsp;&nbsp;&nbsp;
                            						<input type="hidden" name="bkmAction" id="bkmAction" value="bookmark_renamed" />													
													<input type="hidden" name="bookmarkid" value="<?php echo $_POST["selected_bm"] ?>" />													
													<input name="bmName" type="text" id="bmName" />
													<input type="submit" value=" Rename Bookmark" /></p>
												</form>
											</td>
										</tr>
									</table>
									</div>
								<?php
								}																
								else { ?>
									<div id="workingDiv" style="width:100%;height:<?php echo CALENDAR_HEIGHT ?>">
										<table bgcolor="#505050" width="100%" height="100%" >
											<tr>
												<td style="padding-top:5px;"><!-- InstanceBeginEditable name="working-area" -->
													<?php 
													if (isset($_POST['bkmAction']) && $_POST['bkmAction'] == "bookmark_added") {
															
															# get next available id from the sequence
															$idUser = $objSession->getIdUser();
															$savequery = pg_escape_string($_POST['query']);
															$bmname = safeDatabase($_POST['bmName']);
															$strUid = $_REQUEST['strUid'];															
															$strName = $_REQUEST['strName'];
															$strEmail = $_REQUEST['strEmail'];
															$strContact = $_REQUEST['strContact'];
															$blnRelationE = $_REQUEST['blnRelationE'];
															$blnRelationN = $_REQUEST['blnRelationN'];
															$cityStatement = $_REQUEST['cityStatement'];
															$deptStatement = $_REQUEST['deptStatement'];
															$projStatement = $_REQUEST['projStatement'];
															$addquery = "INSERT INTO dbatn_bookmarks(iduser,name,query,struid,strname,stremail,strcontact,blnrelatione,blnrelationn,citystatement,deptstatement,projstatement)values('$idUser', '$bmname', '{$savequery}', '$strUid', '$strName', '$strEmail', '$strContact', '$blnRelationE', '$blnRelationN', '$cityStatement', '$deptStatement', '$projStatement')";															
															mazDb_query_params($addquery,array());
															echo "Bookmark Added.";
															//echo $_POST['query'];
													}
													
													if (isset($_POST['delete'])) {									
															$iduser = $objSession->getIdUser();
															$bookmarkid = $_POST['selected_bm'];
															$renamequery = "DELETE FROM dbatn_bookmarks WHERE idbookmark= '$bookmarkid' AND iduser='$iduser'";
															mazDb_query_params($renamequery,array());
															echo "Bookmark Deleted.";
														}
														
													if (isset($_POST['bkmAction']) && $_POST['bkmAction'] == "bookmark_renamed") {									
															$iduser = $objSession->getIdUser();
															$bmname = safeDatabase($_POST['bmName']);
															$bookmarkid = $_POST['bookmarkid'];
															$renamequery = "UPDATE dbatn_bookmarks SET name= '$bmname' WHERE idbookmark= '$bookmarkid' AND iduser='$iduser'";
															mazDb_query_params($renamequery,array());
															echo "Bookmark Renamed.";
														}
														
													
													?>
													<form name="frm2" method="post" action="manage_bookmarks.php">
														<table cellspacing="0" cellpadding="2" width="98%">
															<tr>
																
																<td class="gridHead"> Name </td>
															</tr>
															<?php
																$iduser = $objSession->getIdUser();
																$bkmquery="SELECT * FROM dbatn_bookmarks WHERE iduser = '$iduser'";
																//echo $bkmquery;
																$bkmrs = mazDb_query_params($bkmquery, array());
																if (mazdb_num_rows($bkmrs) > 0)
																{
																	while($arr = mazDb_fetch_array($bkmrs))
																	{	
																		
																		$name = $arr['name'];
																		$id = $arr['idbookmark'];
																		echo "<tr><td class='gridData1'><input type='radio' name='selected_bm' value='$id'>$name</td></tr>";
																	}
																	
																	
																	//echo '<input type="hidden" name="bkmAction" id="bkmAction" value="rename_bookmark" />';
																	echo "<tr><td><input name='rename' type='submit' value='Rename'>";
																	
																	//echo '<input type="hidden" name="bkmAction" id="bkmAction" value="bookmark_deleted" />';
																	echo "<input name='delete' type='submit' value='Delete'></td></tr>";																																		
																}
																else
																{
																	echo '<td>Currently no bookmarks have been added.</td>';
																}
															?>
														</table>
													</form> 
												</td>
											</tr>
										</table>
									</div>
								<?php
								}	
								?>		
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>	
			</div>
		</div>
		<?php echo generateFooter(); ?>
	</body>
</html>