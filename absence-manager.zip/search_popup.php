<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");

	/** Create session object and try to load user info (id name etc from session)**/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		redirect("ldap_do_login.php");
	}

	$arrValidModes = array('users', 'departments');
	$chrMode = 'users';
	$blnMultiple = true;

	if (isset($_POST['chrAction']) && ($_POST['chrAction'] == 'search')){
		$chrMode = $_POST['mode'];
		$blnMultiple = (bool)intval($_POST['multiple']);
	}
	else {
		if (isset($_GET['mode']) && (in_array($_GET['mode'], $arrValidModes))){
			$chrMode = $_GET['mode'];
		}

		if (isset($_GET['multiple'])){
			$blnMultiple = (bool)intval($_GET['multiple']);
		}
	}

	header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("Search Active Directory"); ?></title>
		<?php echo generateScripts(); ?>
		<script type="text/javascript">
			// This function is called when the user has selected the items he/she wants.
			var doneCallback = window.opener.searchDoneCallback;

			function selectUsers(obj, deptCounter){
				var blnChecked = $('.dept'+deptCounter+'Check').is(':checked');
				$('.dept'+deptCounter).each(function (index){
					if (blnChecked){
						$(this).attr('checked', 'checked');
					}
					else {
						$(this).removeAttr('checked');
					}
				});
			}

			function insertSelected() {
				
				var arrSelected = [];
				$('.itemCheck:checked').each(function (i, element){
					arrSelected.push($.parseJSON($(element).val()));
				});
				doneCallback(window, arrSelected);
				window.close();
			}
		</script>
	</head>
	<body>
	<?php
	/*** Get search paramater */
	$arrCities = array();
	if ($_POST["sCity_count"] && $_POST["sCity_count"] > 0){
		for ($j = 0; $j < $_POST["sCity_count"]; $j++){
			if ($_POST["sCity$j"]){
				$chrCity = ($_POST["sCity$j"]);
				$arrCities[($chrCity)] = $chrCity;
			}
		}
	}
	$arrDept = array();
	if ($chrMode == 'users'){
		if ($_POST["sDept_count"] && $_POST["sDept_count"] > 0){
			for ($j = 0; $j < $_POST["sDept_count"]; $j++){
				if ($_POST["sDept$j"]){
					$arrDept[$_POST["sDept$j"]] = $_POST["sDept$j"];
				}
			}
		}
	} else {
		if ($_POST["sDept"]){
			$arrExploded = explode(';', $_POST["sDept"]);
			foreach ($arrExploded as $chrDept){
				if ($chrDept && strlen($chrDept) > 0){
					$arrDept[$chrDept] = $chrDept;
				}
			}
		}
	}
	
	$arrProjects = array();
	if ($_POST["sProj_count"] && $_POST["sProj_count"] > 0){
		for ($j = 0; $j < $_POST["sProj_count"]; $j++){
			if ($_POST["sProj$j"]){
				$chrProj = ($_POST["sProj$j"]);
				$arrProjects[($chrProj)] = $chrProj;
			}
		}
	}

	?>
	<div id="contentBody">
		<h2>Search <?php echo (($chrMode == 'users')?'User':'Department'); ?></h2>
	    <form action="search_popup.php" method="post">
	    	<div>
		       	<input type="hidden" name="chrAction" id="chrAction" value="search" />
		       	<input type="hidden" name="multiple" id="multiple" value="<?php echo ($blnMultiple ? '1':'0'); ?>" />
		       	<input type="hidden" name="mode" id="mode" value="<?php echo $chrMode; ?>" />
		       	<?php if ($chrMode=='users'){ ?>
				<table width="100%" border="0" cellspacing="3" cellpadding="3">
		        	<tr>
		            	<td class="caption">Search by uid:</td>
		                <td><input type="text" name="sUid" id="sUid" value="<?php echo $_POST["sUid"] ?>" /><span class="critical">Enter multiple values as ; separated</span></td>
		            </tr>
		            <tr>
		            	<td class="caption">Search by name:</td>
		                <td><input type="text" name="sName" id="sName" value="<?php echo $_POST["sName"] ?>" /><span class="critical">Enter multiple values as ; separated</span></td>
		            </tr>
		            <tr>
		            	<td class="caption">Search by dep/sec:</td>
		            	<td class="caption">Search by city:</td>
					</tr>
		            <tr>
		                <td><?php	# Search by dep/sec:
							# get all department from the database, as we have to show departmet
							# select box control
		                    $arrDeptX = get_departments_from_db();
							ksort($arrDeptX);
							mazSelectControlSearch("sDept",$arrDeptX,$arrDept, true, true);
							?>
						</td>
		                <td><?php	# Search by city:
							# get list of cities from the database
							$arrCitiesX = get_cities_from_db();
							ksort($arrCitiesX);
							mazSelectControlSearch("sCity",$arrCitiesX,$arrCities, true, true);
							?>
						</td>
					</tr>
		            <tr>
		            	<td colspan="2" class="caption"><br><br><br><input type="submit" name="btnSearch" id="btnSearch" value="Search" /></td>
					</tr>
			    </table>
				<?php } else { ?>
				<table width="100%" border="0" cellspacing="3" cellpadding="3">
		        	<tr>
		            	<td class="caption">Search by department name:</td>
		                <td><input type="text" name="sDept" id="sDept" value="<?php echo $_POST["sDept"] ?>" /></td>
		            </tr>
		            <tr>
		            	<td class="caption">Search by city:</td>
		                <td><?php	# Search by city:
							# get list of cities from the database
							$arrCitiesX = get_cities_from_db();
							ksort($arrCitiesX);
							mazSelectControl("sCity",$arrCitiesX,$arrCities, true, true);
							?>
						</td>
					</tr>
		            <tr>
		            	<td colspan="2" class="caption"><input type="submit" name="btnSearch" id="btnSearch" value="Search" /></td>
					</tr>
			    </table>
				<?php } ?>
		    </div>
	    </form>
		<?php
		if (isset($_POST['chrAction']) && ($_POST['chrAction'] == 'search')) {
			$arrMatch = array();
		?>
		<br />
		<h2>Search Results</h2>
		<table width="100%">
	        <tr valign= "top">				 
	        	<?php
				//Show search sorted by Department
	            	/*** Check if required search filters are provided */
					if ($_POST["sName"] || $_POST["sUid"] || sizeof($arrCities) > 0 || sizeof($arrDept) > 0){
				echo "<td class='text'> <h3>Sorted by Departments </h3><br>";
						foreach($arrCities as $key=>$value){
							$arrCities[$key] = ($value); # utf8 enconding was applied
						}
						#separate the names if multiple user name are provided
						if ($_POST["sName"]){
							$arrNames = explode(";",$_POST["sName"]);
							foreach($arrNames as $idx=>$chrName) {
								if ($chrName){
									$arrNames[$idx] = mb_strtolower((trim($chrName)));
								}
							}
						}
						#separate uids if multiple are searched
						if ($_POST["sUid"]){
							$arrUid   = explode(";",$_POST["sUid"]);
							foreach($arrUid as $idx=>$chrUid) {
								if ($chrUid){
									$arrUid[strtolower(trim($chrUid))] = strtolower(trim($chrUid));
								}
							}
						}
						#Create filter for ldap search for name
						$arrFilters = array();
						if (sizeof($arrNames) > 0) {
							$chrNameFormat = '(| ('.LDAP_DISPLAY_NAME.'=%1$s) ('.LDAP_XDISPLAY_NAME.'=%1$s))';
							if (sizeof($arrNames) > 1) {
								$chrSearchFilter = "(|";
								foreach ($arrNames as $chrName) {
									$chrSearchFilter .= sprintf($chrNameFormat, "$chrName");
								}
								$chrSearchFilter .= ")";
							}
							else {
								$chrSearchFilter = sprintf($chrNameFormat, $arrNames[0]);
							}
							$arrFilters[] = $chrSearchFilter;
              
						}
						if (sizeof($arrUid) > 0) {
							#Create search filter, for uids
							$chrSearchFilter = "(|(".LDAP_USER_ID."=".implode(")(".LDAP_USER_ID."=",$arrUid)."))";
							$arrFilters[] = $chrSearchFilter;
						}
						if (sizeof($arrDept) > 0){
							#Create search filter, for department name
							$chrSearchFilter = "(|";
							foreach ($arrDept as $chrDept){
								$chrSearchFilter .= sprintf(LDAP_DEPARTMENT_FILTER, "$chrDept*");
							}
							$chrSearchFilter .= ")";
							$arrFilters[] = $chrSearchFilter;
						}
						if (sizeof($arrCities) > 0){
							#Create search filter, for city
							$chrSearchFilter = "(|(".LDAP_CITY."=".implode(")(".LDAP_CITY."=",$arrCities)."))";
							$arrFilters[] = $chrSearchFilter;
						}
						$chrSearchFilter = '(& '.implode(' ', $arrFilters).')';
						$chrSearchFilter = trim($chrSearchFilter);
						$_SESSION['searchfilter'] = $chrSearchFilter;#etorhun, bara f�r kontroll
						#retrive users on the specified search filter for ldap
						$chrAction = ($chrMode == 'users') ? 'getusers' : 'getsections';
						$arrRec = import_from_ldap($chrSearchFilter,$chrAction,true);

						# loop on found records
						if ($chrMode == 'users'){
							foreach ($arrRec as $chrDepartment=>$arrUsers){
								foreach ($arrUsers as $ctx => $arrUser){
									$arrMatch[$chrDepartment][] = $arrUser;
								}
							}
						}
						else{
							$arrMatch = array_keys($arrRec);
						}

						ksort($arrMatch);
						if (sizeof($arrMatch) > 0){
							#$_SESSION['foundUsers']=$arrUsers; etorhun
							?><input type="button" value="Insert Selected" onclick="javascript:insertSelected()" /><br /><?php
						}

						$inputType = 'type="radio" name="selectedItem" id="selectedItem"';
						if ($blnMultiple){
							$inputType = 'type="checkbox" checked="checked"';
						}
						$blnFirst = true;
						if ($chrMode == 'users'){
							$intDeptCounter = 0;
							foreach($arrMatch as $chrDpartment=>$arrUsers){
								if ($blnMultiple){
									echo '<input type="checkbox" class="dept'.$intDeptCounter.'Check" checked="checked" onclick="selectUsers(this,'.$intDeptCounter.')" />';
								}
								echo '<b>'.$chrDpartment.'</b><br />';
								foreach($arrUsers as $idx => $arrRecord){

									$chrRecord = safeHTML(json_encode($arrRecord));
									$chrNameUtf8 = safeHTML($arrRecord["name"]);
									$uid = safeHTML($arrRecord['uid']);
									# Make sure the first item is checked
									$extra = $inputType;
									if ($blnMultiple == false && $blnFirst){
										$extra .= ' checked="checked"';
										$blnFirst = false;
									}
									echo '&nbsp;&nbsp;<input '.$extra.' class="itemCheck dept'.$intDeptCounter.'" value="'.$chrRecord.'" />'.$chrNameUtf8.' <span style="color:red;">('.($uid).')</span><br />';
								}#foreach user
								echo "<hr />";
								$intDeptCounter++;
							}#end foreachdept
						}
						else{
							foreach ($arrMatch as $chrDepartment){
								$chrSafe = safeHTML($chrDepartment);
								$chrJSON = safeHTML(json_encode(array('department' => $chrDepartment)));
								# Make sure the first item is checked
								$extra = $inputType;
								if ($blnMultiple == false && $blnFirst){
									$extra .= ' checked="checked"';
									$blnFirst = false;
								}
								echo '<input class="itemCheck" '.$extra.' value="'.$chrJSON.'" />'.$chrSafe.'<br />';
							}#end foreachdept
						}
					echo "</td>";
					}
									
					//Show search by Groups
					// Groups are to be searched in Absence Manager database and not LDAP so strings have to be manipulated in a different way 					
					if(sizeof($arrProjects) > 0)
					{					
					echo "<td class='text'><h3>Sorted by Groups</h3> <br>";
						$arrSearchPart = array();
					#search for uid
						if ($_POST["sUid"]){
							$arrTmp = explode(";",trim($_POST["sUid"],";"));
							$intCount = 0;
							#if single is searched then use wild card
							if (sizeof($arrTmp)  == 1 && trim($arrTmp[0])){
								$arrSearchPart[$intCount]["uid"] = "upper(uid) like '%".strtoupper(trim($arrTmp[0]))."%'";
							}
							else if (sizeof($arrTmp) > 0)
							{
								foreach($arrTmp as  $chrValue){
									if (trim($chrValue))
									{
										$arrSearchPart[$intCount]["uid"] = "upper(uid)='".strtoupper(trim($chrValue))."'";
										$intCount++;
									}
								}
							}
						}
					
					#search for name
						if ($_POST["sName"]){
							$arrTmp = explode(";",trim($_POST["sName"],";"));
							$intCount = 0;
							if (sizeof($arrTmp)  == 1 && trim($arrTmp[0])){
								$arrSearchPart[$intCount]["name"] = " upper(name) like upper('%".trim($arrTmp[0])."%')";

							}
							else
							{
								foreach($arrTmp as  $chrValue)
								{
									if (trim($chrValue))
									{
										if (trim($chrValue))
										{
											//$arrSearchPart[$intCount]["name"] = "upper(name)='".mb_strtoupper(trim($chrValue))."'";
											$arrSearchPart[$intCount]["name"] = "upper(name) = upper('".trim($chrValue)."')";
											$intCount++;
										}
									}
								}
							}
						}
						
					#-- Part1
						if (sizeof($arrSearchPart) > 0)
						{
							$arrWhere[] = "(".implode(" OR ",$arrSearchPart).")";
						}
					

					//print_r($arrCities);
					//print_r($arrDept);
					//print_r($arrProjects);
					#search for city
						# City
						
						if (sizeof($arrCities) > 0){
							#-- Part2
							$cityStatement = implode(", ",$arrCities);												
							$arrWhere[] = "city IN ('". implode("', '",$arrCities)."')";
						}
					
					#search for department
						# Department
						if (sizeof($arrDept) > 0){
							#-- Part3
							$deptStatement = implode(", ",$arrDept);
							$arrWhere[] = "department IN ('".implode("', '",$arrDept)."')";
						}
							
					#search for project
						# Project
						if (sizeof($arrProjects) > 0){
							#-- Part4
							$projStatement = implode(", ",$arrProjects);
							$arrWhere[] = "chrproject IN ('".implode("', '",$arrProjects)."')";
							$blnProjectUsed = true;
						}


						if (is_array($arrWhere)) {
							$chrWherePart = implode(" AND ",$arrWhere);
						}
						else {
							$chrWherePart = "uid=null";
						}
						
						#if project is used as search filter then, include required tables in the query
						if ($blnProjectUsed == true)
						{
							$chrQuery = "SELECT name,uid,chrproject,idproject FROM dbatn_userslist,dbatn_projectlist
							WHERE $chrWherePart
							AND dbatn_userslist.iduser = dbatn_projectlist.iduser
							ORDER BY chrproject";							
						}
						
						//echo "<br>".$chrQuery."<br>";
						$rs = mazDb_query_params($chrQuery, array());
						if (mazdb_num_rows($rs) > 0)
						{
							$arr = array();
							$intx = 0;
							while($arrtmp = mazDb_fetch_array($rs))							
							{
								$arr[$intx]['name'] = $arrtmp['name'];
								$arr[$intx]['chrproject'] = $arrtmp['chrproject'];
								$arr[$intx]['uid'] = $arrtmp['uid'];
								$arr[$intx]['parent_idproject'] = $arrtmp['idproject'];
								//print_r($arrtmp).'<br>';
								//echo $arr["chrproject"].' '.$arr["name"].' ('.$arr["uid"].")<br>";
								$intx++;
							}							
						
							
							# loop on found records						
							foreach ($arr as $idx=>$arrUser){
									$chrProject = $arrUser['chrproject'];
									$arrGroup[$chrProject][] = $arrUser;								
							}
							//print_r($arrGroup);
							
							
							if (sizeof($arrGroup) > 0){
								#$_SESSION['foundUsers']=$arrUsers; etorhun
								?><input type="button" value="Insert Selected" onclick="javascript:insertSelected()" /><br /><?php
							}

							$inputType = 'type="radio" name="selectedItem" id="selectedItem"';
							if ($blnMultiple){
								$inputType = 'type="checkbox" checked="checked"';
							}
							$blnFirst = true;
							
							$intProjCounter = 0;
							foreach($arrGroup as $chrProject=>$arrUsers){
								if ($blnMultiple){
									echo '<input type="checkbox" class="dept'.$intProjCounter.'Check" checked="checked" onclick="selectUsers(this,'.$intProjCounter.')" />';
								}
								echo '<b>'.$chrProject.'</b><br />';
								foreach($arrUsers as $idx => $arrRecord){

									$chrRecord = safeHTML(json_encode($arrRecord));
									$chrNameUtf8 = safeHTML($arrRecord["name"]);
									$uid = safeHTML($arrRecord['uid']);
									# Make sure the first item is checked
									$extra = $inputType;
									if ($blnMultiple == false && $blnFirst){
										$extra .= ' checked="checked"';
										$blnFirst = false;
									}
									echo '&nbsp;&nbsp;<input '.$extra.' class="itemCheck dept'.$intProjCounter.'" value="'.$chrRecord.'" />'.$chrNameUtf8.' <span style="color:red;">('.($uid).')</span><br />';
								}#foreach user
								echo "<hr />";
								$intProjCounter++;
							}#end foreachdept
												
						}
					echo "</td>";
					}					
					?>				
	        </tr>
			<tr>
				<?php
				if(sizeof($arrMatch) > 0 || sizeof($arrGroup) > 0) {
					if (sizeof($arrMatch) > 0){			
						$_SESSION['foundUsers']=$arrUsers;														
						echo '<td><input type="button" value="Insert Selected" onclick="javascript:insertSelected()" /></td>';											
					}
					if (sizeof($arrGroup) > 0){			
						$_SESSION['foundUsers']=$arrUsers;														
						echo '<td><input type="button" value="Insert Selected" onclick="javascript:insertSelected()" /></td>';											
					}
				}
				else{
					echo'<td class="text">No result(s) found</td>';
				}
				?>
			</tr>	        
	    </table>
	    <?php } ?>
	</div>
	</body>
</html>
