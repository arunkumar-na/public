<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");

	/** Create session object and try to load user info (id name etc from session) **/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
		exit();
	}

	# get rights of this user for departments
	$arrRights = getDepartmentRights($objSession->getUid());
	if ($_REQUEST["chrAction"] == "update_email_settings") {
			/* If user is updaing his email settings etc */
			$uid= $objSession->getUid();
			$blnConfirm = $_REQUEST["blnConfirm"];
			$blnResponse = $_REQUEST["blnResponse"];
			$blnAdvanceUser = $_REQUEST["blnAdvanceUser"];
			$blnlegalmanageremail = ($_REQUEST["blnlegalmanageremail"] == 1 ? "true" : "false");
			$intStartPage = $_REQUEST["intStartPage"]; 
			if (!$intStartPage) {
				$intStartPage = 1;
			}
			# also update session to depict that he is advanced user
			# so that without refreshing login he can access some extra functionality
			$objSession->setBlnAdvanceUser($blnAdvanceUser);
			if ( $_REQUEST["blnUpdate"] == "true"){
				$chrQuery = "UPDATE dbatn_personal_settings
							SET
							blnconfirm=$blnConfirm,
							blnresponse=$blnResponse,
							blnadvanceuser=$blnAdvanceUser,
							blnlegalmanageremail = $blnlegalmanageremail,
							intstartpage=$intStartPage
							WHERE iduser=".$objSession->getIdUser();
			}
			else {
				$chrQuery = "INSERT INTO dbatn_personal_settings(blnconfirm, blnresponse ,blnadvanceuser ,intstartpage, iduser, blnlegalmanageremail) values($blnConfirm, $blnResponse,$blnAdvanceUser,$intStartPage, ".$objSession->getIdUser().", $blnlegalmanageremail)";
			}
			mazDb_query_params($chrQuery, array());
	}
	header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("Personal Settings"); ?></title>
		<?php echo generateScripts(); ?>
	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar">
					<img src="media/images/personal3.png" />&nbsp;
					<span class="pageheading"><span class="ericssonHeading">Personal Settings</span></span>
				</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  	<tr>
    	<td valign="top" bgcolor="#505050" height="100%" >
    		<table cellpadding="0" cellspacing="" width="100%">
        		<tr>
          			<td bgcolor="#505050">&nbsp;</td>
            		<td class="workareaBox" valign="top">
    					<!-- ################################## Working Area START ################################# -->
        				<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="1">
        					<!-- InstanceBeginEditable name="subheader section" -->
               				<!-- InstanceEndEditable -->
      						<tr>
        						<td height="100%">							<!-- _____Contents START_____ -->
							       	<div id="workingDiv" style="width:100%;height:<?php echo CALENDAR_HEIGHT ?>">
                					<table bgcolor="#505050" width="100%" height="100%" >
                    					<tr>
                        					<td style="padding-top:5px;"><!-- InstanceBeginEditable name="working-area" -->
                        						<?php
						 						# load personal settings
                              					$chrQuery = "SELECT * FROM dbatn_personal_settings WHERE iduser=$1";
												$rs = mazDb_query_params($chrQuery, array($objSession->getIdUser()));
												$blnValue = "false";
												if (mazDb_num_rows($rs) > 0 ){
													$arr = mazDb_fetch_array($rs);
													$blnValue = "true";
												}
												if ( $arr["blnconfirm"] == 1){
													$chrConfirmYes = "checked=checked";
													$chrConfrimNo = "";
												}
												else {
													$chrConfirmYes = "";
													$chrConfrimNo = "checked=checked";
												}
												if ( $arr["blnresponse"] == 1){
													$chrResponseYes = "checked=checked";
													$chrResponseNo = "";
												}
												else {
													$chrResponseYes = "";
													$chrResponseNo = "checked=checked";
												}
												#$chrAdvanceYes = "";
												#$chrAdvanceNo = "checked=checked";
												if ( $arr["blnadvanceuser"] == 1){
													$chrAdvanceYes = "checked=checked";
													$chrAdvanceNo = "";
												}
												else {
													$chrAdvanceYes = "";
													$chrAdvanceNo = "checked=checked";
												}
												if($arr['blnlegalmanageremail'] == 't') {
													$blnlegalmanageremailYes = "checked=checked";
													$blnlegalmanageremailNo = "";
												} else {
													$blnlegalmanageremailYes = "";
													$blnlegalmanageremailNo = "checked=checked";
												}
						  						?>
					                            <form name="frm1" method="post">
                          							<input type="hidden" name="chrAction" value="update_email_settings" />
                          							<input type="hidden" name="blnUpdate" value="<?php echo $blnValue ?>" />
                          							<input type="hidden" name="chrdepartment" value="<?php echo $chrDepartment ?>" />
                            						<table cellspacing="0" width="100%" bgcolor="#FFFFFF" cellpadding="5">
                              							<tr>
                                							<td class="gridDataSelected" colspan="2"><?php echo $chrDepartment ?></td>
                              							</tr>
														<tr>
                              								<td class="gridData1" colspan="2">
	                              								<div>Would you like to receive an e-mail when your absence request has been sent?<br/>
		                                							<input type="radio"  name="blnConfirm" <?php echo $chrConfirmYes ?> id="blnConfirm" value="1" />Yes
		                           	    							<input type="radio"  name="blnConfirm" <?php echo $chrConfrimNo ?> id="blnConfirm" value="0" /> No
	                           	    							</div>
	                           	    						</td>
                              							</tr>
                               							<tr>
                              								<td class="gridData1" colspan="2">
                              									<div>Would you like to receive an e-mail when your manager has handled your request?<br/>
	                                								<input type="radio"  name="blnResponse" <?php echo $chrResponseYes ?> id="blnResponse" value="1" />Yes
	                                								<input type="radio"  name="blnResponse" <?php echo $chrResponseNo ?> id="blnResponse" value="0" />No
                                								</div>
                                							</td>
                              							</tr>
                              							<?php if ($objSession->getIsLegalManager() == 't') { ?>
		                              							<tr>
								                              		<td class="gridData1" colspan="2">
									                              		<div>Would you like to receive an e-mail when people that you are legal manager for send an absence request?<br/>
										                                	<input type="radio"  name="blnlegalmanageremail" <?php echo $blnlegalmanageremailYes ?> id="blnlegalmanageremail" value="1" />Yes
										                           	        <input type="radio"  name="blnlegalmanageremail" <?php echo $blnlegalmanageremailNo ?> id="blnlegalmanageremail" value="0" />No
									                           	        </div>
								                           	    	</td>
								                            	</tr>
								                         <?php } ?>							                            
						                            	<tr>
						                              		<td class="gridData1" colspan="2">
							                              		<div>User Type:<br/>
								                                	<input type="radio"  name="blnAdvanceUser" <?php echo $chrAdvanceYes ?> id="blnAdvanceUser" value="1" />Advanced User
								                           	        <input type="radio"  name="blnAdvanceUser" <?php echo $chrAdvanceNo ?> id="blnAdvanceUser" value="0" />Normal User
							                           	        </div>
						                           	    	</td>
						                            	</tr>
					                        	   		<tr>
					                    	           		<td  class="gridData1" colspan="2">Startup Page : <br/>
					                	                			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							    	                            <select name="intStartPage" id="intStartPage">
								                                <option value="1" <?php echo ($arr["intstartpage"] == 1) ? "selected='selected'" : "" ?>>My Calendar</option>
								                                <option value="2" <?php echo ($arr["intstartpage"] == 2) ? "selected='selected'" : "" ?>>Dept Calendar</option>
								                                <option value="3" <?php echo ($arr["intstartpage"] == 3) ? "selected='selected'" : "" ?>>Group Calendar</option>
								                                </select>
							                                </td>
						    	                        </tr>
    	                        	  					<tr>
	                              							<td width="5%">&nbsp;</td>
                              								<td width="95%"><input type="submit" value="Save Settings" /></td>
                              							</tr>
                            						</table>
                            					</form>
                        					</td>							<!-- InstanceEndEditable -->
                        				</tr>
                    				</table>
                					</div>							<!-- _____Contents End_____ -->
        						</td>
      						</tr>
    					</table>
        			<!-- ##################################	Working Area END ################################# -->
        			</td>
					<td bgcolor="#505050">&nbsp;</td>
    			</tr>
    			<tr>
    				<td bgcolor="#505050" colspan="3">&nbsp;</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
			</div>
		</div>
		<?php echo generateFooter(); ?>
	</body>
</html>
