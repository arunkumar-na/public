<?php
session_start();

include_once("include/site/settings.php");
include_once("include/site/db.php");
include_once("include/ldapfunc.php");
include_once("include/utilfunc.php");
include_once("include/cmazsession.php");
include_once("include/common.php");
include_once("include/menu.php");
include_once("include/page.php");

/** Create session object and try to load user info (id name etc from session) */
$objSession = new cMazSession();
$objSession->loadFromSessionToken();
	# check if user is logged in
if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
	header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
	exit();
}

# if user is not a legal manager
if($objSession->getIsLegalManager() == 'f'){
	header("location: index.php");
	exit();
}
header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title><?php echo generateTitle("People Managed List"); ?></title>
	<?php echo generateScripts(); ?>
	<script>
		$(document).ready(function () {
			$("html").css("height", $("#contentInner").height()+200);
		});
	</script>
</head>
<body>
	<?php
	echo generateHeader();
	echo generateMenu($objSession);
	?>
	<div id="content">
		<div id="contentInner">
			<div id="toolbar">
				<img src="media/images/TextArea2.png" />&nbsp;
				<span class="pageheading"><span class="ericssonHeading">People Managed</span></span>
			</div>
				<?php
					$nameSpan = (sizeof($settings["col"]) == 0) ? "colspan=2" : "";
					$intColumns = 6;
					$intColSpan = 6;
				?>
					<table cellspacing="0" cellpadding="1" width="100%" border="0">                        	

						<?php
								function createPeopleManagedListHtml($managerUid) {
									global $tabSize, $chrOrderBy;

									$html = "";
									$tabbedInStyle = "margin-left:10px;";

									$hierarchyClass = "";//Class name with all parent project id's. Separated with spaces
									for($i = 0 ; $i<sizeof($parentProjects) ; $i++) {
										$hierarchyClass .= $parentProjects[$i]." ";
									}
									$html = createColHeaders($nrOfTabs, $hierarchyClass);

									$chrQuery = "SELECT * FROM dbatn_userslist
									WHERE
									\"legalManager\" = '$managerUid'
									ORDER BY name ASC";

									$rs = mazDb_query_params($chrQuery, array());
									if (mazDb_num_rows($rs) > 0) {
										$counter=0;
										$chrOld = "";
										$blnCanView = true;

										while($arr = mazDb_fetch_array($rs)){
											$counter++;
											$chrClass = "gridData1";
											if ($counter % 2 == 0){
												$chrClass = "gridData2";
											}
											$html .= '
											<tr class="'.$hierarchyClass.'">
											<td><div style="'.$tabbedInStyle.'" class="'.$chrClass.'">'.($arr["name"]).' </div></td>
											<td><div class="'.$chrClass.'">'.$arr["uid"].' </div></td>
											<td><div class="'.$chrClass.'">'.$arr["email"].' </div></td>
											<td><div class="'.$chrClass.'">'.($arr["city"]).' </div></td>
											<td><div class="'.$chrClass.'">'.$arr["erelation"].' </div></td>
											<td><div class="'.$chrClass.'">'.$arr["department"].' </div></td>
											</tr>';
										}
									}
									return $html;
								}

								//Create headers for each column
								function createColHeaders($nrOfTabs, $hierarchyClass) {
									global $tabSize;
									$tabbedInStyle = "margin-left:".($nrOfTabs*$tabSize+10)."px;";								
									return '<tr class="'.$hierarchyClass.'">
									<td> <div style ="'.$tabbedInStyle.'" class="gridHead"> Name </div></td>
									<td> <div class="gridHead"> UID </div></td>
									<td> <div class="gridHead"> Email </div></td>
									<td> <div class="gridHead"> City </div></td>
									<td> <div class="gridHead"> Relation </div></td>
									<td> <div class="gridHead"> Department </div></td>
									</tr>';
								}

								//Get people managed
								if($objSession->getUid()) {
									echo createPeopleManagedListHtml($objSession->getUid());
								}
								?>
							</table>
							<!-- InstanceEndEditable -->
				</div><!-- contentInner -->
			</div><!-- content -->
			<?php echo generateFooter(); ?>
		</body>
		</html>
