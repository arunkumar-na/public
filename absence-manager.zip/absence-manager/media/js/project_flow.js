$(document).ready(function(){

  $('li.tree').css('color','white');
  $('li.tree').children(".open").css('display','inline');
  $('li.tree').children(".closed").css('display','inline');
  $('li.tree').children(".name").css('display','inline');
  $('li.tree').children(".child_projects").children('ul').css({'list-style-type':'none', 'padding-left':'50px', 'padding-top':'5px'});
  $('li.tree').css('list-style-type','none');
  $('li.tree').children(".child_projects").hide();
  $('li.tree').children(".open").hide();

  $("li.tree").children(".closed").click(function(){
    $(this).hide();
	$(this).parent().children(".child_projects").show(200);
    $(this).parent().children(".open").show();
  });
  $("li.tree").children(".open").click(function(){
    $(this).hide();
	$(this).parent().children(".child_projects").hide(300);
    $(this).parent().children(".closed").show();
    
  });
  
});
function submitProjStructForm(val)
{
  document.getElementById('chrProject').value = val;
  document.forms['proj_struct_form'].submit();
  //document.getElementById('bookmarks_form').submit();
}