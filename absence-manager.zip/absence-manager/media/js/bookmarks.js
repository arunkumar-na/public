$(document).ready(function(){

  $('li.bookmark').children(".open").css('display','inline');
  $('li.bookmark').children(".closed").css('display','inline');
  $('li.bookmark').children(".name").css('display','inline');
  $('li.bookmark').children(".description").children('ul').css({'list-style-type':'none', 'padding-left':'25px', 'padding-top':'5px'});
  $('li.bookmark').css('list-style-type','none');
  $('li.bookmark').children(".description").hide();
  $('li.bookmark').children(".open").hide();

  $("li.bookmark").children(".closed").click(function(){
    $(this).hide();
	$(this).parent().children(".description").show(200);
    $(this).parent().children(".open").show();
  });
  $("li.bookmark").children(".open").click(function(){
    $(this).hide();
	$(this).parent().children(".description").hide(300);
    $(this).parent().children(".closed").show();
    
  });
  
});

function submitbookmarkform(val)
{
  document.getElementById('idbookmark').value = val;
  document.forms['bookmarks_form'].submit();
  //document.getElementById('bookmarks_form').submit();
}