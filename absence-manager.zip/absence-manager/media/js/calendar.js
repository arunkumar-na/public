var person_array=new Array(),
	person_array_id=new Array(),
	startMarker = null,
	stopMarker = null,
	idUser = null,
	isLegalManager = null;

function mySelDays(){
	
	var i=0;
	var day=0, start_day=0, end_day=0;
	var month=0;
	var startday = parseInt($('select[name="start_day"]').val());
	var endday = parseInt($('select[name="end_day"]').val());
	var startmonth = parseInt($('#startMonth').val());
	var endmonth = parseInt($('#endMonth').val());
	for(month=startmonth; month<=endmonth;month++)
	{
		if(month==startmonth)
			start_day=startday;
		else
			start_day=1;
	
		if(month==endmonth)
			end_day=endday;
		else
			end_day=31;
	
		for(day=start_day; day<=end_day;day++)
		{
			var elems = $('td[class!="selectedbox"][onclick="selectbox(this)"][dayvalue="'+day+'"][monthvalue="'+month+'"]');
			if(elems.length>0)
				selectbox(elems[0]);
		}
	}
}
function selDays(){
	
	var i=0;
	var day=0, start_day=0, end_day=0;
	var month=0, start_month=0, end_month=0;
	var year=0;
	var iduser = parseInt($('select[name="select_name"]').val());
	var startday = parseInt($('select[name="start_day"]').val());
	var endday = parseInt($('select[name="end_day"]').val());
	var startmonth = parseInt($('#startMonth').val());
	var endmonth = parseInt($('#endMonth').val());
	var startyear = parseInt($('#startYear').val());
	var endyear = parseInt($('#endYear').val());
	for(year=startyear;year<=endyear;year++)
	{
		if(year==startyear)
			start_month=startmonth;
		else
			start_month=0;
		
		if(year==endyear)
			end_month=endmonth;
		else
			end_month=13;
		
		for(month=start_month; month<=end_month;month++)
		{
			if(month==start_month)
				start_day=startday;
			else
				start_day=1;
	
			if(month==end_month)
				end_day=endday;
			else
				end_day=31;
	
			for(day=start_day; day<=end_day;day++)
			{
				var elems = $('td[iduser="'+iduser+'"][class!="selectedbox"][onclick="selectbox(this)"][dayvalue="'+day+'"][monthvalue="'+month+'"][yearvalue="'+year+'"]');
				if(elems.length == 0)
					elems = $('td[iduser="'+iduser+'"][class!="selectedbox"][onclick="selectbox(this)"][dayvalue="'+day+'"][monthvalue="0'+month+'"][yearvalue="'+year+'"]');
				for(i=0;i<elems.length;i++)
					selectbox(elems[i]);
			}
		}
	}
}
function unselDays(){
	var i=0;
	var elems = $('td.selectedbox');
	for(i=0;i<elems.length;i++)
		selectbox(elems[i]);
}

$(document).ready(function(){	
	var width = $(window).width() - 470;

	idUser = $("#idUserDiv")[0].innerHTML;
	isLegalManager = $("#isLegalManagerDiv")[0].innerHTML;

	$(".inner").width(width);
	
	//for activating the scrollbar
	//$('#scrollingarea').tinyscrollbar({ axis: 'x', scroll: false, size: 'auto'});
	
	//resizing the calendar table when the window is resized
	$(window).resize(function() {
        width = $(window).width() - 470;
		$(".inner").width(width);
		//$('#scrollingarea').tinyscrollbar_update();
    });
	
	
	//for selection options
	$('#selectOptionsContent').hide();
	$('#showHideOption').children(".open").hide();
	$('#showHideOption').children(".hideSelection").hide();
	$("#showHideOption").children(".closed").click(function(){
		$(this).hide();
		$(this).parent().children(".showSelection").hide();
		$(this).parent().children(".hideSelection").show(500);
		$(this).parent().children(".open").show();
		$('#selectOptionsContent').show(500);
	});
	$("#showHideOption").children(".open").click(function(){
		$(this).hide();
		$(this).parent().children(".hideSelection").hide();
		$(this).parent().children(".showSelection").show(500);
		$(this).parent().children(".closed").show();
		$('#selectOptionsContent').hide(500);
	});
	$(".daybox").mousedown(function(e) {
		if(e.which == 3) {
			onRightClickDay(e);			
		}
	});
	$(".noteadded").mousedown(function(e) {
		if(e.which == 3) {
			onRightClickDay(e);			
		}
	});
	$(".noteaddedi").mousedown(function(e) {
		if(e.which == 3) {
			onRightClickDay(e);			
		}
	});
	$(".approved").mousedown(function(e) {
		if(e.which == 3) {
			onRightClickDay(e);			
		}
	});
	//Close right click menu on click
	$(document).click(function(e) {
		if($(".rightClickMenu").is(':visible')) {
        	$(".rightClickMenu").toggle();
        }
        if($(".chooseAbsence").is(':visible')) {
        	$(".chooseAbsence").toggle();
        }
	});
	
});

function onRightClickDay(e) {
	//If onclick is set user is allowed to edit box
	if ($(e.currentTarget)[0].onclick != null) {
		var name = $(e.currentTarget)[0].attributes.name.value;
		$(".rightClickMenu").css("left", e.pageX);
		$(".rightClickMenu").css("top", e.pageY);
		$(".rightClickMenu").toggle();
		//Display different alternatives depending on if start marker is set out
		if( !startMarker || startMarker[0] != name.split("_")[0] ){
			$(".rightClickMenu").html("<div id='startMarking' class='rightClickAlternative' onClick='setStartMark(\"" + name + "\")'>Set start marker</div>");
		} else {
			$(".rightClickMenu").html("<div class='rightClickAlternative' onClick='setStopMark(\"" + name + "\")'>Set stop marker</div>");
		}
		//Display vacation alternative if there are selected boxes
		if($('.selectedbox').length > 0) {
			if(isLegalManager == 't') {
				$(".rightClickMenu").append("<div class='rightClickAlternative' onClick='saveBoxes(\"A\")'>Approve</div>");
				$(".rightClickMenu").append("<div class='rightClickAlternative' onClick='saveBoxes(\"D\")'>Deny</div>");
			}
			$(".rightClickMenu").append("<div class='rightClickAlternative' onClick='chooseAbsenceType()'>Apply for absence <i style='font-size:10px;'>(selected days)</i></div>");			
			$(".rightClickMenu").append("<div class='rightClickAlternative' onClick='clearSelectedDays()'>Clear days</div>");			
			$(".rightClickMenu").append("<div class='rightClickAlternative' onClick='saveBoxes(\"edit_comments\")'>Edit comments</div>");			
		}		
	}
}

function setStartMark(targetName){
	//Don't select if already selected
	if($("[name='" + targetName + "']")[0].className != "selectedbox") {
		selectbox($("[name='" + targetName + "']")[0]);
	}
	startMarker = targetName.split("_");
}

function setStopMark(targetName) {
	stopMarker = targetName.split("_");
	markInterval();
}

function markInterval() {
	var id = startMarker[0],
		tmp = null,
		years = new Array(),
		months = new Array(),
		days = new Array(),
		date = null,
		endDate = null,
		nameString;
	//If both start and stop is set
	if(startMarker && stopMarker){
		//Swap if stop date is before start date		
		if( ( new Date(parseInt(stopMarker[1]), (parseInt(stopMarker[2])-1), parseInt(stopMarker[3])) ) < ( new Date(parseInt(startMarker[1]), (parseInt(startMarker[2])-1), parseInt(startMarker[3])) ) ) {
			tmp = startMarker;
			startMarker = stopMarker;
			stopMarker = tmp;
		}
		//JS starts counting months from 0
		date = new Date(parseInt(startMarker[1]), (parseInt(startMarker[2])-1), parseInt(startMarker[3]));
		endDate = new Date(parseInt(stopMarker[1]), (parseInt(stopMarker[2])-1), parseInt(stopMarker[3]));
				
		//Loop through intervall and select the boxes
		for(date ; date <= endDate ; date.setDate(date.getDate() + 1)) {
			nameString = id + "_" + date.getFullYear() + "_" + (parseInt(date.getMonth())+1) + "_" + date.getDate();
			//Skip the boxes that are already selected
			if($("[name='" + nameString + "']")[0].className != "selectedbox" && ($("[name='" + nameString + "']")[0].className != "dayboxholiday") && ($("[name='" + nameString + "']")[0].className != "redday") ) {
				selectbox($("[name='" + nameString + "']")[0]);
			}
		}
	}
	//Reset markers
	startMarker = null;
	stopMarker = null;
}

function chooseAbsenceType() {	
	setTimeout(function (){
		$(".chooseAbsence").toggle();
	}, 500);
	
}


