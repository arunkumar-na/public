function populateList(id, idsValues) {
	$('#'+id).empty();

	for (var key in idsValues) {
		val = idsValues[key];
		if (val) {
			$('#'+id).append($('<option></option>').attr('value', key).text(val));
		}
	}
	$('#'+id).val($('#'+id+' option:first').val());
}

function addAll(sourceId, targetId) {
	$('#'+targetId).empty();
	$('#'+sourceId+ ' option').clone().each(function (index, element) {
		$('#'+targetId).append(element);
	});
}

function removeAll(targetId) {
	$('#'+targetId).empty();
}

function addItems(sourceId, targetId) {
	$('#'+sourceId+' option:selected').clone().each(function (index, element) {
		var sel = '#'+targetId+' option[value="'+$(this).val()+'"]';
		if ($(sel).length == 0) {
			$('#'+targetId).append(element);
		}
	});
}

function removeItems(targetId) {
	$('#'+targetId+' option:selected').remove();
}

function connectFilterToList(filterId, listId, data) {
	$('#'+filterId).keyup(function () {
		var filter = $(this).val().toLowerCase();
		var filtered = [];
		for (key in data) {
			var val = data[key];
			if (val && val.toLowerCase().indexOf(filter) !== -1 ) {
				option = '<'+'option value="'+key+'">'+val+'<'+'/option>';
				filtered.push(option);
			}
		}

		var list = $('#'+listId);
		list.empty();
		list.append(filtered.join(''));
		
		if (filtered.length > 0) {
			list.val($('#'+listId+' option:first').val());
		}
	});
}

function searchInSelectBox(boxId, searchFieldId){
	var checkBoxArea = $('#'+boxId),
		searchString = $('#'+searchFieldId).val();
	checkBoxArea.children('div').each(function () {
		if(this.id.indexOf(searchString) == -1 && this.id.toLowerCase().indexOf(searchString.toLowerCase()) == -1) {
			$(this).hide();
		} else {
			$(this).show();
		}
	});
}
function uncheckAll(checkBoxClass) {
	$("input."+checkBoxClass).removeAttr('checked');
}
