/**
 * 
 */

callbacks = {
};

//Search users functions ---
function searchPopup(callback, mode, multiple){
	var url = "search_popup.php?chkCounter=0&mode="+mode+"&multiple="+multiple;
	var w = window.open(url,"amSearch","width=800,height=600,resizable=1,scrollbars=1");
	callbacks[w] = callback;
	blockPage();
}

function searchDoneCallback(window, arrSelected){
	var callback = callbacks[window];
	delete callbacks[window]; // Window is now closed
	callback(arrSelected);
	unblockPage();
}

function searchDepartments(callback, multiple){
	if (multiple == null){
		multiple = 0;
	}
	searchPopup(callback, "departments", multiple);
}

function searchUsers(callback, multiple){
	if (multiple == null){
		multiple = 1;
	}
	searchPopup(callback, "users", multiple);
}
//---

//Search groups functions
function searchPopupGroups(callback, mode, multiple){
	var url = "search_popup_groups.php?chkCounter=0&mode="+mode+"&multiple="+multiple;
	var w = window.open(url,"amSearch","width=800,height=600,resizable=1,scrollbars=1");
	callbacks[w] = callback;
	blockPage();
}
function searchGroups(callback, multiple){
	if (multiple == null){
		multiple = 1;
	}
	searchPopupGroups(callback, "users", multiple);
}

function groupSearchDoneCallback(window, arrSelected){
	var callback = callbacks[window];
	delete callbacks[window]; // Window is now closed
	callback(arrSelected);
	unblockPage();
}
//---
