function toggleMenu(groupClass){
	$('.'+groupClass).toggle();
}

function mazCustomSelectCheckUnCheck(obj,prefix){
	var blnChecked = false;
	if (obj.checked == true){
		blnChecked = true;
	}
	intCount = document.getElementById(prefix+"_count").value;
	for(i = 0; i < intCount; i++){
		document.getElementById(prefix+i).checked = blnChecked;
	}
}

function htmlEntities(str){
	return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function pageInit(){
	$('.newWindow').click(function (){
		window.open(this.href);
		return false;
	});
	setTimeout(function (){
		$('#message[display!="none"]').fadeOut(2*1000);
	}, 6*1000);
}

function blockPage(){
	$('#pageBlock').css('opacity', 0);
	$('#pageBlock').css('display', 'block');
	$('#pageBlock').fadeTo('slow', 0.8);
}

function unblockPage(){
	$('#pageBlock').hide();
}
