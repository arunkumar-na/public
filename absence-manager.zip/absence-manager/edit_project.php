<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");
	include_once("include/user.php");

	/** Create session object and try to load user info (id name etc from session) **/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();
	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
		exit();
	}
	#get id and type of project for edit
	$chrQuery = "SELECT idproject,isgroup FROM dbatn_projects where chrproject=$1";
	if(!isset($_REQUEST["oldprojname"])) { //check to enable changing name and remove/adding projects at the same time
		$params = array($_REQUEST["chrProject"]);
	}
	else {
		$params = array($_REQUEST["oldprojname"]);
	}
	
	$rsx = mazDb_query_params($chrQuery, $params);
	$isgroup = '';
	if (mazDb_num_rows($rsx) > 0) {
		$arr = mazDb_fetch_array($rsx);
		$isgroup = $arr["isgroup"];
		$onAddClick = '';
		if($isgroup == 't'){
			$onAddClick = "openPopupSearchUsers()";
		}
		else if($isgroup == 'f'){
			$onAddClick = "openPopupSearchGroups()";
		}
	}


	$idUser = $objSession->getIdUser();
	#check if required fields are there
	if ($_REQUEST["chrAction"] == "update_project" && (($_REQUEST["total"] > 0 || $_REQUEST["old_count"] > 0) || $isgroup == 'f')){
		$blnNameAlready = false;
		$idProject = $_REQUEST["idProject"];
		if ($idProject < 1) {
			echo "invalid idproject";
			exit();
		}

		# make sure, if project name already exist or not
		$chrQuery = "SELECT idproject FROM dbatn_projects where chrproject=$1 AND idproject != $2";
		$params = array($_REQUEST["chrProject"], $idProject);
		$rsx = mazDb_query_params($chrQuery, $params);
		$chrProjectName = $_REQUEST["chrProject"];
		if (mazDb_num_rows($rsx)){
			$blnNameAlready = true;
			if (!$_REQUEST["oldname"]){
				# if already name taken then select a random name,
				# as we have to complete the process then we will send user to edit form
				# again where he can choose diff name
				$chrProjectName = time();
			}
			else{
				$chrProjectName = $_REQUEST["oldname"];
			}
		}

		#update project info
		
		$chrProjectName = preg_replace("/\s+/"," ",$chrProjectName );
		$chrProjectName = preg_replace("[^A-Za-z0-9&/]", "", $chrProjectName );
		$chrQuery = "UPDATE dbatn_projects SET chrproject=$1,idupdatedby=$2, intdateupdated=$3 WHERE idProject=$4";
		$params = array(safeDatabase($chrProjectName), $objSession->getIdUser(), time(), $idProject);
		mazDb_query_params($chrQuery, $params);

		#Delete Old entry for viewing this, that was insetrted on createion
		$chrQuery = "DELETE FROM dbatn_project_project WHERE idproject=$1";
		mazDb_query_params($chrQuery, array($idProject));

		#insert this new as defualt value
		$chrQuery = "INSERT INTO dbatn_project_project(idproject,chrprojectallowed) values ($idProject,'".safeDatabase($chrProjectName)."');";
		mazDb_query_params($chrQuery, array());


		if($isgroup == 't'){ #the incoming item is a group
			#remove old entries
			$chrQuery = "DELETE FROM dbatn_projectlist WHERE idproject=$1";
			mazDb_query_params($chrQuery, array($idProject));


			$arrAlreadyProcessesed = array();
			#make old selected entries there
			$intOldCount = $_REQUEST["old_count"];
			for ($i = 0; $i < $intOldCount; $i++){
				$idUser = $_REQUEST["old".$i];
				if ($idUser){
					if (in_array($idUser,$arrAlreadyProcessesed)){
						continue;
					}
					else {
						$arrAlreadyProcessesed[] = $idUser;
					}
					# make current user member of this project
					$chrQuery = "INSERT INTO dbatn_projectlist(idproject,iduser,chrproject)values($idProject,$idUser,'$chrProjectName')";
					mazDb_query_params($chrQuery, array());
				}
			}
			$arrIdUsers = array();
			# add all other selected users member of this project
			$objRecord = array();
			for($i = 0; $i < $_REQUEST["total"]; $i++) { #fails here! thursday etorhun
				if ($_REQUEST["sel_$i"]) {
					$chrUserID = $_REQUEST["sel_$i"];
					$objRecord = getOrImportUser($chrUserID);
					$uid = $chrUserID;
					$chrQuery = "SELECT iduser FROM dbatn_userslist WHERE uid=$1";
					$rs = mazDb_query_params($chrQuery, array($uid));
					$idNextNumber = 0;
					if (mazDb_num_rows($rs) > 0 ) {
						$arr = mazDb_fetch_array($rs);
						#display($arr);
						$idNextNumber = $arr["iduser"];
						
						if (in_array($idNextNumber,$arrAlreadyProcessesed)){
							continue;
						}
						else {
							$arrAlreadyProcessesed[] = $idNextNumber;
						}
					}
					$arrIdUsers[] = $idNextNumber;
				}#if record
			}#end foreach

			# make users member of this project
			foreach($arrIdUsers as $idSelectedUser) {
				$chrListQuery = "INSERT INTO dbatn_projectlist(idproject,iduser,chrproject) values($idProject,$idSelectedUser,'".$chrProjectName."')";
				mazDb_query_params($chrListQuery, array());
			}

		} else if($isgroup == 'f'){#the incoming item is a project

			#remove old entries
			$chrQuery = "DELETE FROM dbatn_project_subprojects WHERE idproject=$1";
			mazDb_query_params($chrQuery, array($idProject));

			$intOldCount = $_REQUEST["old_count"];
			for ($i = 0; $i < $intOldCount; $i++){
				$idProj = $_REQUEST["old".$i];
				if ($idProj){
					if (in_array($idProj,$arrAlreadyProcessesed)){
						continue;
					}
					else {
						$arrAlreadyProcessesed[] = $idProj;
					}
					# make current project/group member of this project
					$chrQuery = "INSERT INTO dbatn_project_subprojects(idproject,idsubproject)values($idProject,$idProj)";
					mazDb_query_params($chrQuery, array());
				}
			}

			$arrIdUsers = array();
			# add all other selected users member of this project
			$objRecord = array();
			for($i = 0; $i < $_REQUEST["total"]; $i++) { #fails here! thursday etorhun
				if ($_REQUEST["sel_$i"]) {
					$chrUserID = $_REQUEST["sel_$i"];
					$objRecord = getOrImportUser($chrUserID);
					$uid = $chrUserID;
					$chrQuery = "SELECT idproject FROM dbatn_projects WHERE idproject=$1";
					$rs = mazDb_query_params($chrQuery, array($uid));
					$idNextNumber = 0;
					if (mazDb_num_rows($rs) > 0 ) {
						$arr = mazDb_fetch_array($rs);
						$idNextNumber = $arr["idproject"];
						
						if (in_array($idNextNumber,$arrAlreadyProcessesed)){
							continue;
						}
						else {
							$arrAlreadyProcessesed[] = $idNextNumber;
						}
					}
					$arrIdUsers[] = $idNextNumber;
				}#if record
			}#end foreach

			# make subprojects members of this project
			foreach($arrIdUsers as $idSelectedUser) {
					$chrListQuery = "INSERT INTO dbatn_project_subprojects(idproject,idsubproject) values($idProject,$idSelectedUser)";
					mazDb_query_params($chrListQuery, array());
			}


		}
		if ($blnNameAlready == true){
			header("location: edit_project.php?proj0=".$_REQUEST["oldname"]."&proj_count=1&chrAction=edit_list&msg=".urlencode($_REQUEST["chrProject"].", name Already exsist"));
		}
		else {
			header("location: edit_project_choose.php");
		}
		exit();
		
	}

	header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("Edit Project"); ?></title>
		<?php echo generateScripts(); ?>
<script type="text/javascript">
var intCheckCounter = 0;
var intSelectedUser = -1;


function openPopupSearchUsers(){
	searchUsers(function (arrSelected){
		var counter = intCheckCounter;
		intCheckCounter += arrSelected.length;
		intSelectedUser += arrSelected.length;
		var selUsers = $('#selUsers');
		for (var i = 0; i < arrSelected.length; i++){
			if (i != 0 && i % 4 == 0){
				selUsers.append('<br />');
			}
			var user = arrSelected[i];
			str = "<"+"input type=\"checkbox\" checked=\"checked\" name=\"sel_"+counter+"\" id=\"sel_"+counter+"\" value=\""+user.uid+"\" />"+user.name+ "&nbsp;";
			selUsers.append(str);
			counter++;
		}
	});
}

function openPopupSearchGroups(){
	searchGroups(function (arrSelected){
		var counter = intCheckCounter;
		intCheckCounter += arrSelected.length;
		intSelectedUser += arrSelected.length;
		var selRecords = $('#selUsers');
		for (var i = 0; i < arrSelected.length; i++){
			if (i != 0 && i % 4 == 0){
				selRecords.append('<br />');
			}
			var record = arrSelected[i];
			str = "<"+"input type=\"checkbox\" checked=\"checked\" name=\"sel_"+counter+"\" id=\"sel_"+counter+"\" value=\""+record.idproject+"\" />"+record.chrproject+ "&nbsp;";					
			selRecords.append(str);
			counter++;
		}
	});
}

function getOldUserSelectedCount(){
	intCount = document.frmCreate.old_count.value;
	intSelCount = 0;
	if (intCount > 0){
		for (i = 0; i < intCount; i++){
			if (document.getElementById("old"+i).checked == true){
				intSelCount++;
			}
		}
		return intSelCount;
	}
	return 0;
}
function validateForm(){
	if (document.frmCreate.chrProject.value == ""){
		alert("Please enter group name to create");
		document.frmCreate.chrProject.focus();
		return false;
	}
	else if (intSelectedUser < 0  && getOldUserSelectedCount() < 0){
		alert("No user selected");
		return false;
	}
	else {
		document.frmCreate.total.value = intCheckCounter;
		return true;
	}
	return false;
}

function removeUser(idx){
	document.getElementById("sel_"+idx).value = "";
	//document.getElementById("msnUser"+idx).innerHTML = "";
	var d = document.getElementById("selUsers");
	var child1 = document.getElementById("sel_"+idx);
	var child2 = document.getElementById("msnUser"+idx);
	child2.innerHTML = "";
	d.removeChild(child1);
	d.removeChild(child2);
	intSelectedUser--;
}

</script>
	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar">
					<img src="media/images/edit.png" />&nbsp;
					<span class="ericssonHeading">Edit Group/Project</span>
				</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  	<tr>
    	<td valign="top" bgcolor="#505050" height="100%" >
    		<table cellpadding="0" cellspacing="" width="100%">
        		<tr>
					<td bgcolor="#505050">&nbsp;</td>
		            <td class="workareaBox" valign="top">
    					<!-- ##################################	Working Area START ################################# -->
        				<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="1">
        					<!-- InstanceBeginEditable name="subheader section" -->
							<!-- InstanceEndEditable -->
      						<tr>
        						<td height="100%">		<!-- _____Contents START_____ -->
            					<div id="workingDiv" style="width:100%;height:<?php echo CALENDAR_HEIGHT ?>">
                				<table bgcolor="#505050" width="100%" height="100%" >
                    				<tr>
                        				<td style="padding-top:5px;"><!-- InstanceBeginEditable name="working-area" -->
            			              	<?php
										if ($_REQUEST["chrAction"] == "edit_list"){
											if(isset($_REQUEST["projsSelected"][0])) {
												$chrProject = $_REQUEST["projsSelected"][0];
											} else {
												$chrProject = $_REQUEST["chrProject"];
											}
						  				}
						  				?>
						  				<form name="frmCreate" id="frmCreate" method="post" onsubmit="return validateForm()">
                             				<input type="hidden" name="chrAction" value="update_project" />
                             				<input type="hidden" name="oldname" value="<?php echo $chrProject ?>" />
                             				<input type="hidden" name="total" id="total" value="0" />
                           					<table width="100%" bgcolor="#FFFFFF" border="0" cellspacing="3" cellpadding="3">
                              					<tr>
                                					<td colspan="2" class="formheading">Edit Group/Project</td>
                            					</tr>
				                              	<?php
									  			# get project detail that will be displayed on the edit form
                		              			$chrQuery = "SELECT idproject FROM dbatn_projects WHERE chrproject=$1";
												$rs = mazDb_query_params($chrQuery, array($chrProject));
												$idProject = 0;
												if (mazDb_num_rows($rs)){
													$arr = mazDb_fetch_array($rs);
													$idProject = $arr["idproject"];
													unset($arr);
												}
												# get user rights
												$arrRights = getProjectRights($objSession->getUid());
								  				$blnCanView = true;
								  				
							  					if ($objSession->isAdminUser() == false && !in_array($idProject, $arrRights["owner"])){
													$blnCanEdit = false;
													$_REQUEST["msg"] = "Only owners can edit this list";
													if (!in_array($idProject, $arrRights["view"])){
														$blnCanView = false;
													}
								  				}
								  				else {
													$blnCanEdit = true;
												}
												$chrDisabled =  ($blnCanEdit == true) ? "" : "disabled='disabled'";
							  					if ($_REQUEST["msg"]){
							  						?>
	                              					<tr>
    	                          						<td colspan="2" align="left">
        	                        						<table>
            	                        					<tr>
                	                        					<td><img src="media/images/critical.png" /></td>
                    	                    					<td class="critical"><?php echo $_REQUEST["msg"] ?></td>
					    	                                </tr>
		    			    	                            </table>
        	                    	    				</td>
                              						</tr>
													<?php
							  					}#end if message
							  					?>
                              					<tr>
                                					<td width="27%" class="caption" id="typeName"><?php if($isgroup == 't'){echo "Group name:";}else if($isgroup == 'f'){echo "Project name:";}?></td>
                                					<td width="73%"><input type="text" name="chrProject" id="chrProject" <?php echo ($blnCanEdit == true) ? "" : "disabled='disabled'" ?> value="<?php echo $chrProject ?>" /></td>
                              					</tr>
                             					<tr>
                               						<td class="caption" id="subItems"><?php if($isgroup == 't'){echo "Existing users:";}else if($isgroup == 'f'){echo "Existing Groups/Projects:";}?></td>
                               						<td  class="msnuserbox" valign="top">
	                               					<?php
													echo "<input type='hidden' value='$idProject' name='idProject' id='idProject'  />";
													# get already existing member of this project
													if($isgroup == 't'){
														$chrQuery = "SELECT dbatn_userslist.*
														FROM dbatn_userslist,dbatn_projectlist
														WHERE dbatn_projectlist.chrproject=$1
														AND	dbatn_userslist.iduser=dbatn_projectlist.iduser AND name!='' ORDER BY name ASC";
														$rs = mazDb_query_params($chrQuery, array($chrProject));
														$intOld = 0;
														if (mazDb_num_rows($rs)){
															while( $arr = mazDb_fetch_array($rs) ){
																if ($blnCanView == false){
																	$arr["name"] = "****";
																}
																echo "<input type='checkbox' checked='checked' $chrDisabled  value='".$arr["iduser"]."' id='old".$intOld."'
																name='old".$intOld."'>".($arr["name"])." ";
																$intOld ++;
															}
														}
														echo "<input type='hidden' value='$intOld' name='old_count' id='old_count' />";
													}
													else if($isgroup == 'f'){
														$chrQuery = "SELECT * FROM dbatn_project_subprojects
																	INNER JOIN dbatn_projects
																	ON dbatn_project_subprojects.idsubproject = dbatn_projects.idproject 
																	AND dbatn_project_subprojects.idProject=$1";
														$rs = mazDb_query_params($chrQuery, array($idProject));
														$intOld = 0;
														if(mazDb_num_rows($rs)){
															while ( $arr = mazDb_fetch_array($rs) ){
																if($blnCanView == false) {
																	$arr["name"] = "****";
																}
																echo "<input type='checkbox' checked='checked' $chrDisabled  value='".$arr["idproject"]."' id='old".$intOld."'
																name='old".$intOld."'>".($arr["chrproject"])." ";
																$intOld ++;
															}
														}
														echo "<input type='hidden' value='$intOld' name='old_count' id='old_count' />";
													} 
													?>
                               						</td>
                             					</tr>
                             					<tr>
                               						<td class="caption" id="newItem"><?php if($isgroup == t){ echo "New users:"; }else if($isgroup == f) {echo "New Groups/Projects:";}?></td>
                               						<td  id="selUsers" class="msnuserbox" valign="top">&nbsp;</td>
                             					</tr>
                              					<tr>
                                					<td>&nbsp;</td>
                                					<td><input type="hidden" name="mixUsers" id="mixUsers" value="" />
                                    					<input type="button" value=<?php if($isgroup == t){ echo "Add users:"; }else {echo "Add Groups/Projects";}?> <?php echo ($blnCanEdit == true) ? "" : "disabled='disabled'"; ?> onclick="<?php echo $onAddClick ?>"/>&nbsp;
                                    					<input type="submit" name="btnCreate" <?php echo ($blnCanEdit == true) ? "" : "disabled='disabled'"; ?> id="btnCreate" value="Update Group/Project" />
                                    					<input type='hidden' <?php echo "value='".$_REQUEST["chrProject"]."'"; ?> name='oldprojname' id='oldprojname' />
                                    				</td>
                              					</tr>
                                        	</table>
                              			</form>
                        				<!-- InstanceEndEditable --></td>
                        			</tr>
                    				</table>
                					</div>			<!-- _____Contents End_____ -->
        						</td>
      						</tr>
    					</table>
        				<!-- ##################################	Working Area END ################################# -->
          			</td>
            		<td bgcolor="#505050">&nbsp;</td>
				</tr>
          		<tr>
			       	<td bgcolor="#505050" colspan="3">&nbsp;</td>
          		</tr>
	  		</table>
    	</td>
  	</tr>
</table>
			</div>
		</div>
		<?php echo generateFooter(); ?>
	</body>
</html>