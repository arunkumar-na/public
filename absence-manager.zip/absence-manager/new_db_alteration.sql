﻿ALTER TABLE dbatn_userslist ADD COLUMN visible boolean NOT NULL DEFAULT TRUE;
CREATE TABLE dbatn_department_holidaytemplate(chrdepartment varchar(250) PRIMARY KEY, iduser integer PRIMARY KEY);
-- what privileges should be implemented? etorhun, tool, public?
-- INSERT INTO dbatn_userslist(iduser, dn, name, erelation, title, uid) VALUES (11, 't', 'Public Holidays - Sweden', 'SE' , 'Template', 'SE01');