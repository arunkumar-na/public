Truncate dbatn_department_manager;
Truncate dbatn_department_settings1;
Truncate dbatn_department_project;
Truncate dbatn_project_owner;
Truncate dbatn_project_department;
Truncate dbatn_project_project;
Truncate dbatn_project_settings1;
Truncate dbatn_department_owner;
Truncate dbatn_department_settings2;
Truncate dbatn_userdays;
Truncate dbatn_personal_settings;
Truncate dbatn_department_department;
Truncate dbatn_department_email_settings;
Truncate dbatn_project_settings2;
Truncate dbatn_projectlist;
Truncate tmp_sent_email_log;

Truncate dbatn_userslist;
Truncate dbatn_projects;


ALTER SEQUENCE serial RESTART WITH 105;


/*
$rs = mazDb_query("SELECT tablename FROM pg_tables
WHERE tablename NOT LIKE 'pg%'
AND tablename NOT LIKE 'sql%'");

$arrQ = array();
while($arr = mazDb_fetch_array($rs)){
$arrQ[] = "Truncate ".$arr[0];
}


$chrS = implode(";\n",$arrQ);
display($chrS);
*/