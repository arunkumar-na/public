--
-- PostgreSQL database dump
--

-- Dumped from database version 8.1.19
-- Dumped by pg_dump version 9.2.3
-- Started on 2013-06-13 16:41:11

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 107 (class 1259 OID 16707)
-- Name: dbatn_admin; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_admin (
    idadmin integer NOT NULL,
    uid character varying(50),
    pwd character varying,
    email character varying(250)
);


ALTER TABLE public.dbatn_admin OWNER TO absman_test;

--
-- TOC entry 132 (class 1259 OID 16930)
-- Name: dbatn_bookmarks; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_bookmarks (
    idbookmark integer NOT NULL,
    iduser integer,
    name character varying(250),
    query character varying(1000),
    struid character varying(100),
    strname character varying(100),
    stremail character varying(100),
    strcontact character varying(100),
    blnrelatione character varying(1),
    blnrelationn character varying(1),
    citystatement character varying(1000),
    deptstatement character varying(1000),
    projstatement character varying(1000),
    "time" timestamp without time zone
);


ALTER TABLE public.dbatn_bookmarks OWNER TO absman_test;

--
-- TOC entry 131 (class 1259 OID 16928)
-- Name: dbatn_bookmarks_idbookmark_seq; Type: SEQUENCE; Schema: public; Owner: absman_test
--

CREATE SEQUENCE dbatn_bookmarks_idbookmark_seq
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dbatn_bookmarks_idbookmark_seq OWNER TO absman_test;

--
-- TOC entry 1648 (class 0 OID 0)
-- Dependencies: 131
-- Name: dbatn_bookmarks_idbookmark_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: absman_test
--

ALTER SEQUENCE dbatn_bookmarks_idbookmark_seq OWNED BY dbatn_bookmarks.idbookmark;


--
-- TOC entry 108 (class 1259 OID 16712)
-- Name: dbatn_department_department; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_department_department (
    chrdepartment character varying(250) NOT NULL,
    chrdepartmentallwoed character varying(250) NOT NULL
);


ALTER TABLE public.dbatn_department_department OWNER TO absman_test;

--
-- TOC entry 109 (class 1259 OID 16717)
-- Name: dbatn_department_email_settings; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_department_email_settings (
    chrdepartment character varying(250) NOT NULL,
    intemailrequired integer DEFAULT 1 NOT NULL,
    chrconfirmationmsg text,
    chrreplymsg text,
    intautoapprove integer DEFAULT 0
);


ALTER TABLE public.dbatn_department_email_settings OWNER TO absman_test;

--
-- TOC entry 110 (class 1259 OID 16724)
-- Name: dbatn_department_holidaytemplate; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_department_holidaytemplate (
    chrdepartment character varying(250) NOT NULL,
    iduser integer
);


ALTER TABLE public.dbatn_department_holidaytemplate OWNER TO absman_test;

--
-- TOC entry 111 (class 1259 OID 16726)
-- Name: dbatn_department_manager; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_department_manager (
    iduser integer,
    chrdepartment character varying(250)
);


ALTER TABLE public.dbatn_department_manager OWNER TO absman_test;

--
-- TOC entry 112 (class 1259 OID 16728)
-- Name: dbatn_department_owner; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_department_owner (
    iduser integer NOT NULL,
    chrdepartment character varying(250) NOT NULL
);


ALTER TABLE public.dbatn_department_owner OWNER TO absman_test;

--
-- TOC entry 113 (class 1259 OID 16730)
-- Name: dbatn_department_project; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_department_project (
    chrdepartment character varying(250),
    chrprojectallowed character varying(250)
);


ALTER TABLE public.dbatn_department_project OWNER TO absman_test;

--
-- TOC entry 114 (class 1259 OID 16735)
-- Name: dbatn_department_settings1; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_department_settings1 (
    iduser integer,
    department character varying(100)
);


ALTER TABLE public.dbatn_department_settings1 OWNER TO absman_test;

--
-- TOC entry 115 (class 1259 OID 16737)
-- Name: dbatn_department_settings2; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_department_settings2 (
    iduser integer,
    intcol integer
);


ALTER TABLE public.dbatn_department_settings2 OWNER TO absman_test;

--
-- TOC entry 116 (class 1259 OID 16739)
-- Name: dbatn_personal_settings; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_personal_settings (
    blnconfirm integer DEFAULT 0,
    blnresponse integer DEFAULT 0,
    blnadvanceuser smallint DEFAULT 0,
    iduser integer DEFAULT 0,
    intstartpage smallint DEFAULT 1,
	blnlegalmanageremail boolean DEFAULT false NOT NULL
);


ALTER TABLE public.dbatn_personal_settings OWNER TO absman_test;

--
-- TOC entry 117 (class 1259 OID 16746)
-- Name: dbatn_project_department; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_project_department (
    idproject integer,
    chrdepartmentallwoed character varying(250)
);


ALTER TABLE public.dbatn_project_department OWNER TO absman_test;

--
-- TOC entry 118 (class 1259 OID 16748)
-- Name: dbatn_project_owner; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_project_owner (
    iduser integer,
    idproject integer
);


ALTER TABLE public.dbatn_project_owner OWNER TO absman_test;

--
-- TOC entry 119 (class 1259 OID 16750)
-- Name: dbatn_project_project; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_project_project (
    idproject integer,
    chrprojectallowed character varying(250)
);


ALTER TABLE public.dbatn_project_project OWNER TO absman_test;

--
-- TOC entry 120 (class 1259 OID 16752)
-- Name: dbatn_project_settings1; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_project_settings1 (
    iduser integer,
    project character varying(100)
);


ALTER TABLE public.dbatn_project_settings1 OWNER TO absman_test;

--
-- TOC entry 121 (class 1259 OID 16754)
-- Name: dbatn_project_settings2; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_project_settings2 (
    iduser integer,
    intcol integer
);


ALTER TABLE public.dbatn_project_settings2 OWNER TO absman_test;

--
-- TOC entry 133 (class 1259 OID 16945)
-- Name: dbatn_project_subprojects; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_project_subprojects (
    idproject integer,
    idsubproject integer
);


ALTER TABLE public.dbatn_project_subprojects OWNER TO absman_test;

--
-- TOC entry 122 (class 1259 OID 16756)
-- Name: dbatn_projectlist; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_projectlist (
    idproject integer,
    iduser integer,
    chrproject character varying(50)
);


ALTER TABLE public.dbatn_projectlist OWNER TO absman_test;

--
-- TOC entry 123 (class 1259 OID 16758)
-- Name: dbatn_projects; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_projects (
    idproject integer NOT NULL,
    chrproject character varying(50),
    idcreatedby integer,
    intdate integer,
    idupdatedby integer,
    intdateupdated integer,
    isgroup boolean DEFAULT true NOT NULL
);


ALTER TABLE public.dbatn_projects OWNER TO absman_test;

--
-- TOC entry 124 (class 1259 OID 16760)
-- Name: dbatn_userdays; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_userdays (
    "idUser" integer NOT NULL,
    "intDay" integer NOT NULL,
    "intMonth" integer NOT NULL,
    "intYear" integer NOT NULL,
    "chrCharacter" character varying(2),
    "chrComments" character varying(500),
    "intApproved" integer DEFAULT 0,
    "chrComments2" character varying(250),
    inttime integer,
    blnapproved integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.dbatn_userdays OWNER TO absman_test;

--
-- TOC entry 125 (class 1259 OID 16767)
-- Name: dbatn_userslist; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE dbatn_userslist (
    iduser integer NOT NULL,
    dn character varying(250),
    name character varying(250),
    department character varying(250),
    city character varying(250),
    erelation character varying(250),
    phone character varying(50),
    title character(100),
    email character varying(100),
    mdept character varying(100),
    sdept character varying(100),
    uid character varying(100),
    "legalManager" character varying(100),
    "isLegalManager" boolean DEFAULT false NOT NULL,
    visible boolean DEFAULT true NOT NULL
);


ALTER TABLE public.dbatn_userslist OWNER TO absman_test;


CREATE TABLE dbatn_department_free_access (
    chrdepartment character varying(250),
    freeaccess boolean DEFAULT false NOT NULL
);


ALTER TABLE public.dbatn_department_free_access OWNER TO absman_test;

--
-- TOC entry 126 (class 1259 OID 16773)
-- Name: seq_iddepartment_departments; Type: SEQUENCE; Schema: public; Owner: absman_test
--

CREATE SEQUENCE seq_iddepartment_departments
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_iddepartment_departments OWNER TO absman_test;

--
-- TOC entry 127 (class 1259 OID 16775)
-- Name: seq_idlist_lists; Type: SEQUENCE; Schema: public; Owner: absman_test
--

CREATE SEQUENCE seq_idlist_lists
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_idlist_lists OWNER TO absman_test;

--
-- TOC entry 128 (class 1259 OID 16777)
-- Name: seq_idproject_projects; Type: SEQUENCE; Schema: public; Owner: absman_test
--

CREATE SEQUENCE seq_idproject_projects
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_idproject_projects OWNER TO absman_test;

--
-- TOC entry 129 (class 1259 OID 16779)
-- Name: seq_iduser_userinfo; Type: SEQUENCE; Schema: public; Owner: absman_test
--

CREATE SEQUENCE seq_iduser_userinfo
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_iduser_userinfo OWNER TO absman_test;

--
-- TOC entry 1649 (class 0 OID 0)
-- Dependencies: 129
-- Name: SEQUENCE seq_iduser_userinfo; Type: COMMENT; Schema: public; Owner: absman_test
--

COMMENT ON SEQUENCE seq_iduser_userinfo IS 'hi man';


--
-- TOC entry 130 (class 1259 OID 16781)
-- Name: tmp_sent_email_log; Type: TABLE; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE TABLE tmp_sent_email_log (
    chrto text,
    chrfrom text,
    chrsubject text,
    chrbody text,
    intdate bigint DEFAULT 0,
    chrheader text
);


ALTER TABLE public.tmp_sent_email_log OWNER TO absman_test;

--
-- TOC entry 1650 (class 0 OID 0)
-- Dependencies: 130
-- Name: TABLE tmp_sent_email_log; Type: COMMENT; Schema: public; Owner: absman_test
--

COMMENT ON TABLE tmp_sent_email_log IS 'This table is only for testing purpose, and will be deleted, once application is complete';


--
-- TOC entry 1573 (class 2604 OID 16932)
-- Name: idbookmark; Type: DEFAULT; Schema: public; Owner: absman_test
--

ALTER TABLE ONLY dbatn_bookmarks ALTER COLUMN idbookmark SET DEFAULT nextval('dbatn_bookmarks_idbookmark_seq'::regclass);


--
-- TOC entry 1593 (class 2606 OID 16847)
-- Name: composite_primary_key_userdays; Type: CONSTRAINT; Schema: public; Owner: absman_test; Tablespace: 
--

ALTER TABLE ONLY dbatn_userdays
    ADD CONSTRAINT composite_primary_key_userdays PRIMARY KEY ("idUser", "intDay", "intMonth", "intYear");


--
-- TOC entry 1597 (class 2606 OID 16939)
-- Name: dbatn_bookmarks_iduser_key; Type: CONSTRAINT; Schema: public; Owner: absman_test; Tablespace: 
--

ALTER TABLE ONLY dbatn_bookmarks
    ADD CONSTRAINT dbatn_bookmarks_iduser_key UNIQUE (iduser, query);


--
-- TOC entry 1599 (class 2606 OID 16937)
-- Name: dbatn_bookmarks_pkey; Type: CONSTRAINT; Schema: public; Owner: absman_test; Tablespace: 
--

ALTER TABLE ONLY dbatn_bookmarks
    ADD CONSTRAINT dbatn_bookmarks_pkey PRIMARY KEY (idbookmark);


--
-- TOC entry 1577 (class 2606 OID 16849)
-- Name: dbatn_department_holidaytemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: absman_test; Tablespace: 
--

ALTER TABLE ONLY dbatn_department_holidaytemplate
    ADD CONSTRAINT dbatn_department_holidaytemplate_pkey PRIMARY KEY (chrdepartment);


--
-- TOC entry 1575 (class 2606 OID 16851)
-- Name: pk_admin_idadmin; Type: CONSTRAINT; Schema: public; Owner: absman_test; Tablespace: 
--

ALTER TABLE ONLY dbatn_admin
    ADD CONSTRAINT pk_admin_idadmin PRIMARY KEY (idadmin);


--
-- TOC entry 1595 (class 2606 OID 16853)
-- Name: primary_idlistuser_userslist; Type: CONSTRAINT; Schema: public; Owner: absman_test; Tablespace: 
--

ALTER TABLE ONLY dbatn_userslist
    ADD CONSTRAINT primary_idlistuser_userslist PRIMARY KEY (iduser);


--
-- TOC entry 1591 (class 2606 OID 16855)
-- Name: project_idproject_pk; Type: CONSTRAINT; Schema: public; Owner: absman_test; Tablespace: 
--

ALTER TABLE ONLY dbatn_projects
    ADD CONSTRAINT project_idproject_pk PRIMARY KEY (idproject);


--
-- TOC entry 1583 (class 1259 OID 16856)
-- Name: FKI_IDPROJECT; Type: INDEX; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE INDEX "FKI_IDPROJECT" ON dbatn_project_department USING btree (idproject);


--
-- TOC entry 1589 (class 1259 OID 16857)
-- Name: FKI_IDPROJECT_PROJECTLIST; Type: INDEX; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE INDEX "FKI_IDPROJECT_PROJECTLIST" ON dbatn_projectlist USING btree (idproject);


--
-- TOC entry 1584 (class 1259 OID 16858)
-- Name: FKI_IDPROJECT_PROJECT_OWNER; Type: INDEX; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE INDEX "FKI_IDPROJECT_PROJECT_OWNER" ON dbatn_project_owner USING btree (idproject);


--
-- TOC entry 1586 (class 1259 OID 16859)
-- Name: FKI_IDPROJECT_PROJECT_PROJECT; Type: INDEX; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE INDEX "FKI_IDPROJECT_PROJECT_PROJECT" ON dbatn_project_project USING btree (idproject);


--
-- TOC entry 1582 (class 1259 OID 16860)
-- Name: FKI_IDUSER; Type: INDEX; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE INDEX "FKI_IDUSER" ON dbatn_personal_settings USING btree (iduser);


--
-- TOC entry 1578 (class 1259 OID 16861)
-- Name: FKI_IDUSER_DEPARTMENT_MANAGER; Type: INDEX; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_DEPARTMENT_MANAGER" ON dbatn_department_manager USING btree (iduser);


--
-- TOC entry 1579 (class 1259 OID 16862)
-- Name: FKI_IDUSER_DEPARTMENT_OWNER; Type: INDEX; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_DEPARTMENT_OWNER" ON dbatn_department_owner USING btree (iduser);


--
-- TOC entry 1580 (class 1259 OID 16863)
-- Name: FKI_IDUSER_DEPARTMENT_SETTINGS1; Type: INDEX; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_DEPARTMENT_SETTINGS1" ON dbatn_department_settings1 USING btree (iduser);


--
-- TOC entry 1581 (class 1259 OID 16864)
-- Name: FKI_IDUSER_DEPARTMENT_SETTINGS2; Type: INDEX; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_DEPARTMENT_SETTINGS2" ON dbatn_department_settings2 USING btree (iduser);


--
-- TOC entry 1585 (class 1259 OID 16865)
-- Name: FKI_IDUSER_PROJECT_OWNER; Type: INDEX; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_PROJECT_OWNER" ON dbatn_project_owner USING btree (iduser);


--
-- TOC entry 1587 (class 1259 OID 16866)
-- Name: FKI_IDUSER_PROJECT_SETTINGS1; Type: INDEX; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_PROJECT_SETTINGS1" ON dbatn_project_settings1 USING btree (iduser);


--
-- TOC entry 1588 (class 1259 OID 16867)
-- Name: FKI_IDUSER_PROJECT_SETTINGS2; Type: INDEX; Schema: public; Owner: absman_test; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_PROJECT_SETTINGS2" ON dbatn_project_settings2 USING btree (iduser);


--
-- TOC entry 1604 (class 2606 OID 16868)
-- Name: FK_IDPROJECT; Type: FK CONSTRAINT; Schema: public; Owner: absman_test
--

ALTER TABLE ONLY dbatn_project_department
    ADD CONSTRAINT "FK_IDPROJECT" FOREIGN KEY (idproject) REFERENCES dbatn_projects(idproject);


--
-- TOC entry 1610 (class 2606 OID 16873)
-- Name: FK_IDPROJECT_PROJECTLIST; Type: FK CONSTRAINT; Schema: public; Owner: absman_test
--

ALTER TABLE ONLY dbatn_projectlist
    ADD CONSTRAINT "FK_IDPROJECT_PROJECTLIST" FOREIGN KEY (idproject) REFERENCES dbatn_projects(idproject);


--
-- TOC entry 1605 (class 2606 OID 16878)
-- Name: FK_IDPROJECT_PROJECT_OWNER; Type: FK CONSTRAINT; Schema: public; Owner: absman_test
--

ALTER TABLE ONLY dbatn_project_owner
    ADD CONSTRAINT "FK_IDPROJECT_PROJECT_OWNER" FOREIGN KEY (idproject) REFERENCES dbatn_projects(idproject);


--
-- TOC entry 1607 (class 2606 OID 16883)
-- Name: FK_IDPROJECT_PROJECT_PROJECT; Type: FK CONSTRAINT; Schema: public; Owner: absman_test
--

ALTER TABLE ONLY dbatn_project_project
    ADD CONSTRAINT "FK_IDPROJECT_PROJECT_PROJECT" FOREIGN KEY (idproject) REFERENCES dbatn_projects(idproject);


--
-- TOC entry 1600 (class 2606 OID 16893)
-- Name: FK_IDUSER_DEPARTMENT_MANAGER; Type: FK CONSTRAINT; Schema: public; Owner: absman_test
--

ALTER TABLE ONLY dbatn_department_manager
    ADD CONSTRAINT "FK_IDUSER_DEPARTMENT_MANAGER" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- TOC entry 1601 (class 2606 OID 16898)
-- Name: FK_IDUSER_DEPARTMENT_OWNER; Type: FK CONSTRAINT; Schema: public; Owner: absman_test
--

ALTER TABLE ONLY dbatn_department_owner
    ADD CONSTRAINT "FK_IDUSER_DEPARTMENT_OWNER" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- TOC entry 1602 (class 2606 OID 16903)
-- Name: FK_IDUSER_DEPARTMENT_SETTINGS1; Type: FK CONSTRAINT; Schema: public; Owner: absman_test
--

ALTER TABLE ONLY dbatn_department_settings1
    ADD CONSTRAINT "FK_IDUSER_DEPARTMENT_SETTINGS1" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- TOC entry 1603 (class 2606 OID 16908)
-- Name: FK_IDUSER_DEPARTMENT_SETTINGS2; Type: FK CONSTRAINT; Schema: public; Owner: absman_test
--

ALTER TABLE ONLY dbatn_department_settings2
    ADD CONSTRAINT "FK_IDUSER_DEPARTMENT_SETTINGS2" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- TOC entry 1606 (class 2606 OID 16913)
-- Name: FK_IDUSER_PROJECT_OWNER; Type: FK CONSTRAINT; Schema: public; Owner: absman_test
--

ALTER TABLE ONLY dbatn_project_owner
    ADD CONSTRAINT "FK_IDUSER_PROJECT_OWNER" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- TOC entry 1608 (class 2606 OID 16918)
-- Name: FK_IDUSER_PROJECT_SETTINGS1; Type: FK CONSTRAINT; Schema: public; Owner: absman_test
--

ALTER TABLE ONLY dbatn_project_settings1
    ADD CONSTRAINT "FK_IDUSER_PROJECT_SETTINGS1" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- TOC entry 1609 (class 2606 OID 16923)
-- Name: FK_IDUSER_PROJECT_SETTINGS2; Type: FK CONSTRAINT; Schema: public; Owner: absman_test
--

ALTER TABLE ONLY dbatn_project_settings2
    ADD CONSTRAINT "FK_IDUSER_PROJECT_SETTINGS2" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- TOC entry 1611 (class 2606 OID 16940)
-- Name: dbatn_bookmarks_iduser_fkey; Type: FK CONSTRAINT; Schema: public; Owner: absman_test
--

ALTER TABLE ONLY dbatn_bookmarks
    ADD CONSTRAINT dbatn_bookmarks_iduser_fkey FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- TOC entry 1612 (class 2606 OID 16947)
-- Name: dbatn_project_subprojects_idproject_fkey; Type: FK CONSTRAINT; Schema: public; Owner: absman_test
--

ALTER TABLE ONLY dbatn_project_subprojects
    ADD CONSTRAINT dbatn_project_subprojects_idproject_fkey FOREIGN KEY (idproject) REFERENCES dbatn_projects(idproject);


--
-- TOC entry 1613 (class 2606 OID 16952)
-- Name: dbatn_project_subprojects_idsubproject_fkey; Type: FK CONSTRAINT; Schema: public; Owner: absman_test
--

ALTER TABLE ONLY dbatn_project_subprojects
    ADD CONSTRAINT dbatn_project_subprojects_idsubproject_fkey FOREIGN KEY (idsubproject) REFERENCES dbatn_projects(idproject);


--
-- TOC entry 1647 (class 0 OID 0)
-- Dependencies: 4
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;

INSERT INTO dbatn_admin(
            idadmin, uid, pwd, email)
    VALUES ('1', 'admin', 'adminpassword', 'admin@ericsson.com');


-- Completed on 2013-06-13 16:41:14

--
-- PostgreSQL database dump complete
--

