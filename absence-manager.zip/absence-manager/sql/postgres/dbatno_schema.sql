--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: dbatn_admin; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_admin (
    idadmin integer NOT NULL,
    uid character varying(50),
    pwd character varying,
    email character varying(250)
);


ALTER TABLE public.dbatn_admin OWNER TO absencemanager;

--
-- Name: dbatn_department_department; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_department_department (
    chrdepartment character varying(250) NOT NULL,
    chrdepartmentallwoed character varying(250) NOT NULL
);


ALTER TABLE public.dbatn_department_department OWNER TO absencemanager;

--
-- Name: dbatn_department_email_settings; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_department_email_settings (
    chrdepartment character varying(250) NOT NULL,
    intemailrequired integer DEFAULT 1 NOT NULL,
    chrconfirmationmsg text,
    chrreplymsg text,
    intautoapprove integer DEFAULT 0
);


ALTER TABLE public.dbatn_department_email_settings OWNER TO absencemanager;

--
-- Name: dbatn_department_manager; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_department_manager (
    iduser integer,
    chrdepartment character varying(250)
);


ALTER TABLE public.dbatn_department_manager OWNER TO absencemanager;

--
-- Name: dbatn_department_owner; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_department_owner (
    iduser integer NOT NULL,
    chrdepartment character varying(250) NOT NULL
);


ALTER TABLE public.dbatn_department_owner OWNER TO absencemanager;

--
-- Name: dbatn_department_project; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_department_project (
    chrdepartment character varying(250),
    chrprojectallowed character varying(250)
);


ALTER TABLE public.dbatn_department_project OWNER TO absencemanager;

--
-- Name: dbatn_department_settings1; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_department_settings1 (
    iduser integer,
    department character varying(100)
);


ALTER TABLE public.dbatn_department_settings1 OWNER TO absencemanager;

--
-- Name: dbatn_department_settings2; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_department_settings2 (
    iduser integer,
    intcol integer
);


ALTER TABLE public.dbatn_department_settings2 OWNER TO absencemanager;

--
-- Name: dbatn_personal_settings; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_personal_settings (
    blnconfirm integer DEFAULT 0,
    blnresponse integer DEFAULT 0,
    blnadvanceuser smallint DEFAULT 0,
    iduser integer DEFAULT 0,
    intstartpage smallint DEFAULT 1
);


ALTER TABLE public.dbatn_personal_settings OWNER TO absencemanager;

--
-- Name: dbatn_project_department; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_project_department (
    idproject integer,
    chrdepartmentallwoed character varying(250)
);


ALTER TABLE public.dbatn_project_department OWNER TO absencemanager;

--
-- Name: dbatn_project_owner; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_project_owner (
    iduser integer,
    idproject integer
);


ALTER TABLE public.dbatn_project_owner OWNER TO absencemanager;

--
-- Name: dbatn_project_project; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_project_project (
    idproject integer,
    chrprojectallowed character varying(250)
);


ALTER TABLE public.dbatn_project_project OWNER TO absencemanager;

--
-- Name: dbatn_project_settings1; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_project_settings1 (
    iduser integer,
    project character varying(100)
);


ALTER TABLE public.dbatn_project_settings1 OWNER TO absencemanager;

--
-- Name: dbatn_project_settings2; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_project_settings2 (
    iduser integer,
    intcol integer
);


ALTER TABLE public.dbatn_project_settings2 OWNER TO absencemanager;

--
-- Name: dbatn_projectlist; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_projectlist (
    idproject integer,
    iduser integer,
    chrproject character varying(50)
);


ALTER TABLE public.dbatn_projectlist OWNER TO absencemanager;

--
-- Name: dbatn_projects; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_projects (
    idproject integer NOT NULL,
    chrproject character varying(50),
    idcreatedby integer,
    intdate integer,
    idupdatedby integer,
    intdateupdated integer
);


ALTER TABLE public.dbatn_projects OWNER TO absencemanager;

--
-- Name: dbatn_userdays; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_userdays (
    "idUser" integer NOT NULL,
    "intDay" integer NOT NULL,
    "intMonth" integer NOT NULL,
    "intYear" integer NOT NULL,
    "chrCharacter" character varying(2),
    "chrComments" character varying(250),
    "intApproved" integer DEFAULT 0,
    "chrComments2" character varying(250),
    inttime integer,
    blnapproved integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.dbatn_userdays OWNER TO absencemanager;

--
-- Name: dbatn_userslist; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE dbatn_userslist (
    iduser integer NOT NULL,
    dn character varying(250),
    name character varying(250),
    department character varying(250),
    city character varying(250),
    erelation character varying(250),
    phone character varying(50),
    title character(100),
    email character varying(100),
    mdept character varying(100),
    sdept character varying(100),
    uid character varying(100)
);


ALTER TABLE public.dbatn_userslist OWNER TO absencemanager;

--
-- Name: seq_iddepartment_departments; Type: SEQUENCE; Schema: public; Owner: absencemanager
--

CREATE SEQUENCE seq_iddepartment_departments
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.seq_iddepartment_departments OWNER TO absencemanager;

--
-- Name: seq_idlist_lists; Type: SEQUENCE; Schema: public; Owner: absencemanager
--

CREATE SEQUENCE seq_idlist_lists
    START WITH 139
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.seq_idlist_lists OWNER TO absencemanager;

--
-- Name: seq_idproject_projects; Type: SEQUENCE; Schema: public; Owner: absencemanager
--

CREATE SEQUENCE seq_idproject_projects
    START WITH 93
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.seq_idproject_projects OWNER TO absencemanager;

--
-- Name: seq_iduser_userinfo; Type: SEQUENCE; Schema: public; Owner: absencemanager
--

CREATE SEQUENCE seq_iduser_userinfo
    START WITH 13
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.seq_iduser_userinfo OWNER TO absencemanager;

--
-- Name: SEQUENCE seq_iduser_userinfo; Type: COMMENT; Schema: public; Owner: absencemanager
--

COMMENT ON SEQUENCE seq_iduser_userinfo IS 'hi man';


--
-- Name: tmp_sent_email_log; Type: TABLE; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE TABLE tmp_sent_email_log (
    chrto text,
    chrfrom text,
    chrsubject text,
    chrbody text,
    intdate bigint DEFAULT 0,
    chrheader text
);


ALTER TABLE public.tmp_sent_email_log OWNER TO absencemanager;

--
-- Name: TABLE tmp_sent_email_log; Type: COMMENT; Schema: public; Owner: absencemanager
--

COMMENT ON TABLE tmp_sent_email_log IS 'This table is only for testing purpose, and will be deleted, once application is complete';


--
-- Name: composite_primary_key_userdays; Type: CONSTRAINT; Schema: public; Owner: absencemanager; Tablespace: 
--

ALTER TABLE ONLY dbatn_userdays
    ADD CONSTRAINT composite_primary_key_userdays PRIMARY KEY ("idUser", "intDay", "intMonth", "intYear");


--
-- Name: pk_admin_idadmin; Type: CONSTRAINT; Schema: public; Owner: absencemanager; Tablespace: 
--

ALTER TABLE ONLY dbatn_admin
    ADD CONSTRAINT pk_admin_idadmin PRIMARY KEY (idadmin);


--
-- Name: primary_idlistuser_userslist; Type: CONSTRAINT; Schema: public; Owner: absencemanager; Tablespace: 
--

ALTER TABLE ONLY dbatn_userslist
    ADD CONSTRAINT primary_idlistuser_userslist PRIMARY KEY (iduser);


--
-- Name: project_idproject_pk; Type: CONSTRAINT; Schema: public; Owner: absencemanager; Tablespace: 
--

ALTER TABLE ONLY dbatn_projects
    ADD CONSTRAINT project_idproject_pk PRIMARY KEY (idproject);


--
-- Name: FKI_IDPROJECT; Type: INDEX; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE INDEX "FKI_IDPROJECT" ON dbatn_project_department USING btree (idproject);


--
-- Name: FKI_IDPROJECT_PROJECTLIST; Type: INDEX; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE INDEX "FKI_IDPROJECT_PROJECTLIST" ON dbatn_projectlist USING btree (idproject);


--
-- Name: FKI_IDPROJECT_PROJECT_OWNER; Type: INDEX; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE INDEX "FKI_IDPROJECT_PROJECT_OWNER" ON dbatn_project_owner USING btree (idproject);


--
-- Name: FKI_IDPROJECT_PROJECT_PROJECT; Type: INDEX; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE INDEX "FKI_IDPROJECT_PROJECT_PROJECT" ON dbatn_project_project USING btree (idproject);


--
-- Name: FKI_IDUSER; Type: INDEX; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE INDEX "FKI_IDUSER" ON dbatn_personal_settings USING btree (iduser);


--
-- Name: FKI_IDUSER_DEPARTMENT_MANAGER; Type: INDEX; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_DEPARTMENT_MANAGER" ON dbatn_department_manager USING btree (iduser);


--
-- Name: FKI_IDUSER_DEPARTMENT_OWNER; Type: INDEX; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_DEPARTMENT_OWNER" ON dbatn_department_owner USING btree (iduser);


--
-- Name: FKI_IDUSER_DEPARTMENT_SETTINGS1; Type: INDEX; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_DEPARTMENT_SETTINGS1" ON dbatn_department_settings1 USING btree (iduser);


--
-- Name: FKI_IDUSER_DEPARTMENT_SETTINGS2; Type: INDEX; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_DEPARTMENT_SETTINGS2" ON dbatn_department_settings2 USING btree (iduser);


--
-- Name: FKI_IDUSER_PROJECT_OWNER; Type: INDEX; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_PROJECT_OWNER" ON dbatn_project_owner USING btree (iduser);


--
-- Name: FKI_IDUSER_PROJECT_SETTINGS1; Type: INDEX; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_PROJECT_SETTINGS1" ON dbatn_project_settings1 USING btree (iduser);


--
-- Name: FKI_IDUSER_PROJECT_SETTINGS2; Type: INDEX; Schema: public; Owner: absencemanager; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_PROJECT_SETTINGS2" ON dbatn_project_settings2 USING btree (iduser);


--
-- Name: FK_IDPROJECT; Type: FK CONSTRAINT; Schema: public; Owner: absencemanager
--

ALTER TABLE ONLY dbatn_project_department
    ADD CONSTRAINT "FK_IDPROJECT" FOREIGN KEY (idproject) REFERENCES dbatn_projects(idproject);


--
-- Name: FK_IDPROJECT_PROJECTLIST; Type: FK CONSTRAINT; Schema: public; Owner: absencemanager
--

ALTER TABLE ONLY dbatn_projectlist
    ADD CONSTRAINT "FK_IDPROJECT_PROJECTLIST" FOREIGN KEY (idproject) REFERENCES dbatn_projects(idproject);


--
-- Name: FK_IDPROJECT_PROJECT_OWNER; Type: FK CONSTRAINT; Schema: public; Owner: absencemanager
--

ALTER TABLE ONLY dbatn_project_owner
    ADD CONSTRAINT "FK_IDPROJECT_PROJECT_OWNER" FOREIGN KEY (idproject) REFERENCES dbatn_projects(idproject);


--
-- Name: FK_IDPROJECT_PROJECT_PROJECT; Type: FK CONSTRAINT; Schema: public; Owner: absencemanager
--

ALTER TABLE ONLY dbatn_project_project
    ADD CONSTRAINT "FK_IDPROJECT_PROJECT_PROJECT" FOREIGN KEY (idproject) REFERENCES dbatn_projects(idproject);


--
-- Name: FK_IDUSER; Type: FK CONSTRAINT; Schema: public; Owner: absencemanager
--

ALTER TABLE ONLY dbatn_personal_settings
    ADD CONSTRAINT "FK_IDUSER" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- Name: FK_IDUSER_DEPARTMENT_MANAGER; Type: FK CONSTRAINT; Schema: public; Owner: absencemanager
--

ALTER TABLE ONLY dbatn_department_manager
    ADD CONSTRAINT "FK_IDUSER_DEPARTMENT_MANAGER" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- Name: FK_IDUSER_DEPARTMENT_OWNER; Type: FK CONSTRAINT; Schema: public; Owner: absencemanager
--

ALTER TABLE ONLY dbatn_department_owner
    ADD CONSTRAINT "FK_IDUSER_DEPARTMENT_OWNER" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- Name: FK_IDUSER_DEPARTMENT_SETTINGS1; Type: FK CONSTRAINT; Schema: public; Owner: absencemanager
--

ALTER TABLE ONLY dbatn_department_settings1
    ADD CONSTRAINT "FK_IDUSER_DEPARTMENT_SETTINGS1" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- Name: FK_IDUSER_DEPARTMENT_SETTINGS2; Type: FK CONSTRAINT; Schema: public; Owner: absencemanager
--

ALTER TABLE ONLY dbatn_department_settings2
    ADD CONSTRAINT "FK_IDUSER_DEPARTMENT_SETTINGS2" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- Name: FK_IDUSER_PROJECT_OWNER; Type: FK CONSTRAINT; Schema: public; Owner: absencemanager
--

ALTER TABLE ONLY dbatn_project_owner
    ADD CONSTRAINT "FK_IDUSER_PROJECT_OWNER" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- Name: FK_IDUSER_PROJECT_SETTINGS1; Type: FK CONSTRAINT; Schema: public; Owner: absencemanager
--

ALTER TABLE ONLY dbatn_project_settings1
    ADD CONSTRAINT "FK_IDUSER_PROJECT_SETTINGS1" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- Name: FK_IDUSER_PROJECT_SETTINGS2; Type: FK CONSTRAINT; Schema: public; Owner: absencemanager
--

ALTER TABLE ONLY dbatn_project_settings2
    ADD CONSTRAINT "FK_IDUSER_PROJECT_SETTINGS2" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- Name: public; Type: ACL; Schema: -; Owner: tool
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM tool;
GRANT ALL ON SCHEMA public TO tool;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: dbatn_admin; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON TABLE dbatn_admin FROM PUBLIC;
REVOKE ALL ON TABLE dbatn_admin FROM absencemanager;
GRANT ALL ON TABLE dbatn_admin TO absencemanager;
GRANT ALL ON TABLE dbatn_admin TO PUBLIC;


--
-- Name: dbatn_department_department; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON TABLE dbatn_department_department FROM PUBLIC;
REVOKE ALL ON TABLE dbatn_department_department FROM absencemanager;
GRANT ALL ON TABLE dbatn_department_department TO absencemanager;
GRANT ALL ON TABLE dbatn_department_department TO PUBLIC;


--
-- Name: dbatn_department_email_settings; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON TABLE dbatn_department_email_settings FROM PUBLIC;
REVOKE ALL ON TABLE dbatn_department_email_settings FROM absencemanager;
GRANT ALL ON TABLE dbatn_department_email_settings TO absencemanager;
GRANT ALL ON TABLE dbatn_department_email_settings TO PUBLIC;


--
-- Name: dbatn_department_manager; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON TABLE dbatn_department_manager FROM PUBLIC;
REVOKE ALL ON TABLE dbatn_department_manager FROM absencemanager;
GRANT ALL ON TABLE dbatn_department_manager TO absencemanager;
GRANT ALL ON TABLE dbatn_department_manager TO PUBLIC;


--
-- Name: dbatn_department_owner; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON TABLE dbatn_department_owner FROM PUBLIC;
REVOKE ALL ON TABLE dbatn_department_owner FROM absencemanager;
GRANT ALL ON TABLE dbatn_department_owner TO absencemanager;
GRANT ALL ON TABLE dbatn_department_owner TO PUBLIC;


--
-- Name: dbatn_department_project; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON TABLE dbatn_department_project FROM PUBLIC;
REVOKE ALL ON TABLE dbatn_department_project FROM absencemanager;
GRANT ALL ON TABLE dbatn_department_project TO absencemanager;
GRANT ALL ON TABLE dbatn_department_project TO PUBLIC;


--
-- Name: dbatn_department_settings2; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON TABLE dbatn_department_settings2 FROM PUBLIC;
REVOKE ALL ON TABLE dbatn_department_settings2 FROM absencemanager;
GRANT ALL ON TABLE dbatn_department_settings2 TO absencemanager;
GRANT ALL ON TABLE dbatn_department_settings2 TO PUBLIC;


--
-- Name: dbatn_personal_settings; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON TABLE dbatn_personal_settings FROM PUBLIC;
REVOKE ALL ON TABLE dbatn_personal_settings FROM absencemanager;
GRANT ALL ON TABLE dbatn_personal_settings TO absencemanager;
GRANT ALL ON TABLE dbatn_personal_settings TO PUBLIC;


--
-- Name: dbatn_project_department; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON TABLE dbatn_project_department FROM PUBLIC;
REVOKE ALL ON TABLE dbatn_project_department FROM absencemanager;
GRANT ALL ON TABLE dbatn_project_department TO absencemanager;
GRANT ALL ON TABLE dbatn_project_department TO PUBLIC;


--
-- Name: dbatn_project_owner; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON TABLE dbatn_project_owner FROM PUBLIC;
REVOKE ALL ON TABLE dbatn_project_owner FROM absencemanager;
GRANT ALL ON TABLE dbatn_project_owner TO absencemanager;
GRANT ALL ON TABLE dbatn_project_owner TO PUBLIC;


--
-- Name: dbatn_project_project; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON TABLE dbatn_project_project FROM PUBLIC;
REVOKE ALL ON TABLE dbatn_project_project FROM absencemanager;
GRANT ALL ON TABLE dbatn_project_project TO absencemanager;
GRANT ALL ON TABLE dbatn_project_project TO PUBLIC;


--
-- Name: dbatn_project_settings2; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON TABLE dbatn_project_settings2 FROM PUBLIC;
REVOKE ALL ON TABLE dbatn_project_settings2 FROM absencemanager;
GRANT ALL ON TABLE dbatn_project_settings2 TO absencemanager;
GRANT ALL ON TABLE dbatn_project_settings2 TO PUBLIC;


--
-- Name: dbatn_projectlist; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON TABLE dbatn_projectlist FROM PUBLIC;
REVOKE ALL ON TABLE dbatn_projectlist FROM absencemanager;
GRANT ALL ON TABLE dbatn_projectlist TO absencemanager;
GRANT ALL ON TABLE dbatn_projectlist TO PUBLIC;


--
-- Name: dbatn_projects; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON TABLE dbatn_projects FROM PUBLIC;
REVOKE ALL ON TABLE dbatn_projects FROM absencemanager;
GRANT ALL ON TABLE dbatn_projects TO absencemanager;
GRANT ALL ON TABLE dbatn_projects TO PUBLIC;


--
-- Name: dbatn_userdays; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON TABLE dbatn_userdays FROM PUBLIC;
REVOKE ALL ON TABLE dbatn_userdays FROM absencemanager;
GRANT ALL ON TABLE dbatn_userdays TO absencemanager;
GRANT SELECT,INSERT,REFERENCES,UPDATE ON TABLE dbatn_userdays TO PUBLIC;


--
-- Name: dbatn_userslist; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON TABLE dbatn_userslist FROM PUBLIC;
REVOKE ALL ON TABLE dbatn_userslist FROM absencemanager;
GRANT ALL ON TABLE dbatn_userslist TO absencemanager;
GRANT ALL ON TABLE dbatn_userslist TO PUBLIC;


--
-- Name: seq_iddepartment_departments; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON SEQUENCE seq_iddepartment_departments FROM PUBLIC;
REVOKE ALL ON SEQUENCE seq_iddepartment_departments FROM absencemanager;
GRANT ALL ON SEQUENCE seq_iddepartment_departments TO absencemanager;
GRANT ALL ON SEQUENCE seq_iddepartment_departments TO PUBLIC;


--
-- Name: seq_idlist_lists; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON SEQUENCE seq_idlist_lists FROM PUBLIC;
REVOKE ALL ON SEQUENCE seq_idlist_lists FROM absencemanager;
GRANT ALL ON SEQUENCE seq_idlist_lists TO absencemanager;
GRANT ALL ON SEQUENCE seq_idlist_lists TO PUBLIC;


--
-- Name: seq_idproject_projects; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON SEQUENCE seq_idproject_projects FROM PUBLIC;
REVOKE ALL ON SEQUENCE seq_idproject_projects FROM absencemanager;
GRANT ALL ON SEQUENCE seq_idproject_projects TO absencemanager;
GRANT ALL ON SEQUENCE seq_idproject_projects TO PUBLIC;


--
-- Name: seq_iduser_userinfo; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON SEQUENCE seq_iduser_userinfo FROM PUBLIC;
REVOKE ALL ON SEQUENCE seq_iduser_userinfo FROM absencemanager;
GRANT ALL ON SEQUENCE seq_iduser_userinfo TO absencemanager;
GRANT ALL ON SEQUENCE seq_iduser_userinfo TO PUBLIC;


--
-- Name: tmp_sent_email_log; Type: ACL; Schema: public; Owner: absencemanager
--

REVOKE ALL ON TABLE tmp_sent_email_log FROM PUBLIC;
REVOKE ALL ON TABLE tmp_sent_email_log FROM absencemanager;
GRANT ALL ON TABLE tmp_sent_email_log TO absencemanager;
GRANT ALL ON TABLE tmp_sent_email_log TO PUBLIC;


--
-- PostgreSQL database dump complete
--

