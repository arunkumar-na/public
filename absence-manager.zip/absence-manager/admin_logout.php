<?php
	/**
	 * Simply logout admin user, and will make him normal user
	 */
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");

	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	$objSession->setAdministratorUser(false);
	header("location: index.php");
?>
