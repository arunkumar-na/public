<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");

	/** Create session object and try to load user info (id name etc from session) **/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		if ($_REQUEST["ldaplogin"]==1){
			echo "Session has timed out";
			header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
			exit();
		}
		#header("location: ldap_do_login.php?loginid=".$_REQUEST["loginid"]."&requrl=".$_SERVER['REQUEST_URI']);
		#exit();
	}

	$title = 'View Group Structure';	
	header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle($title); ?></title>
		<?php echo generateScripts(); ?>
		<script type="text/javascript" src="media/js/project_flow.js" charset="UTF-8"></script>
	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar">
					<img src="media/images/search.png" />&nbsp;
					<span class="pageheading"><?php echo safeHTML($title); ?></span>
				</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  	<tr>
    	<td valign="top" bgcolor="#505050" height="100%" width="30%">
    		<table cellpadding="0" cellspacing="" width="100%">
        		<tr>
          			<td bgcolor="#505050">&nbsp;</td>
            		<td class="workareaBox" valign="top">
					<!-- ##################################	Working Area START ################################# -->
        				<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="1">
        					<!-- InstanceBeginEditable name="subheader section" -->
				  			<!-- InstanceEndEditable -->
      						<tr>
        						<td height="100%">				<!-- _____Contents START_____ -->
									<div id="workingDiv" style="width:100%;height:<?php echo CALENDAR_HEIGHT ?>">
										<table bgcolor="#505050" width="100%" height="100%" >
											<tr>
												<td style="padding-top:5px;"><!-- InstanceBeginEditable name="working-area" -->													
													<form name="frm2" method="post" action="view_project_flow.php">
														<table cellspacing="0" cellpadding="2" width="98%" height="100%"  class='gridData1'>
															<tr>															
																<td class="gridHead">&nbsp;&nbsp; Select Group: </td>
															</tr>
															<tr>
															<td>
															<div style="height: 500px; overflow: auto;">
															<table>
															<?php
																//$iduser = $objSession->getIdUser();
																#get all the available projects
																$projquery="SELECT idproject,chrproject FROM dbatn_projects ORDER BY chrproject";																
																
																$rs = mazDb_query_params($projquery, array());
																
																#fetch the rows if they exist
																if (mazdb_num_rows($rs) > 0)
																{
																	while($arr = mazDb_fetch_array($rs))
																	{	
																		
																		$name = $arr['chrproject'];
																		$id = $arr['idproject'];
																		echo "<tr><td class='gridData1' style='padding:2px'><input type='radio'";
																		if(isset($_POST['show']) && $_POST['sel_proj_id'] == $id ) {
																			echo "checked='checked'";
																		}
																		echo "name='sel_proj_id' value='$id'>$name</td></tr>";
																	}																																									
																}																	
															?>
															</table>
															</div>
															</td>
															</tr>
															<tr>
																<td><input name='show' type='submit' value='Show Structure'></td>
															</tr>	
														</table>
													</form> 
												</td>
											</tr>
										</table>
									</div>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
		<td valign="top">

			<?php
				#show the project structure if the show structure button is selected
				if (isset($_POST['show']) && $_POST['sel_proj_id']!=NULL) {
				
					echo "<form name='proj_struct_form' action='view_project_calendar.php' method='post'>";
					echo '<input type="hidden" name="chrAction" id="chrAction" value="single" />';
					echo '<input type="hidden" name="chrProject" id="chrProject" value="" />';
					$parentid = $_POST['sel_proj_id'];
					
					#get the project selected
					$namequery = "SELECT chrproject FROM dbatn_projects WHERE idproject = $parentid";
					$rs2 = mazDb_query_params($namequery, array());
					$arr2 = mazDb_fetch_array($rs2);
					echo '<ul>';
					echo '<li class="tree">';
					echo '<div class="closed"><img src="media/images/buttonDown_On.png" /></div>';
					echo '<div class="open"><img src="media/images/buttonUp_On.png" /></div>';
					echo "<div class='name'>";
					echo '<a href="#" onclick="submitProjStructForm(\''.$arr2['chrproject'].'\')"><u>'.$arr2['chrproject'].'</u></font></a>';
					echo '</div>';
					echo "<div class='child_projects'>";
					echo '<ul>';
					
					#get the group structure
					findsubtree($parentid);
					echo '</ul>';
					echo "</div>";
					echo '</li>';
					echo '</ul>';
					echo '</form>';
				}
			?>
		</td>
	</tr>
</table>	
			</div>
		</div>
		<?php echo generateFooter(); ?>
	</body>
</html>
