<?php

    $spBaseUrl = 'https://absencemanager-uat.internal.ericsson.com/'; //or http://<your_domain>

    $settingsInfo = array (
        'sp' => array (
            'entityId' => $spBaseUrl.'/metadata.php',
            'assertionConsumerService' => array (
                'url' => $spBaseUrl.'/index.php?acs',
            ),
            'singleLogoutService' => array (
                'url' => $spBaseUrl.'/index.php?sls',
            ),
            'NameIDFormat' => 'urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified',
        ),
        'idp' => array (
            'entityId' => '',
            'singleSignOnService' => array (
                'url' => '',
            ),
            'singleLogoutService' => array (
                'url' => '',
            ),
            'x509cert' => '',
        ),
    );
