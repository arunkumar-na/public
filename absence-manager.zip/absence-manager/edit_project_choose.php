<?php
session_start();

include_once("include/site/settings.php");
include_once("include/site/db.php");
include_once("include/ldapfunc.php");
include_once("include/utilfunc.php");
include_once("include/cmazsession.php");
include_once("include/common.php");
include_once("include/menu.php");
include_once("include/page.php");
include_once("include/model.php");
include_once("include/usersync.php");
include_once("include/template.php");

/** Create session object and try to load user info (id name etc from session) **/
$objSession = new cMazSession();
$objSession->loadFromSessionToken();
$iduser = $objSession->getIdUser();	

	# check if user is logged in
if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
	header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
		#redirect('ldap_do_login.php');
}

	//Get the projects that the users owns
	$projectsArr = array(); //For searching
	$projectsHTML = "";
	$disabled = "disabled";

	if($objSession->isAdminUser() == true) {
		//If user is logged in as admin, list all projects for editing
		$chrQuery = "SELECT dbatn_projects.chrproject, dbatn_projects.isgroup FROM dbatn_projects;";
	} else {
		//List all users projects/groups for editing
		$chrQuery = "SELECT dbatn_projects.chrproject, dbatn_projects.isgroup FROM dbatn_projects INNER JOIN dbatn_project_owner
		ON
		dbatn_project_owner.idproject=dbatn_projects.idproject
		WHERE iduser=$iduser;";
	}

	//Create html code of all the results
	$rs = mazDb_query_params($chrQuery, array());											
	if (mazDb_num_rows($rs) > 0) {
		while($arr = mazDb_fetch_array($rs)){
			// make the strings use safeHTML, enabeling to show the HTML tags in project and groups name
			$safeHTMLName = script_safe($arr['chrproject']);
			$safeHTMLName = str_replace('"', "'", $safeHTMLName);

			$safeHTMLType = script_safe($arr['chrproject'].$type);
			$safeHTMLType = str_replace('"', "'", $safeHTMLType);

			// see if the current content is group or project, t == true
			if ($arr['isgroup'] == "t"){
				$projectsHTML .= "<option value='".$safeHTMLName."'>".$safeHTMLType." (group)</option>";
			}
			else {
				$projectsHTML .= "<option value='".$safeHTMLName."'>".$safeHTMLType." (project)</option>";
			}
			$projectsArr[$arr['chrproject']] = array($safeHTMLType, $arr['isgroup']);
		}
		$disabled = "";
	} else {
		$projectsHTML = "<option>You do not own any projects</option>";
	}
	//Check if delete
	if(isset($_REQUEST['chrAction']) && $_REQUEST['chrAction'] == "delete_proj") {
		$msg = deleteProject($_REQUEST['chrProject'], $objSession);
		header("location: edit_project_choose.php?msg=".$msg);
		exit();	
	}


	header('Content-Type: text/html; charset=utf-8');
	?>

	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Edit project/group</title>
		<?php echo generateScripts(); ?>
		<script type="text/javascript">
		var projectsArr = <?php echo json_encode($projectsArr); ?>;
		var formIsValid = false;

			//this is the new search/filter function for groups and projects
			function searchList(filterId, listId, data) {

				$('#'+filterId).keyup(function () {
					var filter = htmlEntities($(this).val().toLowerCase(), 'UTF-8');
					var filtered = [];					
					for (key in data) {
						var val = data[key][0];
						var isGroup = data[key][1];
						if (val && val.toLowerCase().indexOf(filter) !== -1) {
							if (isGroup == "t") {
								option = '<'+'option value="'+key+'">'+val+' (group)<'+'/option>';
							}
							else {
								option = '<'+'option value="'+key+'">'+val+' (project)<'+'/option>';
							}
							filtered.push(option);
						}
					}

					var list = $('#'+listId);
					list.empty();
					list.append(filtered.join(''));
					
					if (filtered.length > 0) {
						list.val($('#'+listId+' option:first').val());
					}
				});
			}


			$(document).ready(function () {
				searchList('projFilter', 'chrProject', projectsArr);
			});

		   	//Prepare for set edit redirect
		   	function setEdit() {
		   		document.editForm.action = "edit_project.php";
		   		document.editForm.chrAction = 'edit_list';
		   	}

			//Prepare for set ownership redirect
			function setOwnership() {
				document.editForm.action = "edit_ownership.php";
				document.editForm.chrAction = 'edit_ownership';
			}

			function deleteProj(){
				if($('#chrProject option:selected').val() != undefined) {
					if (confirm("Are you sure you want to delete this project/group?"))
					{
						document.editForm.action = "edit_project_choose.php";
						document.editForm.chrAction.value = 'delete_proj';
						document.editForm.submit();
					}
					else {
						return false;
					}
				}
			}
			function validateForm() {
				formIsValid = false;
				if($('#chrProject option:selected').val() != undefined){
					formIsValid = true;
				}
				return formIsValid;
			}
			</script>
		</head>
		<body>
			<?php
			echo generateHeader();
			echo generateMenu($objSession);
			?>
			<div id="content">
				<div id="contentInner">
					<div id="toolbar">
						<img src="media/images/edit.png" />&nbsp;
						<span class"pageHeading">
							<span class="ericssonHeading">Edit Project/Group</span>
						</span>
					</div>
					<div id="contentBody">
						<h2>Choose Project/Group</h2>
						<form name="editForm" id="editForm" action="edit_project.php" method="get" onsubmit="return validateForm();">
							<input type='hidden' value='edit_list' id='chrAction' name='chrAction'>
							<div>
								<div class="left">
									<label for="projFilter">Search:</label>
									<small>Description</small>
								</div>
								<div class="right">
									<input type="text" id="projFilter" autocomplete="off"/><br />
									<select name="chrProject" id="chrProject" size="10" >
										<?php echo $projectsHTML; ?>
									</select><br />
									<input type="submit" value="Edit" onClick="setEdit()" <?php echo $disabled?> />
									<input type="submit" value="Ownership / Read access" onClick="setOwnership()" <?php echo $disabled?> />
									<button type="button" value="Delete" onClick="deleteProj()" style="font-size:10px; height:21px;" <?php echo $disabled?> >Delete</button>
								</div>
								<br />
							</div>
						</form>

					</div>
				</div>
			</div>
			<?php echo generateFooter(); ?>
		</body>
		</html>
