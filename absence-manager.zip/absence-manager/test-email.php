<?php
date_default_timezone_set('Asia/Kolkata');
//$chrFrom = "FROM : Notan Bera<notan.bera@ericsson.com>";
$chrTo = "arunkumar-na@hcl.com";
$chrSubject = "Absence Manager Leave Request";
// To send HTML mail, the Content-type header must be set
$headers = "MIME-Version: 1.0" . "\n";
$headers .= "Content-type:text/html;charset=utf-8" . "\n";

$headers .= "From: no-reply@absencemanager.internal.ericsson.com " . "\n";
// Additional headers
//$headers .= $chrFrom . "\r\n";
// Mail it				
$chrBody = "<html><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
				<body>
					<p>Dear User,</p>
					<h4 style='color:blue;'>Your request for leave has been submitted Successfully!</h4>
				</body>
			</html>";
		
$blnSent = mail($chrTo, $chrSubject, $chrBody, $headers); #MAILTASK:renenable this
echo "Mail Sent.";
//mail('arunkumar-na@hcl.com','Works!','An email has been generated from your localhost, congratulations!');
?> 