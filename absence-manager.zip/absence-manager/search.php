<?php
	session_start();
	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");

	/** Create session object and try to load user info (id name etc from session) **/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		if ($_REQUEST["ldaplogin"]==1){
			echo "Session has timed out";
			header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
			exit();
		}
		#header("location: ldap_do_login.php?loginid=".$_REQUEST["loginid"]."&requrl=".$_SERVER['REQUEST_URI']);
		#exit();
	}

	if (isset($_REQUEST['chrAction'])){
		$title = 'Search Results';
	}
	else {
		$title = 'Search';
	}

	header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle($title); ?></title>
		<?php echo generateScripts(); ?>
		<script type="text/javascript">
			$(document).ready(function () {
				//Change html height to fit the new height (after calendar has been generated)
				$("html").css("height", $('#contentInner').height()+400);
			});
		</script>
	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>
		
		
		<div id="content">
		
												
		
			<div id="contentInner">
				<div id="toolbar">
					<img src="media/images/find_reference2.png" />&nbsp;
					<span class="pageheading"><span class="ericssonHeading"><?php echo safeHTML($title); ?></span></span>
				</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  	<tr>
    	<td valign="top" bgcolor="#505050" height="100%" >
    		<table cellpadding="0" cellspacing="" width="100%">
        		<tr>
          			<td bgcolor="#505050">&nbsp;</td>
            		<td class="workareaBox" valign="top">
    					<!-- ##################################	Working Area START ################################# -->
        				<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="1">
        					<!-- InstanceBeginEditable name="subheader section" -->
				  			<!-- InstanceEndEditable -->
      						<tr>
        						<td height="100%" width="80%">				<!-- _____Contents START_____ -->
								<?php if (!isset($_REQUEST['chrAction']) && !isset($_POST['bkmAction'])) { ?>
            						<div id="workingDiv" style="width:100%; display:inline; height:<?php echo CALENDAR_HEIGHT ?>">
                					<table bgcolor="#505050" width="100%" height="100%" >
                    					<tr>
                        					<td style="padding-top:5px;"><!-- InstanceBeginEditable name="working-area" -->
                            					<form name="frm1" method="post" action="search.php">
                            						<input type="hidden" name="chrAction" id="chrAction" value="search_special" />
                            						<table cellspacing="0" width="100%" bgcolor="#FFFFFF" cellpadding="0" height="100%">
                             							<tr>
                                							<td>
                                    							<table cellspacing="5" width="100%" bgcolor="#FFFFFF" cellpadding="5" border="0">
                              										<tr>
                                										<td class="gridDataSelected" colspan="2"><?php echo $chrDepartment ?></td>
                              										</tr>
                              										<tr>
                              											<td width="20%" class="caption">Search by UID:</td>
                                 										<td width="80%" class="">
                                											<input name="strUid" type="text" />
                                											<span class="critical">Enter multiple values as ; separated</span>
                                										</td>
                              										</tr>																	
                               										<tr>
					                              						<td class="caption">Search by Name:</td>
                                 										<td class="">
                                 											<input name="strName" type="text" id="strName" />
                                    										<span class="critical"> Enter multiple values as ; separated</span>
                                    									</td>
                              										</tr>
																	
                                									<tr>
                              											<td class="caption">Search by Email:</td>
                                 										<td class="">
                                 											<input name="strEmail" type="text" id="strEmail" />
                                    										<span class="critical"> Enter multiple values as ; separated</span>
                                    									</td>
                              										</tr>
                               										<tr>
                              											<td class="caption">Search by Telephone Number:</td>
                                 										<td class="">
                                											<input name="strContact" type="text" />
                                    										<span class="critical"> Enter multiple values as ; separated</span>
                                    									</td>
								                              		</tr>
                                									<tr>
                              											<td class="caption">Search by Relation:</td>
                                 										<td class="submenulink">
                                											<input  name="blnRelationE" type="checkbox" id="blnRelationE" value="E" <?php echo $chrConfirmYes ?> />
                                											<?php echo RELATION_TYPE_E ?>
																			<input type="checkbox"  name="blnRelationN" <?php echo $chrConfrimNo ?> id="blnRelationN" value="X" /> <?php echo RELATION_TYPE_N ?>
																		</td>
                              										</tr>
																	<tr>
																		<td colspan=2>
																			<table style="margin-top:5px">
																				<tr>
																					<td class="caption">Search by City:</td>
																					<td class="caption">Search by DEP/SEC:</td>
																					<td class="caption">Search by Group:</td>                                 									
																				</tr>
																				<tr>
																					<td class="">
																						<?php
																						#$arrCitiesX = get_field_from_ldap("physicaldeliveryofficename");
																						$arrCitiesX = get_cities_from_db();
																						ksort($arrCitiesX);
																						mazSelectControlSearch("sCity",$arrCitiesX,array(),true,true);
																						?>
																					</td>
																					<td class="">
																						<?php
																						$arrDepts = get_departments_from_db();
																						ksort($arrDepts);
																						mazSelectControlSearch("dept",$arrDepts,array(),true,true);
																						?>
																					</td>
																					<td class="">
																						<?php
																						$arrProjs = get_groups_from_db();
																						ksort($arrProjs);
																						mazSelectControlSearch("proj",$arrProjs,array(),true,true); ?>
																					 </td>
																				</tr>   
																			</table>
																		</td>																	
																	</tr>																	
                              										<tr>                              											
                              											<td><br><br><br><br><input type="submit" value="Search Now" /></td>
                              										</tr>
                            									</table>
		                                    				</td>
                                						</tr>
                            						</table>
                            					</form>					<!-- InstanceEndEditable -->
                            				</td>
											
										</tr>
                    				</table>
                					</div>					<!-- _____Contents End_____ -->
                					<?php } else { ?>
				        	<!-- _____Contents START_____ -->
				            	<div id="workingDiv" style="width:100%; display:inline; height:<?php echo CALENDAR_HEIGHT ?>">
				                	<table bgcolor="#505050" width="100%" height="100%" >
				                    	<tr>
				                        	<td style="padding-top:5px;"><!-- InstanceBeginEditable name="working-area" -->
				                              <table cellspacing="0" cellpadding="2" width="98%">
				                              <tr>
				                                <td class="gridHead"> Name <a href="search.php?sopt=1&chrAction"><img src="media/images/sort.png" border="0" /></a></td>
				                                <td class="gridHead"> UID <a href="search.php?sopt=2&chrAction"><img src="media/images/sort.png" border="0" /></a></td>
				                                <td class="gridHead"> Email <a href="search.php?sopt=3&chrAction"><img src="media/images/sort.png" border="0" /></a></td>
				                                <td class="gridHead"> City <a href="search.php?sopt=4&chrAction"><img src="media/images/sort.png" border="0" /></a></td>
				                                <td class="gridHead"> Relation <a href="search.php?sopt=5&chrAction"><img src="media/images/sort.png" border="0" /></a></td>
				                                <td class="gridHead"> Department <a href="search.php?sopt=6&chrAction"><img src="media/images/sort.png" border="0" /></a></td>
				                              </tr>
				                            <?php
				                            # select sorting order
				                            $chrOrderBy = "department";
											  switch($_REQUEST["sopt"]){
											  	case 1:
													$chrOrderBy = "name";
												break;
												case 2:
													$chrOrderBy = "uid";
												break;
												case 3:
													$chrOrderBy = "email";
												break;
												case 4:
													$chrOrderBy = "city";
												break;
												case 5:
													$chrOrderBy = "erelation";
												break;
											  }			
										
										  $arrSearchPart = array();
								#search for uid
										  if ($_REQUEST["strUid"]){
										  	$arrTmp = explode(";",trim(safeDatabase($_REQUEST["strUid"]),";"));
											$intCount = 0;
											#if single is searched then use wild card
											if (sizeof($arrTmp)  == 1 && trim($arrTmp[0])){
												$arrSearchPart[$intCount]["uid"] = "upper(uid) like '%".strtoupper(trim($arrTmp[0]))."%'";
											}
											else if (sizeof($arrTmp) > 0)
											{
												foreach($arrTmp as  $chrValue){
													if (trim($chrValue))
													{
														$chrValue = safeDatabase($chrValue);
														$arrSearchPart[$intCount]["uid"] = "upper(uid)='".strtoupper(trim($chrValue))."'";
														$intCount++;
													}
												}
											}
										  }

								#search for name
										  if ($_REQUEST["strName"]){
										  	$arrTmp = explode(";",trim(safeDatabase($_REQUEST["strName"]),";"));
											$intCount = 0;
											if (sizeof($arrTmp)  == 1 && trim($arrTmp[0])){
												$arrSearchPart[$intCount]["name"] = " upper(name) like upper('%".safeDatabase(trim($arrTmp[0]))."%')";

											}
											else
											{
												foreach($arrTmp as  $chrValue)
												{
													if (trim($chrValue))
													{
														if (trim($chrValue))
														{
															//$arrSearchPart[$intCount]["name"] = "upper(name)='".mb_strtoupper(trim($chrValue))."'";
															$arrSearchPart[$intCount]["name"] = "upper(name) = upper('".safeDatabase(trim($chrValue))."')";
															$intCount++;
														}
													}
												}
											}
										  }
							#search for email address
										  if ($_REQUEST["strEmail"]){
										  	$arrTmp = explode(";",safeDatabase($_REQUEST["strEmail"]));
											$intCount = 0;
											if (sizeof($arrTmp)  == 1 && trim($arrTmp[0])){
												$arrSearchPart[$intCount]["email"] = "upper(email) like '%".strtoupper(trim($arrTmp[0]))."%'";
											}
											else
											{
												foreach($arrTmp as  $chrValue)
												{
													if (trim($chrValue))
													{
														$arrSearchPart[$intCount]["email"] = "upper(email)='".strtoupper(trim($chrValue))."'";
														$intCount++;
													}
												}
											}
										  }
								#search for phone number
										   if ($_REQUEST["strContact"]){
										  	$arrTmp = explode(";",safeDatabase($_REQUEST["strContact"]));
											$intCount = 0;
											foreach($arrTmp as  $chrValue){
												if (trim($chrValue))
												{
													$arrSearchPart[$intCount]["contact"] = "phone='".trim($chrValue)."'";
													$intCount++;
												}
											}
										  }

										foreach($arrSearchPart as $idx=>$arrParts){
											$arrSearchPart[$idx] = "(".implode(" AND ", $arrParts).")";
										}

										#-- Part1
										if (sizeof($arrSearchPart) > 0)
										{
											$arrWhere[] = "(".implode(" OR ",$arrSearchPart).")";
										}

						#search based on relation type
										#-- Part2
										if ($_REQUEST["blnRelationE"] == "E" || $_REQUEST["blnRelationN"] == "X")
										{
											if ($_REQUEST["blnRelationE"] == "E" && $_REQUEST["blnRelationN"] == "X") {
												$arrWhere[] = "(erelation='E' OR erelation='N')";
											}
											else {
												$selectedRelation = ($_REQUEST["blnRelationE"] == "E") ? "E" : "X";
												$arrWhere[] = " erelation='$selectedRelation' ";
											}
										}

						#search for city
										# City
										$intCount = $_REQUEST["sCity_count"];
										$arrCities = array();
										$cityStatement = "";
										for ($i=0; $i < $intCount; $i++){
											if ($_REQUEST["sCity".$i]){
												$arrCities[] = safeDatabase(trim($_REQUEST["sCity".$i]));	
											}
										}
										if (sizeof($arrCities) > 0){
											#-- Part3
											$cityStatement = implode(", ",$arrCities);												
											$arrWhere[] = "city IN ('". implode("', '",$arrCities)."')";
										}

						#search for department
										# Department
										$intCount = $_REQUEST["dept_count"];
										$arrDept = array();
										$deptStatement = "";
										for ($i=0; $i < $intCount; $i++){
											if ($_REQUEST["dept".$i]){
												$arrDept[] = safeDatabase(trim($_REQUEST["dept".$i]));													
											}
										}
										if (sizeof($arrDept) > 0){
											#-- Part4
											$deptStatement = implode(", ",$arrDept);
											$arrWhere[] = "department IN ('".implode("', '",$arrDept)."')";
										}
						#search for project
										# Project
										$intCount = $_REQUEST["proj_count"];
										$arrProj = array();
										$projStatement = "";
										for ($i=0; $i < $intCount; $i++){
											if ($_REQUEST["proj".$i]){
												$arrProj[] = safeDatabase(trim($_REQUEST["proj".$i]));
											}
										}
										$blnProjectUsed = false;
										if (sizeof($arrProj) > 0){
											#-- Part5
											$projStatement = implode(", ",$arrProj);
											$arrWhere[] = "chrproject IN ('".implode("', '",$arrProj)."')";
											$blnProjectUsed = true;
										}


											if (is_array($arrWhere)) {
												$chrWherePart = implode(" AND ",$arrWhere);
											}
											else {
												$chrWherePart = "uid=null";
											}
										  	$arrDeptOwners = getAllDepartmentOwners();
									#if project is used as search filter then, include required tables in the query
											if ($blnProjectUsed == true)
											{
												$chrQuery = "SELECT * FROM dbatn_userslist,dbatn_projectlist
												WHERE $chrWherePart
												AND dbatn_userslist.iduser = dbatn_projectlist.iduser";

											}
											else
											{
												$chrQuery = "SELECT * FROM dbatn_userslist
												WHERE $chrWherePart";

											}
											# query is saved in session, becuase when user request for
											# sorting at that time he does not provide the search criteria
											# so first we check if sorting request is made
											# the retrive the old query and then apply ORDER by clause on that
												$chrOldQuery = $objSession->getAttribute("qry");
												if ($chrOldQuery && $_REQUEST["sopt"] > 0) {
													$chrQuery = $chrOldQuery;
												}

												# query is saved in session for sorting
												$objSession->setAttribute("qry",$chrQuery);
												
												$chrOldQuery = $chrQuery;
												#sorting part is added to the query
												$chrQuery .="
												ORDER BY $chrOrderBy";
												//display($chrOldQuery);
												
												
												$rs = mazDb_query_params($chrQuery, array());
												if (mazdb_num_rows($rs) > 0)
												{
													$counter=0;
													$chrOld = "";
													$blnCanView = true;
													$chrClass = "gridData1";
													$strUser = "";
													while($arr = mazDb_fetch_array($rs))
													{
														$chrClass = "gridData1";
														if ($counter % 2 == 0){
															$chrClass = "gridData2";
														}
														$counter++;
														$strUser .= $arr["uid"].","
														?>
													  <tr>
														<td class="<?php echo $chrClass ?>"><?php echo $arr["name"] ?></td>
				                                        <td class="<?php echo $chrClass ?>"><?php echo $arr["uid"] ?></td>
														<td class="<?php echo $chrClass ?>"><?php echo $arr["email"] ?></td>
														<td class="<?php echo $chrClass ?>"><?php echo $arr["city"] ?></td>
														<td class="<?php echo $chrClass ?>"><?php echo $arr["erelation"] ?></td>
														<td class="<?php echo $chrClass ?>"><?php echo $arr["department"] ?></td>
													  </tr>
												<?php

													}
													?>
				                                       <tr>
				                                      	<td colspan="6" class="<?php echo $chrClass ?>" align="right">
				                                        	<form name="frm1" method="post" action="view_calendar.php" >
				                                            <input type="hidden" name="chrAction" value="user_search"  />
				                                        	<input type="hidden" name="uids" id="uids" value="<?php echo $strUser ?>" />
				                                            <input type="submit" value="View Calendar" />
				                                            </form>
														</td>
														<!--TD start-->
												<?php
													$iduser = $objSession->getIdUser();
													
												}
												else{
													?>
				                                    	 <tr>
				                                            <td class="gridData2" colspan="7"> No Record(s) found</td>
				                                          </tr>
				                                    <?php
												}
				                                ?>
				                            </table>
				                        	<!-- InstanceEndEditable --></td>
				                        </tr>
				                    </table>
				                </div>
				            <!-- _____Contents End_____ -->
				            <?php } ?>
													


				        						</td>
												
													</tr>
													</table>
													</div>
				      						</tr>
				    					</table>
										
										

				        				<!-- ##################################	Working Area END ################################# -->
				          			</td>
				          		</tr>
					  		</table>
				    	</td>
					</tr>
				</table>
			</div>
		</div>
		<?php echo generateFooter(); ?>
		
	</body>
</html>

