<?php
	/**
	 * This file is used to automatically logged user by validating him from
	 * the active directory
	 */
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/common.php");
	
	$requrl = $_REQUEST['requrl'];
	//echo "<pre>"; print_r($requrl); exit;
	unset($_REQUEST['requrl']);
	# get credentional from the active directory of the browsing user
	$arrUserInfo = ldap_get_user_login($_REQUEST['loginid']);
	if (sizeof($arrUserInfo) < 1){
		echo "Account can not be confirmed, your session may have timed out. Please visit the main url again.";
		exit();
	}
	# if any check need to be made
	if (1 ==1){		
		$arrToken["idUser"] 			= $arrUserInfo["idUser"];
		$arrToken["blnAdmin"] 			= false;
		$arrToken["blnLogin"] 			= true;
		$arrToken["chrEmailAddress"]	= $arrUserInfo["chrEmailAddress"];
		$arrToken["chrFullName"]		= $arrUserInfo["chrFullName"];
		$arrToken["uid"]				= $arrUserInfo["uid"];
		$arrToken["chrDepartment"]		= $arrUserInfo["chrDepartment"];
		$arrToken["isLegalManager"]		= $arrUserInfo["isLegalManager"];
		$arrToken["legalManager"]		= $arrUserInfo["legalManager"];

		# get personal settings of this user if there are any else
		#will return the default settings
		$arrSettings = getPersonalSettings($arrUserInfo["idUser"]);
		$arrToken["blnAdvanceUser"]		= $arrSettings['blnadvanceuser'];
		$_SESSION["token"] = $arrToken;

		# if no landing page is selected, send him on the my calendar page
		if (!$arrSettings["intstartpage"]){
			$arrSettings["intstartpage"] = 1;
		}
		if(isset($requrl)){
			header("location: ".$requrl);
			exit();
		}
		else{	
			header("location: index.php?ldaplogin=1&intStartPage=".$arrSettings["intstartpage"]);
			exit();
		}
	}
?>
