<?php
session_start();

include_once("include/site/settings.php");
include_once("include/site/db.php");
include_once("include/ldapfunc.php");
include_once("include/utilfunc.php");
include_once("include/cmazsession.php");
include_once("include/common.php");
include_once("include/menu.php");
include_once("include/page.php");

/** Create session object and try to load user info (id name etc from session) */
$objSession = new cMazSession();
$objSession->loadFromSessionToken();
	# check if user is logged in
if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
	header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
	exit();
}
	# get user rights on project
$arrRights = getProjectRights($objSession->getUid());
	#$arrDepartmentRights = getDepartmentRights($objSession->getUid());

#Save Settings

$arrProjs = get_projects_from_db();
ksort($arrProjs);

$settings = getProjectSettings($objSession->getIdUser(),$objSession->getUid());
$arrProjsFromDB = $settings["proj"];

$arrSearchProjs = array();
	if (!isset($_REQUEST["chrAction"])){ #on entry, the settings are applied and the suggested departments are shown
		$arrSearchProjs = $arrProjsFromDB;
	}
	
	if ($_REQUEST["chrAction"] == "view_new_list") { #if View List has been clicked
		if ($_REQUEST['projsSelected'] != ''){
			foreach ($_REQUEST['projsSelected'] as $pr){
				$arrSearchProjs[$pr] = $pr;
			}
		}
	}
	else if ($_REQUEST["chrAction"] == "save_settings"){
		$arrQueries = array();
		# first delete old settings
		$arrQueries[0] = "DELETE FROM dbatn_project_settings1 WHERE iduser=".$objSession->getIdUser();
		# Add new user settings, for department
		if($_REQUEST["projsSelected"] != ''){
			foreach ($_REQUEST["projsSelected"] as $ps){
				$arrSearchProjs[$ps] = $ps;
				$arrQueries[] = "INSERT INTO dbatn_project_settings1(iduser,project) values(".$objSession->getIdUser().",'".$ps."') ";
			}
		}
		foreach ($arrQueries as $chrQuery){
			mazDb_query_params($chrQuery, array());
		}
		header("location: list_projects.php?msg=".urlencode("User settings updated successfully"));
		exit();
	}
#/Save Settings
#GO ON DEAR...

# ______________delete list______________
	else if ($_REQUEST["chrAction"] == "delete_list"){
		$chrProject = $_REQUEST['projsSelected'][0];		
		$msg = deleteProject($chrProject, $objSession);
		header("location: list_projects.php?msg=".$msg);
		exit();		
	}
	
	header('Content-Type: text/html; charset=utf-8');
	?>

	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("Group List"); ?></title>
		<?php echo generateScripts(); ?>
		<script type="text/javascript">
		function changeSorter(value){
			$('#projsSelected *').attr('selected', 'selected');
			$('#orderBy').attr('value', value);
			document.viewProjsForm.submit();
		}

		function toggleSettingsArea(){
			$('#settingsArea').toggle();
		}

		function saveNewList(){
			document.viewProjsForm.chrAction.value = "save_settings";
			$('#projsSelected *').attr('selected', 'selected');
			document.viewProjsForm.submit();
		}

		function viewNewList(){
			document.viewProjsForm.chrAction.value = "view_new_list";
			$('#projsSelected *').attr('selected', 'selected');
			document.viewProjsForm.submit();
		}

		$(document).ready(function () {
			pageInit();
			var arrAllProjs = <?php echo createJSArray($arrProjs); ?>;
			var arrProjsFromDB = <?php echo createJSArray($arrProjsFromDB); ?>;
			var arrProjsToView = <?php echo createJSArray($arrSearchProjs); ?>;

			populateList('projsAll', arrAllProjs);

	<?php #Display the right department-selections in the selection box 
	if ($_REQUEST['chrAction'] == 'view_new_list'){ 
		echo "populateList('projsSelected', arrProjsToView);";
	} else {
		echo "populateList('projsSelected', arrProjsFromDB);";
	}
	?>
	connectFilterToList('projFilter', 'projsAll', arrAllProjs);
});
		/*****************************************************************/
		function show_calendar(){
			$('#projsSelected *').attr('selected', 'selected');
			var selection = document.getElementById("projsSelected");
			var items = document.getElementById("projsSelected").getElementsByTagName("option");
			var i=0;
			var calString = '';


			if (items.length >= 1) {
				for(i=0;i<items.length;i++)
				{
			//var l = items[i].firstChild.value;
			calString = calString + items[i].value + ',';
		}

		document.getElementById("chrProject").value=calString;
		document.viewProjsForm.chrAction.value = 'single';
		document.viewProjsForm.action = 'view_project_calendar.php';
		alert(calString);
	}
}
function hideProject(projectId){
	if($('span.'+projectId).attr('title') == "hide"){
		$('tr.'+projectId+' *').hide();
		$('span.'+projectId).attr('title', 'show');
		$('span.'+projectId).html('&#9650;');
	} else {
		$('tr.'+projectId+' *').show();
		$('span.'+projectId).attr('title', 'hide');
		$('span.'+projectId).html('&#9660;');
	}
}
</script>
</head>
<body>
	<?php
	echo generateHeader();
	echo generateMenu($objSession);
	?>
	<div id="content">
		<div id="contentInner">
			<div id="toolbar">
				<img src="media/images/TextArea2.png" />&nbsp;
				<span class="pageheading"><span class="ericssonHeading">Group List</span></span>
			</div>
			<div id="contentBody">




				<?php

				$self = 'list_projects.php';
				echo getViewProjectsForm($self, $objSession, "list", null, null, null, null);


				$nameSpan = (sizeof($settings["col"]) == 0) ? "colspan=2" : "";
				$intColumns = 6;
				$intColSpan = 6;
				$tabSize = 30;
						# display columns accroding to the user settings, now hardcoded to 5 instead
				?>
				<div class="groupListOuter">
					<table cellspacing="0" cellpadding="1" width="100%" border="0">                        	

						<?php
	                        	//prepare order by variable
						$chrOrderBy = "name";
						if(isset($_REQUEST['orderBy'])){
							$chrOrderBy = $_REQUEST['orderBy'];
						}


	                        	//Get checked projects
						$chrProjects = "'".implode("','",$arrSearchProjs)."'";
						$chrQuery = "SELECT idproject FROM dbatn_projects
						WHERE
						chrProject IN ($chrProjects)";
						$rs = mazDb_query_params($chrQuery, array());

								//If there were any results, create projects html and print it
						if(mazDb_num_rows($rs) > 0) {
									//While there is a new sub project
							while($arr = mazDb_fetch_array($rs)){																		
								echo createProjectHtml($arr['idproject']);
								echo "<tr style='margin-top: 10px; line-height: 50px; background: #FFF;'><td colspan=6> &nbsp; </td></tr>";															
							}
									//Change html height to fit the new height (after calendar has been generated)
							echo '<script> $("html").css("height", $("#contentInner").height()+200) </script>';
						}

						function createProjectHtml($id) {
							global $objSession, $arrRights;
							$html = "";

									//Get project id, name and isGroup flag
							$chrQuery = "SELECT dbatn_projects.idproject, dbatn_projects.chrproject, dbatn_projects.isGroup FROM dbatn_projects
							WHERE dbatn_projects.idproject = $id;";
							$rs = mazDb_query_params($chrQuery, array());

									//If there were any results
							if(mazDb_num_rows($rs) > 0) {
								$arr = mazDb_fetch_array($rs);

										//Array containing all parent id's
								$parentProjects[] = $arr["idproject"];

								$permissionToView = ( ($objSession->isAdminUser() == true) || (in_array($arr['idproject'], $arrRights["view"])));
								$html.=getProjectHeader($arr["chrproject"], $parentProjects, $arr["isgroup"], $permissionToView, false, 0);									

								#removed extra output for project
								// echo getProjectHeader($arr["chrproject"], $parentProjects, $arr["isgroup"], $permissionToView, false, 0);									

										//if project, create html for subprojects/groups
								if($arr["isgroup"] == "f") {
									$html.=createSubProjectsHtml($parentProjects, 1);
										} else { // create html for the group
											//Check if user can view group
											if( $permissionToView == 1 ) {
												$html.=createGroupHtml($parentProjects, 0);
											}
										}
									} else { //If no records found
										$html .= '
										<tr >
										<td colspan=6 class="gridDataSelected">No record found</td>
										</tr>';
									}
									return $html;
								}

								//Create all subprojects and groups for a project
								function createSubProjectsHtml($parentProjects, $nrOfTabs){
									global $objSession, $arrRights;

									$ParentProjectId = end($parentProjects);
									$permissionToView = false;

									//Query for getting all subprojects from $ParentProjectId
									$chrQuery = "SELECT dbatn_projects.idproject, dbatn_projects.chrproject, dbatn_projects.isgroup FROM dbatn_projects
									inner join dbatn_project_subprojects 
									on 
									dbatn_projects.idproject = dbatn_project_subprojects.idsubproject
									where dbatn_project_subprojects.idproject = $ParentProjectId;";
									$rs = mazDb_query_params($chrQuery, array());
									
									//If there were any results
									if(mazDb_num_rows($rs) > 0) {
										//While there is a new sub project
										while($arr = mazDb_fetch_array($rs)){
											if(!in_array($arr['idproject'], $parentProjects)){ //prevent infinite loops
												$subProjectParents = $parentProjects;
												$subProjectParents[] = $arr['idproject'];

												$permissionToView = ( ($objSession->isAdminUser() == true) || (in_array($arr['idproject'], $arrRights["view"])));

												//Add header for project with name and nr of tabs (to vizualize hierarchy)
												$html.=getProjectHeader($arr['chrproject'], $subProjectParents, $arr["isgroup"], $permissionToView, false, $nrOfTabs);

												if($arr["isgroup"] == "f") {
													//Create html for this projects subprojects 
													$subprojectsHtml = createSubProjectsHtml($subProjectParents, $nrOfTabs+1);																	
													if($subprojectsHtml != null){
														$html .= $subprojectsHtml;
													}
												} else {
													//Check if user has permission to view the project
													if($permissionToView==1) {												
														$html .= createGroupHtml($subProjectParents, $nrOfTabs);
													}
												}
											}
										}
										return $html;
									}												
								}

								function createGroupHtml($parentProjects, $nrOfTabs) {
									global $tabSize, $chrOrderBy;

									$html = "";
									$idProject = end($parentProjects);
									$tabbedInStyle = "margin-left:".($nrOfTabs*$tabSize+10)."px;";

									$hierarchyClass = "";//Class name with all parent project id's. Separated with spaces
									for($i = 0 ; $i<sizeof($parentProjects) ; $i++) {
										$hierarchyClass .= $parentProjects[$i]." ";
									}
									$html = createColHeaders($nrOfTabs, $hierarchyClass);

									# get list of projects and user in that list
									$chrQuery = "SELECT * FROM dbatn_userslist
									INNER JOIN
									dbatn_projectlist
									ON
									dbatn_projectlist.iduser = dbatn_userslist.iduser
									WHERE
									dbatn_projectlist.idproject = $idProject
									ORDER BY $chrOrderBy";

									$rs = mazDb_query_params($chrQuery, array());
									if (mazDb_num_rows($rs) > 0) {
										$counter=0;
										$chrOld = "";
										$blnCanView = true;

										while($arr = mazDb_fetch_array($rs)){
											$counter++;
											$chrClass = "gridData1";
											if ($counter % 2 == 0){
												$chrClass = "gridData2";
											}
											$html .= '
											<tr class="'.$hierarchyClass.'">
											<td><div style="'.$tabbedInStyle.'" class="'.$chrClass.'">'.($arr["name"]).' </div></td>
											<td><div class="'.$chrClass.'">'.$arr["uid"].' </div></td>
											<td><div class="'.$chrClass.'">'.$arr["email"].' </div></td>
											<td><div class="'.$chrClass.'">'.($arr["city"]).' </div></td>
											<td><div class="'.$chrClass.'">'.$arr["erelation"].' </div></td>
											<td><div class="'.$chrClass.'">'.$arr["department"].' </div></td>
											</tr>';
										}
									}
									return $html;
								}

								//Create headers for each column
								function createColHeaders($nrOfTabs, $hierarchyClass) {
									global $tabSize;
									$tabbedInStyle = "margin-left:".($nrOfTabs*$tabSize+10)."px;";								
									return '<tr class="'.$hierarchyClass.'">
									<td> <div style ="'.$tabbedInStyle.'" class="gridHead"> Name <img src="media/images/sort.png" border="0" onClick="changeSorter(\'name\')" /></div></td>
									<td> <div class="gridHead"> UID <img src="media/images/sort.png" border="0" onClick="changeSorter(\'uid\')" /></div></td>
									<td> <div class="gridHead"> Email <img src="media/images/sort.png" border="0" onClick="changeSorter(\'email\')" /></div></td>
									<td> <div class="gridHead"> City <img src="media/images/sort.png" border="0" onClick="changeSorter(\'city\')" /></div></td>
									<td> <div class="gridHead"> Relation <img src="media/images/sort.png" border="0" onClick="changeSorter(\'erelation\')" /></div></td>
									<td> <div class="gridHead"> Department <img src="media/images/sort.png" border="0" onClick="changeSorter(\'department\')" /></div></td>
									</tr>';
								}
								?>
								<tr>
									<td class="gridData2" colspan="6"> - </td>
								</tr>
							</table>
							<!-- InstanceEndEditable -->
						</div><!-- groupListOuter -->

					</div><!-- contentBody -->
				</div><!-- contentInner -->
			</div><!-- content -->
			<?php echo generateFooter(); ?>
		</body>
		</html>
