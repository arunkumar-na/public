<?php
	/**
	 * This is email testing file, not part of the project
	 * will be directly accessed through the url link
	 */
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");

	/** Create session object and try to load user info (id name etc from session) **/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	# Only admins are allowed to see this page
	if ($objSession->isValidAdminLogin() === false){
		redirect('index.php');
	}

	if ($_REQUEST["act"] == "clearall"){
		mazDb_query_params("DELETE FROM tmp_sent_email_log", array());
		redirect("checkmails.php");
	}
?>
<table border="1">
	<tr>
		<td colspan="4">
			<a href="checkmails.php?rand=<?php echo time() ?>">Refresh List</a>
		</td>
		<td align="right">
			<a href="checkmails.php?act=clearall">Delete ALL</a>
		</td>
	</tr>
	<tr>
		<td>To</td>
		<td>Subject</td>
		<td>Body</td>
		<td>Header</td>
		<td>Time</td>
	</tr>
    <?php
	$rs = mazDb_query_params("SELECT * FROM tmp_sent_email_log", array());
	while($arr = mazDb_fetch_array($rs)){
		echo "<tr>";
		echo "<td>". htmlentities($arr["chrto"]). "</td>";
		#echo "<td>". $arr["chrfrom"]. "</td>";
		echo "<td>".  htmlentities($arr["chrsubject"]). "</td>";
		echo "<td>".  $arr["chrbody"]. "</td>";
		echo "<td>".  htmlentities($arr["chrheader"]). "</td>";
		echo "<td>". date("d M,Y h:i:s a",$arr["intdate"]). "</td>";
		echo "</tr>";
	}
	?>
</table>