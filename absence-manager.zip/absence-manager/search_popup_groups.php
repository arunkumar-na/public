<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");

	/** Create session object and try to load user info (id name etc from session)**/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		redirect("ldap_do_login.php");
	}

	$arrValidModes = array('users', 'departments');
	$chrMode = 'users';
	$blnMultiple = true;

	if (isset($_POST['chrAction']) && ($_POST['chrAction'] == 'search')){
		$chrMode = $_POST['mode'];
		$blnMultiple = (bool)intval($_POST['multiple']);
	}
	else {
		if (isset($_GET['mode']) && (in_array($_GET['mode'], $arrValidModes))){
			$chrMode = $_GET['mode'];
		}

		if (isset($_GET['multiple'])){
			$blnMultiple = (bool)intval($_GET['multiple']);
		}
	}

	header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("Search Active Directory"); ?></title>
		<?php echo generateScripts(); ?>
		<script type="text/javascript">
			// This function is called when the user has selected the items he/she wants.
			var doneCallback = window.opener.groupSearchDoneCallback;

			function selectRecords(obj, counter){
				var blnChecked = $('.dept'+counter+'Check').is(':checked');
				$('.dept'+counter).each(function (index){
					if (blnChecked){
						$(this).attr('checked', 'checked');
					}
					else {
						$(this).removeAttr('checked');
					}
				});
			}

			function insertSelected() {
				var arrSelected = [];
				$('.itemCheck:checked').each(function (i, element){
					arrSelected.push($.parseJSON($(element).val()));
				});
				doneCallback(window, arrSelected);
				window.close();
			}
		</script>
	</head>
	<body>
	<?php
	/*** Get search paramater */
	
	$arrProjects = array();
	if ($_POST["sProj_count"] && $_POST["sProj_count"] > 0){
		for ($j = 0; $j < $_POST["sProj_count"]; $j++){
			if ($_POST["sProj$j"]){
				$chrProj = ($_POST["sProj$j"]);
				$arrProjects[($chrProj)] = $chrProj;
			}
		}
	}

	?>
	<div id="contentBody">
		<h2>Search Group</h2>
	    <form action="search_popup_groups.php" method="post">
	    	<div>
		       	<input type="hidden" name="chrAction" id="chrAction" value="search" />
		       	<input type="hidden" name="multiple" id="multiple" value="<?php echo ($blnMultiple ? '1':'0'); ?>" />
		       	<input type="hidden" name="mode" id="mode" value="<?php echo $chrMode; ?>" />
		       	<?php if ($chrMode=='users'){ ?>
				<table width="100%" border="0" cellspacing="3" cellpadding="3">
		            <tr>
		            	<td class="caption">Search by group name:</td>
		                <td><input type="text" name="sName" id="sName" value="<?php echo $_POST["sName"] ?>" /></td>
		            </tr>
		            <tr>
		            	<td colspan="2" class="caption"><input type="submit" name="btnSearch" id="btnSearch" value="Search" /></td>
					</tr>
			    </table>
				<?php } else { ?>
				<table width="100%" border="0" cellspacing="3" cellpadding="3">
		            <tr>
		            	<td colspan="2" class="caption"><input type="submit" name="btnSearch" id="btnSearch" value="Search" /></td>
					</tr>
			    </table>
				<?php } ?>
		    </div>
	    </form>
		<?php
		if (isset($_POST['chrAction']) && ($_POST['chrAction'] == 'search')) {
			$arrMatch = array();
		?>
		<br />
		<h2>Search Results</h2>
		<table width="100%">
	        <tr valign= "top">				 
	        	<?php

					if($_POST["sName"]) {
						$searchString = "chrproject ILIKE '%".safeDatabase($_POST["sName"])."%'";

						$chrQuery = "SELECT chrproject,idproject FROM dbatn_projects
							WHERE $searchString";	
						
						$rs = mazDb_query_params($chrQuery, array());
						if (mazdb_num_rows($rs) > 0)
						{
							$arr = array();
							$intx = 0;

							while($arrtmp = mazDb_fetch_array($rs))							
							{
								$arr[$intx]['chrproject'] = $arrtmp['chrproject'];
								$arr[$intx]['idproject'] = $arrtmp['idproject'];
								$intx++;
							}
							$inputType = 'type="radio" name="selectedItem" id="selectedItem"';
							if ($blnMultiple){
								$inputType = 'type="checkbox" checked="checked"';
							}
							$blnFirst = true;
							
							$counter = 0;
							foreach($arr as $record){
								$value = safeHTML(json_encode($record));
								echo '<input type="checkbox" class="itemCheck dept'.$counter.'Check" checked="checked" value="'. $value .'" onclick="javascript:selectRecords(this,'.$counter.')" />';
								echo '<b>'.$record['chrproject'].'</b><br />';								
								$counter++;
							}
												
						}
						echo "</td>";
						}
					}					
					?>				
	        </tr>
			<tr>
				<?php
				if(sizeof($arr) > 0) {		
					$_SESSION['foundGroups']=$arr;														
					echo '<td><input type="button" value="Insert Selected" onclick="javascript:insertSelected()" /></td>';											
				}
				else{
					echo'<td class="text">No result(s) found</td>';
				}
				?>
			</tr>	        
	    </table>
	</div>
	</body>
</html>
