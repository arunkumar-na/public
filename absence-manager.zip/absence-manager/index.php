<?php
	session_start();
	$headers = getallheaders();
	if(isset($headers['REMOTE_USER'])){
       $loginid = $headers['REMOTE_USER'];
	}	
	
	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/cmail.php");
	include_once("include/menu.php");
	include_once("include/page.php");
	include_once("include/template.php");
    include_once("include/user.php");

	/** Create session object
		and try to load user info (id name etc from session)
	**/
	//echo "<pre>"; print_r($_REQUEST);exit;
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();
	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		echo $_REQUEST['ldaplogin'];
		if ($_REQUEST["ldaplogin"]==1) {
			# if commes here this mean user authentication stuck in recursion.
			#(mean user is not validate from the database/ldap and session is not created for this user
			sleep(5);
			header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
			echo "Authentication failed";
			exit();
		}
		# autheticate user from database
		header("location: ldap_do_login.php?loginid=".$loginid);
		//header("location: ldap_do_login.php?loginid=".$_GET['loginid']);
		//header("location: ldap_do_login.php?loginid=EPKPEON");
		exit();
	}
	else{		# User is logged in. Check his personal data in local DB against ldap DB. Update if necessary
		#display($_SERVER);
		
		/*#create mail object
		$objMail = new cMail();
		#if there are some approved days then loop on them
		#coz this array will contain the userinfo and his days info as well	
		$chrTo = $objSession->getFullName()." <".$objSession->getEmailAddress().">";
		$chrSubject = "Absence Manager - Item Updated (". safeDatabase($objSession->getFullName()).")";
		# append mail body as per his department email settings
		$chrBody = "<h3>Absence Request:</h3></P>";		
		$chrFrom = "FROM : ".safeDatabase($objSession->getFullName())." <".$objSession->getEmailAddress().">";
		#if user has subscribed for approvel notification then send him email otherwise not					
		$blnSent = $objMail->sendEmail($chrTo,$chrFrom,$chrSubject,$chrBody,$objSession);
		if($blnSent){
			echo "Index TEST Mail Sent"; exit;
		}*/					
					
			
		$idUser = $objSession->getIdUser();
		$chrQuery = "SELECT * FROM dbatn_userslist WHERE iduser=$1";
		$rs = mazDb_query_params($chrQuery, array($idUser));
		if (mazDb_num_rows($rs)>0){ #user exists in database!
			$user = getUser($idUser);
			$user->syncUser($user->isExternal()); //updates database from LDAP
			$objSession->syncSession(); //updates session variable
			$objSession->populateFromDB(); //updates session from db
		}
	}

	# send user to his prefrence page (that he has selected in the personal setting page)
	if ($_REQUEST["ldaplogin"]==1 && $_REQUEST["intStartPage"] > 0 ){
		if ($_REQUEST["intStartPage"] == 2){
			header("location: view_calendar.php?chrAction=direct");
			exit();
		}
		else if ($_REQUEST["intStartPage"] == 3){
			header("location: view_project_calendar.php?chrAction=direct");
			exit();
		}
	}

	#get iduser of the logged in contact
	$idUser = $objSession->getIdUser();
	if ($_REQUEST["chrAction"] == "save_days"){
		# get all posted days, explode the info from single param to days
		$arrParam = explode("===_===",$_POST["chrParam"]);
		$arrQueries = array();
		$chrDaysApplied = "";
		$datesModified = array();
		

		#get the logged-in user email settings (from his department , for auto approve checking etc)
		$arrSettings = getUserDepartmentMailSettings($objSession->getUid());
		foreach($arrParam as $eachRec){
			if ($eachRec){
				$resultArray = null;
				$arrDay = explode("-_-",$eachRec);
				$intDay = $arrDay[0];
				$intMonth = $arrDay[1];
				$intYear = $arrDay[2];
				$chrCharacter = $arrDay[3];
				$inttime    = mktime(0,0,0,$intMonth,$intDay,$intYear);
				$blnApproved = 0; # false not approved

				#if not holiday, and department setting is auto approve then auto approve it.
				if ($chrCharacter != "R" && $arrSettings["blnAutoApprove"] == 1 && $arrSettings["blnEmailRequired"] == 0){
					$blnApproved = 1;
				}
				$chrComments = safeDatabase(safeHTML($arrDay[4]));

				# first check if record exist this specfic day of this user
				$chrQuery = "SELECT \"chrCharacter\", \"chrComments\", \"idUser\", \"blnapproved\" FROM dbatn_userdays WHERE \"idUser\"=$1 AND \"intDay\"=$2 AND \"intYear\"=$3 AND \"intMonth\"=$4";
				$arrParams = array($idUser, $intDay, $intYear, $intMonth);
				$rs = mazDb_query_params($chrQuery, $arrParams);

				#if record exist then update it, other wise insert it
				if (mazDb_num_rows($rs) > 0){
					# Make sure the value for approval is kept unchanged
					$resultArray = pg_fetch_all($rs);
					$blnApproved = $resultArray[0][blnapproved];

					$chrTmp = $chrCharacter;

					if($resultArray[0][chrCharacter]!= $chrCharacter || $resultArray[0]["chrComments"]!= $chrComments) {
						$arrQueries[] = "UPDATE dbatn_userdays SET \"blnapproved\"='$blnApproved', \"chrCharacter\"='$chrCharacter',\"chrComments\"='$chrComments' WHERE \"idUser\"=$idUser AND \"intDay\"=$intDay  AND \"intYear\"=$intYear  AND \"intMonth\"=$intMonth";
						$chrCharacter = $chrTmp;
						if ($chrCharacter != "R"){
							$chrDaysApplied .= "[updated]".date("d M,Y",mktime(0,0,0,$intMonth,$intDay,$intYear))." ".$chrComments."<br>\n";
							$datesModified[] = array("day" => $intDay, "month" => $intMonth, "year" => $intYear, "chrCharacter" => $chrCharacter, "chrComments" => $chrComments);
						}
					}
				}
				else {

					#means record not exist so inserting it here
					$chrTmp = $chrCharacter;
					$arrQueries[] = "INSERT INTO dbatn_userdays(\"idUser\",\"intDay\",\"intMonth\",\"intYear\",\"chrCharacter\",\"chrComments\",inttime,\"blnapproved\") values ($idUser,$intDay,$intMonth,$intYear,'$chrCharacter','$chrComments',$inttime,$blnApproved)";
					$chrCharacter = $chrTmp;
					if ($chrCharacter != "R"){
						$chrDaysApplied .= "[added]".date("d M,Y",mktime(0,0,0,$intMonth,$intDay,$intYear))." ".$chrComments."<br>\n";
						$datesModified[] = array("day" => $intDay, "month" => $intMonth, "year" => $intYear, "chrCharacter" => $chrCharacter, "chrComments" => $chrComments);
					}
			  	}
			}#if there is record
		}#endforeach

		// Execute all the queries that we made above
		foreach($arrQueries as $chrQuery){
			mazDb_query_params($chrQuery, array());
		}

		#Send email process
		$objMail = new cMail();
		$chrMessage = $objMail->prepareAndSendMail($chrDaysApplied, $objSession, $arrSettings, $chrMessage, $datesModified);

		//header("location: index.php?intYear=".$_POST["intYear"]."&intSlide=".$_POST["intSlide"]."&msg=".urlencode($chrMessage));
		//exit();
	}
	#Choose this is button "Clear Days" has been clicked
	else if ($_REQUEST["chrAction"] == "clear_days"){
		# seprate user marked days (as clear days), from single param
		$arrParam = explode("===_===",$_POST["chrParam"]);
		$arrQueries = array();

		$chrDaysApplied = "";
		#Get settings about deparment such as mail to manager
		$arrSettings = getUserDepartmentMailSettings($objSession->getUid());

		#Delete all absence from marked days
		foreach($arrParam as $eachRec){
			if ($eachRec){
				# seprate marked days (as clear days) information , from single day param
				$arrDay = explode("-_-",$eachRec);
				$intDay = $arrDay[0];
				$intMonth = $arrDay[1];
				$intYear = $arrDay[2];
				$approved = $arrDay[3];
				#Prepare all queries
				$arrQueries[] = "DELETE FROM dbatn_userdays WHERE \"idUser\"=$idUser AND \"intDay\"=$intDay  AND \"intYear\"=$intYear  AND \"intMonth\"=$intMonth";
				#Store infomation about absence deletion for email later. If the removed absence had status approved, an email should be sent later.
				if ($approved == 'approved'){
						$chrDaysApplied .= "[removed]".date("d M,Y",mktime(0,0,0,$intMonth,$intDay,$intYear))."<br>\n";
				}
			}#if there is record
		}#endforeach

		#Run all delete queries genrated above
		foreach($arrQueries as $chrQuery){
			mazDb_query_params($chrQuery, array());
		}

		#If the removed absence had status approved, send email to user and manager if requested by settings.
		if ($chrDaysApplied != ""){
			$objMail = new cMail();
			$objMail->prepareAndSendMail($chrDaysApplied, $objSession, $arrSettings, $chrMessage);
		}

		header("location: index.php?intYear=".$_POST["intYear"]."&intSlide=".$_POST["intSlide"]."&msg=".urlencode($chrMessage));
		exit();
	}
		
	else if ($_GET["chrAction"] == "mail_approve"){
		$_GET["chrAction"] = "";
		# get all posted days, explode the info from single param to days
		$idUserMailApprove = $_GET["idUser"];
		$UserToApprove = getUser($idUserMailApprove);
		$arrParam = explode("|",$_GET["chrParam"]);
		$arrQueries = array();
		$chrDaysApplied = array();
		
		
		#get the logged-in user email settings (from his department , for auto approve checking etc)

		$arrSettings = getUserDepartmentMailSettings($UserToApprove->getUserID());
		
		foreach($arrParam as $eachRec){#for every day off requested
		
			if ($eachRec){								
				$arrDay = explode("~",$eachRec);	
				$intDay = $arrDay[0];
				$intMonth = $arrDay[1];
				$intYear = $arrDay[2];
				$chrCharacter = $arrDay[3];
				$inttime    = mktime(0,0,0,$intMonth,$intDay,$intYear);
				$blnApproved = 1; #everything that reaches this label should be approved.

				$chrComments = safeDatabase(safeHTML($arrDay[4]));

				# first check if record exist this specfic day of this user
				$chrQuery = "SELECT \"idUser\", \"blnapproved\" FROM dbatn_userdays WHERE \"idUser\"=$1 AND \"intDay\"=$2 AND \"intYear\"=$3 AND \"intMonth\"=$4";
				
				$arrParams = array($idUserMailApprove, $intDay, $intYear, $intMonth);
				$rs = mazDb_query_params($chrQuery, $arrParams);

				#if record exist then update it
				if (mazDb_num_rows($rs) > 0){
					# Make shure the value for approval is kept unchanged
					$resultArray = pg_fetch_all($rs);
					$blnApproved = $resultArray[0][blnapproved];
					
					$chrTmp = $chrCharacter;
					#Approve update if business trip or course
					#if ($chrCharacter == 'B' || $chrCharacter == 'C'){
						$blnApproved = 1;
					#}
					$arrQueries[] = "UPDATE dbatn_userdays SET \"blnapproved\"='$blnApproved', \"chrCharacter\"='$chrCharacter' WHERE \"idUser\"=$idUserMailApprove AND \"intDay\"=$intDay  AND \"intYear\"=$intYear  AND \"intMonth\"=$intMonth";
					$chrCharacter = $chrTmp;

					if ($chrCharacter != "R"){
						$chrDaysApplied[] .= "[updated]".date("d M,Y",mktime(0,0,0,$intMonth,$intDay,$intYear))." ".$chrComments."<br>\n";
					}
				}
			}#if there is record
		}#endforeach

		// Execute all the queries that we made above
		foreach($arrQueries as $chrQuery){
			mazDb_query_params($chrQuery, array());
		}

		#Send email process
		#$objMail = new cMail();
		#$chrMessage = $objMail->prepareAndSendMail($chrDaysApproved, $objSession, $arrSettings, $chrMessage);
#------ mail approval -response-email sent here

		#echo "size= " . sizeof($chrDaysApplied);
		#display($chrDaysApplied, "DaysApplied");

		if (sizeof($chrDaysApplied) > 0){
			#echo "send mail!: inside <br />";
			$arrUserIds = array($_REQUEST['idUser']);

			# Get Email address of these ids with names
			$arrEmails = getEmailFromLoginId($arrUserIds);
			# Get users email settings, whos days are approved
			$arrUsersEmailSettings  = getUsersBulkEmailSettings($arrUserIds);
			#find out department whos reponse needs to retived
			$arrDepartmentsUsed = array();
			#display($arrUsersEmailSettings,"user email settings");
			#exit();
			# here we will get the departments from the list of users
			# whos days are approved, we get their departmentes
			# because afterward we will load their department settings for emails
			# and response text message for email body.
			
			
			foreach($arrUsersEmailSettings as $idSelectedUser=>$arrHisSettings){
				$arrDepartmentsUsed[$arrHisSettings["department"]] = $arrHisSettings["department"];
			}
			#display($arrDepartmentsUsed,"Used Departments");
			#get these departments email settings that need to be sent to the user
			$arrDepartmentEmailSettings = getDepartmentBulkMailSettings($arrDepartmentsUsed);
			#display($arrDepartmentEmailSettings,"Department Email Settings");
			
			if (sizeof($arrEmails) > 0 ) {
				#echo "fine, we're here, at 1.";
				#exit();
				include_once("include/cmail.php");
				#create mail object
				$objMail = new cMail();
				#if there are some approved days then loop on them
				#coz this array will contain the userinfo and his days info as well
				# bugfix moved failing loop
				#foreach($chrDaysApplied as $chrDaysApproved){
					$idUser = $arrUserIds[0];
					#if user has subscribed for approvel notification then send him email otherwise not
					if ($arrUsersEmailSettings[$idUser]["blnResponse"] == true){
							$chrTo = safeDatabase($arrEmails[$idUser]["name"])." <".$arrEmails[$idUser]["email"].">";
							$chrSubject = "Absence Manager - Item Updated (". safeDatabase($objSession->getFullName()) .")";
							# append mail body as per his department email settings
							$chrBody = "<pre>".$arrDepartmentEmailSettings[$arrUsersEmailSettings[$idUser]["department"]]["chrReplayMsg"]."</pre>";
							# append what days approved with comments etc
							# bugfix loop here instead
							$chrBody .= "<br>\n";
							foreach($chrDaysApplied as $chrDaysApproved){
							    $chrBody .= $chrDaysApproved;
							} #foreach
							$chrFrom = "FROM : ".safeDatabase($objSession->getFullName())." <".$objSession->getEmailAddress().">";
							$blnSent = $objMail->sendEmail($chrTo,$chrFrom,$chrSubject,$chrBody,$objSession);
							if ($blnSent != true){
								$chrMessage = "Some of the mails could not be sent, ".$objMail->getLastError();
							}# if
					}# if
				#} #foreach removed due to bugfix
			} #if
			else {
				$chrMessage = "No Emails found";
			}
		}# all work done,		
		
#------ mail approval -response-email ended here		
		#display($chrMessage);
		$chrMessage = array("days"=>$chrDaysApplied, "session"=>$objSession, "requestingUser"=>$_REQUEST['idUser']);
		#$arrPar = array(
		#	"intYear"=>$_GET["intYear"],
		#	"intSlide"=>$_GET["intSlide"],
		#	"msg"=>$chrMessage);
		$chrParams = http_build_query($chrMessage);
		header("location: approve_from_mail.php?$chrParams");
		exit();
	}
	header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("My Calendar"); ?></title>
		<?php echo generateScripts(); ?>
<script type="text/javascript">
/*******************************/
N = (document.all) ? 0 : 1;
var ob;

/*	Disable right click menu */
document.oncontextmenu=new Function("return false");

/**	If netscape then over load events */
if (N){
	document.captureEvents(Event.MOUSEDOWN | Event.MOUSEMOVE | Event.MOUSEUP);
}

/** Overloading Mouse events for document */
document.onmousedown = MD;
document.onmousemove = MM;
document.onmouseup = MU;



/*******************************/

var selectedOption = "";
var intBoxSelected = 0;
/**	Cancel comments */
function cancelComments(){
	document.getElementById("divComments").style.display = "none";
}

// To limit the number of input characters in the text field.
function limitText(limitField, limitNum) {
    if (limitField.value.length > limitNum) {
        limitField.value = limitField.value.substring(0, limitNum);
    }
	var charleft = limitNum - limitField.value.length;
	document.getElementById('charleft').innerHTML ='<strong>'+ charleft +'</strong>';
}

/**	Save comments against user days */
function saveComments(){
	document.getElementById("divComments").style.display = "none";
	arrTds = document.getElementsByTagName("td");
	for(i=0; i<arrTds.length; i++){
		if (arrTds[i].className == "selectedbox"){
			if (selectedOption != "edit_comments") {
				arrTds[i].innerHTML = arrTds[i].getAttribute("dayValue")+"<br>"+selectedOption;
				arrTds[i].setAttribute("chrCharacter",selectedOption);
			}
			arrTds[i].setAttribute("chrComments",document.getElementById("chrComments").value);
			arrTds[i].setAttribute("title",document.getElementById("chrComments").value);
			if (document.getElementById("chrComments").value == ""){
				arrTds[i].className = "dirty";
			}
			else{
				arrTds[i].className = "dirtyi";
			}
		}
	}
	applySettings(); /* automatically apply settings */
}

/* ---------------------- */
/**	Clear selected days event */
function clearSelectedDays(){
	arrTds = document.getElementsByTagName("td");
	var str = "";
	for(i=0; i<arrTds.length; i++){
		if (arrTds[i].className == "selectedbox"){
			arrTds[i].className = "dirty";
			str += arrTds[i].getAttribute("dayValue")+"-_-"+arrTds[i].getAttribute("monthValue")+"-_-"+arrTds[i].getAttribute("yearValue")+"-_-"+arrTds[i].getAttribute("class2")+"===_===";
		}
	}
	document.frmApply.chrAction.value = "clear_days";
	document.getElementById("chrParam").value=str;
	document.frmApply.submit();
}

/**	on save apply setting permanetly, this function will aslo submit the form */
function applySettings(){
	arrTds = document.getElementsByTagName("td");
	var str = "";
	for(i=0; i<arrTds.length; i++){
		if (arrTds[i].className == "dirty" || arrTds[i].className=="dirtyi"){
			str += arrTds[i].getAttribute("dayValue")+"-_-"+arrTds[i].getAttribute("monthValue")+"-_-"+arrTds[i].getAttribute("yearValue")+"-_-"+arrTds[i].getAttribute("chrCharacter")+"-_-"+arrTds[i].getAttribute("chrComments")+"===_===";
		}
		if (arrTds[i].className == "noteadded" || arrTds[i].className=="noteaddedi"){
			str += arrTds[i].getAttribute("dayValue")+"-_-"+arrTds[i].getAttribute("monthValue")+"-_-"+arrTds[i].getAttribute("yearValue")+"-_-"+arrTds[i].getAttribute("chrCharacter")+"-_-"+arrTds[i].getAttribute("chrComments")+"===_===";
		}
	}
	document.getElementById("chrParam").value=str;
	document.frmApply.submit();
}

/**	Select days with user selected option */
function saveBoxes(chrType) {
	var chrComments = "";
	if (chrType == "edit_comments" && intBoxSelected == 0){
		alert("Please select a day");
		return;
	}
	arrTds = document.getElementsByTagName("td");
	intRedDays = 0;
	intNormalDays = 0;
	for(i=0; i< arrTds.length; i++)	{
		if (arrTds[i].getAttribute("chrCharacter") == "R" && arrTds[i].className == "selectedbox") {
			intRedDays++;
			arrTds[i].className = "redday";
		}
		else {
			if (arrTds[i].className == "selectedbox" && chrType=='edit_comments'){
				chrComments = arrTds[i].getAttribute("chrComments");
				intNormalDays++;
			}
		}
	}
	if (intRedDays > 0 && intNormalDays == 0){
		alert("You can not change type of holiday, please first clear the Red Status");
		return;
	}
	else if (intRedDays > 0){
		alert("Please note: Holidays will not be affected");
	}
	document.getElementById("chrComments").value = chrComments;
	document.getElementById("divComments").style.display = "";
	selectedOption = chrType;
}

/**	Toggle CSS of user days. */
function selectbox(objTd){
	if (objTd.className == "approved" || objTd.className == "daybox"
		|| objTd.className == "noteadded" || objTd.className == "noteaddedi"
		|| objTd.className == "redday" || objTd.className == "reddayi"){
		objTd.className = "selectedbox";
		intBoxSelected++;
	}
	else if (objTd.className == "selectedbox"){
		objTd.className = objTd.getAttribute("class2");
		intBoxSelected--;
	}
	else if (objTd.className == "weeknumber"){	/* if you have clicked on a weeknumber in your calendar */
		allselected = "true";
		month = objTd.getAttribute("month");
		if (parseInt(month) < 10){
			month = "0" + month;
		}
		day = objTd.getAttribute("monthDay");
		weekday = objTd.getAttribute("firstWeekDay");
		/* Loop through monday to friday */
		if(weekday < 6){
			/* Mark all day elements that hasn't been marked before. If all days was marked unselect. */
			for (i=0; i<(6-weekday); i++){
				if (parseInt(day) < 10){
					day = "0" + day;
				}
				str = month + day;
				elem = document.getElementById(str);
				if (elem != null){
					/* Check if day is marked */
					if (elem.className != "selectedbox"){
					 	elem.className = "selectedbox";
					 	intBoxSelected++;
					 	allselected = "false"; /* At least one day was selected before clicking on weeknumber ie all days shall be marked */
					}
				}
				day++;
			}
			/* If all days already was selected when clicking on weeknumber we shall unselect them all */
			if(allselected == "true"){
				month = objTd.getAttribute("month");
				if (parseInt(month) < 10){
					month = "0" + month;
				}
				day = objTd.getAttribute("monthDay");
				for (i=0; i<(6-weekday); i++){
					if (parseInt(day) < 10){
						day = "0" + day;
					}
					str = month + day;
					elem = document.getElementById(str);
					attr = elem.getAttribute("class2");
					elem.className = attr;
					intBoxSelected--;
					day++;
				}
			}
		}
	}
}


</script>
	</head>
	<body>
<link rel="stylesheet" type="text/css" href="/media/css/blink.css">		
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>

		<div id="rightClickMenu" class="rightClickMenu">
		</div>

		<div id="chooseAbsence" class="chooseAbsence">
			<div class="chooseAlt chooseAltTop" onClick="saveBoxes('FL')">Full Day Leave</div>
			<div class="chooseAlt chooseAltRight" onClick="saveBoxes('H')">Few Hours</div>
			<div class="chooseAlt chooseAltLeft" onClick="saveBoxes('B')">Business Trip</div>
			<div class="chooseAlt chooseAltRight" onClick="saveBoxes('C')">Course</div>
	<!--		<div class="chooseAlt chooseAltLeft" onClick="saveBoxes('P')">Parental Leave</div> -->
		</div>
<div id="message"><p>On 14-Aug-2021, Absence Manager will be down to be migrated to the cloud in the regular maintenance window and therefore should not impact your business operations.</p></div>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar">
					<img src="media/images/TabNavigator2.png" />&nbsp;
					<span class="pageheading">
						<span class="ericssonHeading">My Calendar</span>
						&nbsp;&nbsp;&nbsp;
						<input type="button" value=" FL " title="Full Day Leave" onclick="saveBoxes('FL')" />
						<!-- <input type="button" value="L" title="Leave" onclick="saveBoxes('L')" /> -->
						<input type="button" title="Few Hours" onclick="saveBoxes('H')" value="1-8" />
						<input type="button" value=" B " title="Business Trip" onclick="saveBoxes('B')" />
						<input type="button" value="C" title="Course" onclick="saveBoxes('C')" />
						<!-- <input type="button" value="PL" title="Parental Leave" onclick="saveBoxes('P')" /> -->
						<input type="button" title="Clear Days" onclick="clearSelectedDays()" value="Clear Days" />
						<input type="button" title="Edit Comments" onclick="saveBoxes('edit_comments')" value="Edit Comments" />
						<input type="button" title="Holiday Templates" onClick="parent.location='view_all_templates.php'" value="View all Public Holiday Templates"  style="float:right;"/>
					</span>
				</div>
            		<div class="workareaBox" valign="top">
    				<!-- ##################################	Working Area START ################################# -->
        				<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#505050">
        					<!-- InstanceBeginEditable name="subheader section" -->
         					<tr>
        						<td valign="top" align="center">		<!-- _____SubHeader START_____ -->
        							<table cellpadding="0" align="center" border="0" cellspacing="0" width="100%">
           	  							<tr class="dateControl">
                							<td width="210" class="subheader"></td>
				  							<?php
											$intYear = $_REQUEST["intYear"] ? $_REQUEST["intYear"] : date("Y",time());
											$intSlide = $_REQUEST["intSlide"] ? $_REQUEST["intSlide"] : $intYear - 1;
											?>
                  							<td class="subheader" width="100"><?php echo "<a href=\"index.php?intSlide=".($intSlide-1)."&intYear=".($intYear-1)."\" class=navyearlink>&#9668;</a>" ?></td>
											<td width="1px" style="padding-bottom:3px"><img src="media/images/subheaderseprator.jpg" /></td>
                  							<?php
											for($i = $intSlide; $i < $intSlide+3; $i++){
												if ($i == $intYear){
													echo '<td class="subheader" width="100">'."<span class=subheaderlinkselected>$i</span>".'</td>';
												}
												else {
													echo '<td class="subheader" width="100">'."<a href=\"index.php?intYear=$i&intSlide=$intSlide\" class=subheaderlink>$i</a>".'</td>';
												}
												echo '<td width="2px" style="padding-bottom:3px"><img src="media/images/subheaderseprator.jpg" /></td>';
											}
			   								#echo "<a href=\"index.php?intSlide=".($intSlide+1)."&intYear=$intYear\" class=navyearlink> &#9658; </a>";
											?>
                							<td class="subheader" width="100"><?php echo "<a href=\"index.php?intSlide=".($intSlide+1)."&intYear=".($intYear+1)."\" class=navyearlink> &#9658; </a>" ?></td>
											<td class="subheader">&nbsp;</td>

              							</tr>
									</table>							<!-- _____SubHeader END_____ -->
            					</td>
      						</tr>
							<!-- InstanceEndEditable -->
      						<tr>
        						<td height="100%">						<!-- _____Contents START_____ -->
        							<div id="workingDiv" style="width:100%;height:<?php echo CALENDAR_HEIGHT ?>">
												<div id="divComments" style="display:none;position:absolute;width:400px;left:200px;top:200px">
													<table width="100%" bgcolor="#FEFBF3" style="border:1px solid #000000">
														<tr>
	    													<td class="monthname">Add Comments</td>
	    												</tr>
	    												<tr>
	    													<td><div style="font-size:10px;">Characters Left:<font size="2px" color="red"><span id="charleft">249(Max)</span></font></div>
															<textarea id="chrComments" name="chrComments" cols="40" rows="5" onKeyDown="limitText(this,249);" onKeyUp="limitText(this,249);"></textarea><br />
															<input type="button" onclick="saveComments()" value="Save"/>   <input type="button" onclick="cancelComments()" value="Cancel" /></td>
	    												</tr>
													</table>
												</div>
												<table width="100%" bgcolor="#FFFFFF" border="0" cellspacing="3" cellpadding="3" height="<?php echo CALENDAR_HEIGHT ?>">
  													<tr>
    													<td align="center">
    														<form name="frmApply" id="frmApply" method="post">
	        													<input type="hidden" id="chrAction" name="chrAction" value="save_days" />
	        													<input type="hidden" id="intYear" name="intYear" value="<?php echo $intYear ?>" />
	        													<input type="hidden" id="intSlide" name="intSlide" value="<?php echo $intSlide ?>" />
	        													<input type="hidden" value="" id="chrParam" name="chrParam"/>
        													</form>
    														<?php
																$arrUserDays = getUserAndTemplateDays( $idUser, $intYear );
															?>
															<table width="100%">
    														<?php
    														# draw calendar, months as grid, 3 in one row
															for($i = 1; $i <= 12 ; $i+=3){
																?>
        														<tr>
														        	<td valign="top"><?php drawMonth($i,$intYear,$arrUserDays[$i]); ?></td>
            														<td valign="top"><?php drawMonth($i+1,$intYear,$arrUserDays[$i+1]); ?></td>
            														<td valign="top"><?php drawMonth($i+2,$intYear,$arrUserDays[$i+2]); ?></td>
														        </tr>
        														<?php
															}
															?>
    														</table>
    													</td>
    													<td  valign="top">
    														<div style="max-width:300px;border: 1px solid black;margin-right:40px;padding:10px;background-color: #C9D8E3;font-size: 11px;font-family: Verdana, Arial, Helvetica, sans-serif;float: right;">
																<b>Help</b><hr><br>						
																1. Select calendar days by clicking on them<br>
																2. Choose absence type from the alternatives on the top of the page <i>(FL, 1-8, B ..)</i><br>
																3. Write a comment in the pop-up window<br>
																4. Press <i>Save</i><br><br>

																Right click calendar days for options.<br><br>
                                                                                                                               Note: Quaterly deletion of absence data will take  place leaving last 2 quater(6 months) data available.<br><br>
															</div>
															<!--<div style="max-width:300px;border: 2px solid black;margin-right:40px;margin-top:10px;padding:10px;background-color: white;font-size: 14px;font-family: Verdana, Arial, Helvetica, sans-serif;float: right;">
																<b class="blink">Note:</b><hr><br>						
																1. Absence Manager is moving to a new Team Calendar link available in January 2017 in Employee and Manager Self Service with similar functionality.<br><br>
																2. <b style="color:Red;text-decoration:underline">Absence Manager will be decommissioned in Q2</b>, please take any data needed prior to that date. <br><br>
																3. Please direct feedback to <p style="color:blue;text-decoration:underline">tpy.global.tools.feedback@ericsson.com</p>
																
															</div>-->

    													</td>
  													</tr>
												</table>

                					</div>
        						</td>							<!-- _____Contents End_____ -->
      						</tr>
    					</table>
        				<!-- ##################################	Working Area END ################################# -->
          			</div> <!-- workareabox end -->

			</div>
		</div>
		<?php echo generateFooter(); ?>
	</body>
</html>
