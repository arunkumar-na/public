<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");
	include_once("include/user.php"); #only used to set default template the wrong way.
	include_once("include/department.php");
	include_once("include/template.php");

	/** Create session object and try to load user info (id name etc from session) **/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();
	

	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		if ($_REQUEST["ldaplogin"]==1){
			echo "Authorization Failed or session timed out. 
			Return to <a href=\"admin_login.php\">Admin Login</a> or <a href=\"\">Start page</a> to try again.";
			#header("location: admin_login.php");
			exit();
		}
		header("location: admin_login.php");#ldap_do_login.php?loginid=".$_REQUEST["loginid"]);#."&requrl=".$_SERVER['REQUEST_URI']);
		exit();
	}
	if ($objSession->isAdminUser() == false){
		echo "Access denied! Return to <a href=\"admin_login.php\">Admin Login</a> to try again.";
		header("location: admin_login.php");
		exit();
	}
	$idUser = 0; // its an admin user
	$defaultIdTemplate = 11; #11 should be the first template to be created. If no template is created, what happens then?
	$templ = -1; #the template used to 
	#------------------
	#get a defaultTemplate for current user, based on regular user login
	$user = getUser($objSession->getIdUser());
	# removed ejimenk # $user = getUser(5751); #remove when done.. 5211 EEMIJON, 5751 ETORHUN
	if (is_object($user)){ #if $user is an object
		$userID = $user->getUserID();
		$arrUser = getUserComplete($userID);#getUser($objSession->idUser)));
		$dept = getDepartment($arrUser['department']);
		$templ = $dept->getIdRedDayTemplate();
	}
	
	$defaultTemplate = ($templ == -1)? $defaultIdTemplate : $templ; #if no template is set, use the default template set a few rows earlier
	#------------------
	#om det g�r att plocka fram en default template s� g�r det, annars anv�nd defaultTemplaten
	$idTemplate = (isset($_GET['template'])) ? $_GET['template'] : $defaultTemplate; #Choose template for editing, default to $defaultTemplate.
	#------------------
	$chrTemplateName = getTemplateNameFromId($idTemplate);
	 
	
	if ($_REQUEST["chrAction"] == "save_days"){
		# split single param into userdays param
		$arrParam = explode("===_===",$_POST["chrParam"]);
		$arrQueries = array();
		$chrDaysApplied = "";

		#loop through each user day
		foreach($arrParam as $eachRec){
			if ($eachRec){
				# split day information
				$arrDay = explode("-_-",$eachRec);
				$intDay = $arrDay[0];
				$intMonth = $arrDay[1];
				$intYear = $arrDay[2];
				$chrCharacter = $arrDay[3];
				$inttime    = mktime(0,0,0,$intMonth,$intDay,$intYear);
				$chrComments = safeDatabase(safeHTML($arrDay[4]));

#-----------------------#--Template management--#-----------------------#
				
				$arrQueries[] = getQueryForADayRecord( $idTemplate, $intDay, $intMonth, $intYear, $chrCharacter, $inttime, $chrComments );
				#$arrQueries[] = getQueryForADayRecord(  0 , $intDay, $intMonth, $intYear, $chrCharacter,$inttime,$chrComments );
				
				
				
				
#-----------------------#-----------------------#-----------------------#
/*				
				/* Get All user in our local database *_/
				$arrUsers = getArrAllUserIds();
				foreach ($arrUsers as $idUser){
					# Get Query if it is inset or upade
					$arrQueries[] = getQueryForADayRecord( $idUser, $intDay, $intMonth, $intYear, $chrCharacter,$inttime,$chrComments );
				}

				#Add Query for admin reference as well so that he can see what holidays he has created. idUser = 0  is for admin
				$arrQueries[] = getQueryForADayRecord(  0 , $intDay, $intMonth, $intYear, $chrCharacter,$inttime,$chrComments );
	*/			
			}#if there is record
		}#endforeachRec

		foreach($arrQueries as $chrQuery){
			mazDb_query_params($chrQuery, array());
		}
		header("location: admin_reddays.php?intYear=".$_POST["intYear"]."&intSlide=".$_POST["intSlide"]."&template=".$idTemplate);
		exit();
	}
	else if ($_REQUEST["chrAction"] == "clear_days"){
		$arrParam = explode("===_===",$_POST["chrParam"]);
		$arrQueries = array();
		foreach($arrParam as $eachRec){
			if ($eachRec){
				$arrDay = explode("-_-",$eachRec);
				$intDay = $arrDay[0];
				$intMonth = $arrDay[1];
				$intYear = $arrDay[2];

				# Clear holiday from every one

				$arrQueries[] = $arrQueries[] = "DELETE FROM dbatn_userdays WHERE \"idUser\"=$idTemplate AND \"intDay\"=$intDay  AND \"intYear\"=$intYear  AND \"intMonth\"=$intMonth AND \"chrCharacter\"='R' ";
				//$arrQueries[] = "DELETE FROM dbatn_userdays WHERE \"idUser\"=$idUser AND \"intDay\"=$intDay  AND \"intYear\"=$intYear  AND \"intMonth\"=$intMonth";
			}#if there is record
		}#endforeach
		foreach($arrQueries as $chrQuery){
			mazDb_query_params($chrQuery, array());
		}
		header("location: admin_reddays.php?intYear=".$_POST["intYear"]."&intSlide=".$_POST["intSlide"]."&template=".$idTemplate);
		exit();
	}
	header('Content-Type: text/html; charset=utf-8');
	
	$self = 'admin_reddays.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("Admin Holidays"); ?></title>
		<?php echo generateScripts(); ?>
		<script type="text/javascript">
			N = (document.all) ? 0 : 1;
			var ob;
			var btnDown = false;

			function MD(e){
				if (window.event.srcElement.tagName != "HTML") {
					btnDown = true;
				}
			}

			function MM(){
				if (btnDown == true && document.getElementById("divComments").style.display != ""){
					//document.getElementById("tselect").focus();
					//document.focus();
					return false;
				}
			}

			function MU() {
				btnDown = false;
			}

			if (N) {
				document.captureEvents(Event.MOUSEDOWN | Event.MOUSEMOVE | Event.MOUSEUP);
			}

			document.onmousedown = MD;
			document.onmousemove = MM;
			document.onmouseup = MU;

			function mouseMoveSelection( obj ){
				if (btnDown == true) {
					selectbox(obj);
				}
			}


			function clearSelectedDays(){
				arrTds = document.getElementsByTagName("td");
				var str = "";
				for(i=0; i<arrTds.length; i++){
					if (arrTds[i].className == "selectedbox"){
						arrTds[i].className = "dirty";
						str += arrTds[i].getAttribute("dayValue")+"-_-"+arrTds[i].getAttribute("monthValue")+"-_-"+arrTds[i].getAttribute("yearValue")+"===_===";
					}
				}
				document.frmApply.chrAction.value = "clear_days";
				document.getElementById("chrParam").value=str;
				document.frmApply.submit();
			}

			function applySettings(){
				arrTds = document.getElementsByTagName("td");
				var str = "";
				for(i=0; i<arrTds.length; i++){
					if (arrTds[i].className == "dirty" || arrTds[i].className=="dirtyi"){
						str += arrTds[i].getAttribute("dayValue")+"-_-"+arrTds[i].getAttribute("monthValue")+"-_-"+arrTds[i].getAttribute("yearValue")+"-_-"+arrTds[i].getAttribute("chrCharacter")+"-_-"+arrTds[i].getAttribute("chrComments")+"===_===";
					}
					if (arrTds[i].className == "noteadded" || arrTds[i].className=="noteaddedi"){
						str += arrTds[i].getAttribute("dayValue")+"-_-"+arrTds[i].getAttribute("monthValue")+"-_-"+arrTds[i].getAttribute("yearValue")+"-_-"+arrTds[i].getAttribute("chrCharacter")+"-_-"+arrTds[i].getAttribute("chrComments")+"===_===";
					}
				}
				document.getElementById("chrParam").value=str;
				document.frmApply.submit();
			}

			function saveBoxes(chrType) {
				var chrComments = "";
				if (chrType == "edit_comments" && intBoxSelected != 1){
					alert("Please select only one box inorder to edit its comments");
					return;
				}
				arrTds = document.getElementsByTagName("td");
				intRedDays = 0;
				intNormalDays = 0;
				for(i=0; i< arrTds.length; i++){
					if (arrTds[i].getAttribute("chrCharacter") == "R" && arrTds[i].className == "selectedbox") {
						intRedDays++;
						arrTds[i].className = "redday";
					}
					else {
						if (arrTds[i].className == "selectedbox"){
							chrComments = arrTds[i].getAttribute("chrComments");
							intNormalDays++;
						}
					}
				}
				if (intRedDays > 0 && intNormalDays == 0){
					alert("You can not change type of a Public Holiday (Marked 'R'). Please first clear the Public Holiday Status");
					return;
				}
				else if (intRedDays > 0){
					alert("Please note: Public Holidays (Marked 'R') will not be affected");
				}
				document.getElementById("chrComments").value = chrComments;
				document.getElementById("divComments").style.display = "";
				selectedOption = chrType;
			}

			function selectbox(objTd){
				if (objTd.className == "daybox" || objTd.className == "noteadded" || objTd.className == "noteaddedi" || objTd.className == "redday" || objTd.className == "reddayi"){
					objTd.className = "selectedbox";
					intBoxSelected++;
				}
				else if (objTd.className == "selectedbox"){
					objTd.className = objTd.getAttribute("class2");
					intBoxSelected--;
				}
			}



			var selectedOption = "";
			var intBoxSelected = 0;

			function cancelComments() {
				document.getElementById("divComments").style.display = "none";
			}

			function saveComments() {
				document.getElementById("divComments").style.display = "none";
				arrTds = document.getElementsByTagName("td");
				for(i=0; i<arrTds.length; i++) {
					if (arrTds[i].className == "selectedbox"){
						if (selectedOption != "edit_comments") {
							arrTds[i].innerHTML = arrTds[i].getAttribute("dayValue")+"<br>"+selectedOption;
							arrTds[i].setAttribute("chrCharacter",selectedOption);
						}
						arrTds[i].setAttribute("chrComments",document.getElementById("chrComments").value);
						arrTds[i].setAttribute("title",document.getElementById("chrComments").value);
						if (document.getElementById("chrComments").value == ""){
							arrTds[i].className = "dirty";
						}
						else{
							arrTds[i].className = "dirtyi";
						}

						//alert(arrTds[i].getAttribute("chrCharacter"));
					}
				}
				applySettings(); /* auto matically apply settings */
			}
		</script>
	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar">
					
					<h1 class="pageheading">Add Public Holidays To Template</h1>
					<form action="<?php echo $self ?>" method="get">
					<div>	
						<input type="button" title="Clear Days" onclick="clearSelectedDays()" value="Clear Days" />
						<input type="button" value="Add Holidays" title="Add Holidays" class="redday" onclick="saveBoxes('R')" />
					
						<?php #alter information about what template is in use depending on department settings
						if ($chrTemplateName == "") {
						?>
						<span class="pageheading">&nbsp; &nbsp; &nbsp;
						Please select a template to edit
						 </span> &nbsp; &nbsp; &nbsp;
						<?php 	
						}else {
						?>
						<span class="pageheading">&nbsp; &nbsp; &nbsp;
						Template in use:	
						<?php echo " <u>{$chrTemplateName}</u>"; ?>
						 </span> &nbsp;
						<?php 
						}
						?>
						<select title="Change Template" id="template" name="template" onchange="this.form.submit();">
					<?php					
					foreach (getArrTemplates() as $arrTemplate) {
						#display($arrTemplate);
						$chrSelected = "";
						if ($idTemplate == $arrTemplate['iduser']) {
							$chrSelected = " selected = 'selected'"; 
						}
						echo "<option value=\"".$arrTemplate['iduser']."\"".$chrSelected.">".$arrTemplate['name']."</option>";
					}
					?>
						<!-- <input type="submit" value="Switch to Template" /> -->
						</select>

					</div>
					</form>
				</div>
	<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%"/>
	<tr>
    	<td valign="top" bgcolor="#505050" height="100%" >
    		<table cellpadding="0" cellspacing="" width="100%">
        		<tr>
          			
            		<td class="workareaBox" valign="top">
    				<!-- ##################################	Working Area START ################################# -->
        				<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#505050">
        					<!-- InstanceBeginEditable name="subheader section" -->
	     					<tr>
        						<td valign="top" align="center">				<!-- _____SubHeader START_____ -->
       								<table cellpadding="0" align="center" border="0" cellspacing="0" width="100%">
           	  							<tr class="dateControl" >
                							<td width="1px"><img src="media/images/subheaderleft.jpg" /></td>
                							<td width="210" class="subheader"></td>
				  							<?php
											# cuurent selected day
											$intYear = $_REQUEST["intYear"] ? $_REQUEST["intYear"] : date("Y",time());
											# year starting
											$intSlide = $_REQUEST["intSlide"] ? $_REQUEST["intSlide"] : $intYear - 1;
											?>
                  							<td class="subheader" width="100"><?php echo "<a href=\"admin_reddays.php?intSlide=".($intSlide-1)."&intYear=".($intYear-1)."&template=".($idTemplate)."\" class=navyearlink>&#9668;</a>" ?>
                  							<td width="1px" style="padding-bottom:3px"><img src="media/images/subheaderseprator.jpg" /></td>
                  							<?php
											# draw year slide
											for($i = $intSlide; $i < $intSlide+3; $i++){
												if ($i == $intYear){
													echo '<td class="subheader" width="100">'."<span class=subheaderlinkselected>$i</span>".'</td>';
												}
												else {
													echo '<td class="subheader" width="100">'."<a href=\"admin_reddays.php?intYear=$i&intSlide=$intSlide\" class=subheaderlink>$i</a>".'</td>';
												}
												echo '<td width="2px" style="padding-bottom:3px"><img src="media/images/subheaderseprator.jpg" /></td>';
											}
			   								#echo "<a href=\"admin_reddays.php?intSlide=".($intSlide+1)."&intYear=".($intYear&template=".($_GET[template])."\" class=navyearlink> &#9658; </a>";
											?>
                							<td class="subheader" width="100"><?php echo "<a href=\"admin_reddays.php?intSlide=".($intSlide+1)."&intYear=".($intYear+1)."&template=".($idTemplate)."\" class=navyearlink> &#9658; </a>" ?></td>
											<td class="subheader">&nbsp;</td>
                							<td width="2px"><img src="media/images/subheaderright.jpg" /></td>
              							</tr>
            					</table>			<!-- _____SubHeader END_____ -->
	        				</td>
      					</tr>
        				<!-- InstanceEndEditable -->
      					<tr>
        					<td height="100%">				<!-- _____Contents START_____ -->
            					<div id="workingDiv" style="width:100%;height:<?php echo CALENDAR_HEIGHT ?>">
                				<table bgcolor="#505050" width="100%" height="100%" >
                    				<tr>
                        				<td style="padding-top:1px;"><!-- InstanceBeginEditable name="working-area" -->
                            				<div id="divComments" style="display:none;position:absolute;width:400px;left:200px;top:200px" class="monthtable">
                            				<table width="100%" bgcolor="#FEFBF3" style="border:1px solid #000000">
                                				<tr>
                                    				<td class="monthname">Add Comments</td>
                                				</tr>
                                				<tr>
                                    				<td>
                                        				<textarea id="chrComments" name="chrComments" cols="40" rows="5"></textarea>
                                        				<br />
                                        				<input type="button" onclick="saveComments()" value="Save" />   <input type="button" onclick="cancelComments()" value="Cancel" />
                                        			</td>
                                				</tr>
                            				</table>
                            				</div>
                            				<table width="100%" bgcolor="#FFFFFF" border="0" cellspacing="3" cellpadding="3" height="<?php echo CALENDAR_HEIGHT ?>">
  												<tr>
    												<td align="center" class="yeartd">
    													<form name="frmApply" id="frmApply" method="post">
	        												<input type="hidden" id="chrAction" name="chrAction" value="save_days" />
													        <input type="hidden" id="intYear" name="intYear" value="<?php echo $intYear ?>" />
													        <input type="hidden" id="intSlide" name="intSlide" value="<?php echo $intSlide ?>" />
													        <input type="hidden" value="" id="chrParam" name="chrParam"/>
												        </form>
    													<?php
														$arrUserDays = getTemplateDaysFromId($idTemplate, $intYear);
														#echo $idTemplate.$intYear;
														#display($arrUserDays);
    													/*
    													$chrQuery = "select * FROM dbatn_userdays WHERE \"idUser\"='0' AND \"intYear\"=$1";
														$rs = mazDb_query_params($chrQuery, array($intYear));
														$arrUserDays = array();
														if (mazDb_num_rows($rs)){
															while($arr = mazDb_fetch_array($rs)){
																$arrUserDays[$arr["intMonth"]][$arr["intDay"]] = array("chrCharacter"=>$arr["chrCharacter"], "chrComments"=>$arr["chrComments"], "chrComments2"=>$arr["chrComments2"]);
															}
														}*/
														?>
														<table width="100%">
														    <?php
															for($i = 1; $i <= 12 ; $i+=3){
																?>
														        <tr>
														        	<td valign="top"><?php drawMonth($i,$intYear,$arrUserDays[$i]); ?></td>
														            <td valign="top"><?php drawMonth($i+1,$intYear,$arrUserDays[$i+1]); ?></td>
														            <td valign="top"><?php drawMonth($i+2,$intYear,$arrUserDays[$i+2]); ?></td>
														        </tr>
														        <?php
															}
															?>
												    	</table>
												    </td>
  												</tr>
											</table>				<!-- InstanceEndEditable --></td>
                        				</tr>
                    				</table>
                					</div>				<!-- _____Contents End_____ -->
        						</td>
      						</tr>
    					</table>
    					<!-- ##################################	Working Area END ################################# -->
          			</td>

          		</tr>
	  		</table>
    	</td>
  	</tr>
</table>
			</div>
		</div>
		<?php echo generateFooter(); ?>
	</body>
</html>
