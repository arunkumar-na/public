<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");
	include_once("include/template.php");

	/** Create session object
		and try to load user info (id name etc from session)
	**/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
		exit();
	}
	header('Content-Type: text/html; charset=utf-8');
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("Holiday View"); ?></title>
		<?php echo generateScripts(); ?>
<script type="text/javascript">

$(document).ready(function(){
	setNewHeightAndWidth(0);
});
function setNewHeightAndWidth(tab) {
	$(".firstTd").css("padding-left", tab+"px");

	var calendarWidth = $('#toolbar').width()-50+'px';
	$('.outer').css("width", calendarWidth);
	$('.inner').css("width", calendarWidth);
	//$('.calendarTable').css("width", calendarWidth);

	//Make the fixed scroll control the tablescroll
	$(".outerScrollDiv").css("max-width", calendarWidth);
	$(".scrollDiv").css("width", $('.calendartable').width());
	$(".outerScrollDiv").scroll(
		function(){
			$(".inner").scrollLeft($(".outerScrollDiv").scrollLeft());
			btnDown = false;
		});

	//Change html height to fit the new height (after calendar has been generated)
	$("html").css("height", $('#contentInner').height()+200);
}
</script>
	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar">
					<img src="media/images/TabNavigator2.png" />&nbsp;
					<span class="pageheading"><span class="ericssonHeading">Holiday Calendar</span>
					</span>
				</div>


<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  	<tr>
    	<td valign="top" bgcolor="#505050" height="100%" >
    		<table cellpadding="0" cellspacing="" width="100%">
        		<tr>
          			<td bgcolor="#505050">&nbsp;</td>
            		<td class="workareaBox" valign="top">
    				<?php ###################################	Working Area START ################################# ?>
					<?php # InstanceBeginEditable name="subheader section" ?>
					<?php # InstanceEndEditable ?>
		<!-- _____Contents START_____ -->


					<div id="workingDiv" style="width:100%;height:<?php echo CALENDAR_HEIGHT ?>">
						<div style="padding-top:5px; background-color:#505050;">
						<?php # -------------InstanceBeginEditable name="working-area" ----- ?>                            				
						<?php
						/**
						 * Get list of templates(users) from database as we need to show them
						 * in our custom select box.
						 *
						 * and then we will check those templates that were selected by the user
						 *
						 */
						$arrTemps = get_templates_from_db();
						ksort($arrTemps);
					
						if ($_REQUEST["chrAction"] == "view_list") {
							$intCount = $_REQUEST["temp_count"];
							$arrSearchTemplate = array();
							for ($i = 0; $i < $intCount; $i++) {
								if ($_REQUEST["temp$i"]){
									$arrSearchTemplate[$_REQUEST["temp$i"]] = str_replace("_X_","/",$_REQUEST["temp$i"]);
								}
							}
						}
						else {
							$arrSearchTemplate = $arrTemps;
						}
						
						
						?>
						<form name="frm1" id="frm1" method="post" action="view_all_templates.php">
							<?php
							$chrAction = "view_list";
							?>
							<input type="hidden" name="chrAction" id="chrAction" value="<?php echo $chrAction ?>" />
							<input type="hidden" name="uids" id="uids" value="<?php echo $_REQUEST["uids"] ?>" />
							<input type="hidden" name="chrParam" id="chrParam" value="" />
							<table width="100%" bgcolor="#FFFFFF">
								<tr>
								<td class="expandmenu">
									<table border="0" cellspacing="5" cellpadding="5">
										<tr>
											<td><span class="caption">Holiday Templates:</span>
											<?php
												$ovr_style= "style=width:300px";
												mazSelectControlSearch("temp",$arrTemps ,$arrSearchTemplate,true,false,$ovr_style);
		
											?></td>
											<?php
												/**
												 * Date range selection crtiera is made
												 * if no criteria is mentioed then, all date fields will be selected
												 * with current month and year
												 * for to and from date range
												 */

												$intFromMonth = ($_REQUEST["fromMonth"]) ? $_REQUEST["fromMonth"] : date("m",time());
												$intToMonth = ($_REQUEST["toMonth"]) ? $_REQUEST["toMonth"] : date("m",time());
												$intYear = ($_REQUEST["intYear"]) ? $_REQUEST["intYear"] : date("Y",time());
												$intYear2 = ($_REQUEST["intYear2"]) ? $_REQUEST["intYear2"] : date("Y",time());

												#if to year(end year) is less that from year(start year)
												# then make them same as Start year
												if ($intYear2 < $intYear){
													$intYear2 = $intYear;
													$intToMonth = $intFromMonth;
												}else if ($intYear2 > $intYear+1) {
													#if ending year is not next year make it next year
													# as we are allowed only one year accross the current year
													$intYear2 = $intYear+1;
												}

												#colspan calculation based on year and months
												$intColSpan = ($intYear2 == $intYear) ? (intval($intToMonth) - intval($intFromMonth)) + 2 : (intval($intToMonth) + 12 - intval($intFromMonth)) + 2;
											?>
											<td align="left">
												<table border="0">
													<tr>
													<td class="caption">
															From:
													</td>
													<td class="caption">
															To:
													</td>
													</tr>
													<tr>

														<td>
															<?php echo monthsCombo("fromMonth", $intFromMonth) ?>
														</td>
														<td>
															<?php echo monthsCombo("toMonth", $intToMonth) ?>
														</td>
													</tr>
													<tr>
														<td>
															<?php echo yearsComboX("intYear",2000,date("Y",time())+10,$intYear) ?>                                                    
														</td>
														<td>
															<?php echo yearsComboX("intYear2",2000,date("Y",time())+10,$intYear2) ?>
														</td>
													</tr>
												</table>
											</td>
											<td><input type="submit" name="btnShow" id="btnShow" value="Search" /></td>
										</tr>
									</table>
								</td>
								</tr>
							</table>
						</form>
                <form id="frmCSV" name="frmCSV" method="post" action="generate_csv.php" target="_blank">
                	<input type="submit" value="Generate CSV" />
					<!-- two div for seperate scrolling of calendar, username should not disappear while scrolling months-->
					<div class="outerScrollDiv"><div class='scrollDiv'>.</div></div>
					<div class='outer' bgcolor="#FFFFFF">											
						<div class='inner' bgcolor="#FFFFFF">
							<table class="calendartable" cellspacing="1" width="100%" cellpadding="1" bgcolor="#FFFFFF">
                    	<?php
								
						if ($arrSearchTemplate){
							 $chrTemplateList = "'".implode("','",$arrSearchTemplate)."'";

							 $_REQUEST["chrAction"] = "view_list";
						} else {
							$chrTemplateList = "'-1'"; #means nothing is selected in selection criteria
						}
						# get selected template details								
						$chrQuery = "SELECT * FROM dbatn_userslist WHERE name IN ($chrTemplateList) AND dn='t';";


						$rs = mazDb_query_params($chrQuery, array());
						if (mazdb_num_rows($rs) > 0) {
						$counter=0;

						$blnDisplayWeeks = true;
						while($arr = mazDb_fetch_array($rs))
						{
							$counter++;
							
							# alternative row css style
							$chrClass = "gridData1";
							if ($counter % 2 == 0){
								$chrClass = "gridData2";
							}

							  $idSelectedUser = $arr["iduser"];
							  if (!$idSelectedUser || $idSelectedUser == "" || $idSelectedUser == 0)
							  {
								 $idSelectedUser = $objSession->getIdUser();
							  }

								#get user marked days for both years
								#$arrUserDays[$intYear] = getUserDays($idSelectedUser, $intYear);
								#$arrUserDays[$intYear2] = getUserDays($idSelectedUser, $intYear2); #these rows changed into:
								#-------------------------------------------------------------------
								#-------------------------------------------------------------------
								$arrUserDays[$intYear] = getUserAndTemplateDays( $idSelectedUser, $intYear );
								$arrUserDays[$intYear2] = getUserAndTemplateDays( $idSelectedUser, $intYear2 );
																		
								#-------------------------------------------------------------------
								#-------------------------------------------------------------------

								$intEndMonth = ($intYear == $intYear2) ? $intToMonth : $intToMonth+12;

								# as for each template we show week bar only once, mean not before every user
								# but only before first user, that is handled here
								if ($blnDisplayWeeks == true){

									$chrMonths = "";
									$chrWeeks = "";
									$chrDays = "";
									$csvMonth = "";
									$csvWeek = "";
									$csvDay = "";

									#loop throught month calandre
									for($i = $intFromMonth; $i <= $intEndMonth ; $i++)
									{
										$intSelectedMonth = $i;
										$intSelectedYear = $intYear;

										if ($i > 12) {
											$intSelectedMonth = $i-12;
											$intSelectedYear = $intYear2;
										}
										$arrHd = drawMonthHeader($intSelectedMonth, $intSelectedYear);
										$chrMonths .= $arrHd["month"];
										$chrWeeks .= $arrHd["weeks"];
										$chrDays .= $arrHd["days"];

										$csvMonth .= $arrHd["csv_month"];
										$csvWeek .= $arrHd["csv_week"];
										$csvDay .= $arrHd["csv_day"];
									}
									$csvData .= "Month,".$csvMonth."\n";
									$csvData .= "Week,".$csvWeek."\n";
									$csvData .= "Days,".$csvDay."\n";
									$csvMonth = "";
									$csvWeek = "";
									$csvDay = "";
									# display month names, weeks and days columns
									echo "<tr><td></td>$chrMonths</tr>";
									echo "<tr><td></td>$chrWeeks</tr>";
									echo "<tr><td></td>$chrDays</tr>";

								}

								?>
									  <tr bgcolor="#FFFFFF" id="m">
									  <td class="personname" ><?php echo $chrEnter.str_replace(" ","&nbsp;",(trim($arr["name"]))) ?></td>
									<?php
								$csvUserDays = "";
								for($i = $intFromMonth; $i <= $intEndMonth ; $i++)
								{
									$intSelectedMonth = $i;
									$intSelectedYear = $intYear;

									if ($i > 12) {
										$intSelectedMonth = $i-12;
										$intSelectedYear = $intYear2;
									}
										# month counter
									$month = date("M",mktime(1,1,1,$intSelectedMonth,1,$intSelectedYear));

										# user days also contain year info inotfetr to show proper detaul
									$arrThisMonth = $arrUserDays[$intSelectedYear][intval($intSelectedMonth)];
									$chrExtraParams = "iduser=".$arr["iduser"];
									$blnAllowEditing = false;

										# draw month for selected counters (month,year)
									$arrData = drawMonthUserDaysTemplates($intSelectedMonth, $intSelectedYear, $arrThisMonth, $chrExtraParams, $blnAllowEditing);
									echo $arrData["html"];
									$csvUserDays .= $arrData["csv"];
										#drawMonthLine($intSelectedMonth, $intSelectedYear, $arrThisMonth, $chrExtraParams, $blnAllowEditing, false);

										#drawMonthDaysOnly($i, $intYear, $arrThisMonth, $chrExtraParams, $blnAllowEditing);

								}#endfor month loop
								$csvData .= $arr["name"].",".$csvUserDays."\n";
								$blnDisplayWeeks = false;
									?>
								  </tr>
								<?php
						}
						$intColSpan = getTotalDays($intFromMonth,$intYear,$intToMonth,$intYear2) + 1;
						}
						else
						{
						?>
					  <tr >
						<td class="gridData2" colspan="<?php echo $intColSpan ?>"> No Record found </td>
					  </tr>
					  <?php
					  }
					  ?>
					  <tr>
						<td class="gridData2" colspan="<?php echo $intColSpan ?>"> -  <input type="hidden" name="csvData" value="<?php echo trim($csvData) ?>" /></td>
					  </tr>
					</table>
				</div>
				</div>
			<input type="submit" value="Generate CSV" />
			</form>
					<!-- InstanceEndEditable -->
				</div>
</div>

            <?php  #_____Contents End_____ ?>

        	<!-- ##################################
        	Working Area END
            ################################# -->
          </td>
          </tr>
	  </table>
    </td>
  </tr>
</table>




			</div>
		</div>
		<?php echo generateFooter(); ?>
	</body>
</html>
