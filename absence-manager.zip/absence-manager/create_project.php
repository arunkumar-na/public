<?php
session_start();

include_once("include/site/settings.php");
include_once("include/site/db.php");
include_once("include/ldapfunc.php");
include_once("include/utilfunc.php");
include_once("include/cmazsession.php");
include_once("include/common.php");
include_once("include/menu.php");
include_once("include/page.php");
include_once("include/user.php");

/** Create session object and try to load user info (id name etc from session) **/
$objSession = new cMazSession();
$objSession->loadFromSessionToken();
if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
	header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
	exit();
}
$idUser = $objSession->getIdUser();
if ($_REQUEST["chrAction"] == "create_project"){
	$idCreatedBy = $objSession->getIdUser();
		# Group or Project? Group(1) Project (0)
	$type = $_POST['type'];
	$chrProjectName = safeDatabase($_POST["chrGroup"]);
		//change multiple spaces to 1 space
	$chrProjectName = preg_replace("/\s+/"," ",$chrProjectName );

	if ($idCreatedBy == -1){
			# if this user does not exist in the system then import him in the system
		$idCreatedBy = importUserIntoTheSystem($objSession->getUid());
	}




		#remove backslashes and quotes from name
	$chrProjectName = str_replace('\\', '', $chrProjectName);
	$chrProjectName = str_replace('\'', '', $chrProjectName);
	$chrProjectName = str_replace('"', '', $chrProjectName);

		# check if this group name already exisit or not
	$chrQuery = "SELECT idproject FROM dbatn_projects where chrproject=$1";
	$rsx = mazDb_query_params($chrQuery, array($chrProjectName));
	
		// if name exist or no content of $chrProjectName
	if (mazDb_num_rows($rsx) || strlen($chrProjectName) == 0 ){
		header("location: create_project.php?msg=Group/Project already exists"); //if grp already exists, reload page with error msg
		exit;
		$blnNameAlready = true;
			# if gtoup name already exsist then select a random name, and save record with it and then
			# after saving all record open this project in edit mode and give user an error
			# that name already exist so that he can change it
		$chrProjectName = time();
	}
		# get next available id from the sequence
	$idProject = getNextNumber("seq_idproject_projects");
	if ($idProject < 1) {
		echo "invalid idproject";
		exit();
	}



		# first insert the project
	
	$chrQuery = "INSERT INTO dbatn_projects(idproject,chrproject,idcreatedby,intdate, isGroup)values($idProject,'".safeDatabase($chrProjectName)."',$idUser,".time().",$type)";
	mazDb_query_params($chrQuery, array());

		# allow this project to view him self, mean member of this project will be able to see this project
	$chrQuery = "INSERT INTO dbatn_project_project(idproject,chrprojectallowed) values ($idProject,'".safeDatabase($chrProjectName)."');";
	mazDb_query_params($chrQuery, array());

		# make current user owner of this project
	$chrQuery = "INSERT INTO dbatn_project_owner(iduser,idproject) values($idCreatedBy,$idProject)";
	mazDb_query_params($chrQuery, array());

		#Store user id used to connect user to project/group later
	$arrIdUsers = array();
	$arrParentProj = array();
	$arrAlreadyProcessesed = array();

		//if group
	if($type == "true") {
			#Search and store all user id. Also save queries for users that need to be updated or inserted in dbatn_userslist
		for($i = 0; $i < $_POST["total"]; $i++) {	
			if ($_POST["sel_pg_$i"]) {
				$arrParentProj[] = $_POST["sel_pg_$i"];
			}
			else {
				$arrParentProj[] = NULL;
			}
			
			if ($_POST["sel_$i"]) {
				$chrUserID = $_POST["sel_$i"];
				$objRecord = getOrImportUser($chrUserID); 
					# check if user already exist or not
				$uid = $chrUserID;
				$chrQuery = "SELECT iduser FROM dbatn_userslist WHERE uid=$1";
				$rs = mazDb_query_params($chrQuery, array($uid));
				$idNextNumber = 0;
				
				if (mazDb_num_rows($rs) > 0 ) {
					$arr = mazDb_fetch_array($rs);
					$idNextNumber = $arr["iduser"];
					if (in_array($idNextNumber,$arrAlreadyProcessesed)){
						continue;
					}
					else {
						$arrAlreadyProcessesed[] = $idNextNumber;
					}				
				}
				$arrIdUsers[] = $idNextNumber;							
				}#if record				
			}#end foreach		
			#Connect user to group
			foreach($arrIdUsers as $idSelectedUser) {
				$chrListQuery = "INSERT INTO dbatn_projectlist(idproject,iduser,chrproject) values($idProject,$idSelectedUser,'".safeDatabase($chrProjectName)."')";
				mazDb_query_params($chrListQuery, array());			
			}
			foreach($arrParentProj as $idParent) {
				if($idParent != NULL) {
					$chrQuery = "SELECT * FROM dbatn_project_subprojects WHERE idproject = $idProject AND idsubproject = $idParent";
					$rs = mazDb_query_params($chrQuery, array());				
					if( mazDb_num_rows($rs) == 0 ) {
						$chrSubprojQuery = "INSERT INTO dbatn_project_subprojects(idproject,idsubproject) values ($idProject,$idParent)";
						mazDb_query_params($chrSubprojQuery, array());
					}
				}
			}
		} else { //if project
			for($i = 0; $i < $_POST["total"]; $i++) {
				if ($_POST["sel_$i"]) {
					$subProjID = $_POST["sel_$i"];
					$chrSubprojQuery = "INSERT INTO dbatn_project_subprojects(idproject,idsubproject) values ($idProject,$subProjID)";
					mazDb_query_params($chrSubprojQuery, array());
				}
			}
		}

		#if project name already exist send user on edit project page
		if ($blnNameAlready == true){
			header("location: edit_project.php?proj0=".$chrProjectName."&proj_count=1&chrAction=edit_list&msg=".urlencode($_REQUEST["chrGroup"].", name Already exsist"));
		}
		else {
			header("location: list_projects.php");
		}
		exit();
	}
	header('Content-Type: text/html; charset=utf-8');
	?>

	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("Create Project"); ?></title>
		<?php echo generateScripts(); ?>
		<script type="text/javascript">
		var intCheckCounter = 0;
		var intSelectedRecord = -1;

		//empty selected list when user changes create type
		function onChangeType() {
			var selUsers = document.getElementById("selUsers");
			selUsers.innerHTML="&nbsp;";

			//if user changes type to "group"
			if($('#groupRadio').is(':checked')){
				$('#searchBtn').attr('onclick', 'openPopupSearchUsers()');
				$('#searchBtn').attr('value', 'Add users');
			} else {
				$('#searchBtn').attr('onclick', 'openPopupSearchGroups()');
				$('#searchBtn').attr('value', 'Add projects/groups');
			}
		}

		function openPopupSearchUsers(){
			searchUsers(function (arrSelected){
				var counter = intCheckCounter;
				intCheckCounter += arrSelected.length;
				intSelectedRecord += arrSelected.length;
				var selUsers = $('#selUsers');
				for (var i = 0; i < arrSelected.length; i++){
					if (i != 0 && i % 4 == 0){
						selUsers.append('<br />');
					}
					var user = arrSelected[i];
					str = "<"+"input type=\"checkbox\" checked=\"checked\" name=\"sel_"+counter+"\" id=\"sel_"+counter+"\" value=\""+user.uid+"\" />"+user.name+ "&nbsp;";					
					selUsers.append(str);
					if (user.parent_idproject) {					
						str_parent_group = "<"+"input type=\"hidden\" name=\"sel_pg_"+counter+"\" id=\"sel_pg_"+counter+"\" value=\""+user.parent_idproject+"\" />;";
						selUsers.append(str_parent_group);
					}
					counter++;
				}
			});
		}
		function openPopupSearchGroups(){
			searchGroups(function (arrSelected){
				var counter = intCheckCounter;
				intCheckCounter += arrSelected.length;
				intSelectedRecord += arrSelected.length;
				var selRecords = $('#selUsers');
				for (var i = 0; i < arrSelected.length; i++){
					if (i != 0 && i % 4 == 0){
						selRecords.append('<br />');
					}
					var record = arrSelected[i];
					str = "<"+"input type=\"checkbox\" checked=\"checked\" name=\"sel_"+counter+"\" id=\"sel_"+counter+"\" value=\""+record.idproject+"\" />"+record.chrproject+ "&nbsp;";					
					selRecords.append(str);
					counter++;
				}
			});
		}
		function validateForm(){
			if (document.frmCreate.chrGroup.value == ""){
				alert("Please enter group name to create");
				document.frmCreate.chrGroup.focus();
				return false;
			}
			else if (intSelectedRecord < 0 && $('#groupRadio').is(':checked')){
				alert("No user selected");
				return false;
			}
			else {
				document.frmCreate.total.value = intCheckCounter;
				return true;
			}
			return false;
		}

		function removeUser(idx){
			document.getElementById("sel_"+idx).value = "";
			//document.getElementById("msnUser"+idx).innerHTML = "";
			var d = document.getElementById("selUsers");
			var child1 = document.getElementById("sel_"+idx);
			var child2 = document.getElementById("msnUser"+idx);
			child2.innerHTML = "";
			d.removeChild(child1);
			d.removeChild(child2);
			intSelectedRecord--;
		}
		</script>
	</head>
	<body>
		<?php
		echo generateHeader();
		echo generateMenu($objSession);
		?>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar">
					<img src="media/images/edit.png" />&nbsp;
					<span class="pageheading"><span class="ericssonHeading">Add Group/Project</span></span>
				</div>
				<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
					<tr>
						<td valign="top" bgcolor="#505050" height="100%" >
							<table cellpadding="0" cellspacing="" width="100%">
								<tr>
									<td bgcolor="#505050">&nbsp;</td>
									<td class="workareaBox" valign="top">
										<!-- ################################## Working Area START ################################# -->
										<table width="100%" border="0" cellspacing="1" cellpadding="1">
											<!-- InstanceBeginEditable name="subheader section" -->
											<!-- InstanceEndEditable -->
											<tr>
												<td height="100%">			<!-- _____Contents START_____ -->
													<div id="workingDiv" style="width:100%;height:<?php echo CALENDAR_HEIGHT ?>">
														<table bgcolor="#505050" width="100%">
															<tr>
																<td style="padding-top:5px;"><!-- InstanceBeginEditable name="working-area" -->
																	<form name="frmCreate" id="frmCreate" method="post" onsubmit="return validateForm()">
																		<input type="hidden" name="chrAction" value="create_project" />
																		<input type="hidden" name="total" id="total" value="0" />
																		<table width="100%" bgcolor="#FFFFFF" border="0" cellspacing="3" cellpadding="3">
																			<tr>
																				<td colspan="2" class="formheading">Add Group/Project</td>
																			</tr>
																			<?php
																			$iduser = $objSession->getIdUser();
																			if ($iduser == -1){
																				$_REQUEST["msg"] = "You do not exist in the system, your account will be automatically imported to the system";
																			}
																			?>
																			<tr>
																				<td class="critical" colspan="2" align="center"><?php echo $_REQUEST["msg"] ?></td>
																			</tr>
																			<tr>
																				<td width="27%" class="caption">Name:</td>
																				<td width="73%"><input type="text" name="chrGroup" id="chrGroup" value="<?php echo $_REQUEST["chrGroup"] ?>" /></td>
																			</tr>
																			<tr>
																				<td width="27%" class="caption">Type:</td>
																				<td width="73%">
																					<input type="radio" id="groupRadio" name="type" value=true checked="checked" onclick="onChangeType()"> Group<br>
																					<input type="radio" id="projectRadio" name="type" value=false onclick="onChangeType()"> Project
																				</td>
																			</tr>
																			<tr>
																				<td>&nbsp;</td>
																				<td><input type="hidden" name="mixUsers" id="mixUsers" value="" />
																					<input type="button" id="searchBtn" value="Add users" onclick="openPopupSearchUsers()"/>&nbsp;
																				</td>
																			</tr>
																			<tr>
																				<td class="caption">Selected:</td>
																				<td  id="selUsers" class="msnuserbox" valign="top">&nbsp;</td>
																			</tr>
																			<tr>
																				<td>&nbsp;</td>
																				<td><input type="submit" name="btnCreate" id="btnCreate" value="Create" /></td>
																			</tr>
																		</table>
																	</form>
																	<!-- InstanceEndEditable --></td>
																</tr>
															</table>
														</div>			<!-- _____Contents End_____ -->
													</td>
												</tr>
											</table>
											<!-- ##################################	Working Area END ################################# -->
										</td>
										<td bgcolor="#505050">&nbsp;</td>
									</tr>
									<tr>
										<td bgcolor="#505050" colspan="3">&nbsp;</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</div>
			</div>
			<?php echo generateFooter(); ?>
		</body>
		</html>
