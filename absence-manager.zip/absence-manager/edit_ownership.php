<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");
	
	/** Create session object and try to load user info (id name etc from session) **/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();
	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
		exit();
	}

	if (isset($_REQUEST["projsSelected"])){
		$chrProject = $_REQUEST["projsSelected"][0];
	} else if (isset($_REQUEST['proj0'])){
		$chrProject = $_REQUEST['proj0'];
	} else {
		$chrProject = $_REQUEST['chrProject'];
	}
	#added by etorhun
	$idProject = getIdProject($chrProject);
	#echo ".0:".$chrProject." : ".$idProject.".";
	
	if ($_POST["chrAction"] == "update_ownership"){

		#echo ".1:".$chrProject." : ".$idProject.".";
		#$idProject = $_REQUEST["idProject"];

		# delete old owners of the project, new plus old will be inserted in next step		
		#echo ".2:".$chrProject." : ".$idProject.".";
		$arrOwnerQueries = array();
		#save new entries for owner
		$intOwnerCount = $_REQUEST["own_count"];
		//echo "Owner count:".$intOwnerCount."\n";
		if($intOwnerCount > 0) {
			$chrQuery = "DELETE FROM dbatn_project_owner WHERE idproject=$1";
			mazDb_query_params($chrQuery, array($idProject));
		}
		$arrOwners = array();
		for ($i = 0; $i < $intOwnerCount; $i++){
			$idSelectedUser = $_POST["own_".$i];
			//echo "Selected user:".$idSelectedUser."\n";
			if ($idSelectedUser && !in_array($idSelectedUser,$arrOwners)){
					$arrOwnerQueries[] = "INSERT INTO dbatn_project_owner(iduser,idproject) values ($idSelectedUser,$idProject);";
					$arrOwners[] = $idSelectedUser;
			}
		}
		foreach ($arrOwnerQueries as $chrQuery) {
			mazDb_query_params($chrQuery, array());
		}

		
		#Delete allowed projects
		$chrQuery = "DELETE FROM dbatn_project_project WHERE idproject=$1";
		#echo ".3:".$chrProject." : ".$idProject.".";
		mazDb_query_params($chrQuery, array($idProject));
		$arrProjectQueries = array();
		$intCount = $_REQUEST["allow_proj_count"];
		$flag = true;			//TD if flag remains true then all projects are selected
		for ($i = 0; $i < $intCount; $i++){
			$chrSelectedProject = safeDatabase($_POST["allow_proj".$i]);
			if ($chrSelectedProject){
					$arrProjectQueries[] = "INSERT INTO dbatn_project_project(idproject,chrprojectallowed) values ($idProject,'$chrSelectedProject');";
			}
			else {
				$flag = false;
			}
		}
		$arrProjectQueries[] = "INSERT INTO dbatn_project_project(idproject,chrprojectallowed) values ($idProject,'".safeDatabase($_REQUEST["proj0"])."');";
		if($_REQUEST['allow_proj_checkall'] == 'on') {			//TD all projects are selected then no need to insert all projects rather insert just one string
			$chrSelectedProject = "AllProjectsCanView";
			unset($arrProjectQueries);
			$arrProjectQueries = array();
			$arrProjectQueries[] = "INSERT INTO dbatn_project_project(idproject,chrprojectallowed) values ($idProject,'$chrSelectedProject');";
		}
		foreach ($arrProjectQueries as $chrQuery) {
			mazDb_query_params($chrQuery, array());
		}
		
		#Delete allowed departments
		$chrQuery = "DELETE FROM dbatn_project_department WHERE idproject=$1";
		mazDb_query_params($chrQuery, array($idProject));
		$arrDepartmentQueries = array();
		$intCount = $_REQUEST["allow_dept_count"];
		$flag = true;			//TD if flag remains true then all departments are selected
		for ($i = 0; $i < $intCount; $i++){
			$chrSelectedProject = $_POST["allow_dept".$i];
			if ($chrSelectedProject){
					$arrDepartmentQueries[] = "INSERT INTO dbatn_project_department(idproject,chrdepartmentallwoed) values ($idProject,'$chrSelectedProject');";
			}
			else {
				$flag = false;
			}
		}
		if($_REQUEST['allow_dept_checkall'] == 'on') {			//TD if all departments are selected then no need to insert all departments rather insert just one string
			$chrSelectedProject = "AllDepartmentsCanView";
			unset($arrDepartmentQueries);
			$arrDepartmentQueries = array();
			$arrDepartmentQueries[] = "INSERT INTO dbatn_project_department(idproject,chrdepartmentallwoed) values ($idProject,'$chrSelectedProject');";
		}
		foreach ($arrDepartmentQueries as $chrQuery) {
			mazDb_query_params($chrQuery, array());
		}
		header("location: edit_project_choose.php");
	}

	# get logged in user rights
 	$arrRights = getProjectRights($objSession->getUid());
  	$blnCanView = true;
  	if ($objSession->isAdminUser() == false && !in_array($idProject, $arrRights["owner"])){
		$blnCanEdit = false;
		$_REQUEST["msg"] = "Only owners can update this section";
		if (!in_array($idProject, $arrRights["view"])){
			$blnCanView = false;
		}
  	}
  	else {
	  $blnCanEdit = true;
	}
	$chrDisabled =  ($blnCanEdit == true) ? "" : "disabled='disabled'";
	# get list of owners of this project
  	$chrQuery = "SELECT dbatn_project_owner.iduser,dbatn_userslist.name
		FROM dbatn_project_owner LEFT JOIN dbatn_userslist ON dbatn_project_owner.iduser=dbatn_userslist.iduser
	  	WHERE idproject=$1";
	$rs = mazDb_query_params($chrQuery, array($idProject));
	$chrOwner = "";
	$idx2 = 0;
	if (mazDb_num_rows($rs) > 0 ){
		while($arr = mazDb_fetch_array($rs)){
			 $chrOwner.="<input type='checkbox' checked='checked' $chrDisabled name=\"own_$idx2\" id=\"own_$idx2\" value='".$arr['iduser']."'>".($arr['name'])." ";
			 $idx2++;
		}
	}
	header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("Edit Ownership"); ?></title>
		<?php echo generateScripts(); ?>
<script type="text/javascript">

/*
var intCheckCounter1 = <?php echo $idx ?>;
var intSelectedUser1 = <?php echo $idx ?>;
*/

/**
These tell how many users are already there
and will update on runtime when we insert new user check boxes in the form
**/

var intCheckCounter2 = <?php echo $idx2 ?>;
var intSelectedUser2 = <?php echo $idx2 ?>;

function atLeastOneChecked(){
	for (i = 0; i < intSelectedUser2; i++){
		if (document.getElementById("own_"+i).checked){
			return true;
		}
	}
	return false;
}

function searchManagers(){
		window.open("search_popup_internal.php?chkCounter="+intCheckCounter1,"winsearch","width=800,height=600,resizable=1,scrollbars=2");
}

function searchOwners(){
		window.open("search_popup_internal.php?chkCounter="+intCheckCounter2+"&opt=2","winsearch","width=800,height=600,resizable=1,scrollbars=2");
}

function InsertAllUsers(optionsStr,intCount){
		intCheckCounter1+= (intCount+1);
		intSelectedUser1+= intCount;
		document.getElementById("idManagers").innerHTML += optionsStr;
		//document.getElementById("idBlock").style.display="none";
}
function InsertAllUsers2(optionsStr,intCount){
		intCheckCounter2+= (intCount+1);
		intSelectedUser2+= intCount;
		document.getElementById("idOwners").innerHTML += optionsStr;		
		//document.getElementById("idBlock").style.display="none";
}
function validateForm(){
	if (!atLeastOneChecked()){
		alert("Please select at least 1 owner");
		return false;
	}
	else{
		//document.frm1.sel_count.value = intCheckCounter1;
		document.frm1.own_count.value = intCheckCounter2;
		return true;
	}
}

function checkUncheck(obj,chkBoxes){
	blnChecked = false;
	if (obj.checked == true){
		blnChecked = true;
	}
	intCount = document.getElementById(chkBoxes+"_count").value;
	for(i = 0; i < intCount; i++){
		document.getElementById(chkBoxes+i).checked = blnChecked;
	}
}

$(document).ready(function (){

	if($("#allow_dept_checkall").is(':checked')){
			$(".allow_dept").attr('disabled',true);
		} 

	if($("#allow_proj_checkall").is(':checked')){
			$(".allow_proj").attr('disabled',true);
		} 

	$("#allow_dept_checkall").click(function() {
		if($("#allow_dept_checkall").is(':checked')){
			$(".allow_dept").attr('disabled',true);
		} 
		else {
			$(".allow_dept").attr('disabled',false);
		}
	});
	$("#allow_proj_checkall").click(function() {
		if($("#allow_proj_checkall").is(':checked')){
			$(".allow_proj").attr('disabled',true);
		} 
		else {
			$(".allow_proj").attr('disabled',false);
		}

	});
});

</script>	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar">
					<img src="media/images/edit.png" /> &nbsp;
					<span class="ericssonHeading">Group Ownership</span>
				</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  	<tr>
    	<td valign="top" bgcolor="#505050" height="100%" >
    		<table cellpadding="0" cellspacing="" width="100%">
        		<tr>
          			<td bgcolor="#505050">&nbsp;</td>
            		<td class="workareaBox" valign="top">
    					<!-- ################################## Working Area START ################################# -->
        				<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="1">
        					<!-- InstanceBeginEditable name="subheader section" -->
	  						<!-- InstanceEndEditable -->
      						<tr>
        						<td height="100%">					<!-- _____Contents START_____ -->
            						<div id="workingDiv" style="width:100%;height:<?php echo CALENDAR_HEIGHT ?>">
                					<table bgcolor="#505050" width="100%" height="100%" >
                    					<tr>
                        					<td style="padding-top:5px;"><!-- InstanceBeginEditable name="working-area" -->
                        						<form name="frm1" id="frm1" method="post" onsubmit="return validateForm()" >
                            						<input type="hidden" name="chrAction" value="update_ownership" />
                             						<input type="hidden" name="idProject" value=<?php echo $idProject ?> />
                             						<input type="hidden" name="proj0" value="<?php echo $chrProject ?>" />
                             						<input type="hidden" name="proj_count" value="1" />
                            						<table width="100%" bgcolor="#FFFFFF">
                            							<tr>
                                							<td colspan="3" class="formheading"><?php echo $chrProject ?></td>
                              							</tr>
                                						<?php
                                  						if ($_REQUEST["msg"]) {
							  								?>
                              								<tr>
                              									<td colspan="2" align="center">
                           	  										<table>
                                    									<tr>
                                        									<td><img src="media/images/critical.png" /></td>
                                        									<td class="critical"><?php echo $_REQUEST["msg"] ?></td>
                                        								</tr>
                                    								</table>
                                    							</td>
                              								</tr>
                              								<?php
							  							}#end if message
							  							?>
                                						<tr>
                                							<td width="350" class="caption">Owners:</td>
                                     						<td width="371" class="msnuserbox" id="idOwners"><?php echo $chrOwner; ?></td>
                                     						<td width="122"><input type="button" value="Add Owners" <?php echo $chrDisabled ?> onClick='searchOwners()'  /></td>
                              							</tr>
                                						<tr>
                                  							<td class="caption">Allow read access for these department and section lists:</td>
                                  							<td id="idOwners3">
                                  								<?php
															  	$arrDepts = get_departments_from_db();
																$arrAllowed = getAllowedDepartmentsForProject($idProject);
															  	mazSelectControl("allow_dept",$arrDepts,$arrAllowed,$blnCanEdit,false,NULL,"Read access for everyone");
								  								?>
								  								
								  								
								  							</td>
                                  							<td>&nbsp;</td>
                                  							<script type="text/javascript">
								  							</script>
                                						</tr>
                                						<tr>
                                  							<td class="caption">Allow read access for these groups:</td>
															
                                  							<td id="idOwners4">
							                                	<?php
																$allProj=0;
															  	$arrProjects = get_projects_from_db();
																$arrAllowed = getAllowedProjectsForProject($idProject);
																unset($arrProjects[$chrProject]); #do not show the current project in the list
																unset($arrAllowed[$chrProject]);
															  	mazSelectControl("allow_proj",$arrProjects,$arrAllowed,$blnCanEdit,false,NULL,"Read access for everyone");																
															  	?>
															</td>
															<input type="hidden" name="all_proj" value=<?php echo $allProj?>/>
                                  							<td>&nbsp;</td>
                                						</tr>
                                						<tr>
                                  							<td class="caption">&nbsp;</td>
                                  							<td id="idOwners2">
                                  								<input type="hidden" id="sel_count" name="sel_count" value="0" />
                                   								<input type="hidden" id="own_count" name="own_count" value="0" />
                                  								<input type="submit" name="btnUpdate" id="btnUpdate" <?php echo $chrDisabled ?> value="Save Settings" />
                                  							<!-- submit doesn't work. idproject isn't passed along to the next instance #etorhun thursday-->
                                  							</td>
                                  							<td>&nbsp;</td>
                                						</tr>
                            						</table>
                            					</form>
                        					</td>					<!-- InstanceEndEditable -->
                        				</tr>
                    				</table>
                					</div>				<!-- _____Contents End_____ -->
        						</td>
      						</tr>
    					</table>
        				<!-- ##################################	Working Area END ################################# -->
          			</td>
            		<td bgcolor="#505050">&nbsp;</td>
          		</tr>
          		<tr>
          			<td bgcolor="#505050" colspan="3">&nbsp;</td>
          		</tr>
	  		</table>
    	</td>
  	</tr>
</table>
			</div>
		</div>
		<?php echo generateFooter(); ?>
	</body>
</html>
