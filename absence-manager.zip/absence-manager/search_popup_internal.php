<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/menu.php");
	include_once("include/page.php");

	/** Create session object
		and try to load user info (id name etc from session)
	**/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		header("location: ldap_do_login.php");
		exit();
	}
	header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("Search"); ?></title>
		<?php echo generateScripts(); ?>
<script type="text/javascript">
/**
	Add selected user in the opener webpage
**/
function selectUsers(obj, chrDept){
		var arrChk = document.getElementsByTagName("input");
		blnChecked = false;
		if (obj.checked == true){
			blnChecked = true;
		}
		for (i = 0; i < arrChk.length; i++){
			if (arrChk[i].getAttribute("dept") == chrDept){
				arrChk[i].checked = blnChecked;
			}
		}
	}
	var intSelectedUser = 0;
	function insertUsers(intCount) {
		var optionsStr = "";
		var counter = <?php echo $_REQUEST["chkCounter"] ?>;
		for (i = 0; i < intCount; i++){
			obj = document.getElementById("users_"+i);
			if (obj.checked == true){
				if (i != 0 && i % 4 == 0){
				optionsStr += "<br>";
				}
				optionsStr += createMsnBox(obj.getAttribute("chrName"),counter,obj.value);
				counter++;
			}
		}
		optionsStr +="";
		//optionsStr +="<input type=hidden name=total id=total value='"+counter+"'>\n";
		intSelectedUser = counter;
		//document.getElementById("selUsers").innerHTML = optionsStr;
		<?php
		if ($_REQUEST["opt"] == 2){
			?>
			window.opener.InsertAllUsers2(optionsStr,intSelectedUser);
			<?php
		}
		else
		{
			?>
				window.opener.InsertAllUsers(optionsStr,intSelectedUser);
			<?php
		}
		?>
		window.close();

	}
	function createMsnBox(chrName,idx,chrValue){
		<?php
			if ($_REQUEST["opt"] == 2){
				echo "var preFix = 'own_'; ";
			}
			else {
				echo "var preFix = 'sel_'; ";
			}
		?>
		//str = "<span class=\"msnuserbox\" id=\"msnUser"+idx+"\">";
		str = "<input type='checkbox' checked='checked' name=\""+preFix+idx+"\" id=\""+preFix+idx+"\" value='"+ chrValue +"'>"+chrName+ " ";
        //str += "</span> ";
		return str;
	}
</script>
	</head>
<body>
<table width="100%" bgcolor="#FFFFFF" border="0" cellspacing="3" cellpadding="3">
                              <tr>
                                <td colspan="2" class="gridHead">Search User</td>
                             </tr>
                              <form name="frmSearch" method="post">
                              	<input type="hidden" name="chrAction" id="chrAction" value="search" />
                              <tr>
                                <td class="caption">Search by uid:</td>
                                <td><input type="text" name="sUid" id="sUid" value="<?php echo $_REQUEST["sUid"] ?>" /></td>
                              </tr>
                              <tr>
                                <td class="caption">&nbsp;</td>
                                <td><input type="submit" name="btnSearch" id="btnSearch" value="Search" /></td>
                              </tr>
                              </form>
                            </table>
<table width="100%" bgcolor="#FFFFFF">
                            <tr>
                                	<td class="formheading">Result</td>
                              </tr>
                            <tr>
                            	<td class="text">
                            <?php
								if ( $_REQUEST["chrAction"] == "search" && ($_POST["sName"] || $_POST["sUid"] || sizeof($arrCities) > 0 || sizeof($arrDept) > 0 )) {
									$arrNotFound = array();
									$arrMatch = array();
									if ($_POST["sUid"]) {
										$arrUid   = explode(";",$_POST["sUid"]);
										foreach($arrUid as $index=>$chrUid){
											$arrUid[$index] = safeDatabase(strtoupper($chrUid));
										}
									}

									/**
									 * * Search user on the given critera
									 */
									if (sizeof($arrUid) == 1) {
										$chrWHERE = " WHERE upper(uid) LIKE '%".safeDatabase(strtoupper($_REQUEST["sUid"]))."%';";
									}
									else {
										$chrWHERE = " WHERE upper(uid) IN ('".implode("','",$arrUid)."')";
									}
									$chrQuery = "SELECT name,uid,iduser,department FROM dbatn_userslist $chrWHERE";

									$rs = mazDb_query_params($chrQuery, array());

											$counter=0;
											$chrOld = "";
											#display searched users with chekc boxes
											while($arrMatch = mazDb_fetch_array($rs))
											{
													$chrDpartment = $arrMatch["department"];
													if ($chrOld != $chrDpartment){
														echo "<input type='checkbox' checked='checked' onclick=\"selectUsers(this,'$chrDpartment')\"><b>".$chrDpartment."</b><br>";
														$chrOld = $chrDpartment;
													}

													$chrNameUtf8 = ($arrMatch["name"]);
													$chrRecord = $arrMatch["iduser"];
													echo " &nbsp; &nbsp;<input type='checkbox' checked='checked' chrName=\"".$chrNameUtf8."\" dept='$chrDpartment' value=\"$chrRecord\" name='users_$counter' id='users_$counter'>".$chrNameUtf8." <font color=red>(".($arrMatch["uid"]).")</font><br>";
													$counter++;
													echo "<hr>";
											}#end foreachdept
											echo "<input type=hidden name='intCountUser' id='intCountUser' value='$counter' />";

								}#end if searched some thing
							?>
                            </td>
                            </tr>
                            <?php
								if ($counter > 0){

									?>
                                    	<tr>
                                        <td>
                                        <input type="button" value="Insert Users" onclick="insertUsers(<?php echo $counter ?>)" />
                                        </td>
                                        </tr>
                                    <?php
								}
								else {
									?>
                                    	<tr>
                                        <td class="text">
                                        <?php
										if ($_REQUEST["chrAction"] == "search")
										{
										?>
                                        No result(s) found
                                        <?php
										}
										else
										{
											?>
                                            Please enter a criteria, and press search button
                                            <?php
										}
										?>
                                        </td>
                                        </tr>
                                    <?php
								}
							?>
                            </table>
	</body>
</html>
