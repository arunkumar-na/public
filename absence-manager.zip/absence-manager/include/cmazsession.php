<?php
class cMazSession{
	public $idUser = -1;
	private $blnLogin = false;
	private $blnAdmin = false;
	private $arrQueryString = array();
	private $chrEmailAddress = "";
	private $chrFullName = "";
	private $uid = "";
	private $chrDepartment;
	private $blnAdvanceUser;
	private $isLegalManager;
	private $legalManager;

	/*** ########################################################
	*	Constructor
	*______________________________________________________________*/
	public function cMazSession($idUser=-1)
	{
		$this->idUser = $idUser;
		$this->blnLogin = false; #changed idUser to blnLogin
		$this->blnAdmin = false;
		$this->chrEmailAddress = "";
		$this->chrFullName = "";
		$this->blnAdvanceUser = false;
		$this->isLegalManager = false;
		$this->legalManager = "";
	}

	public function populateFromDB() {
		$q = "SELECT * FROM dbatn_userslist WHERE iduser = $1";
		$rs = mazDb_query_params($q, array($this->idUser));	

		if (mazDb_num_rows($rs) > 0){
			while ($arr = mazDb_fetch_array($rs)){
				$this->idUser = $arr['iduser'];;
				$this->chrFullName = $arr['name'];
				$this->uid = $arr['uid'];
				$this->legalManager = $arr['legalManager'];
				$this->isLegalManager = $arr['isLegalManager'];
				$this->chrDepartment = $arr['department'];
				$this->chrEmailAddress = $arr['email'];
			}
		}
	}

	/*** ########################################################
	*	Retrun True or False if user has selected Advance option
	*____________________________________________________________*/
	public function isAdvanceUser(){
		return $this->blnAdvanceUser;
	}
	/*** ########################################################
	*	SET Advance user true or false
	*____________________________________________________________*/
	public function setBlnAdvanceUser($blnOption = true) {
		$this->blnAdvanceUser = $blnOption;
		$_SESSION["token"]["blnAdvanceUser"] = $blnOption;
	}
	public function setAdministratorUser($blnOption = false){
		$this->blnAdmin = $blnOption;
		$_SESSION["token"]["blnAdmin"] = $blnOption;
	}
	public function getIdUser()
	{
		return $this->idUser;
	}
	public function isAdminUser(){
		return $this->blnAdmin;
	}
	public function getEmailAddress(){
		return $this->chrEmailAddress;
	}
	public function getFullName(){
		return $this->chrFullName;
	}
	public function getUid(){
		return $this->uid;
	}
	public function getDepartment(){
		return $this->chrDepartment;
	}
	public function getLegalManager() {
		return $this->legalManager;
	}
	public function getIsLegalManager() {
		return $this->isLegalManager;
	}

		public function syncSession() {
	$arrToken 				= $_SESSION["token"]; #retrive info from session
		
		
	$arrToken["idUser"] = $this->idUser ;
	$arrToken["blnAdmin"] = $this->blnAdmin;
	$arrToken["blnLogin"] = $this->blnLogin;
	$arrToken["chrEmailAddress"] = $this->chrEmailAddress;
	$arrToken["chrFullName"] = $this->chrFullName;
	$arrToken["chrDepartment"] = $this->chrDepartment;
	$arrToken["blnAdvanceUser"] = $this->blnAdvanceUser;

	$arrToken["legalManager"] = $this->legalManager;
	$arrToken["isLegalManager"] = $this->isLegalManager;
		
	$_SESSION["token"] = $arrToken;
		
	}	
	/*** ########################################################
	*	This function will populate object of this class from SESSION
	*	varaible, information we have stored in session
	*____________________________________________________________*/
	public function loadFromSessionToken(){
		$arrToken 				= $_SESSION["token"]; #retrive info from session

		$this->idUser 			= $arrToken["idUser"];
		$this->blnAdmin 		= $arrToken["blnAdmin"];
		$this->blnLogin 		= $arrToken["blnLogin"];
		$this->chrEmailAddress	= $arrToken["chrEmailAddress"];
		$this->chrFullName		= $arrToken["chrFullName"];

		$this->uid				= $arrToken["uid"];
		$this->chrDepartment 	= $arrToken["chrDepartment"];
		$this->blnAdvanceUser 	= $arrToken["blnAdvanceUser"];

		$this->legalManager 	= $arrToken["legalManager"];
		$this->isLegalManager	= $arrToken["isLegalManager"];
	}
	/*** ########################################################
	*	Update user status if he has been logged successfuly and he is
	*	an admin user
	*____________________________________________________________*/
	public function setBlnLoginSuccess( $blnSuccess , $blnAdmin = false ){
		if ($this->idUser > 0)
		{
			$this->blnLogin = $blnSuccess;
			$this->blnAdmin = $blnAdmin;
		}
	}
	public function isValidUserLogin(){
		if (is_numeric($this->idUser) && $this->idUser > 0 && $this->blnLogin === true &&  $this->blnAdmin === false) {
			return true;
		}
		return false;
	}
	public function isValidAdminLogin(){
		if (is_numeric($this->idUser) && $this->idUser > 0 && $this->blnLogin === true && $this->blnAdmin === true) {
			return true;
		}
		return false;
	}
	public function isAnyLogin(){
		if (is_numeric($this->idUser) && $this->idUser > 0 && $this->blnLogin === true) {
			return true;
		}
		return false;
	}
	/*** ########################################################
	*	encode paramert into single variable
	*____________________________________________________________*/
	public function createQueryString($chrParam){
		return "param=".base64_encode($chrParam);
	}

	/*** ########################################################
	*	Retrive array of params from single param and decode it
	*	@return array
	*____________________________________________________________*/
	public function getArrQueryString(){
		$chrParam = base64_decode($_REQUEST["param"]);
		$arrParam = explode("&",$chrParam);
		$arrQueryString = array();
		foreach($arrParam as $mixParam){
			$pair = explode("=",$mixParam);
			$arrQueryString[$pair[0]] = $pair[1];
		}
		return $this->arrQueryString = $arrQueryString;
		return $arrQueryString;
	}
	/*** ########################################################
	*	Retrive sepecific param from the query string
	*____________________________________________________________*/
	public function getFromQueryString($key){
		return $this->arrQueryString[$key];
	}
	/*** ########################################################
	*	Set any value in session varaiable
	*	Input param : Key and Value pair
	*____________________________________________________________*/
	public function setAttribute($chrKey,$mixValue){
		$_SESSION[$chrKey] = $mixValue;
	}
	/*** ########################################################
	*	Get value from session varaible
	*	Input param : Key
	*	@return mix : value
	*____________________________________________________________*/
	public function getAttribute($chrKey){
		return $_SESSION[$chrKey];
	}
}
?>