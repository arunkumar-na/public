<?php

/**
 * Enter description here ...
 * @author emikwae
 *
 */
class User {
	private $idUser = -1;
	private $chrName = '';
	private $chrUserID = '';
	private $blnExternal = false;
	private $blnVisible = true;
	private $legalManager = '';
	private $isLegalManager = 'f';
	private $department = '';

	/**
	 * Enter description here ...
	 * @param unknown_type $idUser
	 */
	public function User($idUser = -1, $arrData){
		if ($idUser == -1){
			$fields = array();
			$values = array();
			if(isset($arrData['name']) && $arrData['name'] != ""){
					$fields[] = "name";
					$values[] = safeDatabase($arrData['name']);
			}
			if(isset($arrData['uid']) && $arrData['uid'] != ""){
					$fields[] = "uid";
					$values[] = $arrData['uid'];
			}
			if(isset($arrData['erelation']) && $arrData['erelation'] != ""){
					$fields[] = "erelation";
					$values[] = $arrData['erelation'];
			}
			if(isset($arrData['visible'])){ # && $arrData['visible'] != ""){
					$fields[] = "visible";
					$values[] = ($arrData['visible']) ? true : false;
			}
			
			#bugfix ejimenk 111108, altered to nextval from the sequence instead of select max.
			$q1 = "SELECT nextval('seq_idlist_lists') as max";
			#$q1 = "SELECT max(iduser) from dbatn_userslist"; 
			$rs1 = mazDb_query_params($q1, array());
			$arrResult = mazDb_fetch_array($rs1);
			$newId = $arrResult['max'] + 1;
			
			#if(isset($newId)){
			#		$fields[] = "iduser";
			#		$values[] = $newId;
			#}
			$f = implode(",", $fields);
			$v = implode("','", $values);
			
			#$q2 = "INSERT INTO dbatn_userslist (".$f.") VALUES ('".$v."')"; 
			$q2 = "INSERT INTO dbatn_userslist (iduser,".$f.") VALUES (". "nextval('seq_idlist_lists')" . ",'".$v."')";
			mazDb_query_params($q2, array());

			$this->idUser = $newId;
		} else{
			$this->idUser = $idUser;
		}
		
		if (sizeof($arrData)>0){
			$this->loadFromArray($arrData);	
		} else if ($idUser != -1) {
			$this->populateFromDB($idUser);
		}
			
	}

	/**
	 * Enter description here ...
	 * @param unknown_type $arrData
	 */
	private function loadFromArray($arrData){
		if (isset($arrData['name'])){
			$this->chrName = $arrData['name'];
		}
		if (isset($arrData['uid'])){
			$this->chrUserID = $arrData['uid'];
		}
		if (isset($arrData['erelation'])){
			$this->blnExternal = ($arrData['erelation'] != 'E') ? true : false;
		}
		if (isset($arrData['visible'])){
			$this->blnVisible = $arrData['visible'];
		}
		
	}

	private function populateFromDB($idUser) {
		$q = "SELECT * FROM dbatn_userslist WHERE iduser = $1";
		$rs = mazDb_query_params($q, array($idUser));	

		if (mazDb_num_rows($rs) > 0){
			while ($arr = mazDb_fetch_array($rs)){
				$this->idUser = $id;
				$this->chrName = $arr['name'];
				$this->chrUserID = $arr['uid'];
				$this->blnExternal = ($arr['erelation'] != 'E') ? true : false;
				$this->blnVisible = $arr['visible'];
				$this->legalManager = $arr['legalManager'];
				$this->isLegalManager = $arr['isLegalManager'];
				$this->department = $arr['department'];
			}
		}
	}

	/**
	 * Get users department
	 * @return string
	 */
	public function getDepartment(){
		return $this->department;
	}

	/**
	 * Get users legal manager
	 * @return string
	 */
	public function getLegalManager(){
		return $this->legalManager;
	}

	/**
	 * Get if user is a legal manager
	 * @return string
	 */
	public function getIsLegalManager(){
		return $this->isLegalManager;
	}
	/**
	 * Enter description here ...
	 * @return string
	 */
	public function getFullName(){
		return $this->chrName;
	}

	/**
	 * Enter description here ...
	 * @return string
	 */
	public function getUserID(){
		return $this->chrUserID;
	}

	/**
	 * Enter description here ...
	 * @return boolean
	 */
	public function isExternal(){
		return $this->blnExternal;
	}
	
	public function isVisible(){
    $ret = ($this->blnVisible == 't')? TRUE : FALSE;
		return $ret; #($this->blnVisible == 't'); #for some reason this seems to store 't' or 'f' instead of booleans. strange thing.
	}
	
	public function setVisible($blnVis){
		$this->blnVisible = $blnVis;
	}

	/**
	 * Enter description here ...
	 * @return number
	 */
	public function getID(){
		return $this->idUser;
	}

	/**
	 * 
	 * Synchronizes all userdata from LDAP. external users doesn't update departments, $visible sets the visible flag in AMdb
	 * @param boolean $external indicates whether the user should be handled as an external user or not
	 * @param boolean $visible tells whether the user is visible or not
	 */
	public function syncUser($external=false, $visible=NULL, $sessionObj = null){
		$arrLDAPUserData = import_from_ldap("(uid={$this->getUserID()})", "getusers", true);
    	foreach ($arrLDAPUserData as $dept => $usr) {#the returned array from LDAP has the department as root node, so need to descend into that first
			$userDept = $dept;
			$userData= $usr;
		}
		$arrLDAPUserData = $userData[0];
		$newdn = safeDatabase($arrLDAPUserData[dn]);
		$newname = safeDatabase($arrLDAPUserData[name]);
		if ($external){
			$newdepartment = ""; #h�r ska det in anv�ndarens department.
		}else{
			$newdepartment = "department = '{$arrLDAPUserData[department]}',";
		}
		$newvisible = ""; 
		if(isset($visible) && $visible == true){
			$newvisible = ", visible = true";
		}
		$newcity = safeDatabase($arrLDAPUserData[city]);
		$newrelation = safeDatabase($arrLDAPUserData[relationship]);
		$newphone = safeDatabase($arrLDAPUserData[phone]);
		$newtitle = safeDatabase($arrLDAPUserData[title]);
		$newmail = safeDatabase($arrLDAPUserData[mail]);
		$newmdept = safeDatabase($arrLDAPUserData[mdept]);
		$newsdept = safeDatabase($arrLDAPUserData[sdept]);
		$newlegalmanager = safeDatabase($arrLDAPUserData[legalManager]);
		$newislegalmanager = safeDatabase(($arrLDAPUserData[isLegalManager] == "t" ? "\"isLegalManager\" = true" : "\"isLegalManager\" = false" ));

		$chrQuery = "UPDATE dbatn_userslist
					SET dn = '$newdn',
						name = '$newname',
						$newdepartment
						city = '$newcity',
						\"legalManager\" = '$newlegalmanager',
						$newislegalmanager,
						erelation = '$newrelation',
						phone = '$newphone',
						title = '$newtitle',
						email = '$newmail',
						mdept = '$newmdept',
						sdept = '$newsdept'
						$newvisible
					WHERE uid = '{$this->getUserID()}'";
					
		$rs = mazDb_query_params($chrQuery, array());
		
		$department = safeDatabase($arrLDAPUserData[department]);
		#Set the users legal manager as owner manager for the department
 		if($arrLDAPUserData['isLegalManager'] == 'f' && !$external && $newlegalmanager){
 		$idUser = getUserIdByUid($newlegalmanager);
		    if($idUser){
			
		       $chrQuery1 = "INSERT INTO dbatn_department_owner(iduser, chrdepartment) SELECT '$idUser','$department' WHERE NOT EXISTS (SELECT 1 FROM dbatn_department_owner WHERE iduser = '$idUser' and chrdepartment = '$department')";
			   $rs1 = mazDb_query_params($chrQuery1, array());
			   
		       $chrQuery2 = "INSERT INTO dbatn_department_manager(iduser, chrdepartment) SELECT '$idUser','$department' WHERE NOT EXISTS (SELECT 1 FROM dbatn_department_manager WHERE iduser = '$idUser' and chrdepartment = '$department')";
			   $rs2 = mazDb_query_params($chrQuery2, array());
		    }
 		}
	}	
}

/**
 * Enter description here ...
 * @param int $idUser integer that holds the primary-key-field iduser in AM database 
 * @return User
 */
function getUser($idUser){
	$q = "SELECT iduser FROM dbatn_userslist WHERE iduser = $1";
	$rs = mazDb_query_params($q, array($idUser));
	if (mazDb_num_rows($rs) > 0){
		$user = mazDb_fetch_array($rs);
		return new User($user['iduser'], array());
	}
	return NULL;
}

/**
 * Enter description here ...
 * @param string $chrUserID the users userID, often a string consisting of 7 characters.
 * @return User
 */
function getUserByName($chrUserID){ 
	$q = "SELECT iduser,name,uid,erelation,visible,\"isLegalManager\",\"legalManager\" FROM dbatn_userslist WHERE uid = $1";
	$rs = mazDb_query_params($q, array($chrUserID));
	if (mazDb_num_rows($rs) > 0){
		$user = mazDb_fetch_array($rs);
		
		return new User($user['iduser'], $user);
	}
	return NULL;
}

/**
 * Enter description here ...
 * @param unknown_type $chrUserID
 * @return User
 */

function importUser($chrUserID){
			$ldapSearchString = "(uid=".$chrUserID.")";
			$ldapActionString = "getusers";
		 	$arrLdapResult = import_from_ldap($ldapSearchString, $ldapActionString, true);
		 	foreach ($arrLdapResult as $importDepartment => $importUsers) {
		 		foreach ($importUsers as $context => $importUser) {
						#Since dbatn_userslist doesn't incorporate auto_increment
		 			$arrData = array(
		 			"uid"=> $importUser['uid'],
		 			"name"=> $importUser['name'],
		 			"visible"=> true,
		 			"erelation"=> $importUser['relationship']
		 			);
		 			$user = new User(-1, $arrData);
		 			$user->syncUser(); #updates all info in AMdb with info from LDAP
		 	}
		 }
	return $user;	 	
}


/**
 * Enter description here ...
 * @param unknown_type $chrUserID
 * @return User
 */
function getOrImportUser($chrUserID){
	$user = getUserByName($chrUserID);
	if ($user == NULL){
		$user = importUser($chrUserID);
	}
	return $user;
}

/**
 * Enter description here ...
 * @param unknown_type $idUser
 */
function deleteUser($idUser){

}

function getUserComplete($chrUserID){
	$q = "SELECT * FROM dbatn_userslist WHERE uid = $1";
	$rs = mazDb_query_params($q, array($chrUserID));		

	if (mazDb_num_rows($rs) > 0){
		while ($arr = mazDb_fetch_array($rs)){
			$arrUsers = $arr;
		}
	}
	return $arrUsers;
}

function getUserIdByUid($uid) {
	$q = "SELECT iduser FROM dbatn_userslist WHERE uid = $1";
	$rs = mazDb_query_params($q, array($uid));		
	$id=null;
	if (mazDb_num_rows($rs) > 0){
		while ($arr = mazDb_fetch_array($rs)){
			$id = $arr['iduser'];
		}
	}
	return $id;
}
?>
