<?php
	include_once("include/usersync.php");
	include_once("include/user.php");
/**
 * Enter description here ...
 * @author emikwae
 *
 */
class Department{
	private $idDept = -1;
	private $arrAllowedDepts = array();
	private $arrAllowedGroups = array();
	private $arrOwnerIds = array();
	private $arrManagerIds = array();
	private $blnEmailRequired = true;
	private $blnAutoApprove = false;
	private $chrConfirmationMsg = "Your request has been received";
	private $chrReplyMsg = "Your absence item has been updated";
	private $arrAddedUsers = array();
	private $arrRemovedUsers = array();
	private $arrCheckedUsers = array();
	private $arrUncheckedUsers = array();
	private $dbData = array();
	private $chrRedDayTemplateName = "";
	private $idRedDayTemplate = -1;
	/**
	 * Enter description here ...
	 * @param unknown_type $idDept
	 */
	public function Department($data){
		if (is_array($data)){
	
			$arrData = $data;
			$this->idDept=$arrData[0];
			syncUsers($this);
			$q = "INSERT INTO dbatn_department_email_settings(chrdepartment,intemailrequired,chrconfirmationmsg,chrreplymsg,intautoapprove) values($1,1,'Your request is received','Your absence item is updated',0)";
			mazDb_query_params($q, array($this->idDept));
			$this->save();
      
		} else{
			# Department id
			$this->idDept = safeDatabase($data);			
			$this->loadFromDatabase();
		}
	}

	public function syncDepartment($isImport = false){
		syncUsers($this, $isImport); //if import is true managers will be added automatically
	}


	/**
	 * Enter description here ...
	 * @param unknown_type $chrQuery
	 * @return multitype:
	 */
	private function loadArray($chrQuery){
		$rs = mazDb_query_params($chrQuery, array());
		$arrResult = array();
		if (mazDb_num_rows($rs) > 0){
			while($arr = mazDb_fetch_array($rs)){
				$arrResult[] = $arr[0];
			}
		}
		return $arrResult;
	}

	/**
	 * Enter description here ...
	 */
	private function loadFromDatabase(){
		$q = "SELECT chrdepartmentallwoed FROM dbatn_department_department WHERE chrdepartment='".$this->idDept."'";
		$this->arrAllowedDepts = $this->loadArray($q);

		$q = "SELECT chrprojectallowed FROM dbatn_department_project WHERE chrdepartment='".$this->idDept."'";
		$this->arrAllowedGroups = $this->loadArray($q);

		$q = "SELECT * FROM dbatn_department_email_settings WHERE chrdepartment=$1";
		$rs = mazDb_query_params($q, array($this->idDept));
		if (mazDb_num_rows($rs) > 0){
			while($arr = mazDb_fetch_array($rs)){
				$this->blnEmailRequired = ($arr['intemailrequired'] != 0 ? true : false);
				$this->blnAutoApprove = ($arr['intautoapprove'] != 0 ? true : false);
				$this->chrConfirmationMsg = $arr['chrconfirmationmsg'];
				$this->chrReplyMsg = $arr['chrreplymsg'];
			}
		}

		$q = "SELECT iduser FROM dbatn_department_manager WHERE chrdepartment='".$this->idDept."'";
		$this->arrManagerIds = $this->loadArray($q);

		$q = "SELECT iduser FROM dbatn_department_owner WHERE chrdepartment='".$this->idDept."'";
		$this->arrOwnerIds = $this->loadArray($q);
		
		$q = "SELECT ul.name, ul.iduser FROM dbatn_userslist ul JOIN dbatn_department_holidaytemplate ht ON ul.iduser = ht.iduser WHERE ht.chrdepartment=$1";
		$rs = mazDb_query_params($q, array($this->idDept));
		if (mazDb_num_rows($rs) > 0){
			while($arr = mazDb_fetch_array($rs)){
				#$this->chrRedDayTemplateName = $arr['name'];
				$this->idRedDayTemplate = $arr['iduser'];
			}
		}
	
		#$q = "SELECT iduser FROM dbatn_department_manager WHERE chrdepartment='".$this->idDept."'";
		#$this->idRedDayTemplateID = $this->loadArray($q);
		

		

		$this->dbData = array(
			"arrAllowedDepts" => $this->arrAllowedDepts,
			"arrAllowedGroups" => $this->arrAllowedGroups,
			"blnEmailRequired" => $this->blnEmailRequired,
			"blnAutoApprove" => $this->blnAutoApprove,
			"chrConfirmationMsg" => $this->chrConfirmationMsg,
			"chrReplyMsg" => $this->chrReplyMsg,
			"arrManagerIds" => $this->arrManagerIds,
			"arrOwnerIds" => $this->arrOwnerIds,
			"idRedDayTemplate" => $this->idRedDayTemplate,
		);
	}

	/**
	 * Enter description here ...
	 * @param unknown_type $arrNew
	 * @param unknown_type $arrOld
	 * @param unknown_type $chrTable
	 * @param unknown_type $chrColumn
	 */
	private function saveArray($arrNew, $arrOld, $chrTable, $chrColumn){
		if(!isset($arrOld)) {
      $arrOld=array();
    }
    # Insert items that have been added
		$arrAdded = array_diff($arrNew, $arrOld); 
		#$arrRemoved = array_diff($arrOld, $arrNew);
		$arrQuery = array();
		if (count($arrAdded) > 0){
			/*foreach ($arrAdded as $value){ This is the code for multiple inserts that requries Postgres 8.2  Since the server is running 8.1, this code is not used.
				$q = "('".$this->idDept."',";
				if (is_int($value)){
					$q .= $value;
				}
				else{
					$q .= "'".safeDatabase($value)."'";
				}
				$arrQuery[] = $q.")";
			}
			$q = "INSERT INTO ".$chrTable." (chrdepartment, ".$chrColumn.") VALUES ".implode(',', $arrQuery);
			*/

			foreach ($arrAdded as $value){
				if (is_int($value)){
					$safeValue = $value;
				}
				else{
					$safeValue = "'".safeDatabase($value)."'";
				}
				$q = "INSERT INTO ".$chrTable." (chrdepartment, ".$chrColumn.") VALUES ('".$this->idDept."',".$safeValue.")";
				mazDb_query_params($q, array());
			}
		}
		# Delete items which do no longer exist
		$q = "DELETE FROM ".$chrTable." WHERE chrdepartment=$1";
		if (count($arrNew) > 0){
			$chrMerged = implode("','", array_map("safeDatabase", $arrNew));
			$q .= " AND ".$chrColumn." NOT IN ('".$chrMerged."')";
		}
		#echo "<p>query: ".$q."</p>";
		mazDb_query_params($q, array($this->idDept));
	}

	/**
	 * Enter description here ...
	 */
	public function save(){
		# Update allowed departments
		$this->saveArray(
			$this->arrAllowedDepts, $this->dbData["arrAllowedDepts"],
			"dbatn_department_department", "chrdepartmentallwoed"
		);

		# Update allowed groups
		$this->saveArray(
			$this->arrAllowedGroups, $this->dbData["arrAllowedGroups"],
			"dbatn_department_project", "chrprojectallowed"
		);

		# Update email settings

		$values = array(
                        ($this->blnEmailRequired == true ? 1 : 0),
                        ($this->blnAutoApprove == true ? 1 : 0),
                        $this->chrConfirmationMsg,
                        $this->chrReplyMsg,
                        $this->idDept
                );

		$check_if_exists_due_to_stupid_bug = "select * from dbatn_department_email_settings where chrdepartment=$1";
		$result = mazDb_query_params($check_if_exists_due_to_stupid_bug, array($this->idDept));
		if(mazDb_num_rows($result) == 0){
			$q = "INSERT INTO dbatn_department_email_settings(chrdepartment,intemailrequired,chrconfirmationmsg,chrreplymsg,intautoapprove) values($5,$1,$3,$4,$2)";
                	mazDb_query_params($q, $values);
		} else {
		
		$q = "UPDATE dbatn_department_email_settings SET "
		     . "intemailrequired=$1, intautoapprove=$2, "
		     . "chrconfirmationmsg=$3, chrreplymsg=$4 "
		     . "WHERE chrdepartment=$5";
		mazDb_query_params($q, $values);
		}

		# Update managers
		$this->saveArray(
			$this->arrManagerIds, $this->dbData["arrManagerIds"],
			"dbatn_department_manager", "iduser"
		);

		# Update owners
		$this->saveArray(
			$this->arrOwnerIds, $this->dbData["arrOwnerIds"],
			"dbatn_department_owner", "iduser"
		);
		# Update users
		if (count($this->arrAddedUsers) > 0){
			$chrMerged = implode(',', $this->arrAddedUsers);
			$q = "UPDATE dbatn_userslist SET department=$1 WHERE iduser IN ({$chrMerged})";
			mazDb_query_params($q, array($this->idDept));
		}
		#Update holiday template
		if ($this->dbData['idRedDayTemplate'] != $this->idRedDayTemplate ){#if any change is made 
			if ($this->dbData['idRedDayTemplate'] == -1){ #if no template was set prior to the saving action
					$q = "INSERT INTO dbatn_department_holidaytemplate(chrdepartment,iduser) VALUES ('{$this->idDept}',{$this->idRedDayTemplate})";	
			}
			else {# if an earlier set template is changed or deleted
				if ($this->idRedDayTemplate == -1) {
					#if the new one is -1, then UPDATE
					$q = "DELETE FROM dbatn_department_holidaytemplate WHERE chrdepartment = '{$this->idDept}'";
				}
				else {#if not, there is a new one replacing the old one
					$q = "UPDATE dbatn_department_holidaytemplate SET iduser = {$this->idRedDayTemplate} WHERE chrdepartment = '{$this->idDept}'";
				}
			}
			mazDb_query_params($q, array());
		}
		#tisdag: unset department from database.. move this functionality to user.php 
		
		if (count($this->arrRemovedUsers) > 0){
			$chrMergedRemovedUsers = implode(',', $this->arrRemovedUsers);
			$q = "UPDATE dbatn_userslist SET department = '' WHERE iduser IN ({$chrMergedRemovedUsers})";
			mazDb_query_params($q, array());
		}
		
		if (count($this->arrUncheckedUsers) > 0){
			$arrUncheckedUsers = $this->arrUncheckedUsers;
			$arrUncheckedUsersUIDs = array(); 
			
			foreach($arrUncheckedUsers as $user){
				$arrUncheckedUsersUIDs[] = $user->getUserID();
				$user->setVisible(TRUE);
			}
			$chrMergedUncheckedUsers = implode("','", $arrUncheckedUsersUIDs);
			$q = "UPDATE dbatn_userslist SET visible = true WHERE uid IN ('{$chrMergedUncheckedUsers}')";
			mazDb_query_params($q, array());
		}
		
		
		if (count($this->arrCheckedUsers) > 0){
			
			$arrCheckedUsers = $this->arrCheckedUsers;
			$arrCheckedUsersUIDs = array(); 
			foreach($arrCheckedUsers as $user){
				$arrCheckedUsersUIDs[] = $user->getUserID();
				$user->setVisible(TRUE);
			}
			$chrMergedCheckedUsers = implode("','", $arrCheckedUsersUIDs);
			$q = "UPDATE dbatn_userslist SET visible = true WHERE uid IN ('{$chrMergedCheckedUsers}')";
			mazDb_query_params($q, array());
			}
		
		
		
		
		$this->arrCheckedUsers = array();
		$this->arrUncheckedUsers = array();
		$this->arrAddedUsers = array();
		$this->arrRemovedUsers = array();
	}

	/**
	 * Get all users within a department
	 * @return array containing user objects.
	 */
	public function getUsers(){
		$q = "SELECT iduser,name,uid,erelation,visible FROM dbatn_userslist WHERE department=$1";
		$rs = mazDb_query_params($q,  array($this->idDept));
		$arrUsers = array();
		if (mazDb_num_rows($rs) > 0){
			while ($arr = mazDb_fetch_array($rs)){
				$arrUsers[] = new User($arr['iduser'], $arr);
			}
		}
		return $arrUsers;
	}
	/**
	 * Gets arrays with full info about every user 
	 * @param chrUserID $uid to get a full data array about a specific user, 
	 * if not specified, all users from current department is represented
	 * @return Array() containing all data concering specific user/users
	 */
	public function getUsersComplete($uid=NULL){
		$q = "SELECT * FROM dbatn_userslist WHERE department=$1";
		if (isset($uid)) {
			$q .= " AND uid = $2";
			$rs = mazDb_query_params($q, array($this->idDept, $uid));		
		}else{
			$rs = mazDb_query_params($q, array($this->idDept));
		}
		$arrUsers = array();
		if (mazDb_num_rows($rs) > 0){
			while ($arr = mazDb_fetch_array($rs)){
				$arrUsers[] = $arr;
			}
		}
		return $arrUsers;
	}
	
	public function getAddedUsers(){ #added by etorhun
		return $this->arrAddedUsers;
	}

	/**
	 * Enter description here ...
	 * @return Ambiguous
	 */
	public function getManagersAndOwners() {
		$q  = "SELECT users.iduser,name,uid,erelation,visible FROM dbatn_userslist users"; #visible can be left out here
		$q .= " JOIN";
		$q .= " ((SELECT iduser FROM dbatn_department_owner WHERE chrdepartment=$1)";
  		$q .= " UNION";
 		$q .= " (SELECT iduser FROM dbatn_department_manager WHERE chrdepartment=$1)) as A";
		$q .= " ON users.iduser = A.iduser";

		$rs = mazDb_query_params($q, array($this->idDept));
		$arrUsers = array();
		if (mazDb_num_rows($rs) > 0){
			while ($arr = mazDb_fetch_array($rs)){
				$arrUsers[] = new User($arr['iduser'], $arr);
			}
		}
		return $arrUsers;
	}

	/**
	 * Enter description here ...
	 * @return number
	 */
	public function getID(){
		return $this->idDept;
	}

	/**
	 * Enter description here ...
	 * @return multitype:
	 */
	public function getAllowedDepts(){
		return $this->arrAllowedDepts;
	}

	/**
	 * Enter description here ...
	 * @param unknown_type $arrAllowedDepts
	 */
	public function setAllowedDepts($arrAllowedDepts){
		$this->arrAllowedDepts = $arrAllowedDepts;
	}

	/**
	 * Enter description here ...
	 * @return multitype:
	 */
	public function getAllowedGroups(){
		return $this->arrAllowedGroups;
	}

	/**
	 * Enter description here ...
	 * @param unknown_type $arrAllowedGroups
	 */
	public function setAllowedGroups($arrAllowedGroups){
		$this->arrAllowedGroups = $arrAllowedGroups;
	}

	/**
	 * Enter description here ...
	 * @return boolean
	 */
	public function isEmailRequired(){
		return $this->blnEmailRequired;
	}

	/**
	 * Enter description here ...
	 * @param unknown_type $blnRequireEmail
	 */
	public function setRequireEmail($blnRequireEmail){
		$this->blnEmailRequired = $blnRequireEmail;
	}

	/**
	 * Enter description here ...
	 * @return boolean
	 */
	public function isAutoApproved(){
		return $this->blnAutoApprove;
	}

	/**
	 * Enter description here ...
	 * @param unknown_type $blnAutoApprove
	 */
	public function setAutoApprove($blnAutoApprove){
		$this->blnAutoApprove = $blnAutoApprove;
	}

	/**
	 * Enter description here ...
	 * @return string
	 */
	public function getConfirmationMessage(){
		return $this->chrConfirmationMsg;
	}

	/**
	 * Enter description here ...
	 * @param unknown_type $chrMessage
	 */
	public function setConfirmationMessage($chrMessage){
		$this->chrConfirmationMsg = $chrMessage;
	}

	/**
	 * Enter description here ...
	 * @return string
	 */
	public function getReplyMessage(){
		return $this->chrReplyMsg;
	}

	/**
	 * Enter description here ...
	 * @param unknown_type $chrMessage
	 */
	public function setReplyMessage($chrMessage){
		$this->chrReplyMsg = $chrMessage;;
	}

	/**
	 * Enter description here ...
	 * @param unknown_type $idUser
	 */
	public function removeUser($idUser){
		$this->arrRemovedUsers[] = $idUser;
	}
	
	/**
	 * Enter description here ...
	 * @param unknown_type $idUser
	 */
	public function addUser($objUser){
		$this->arrAddedUsers[] = $objUser->getID();
		#echo "arrAddedUsers: (from Department->addUser):";
		#print_r($arrAddedUsers);
	}


	/**
	 * Enter description here ...
	 * @param unknown_type $needle
	 * @param unknown_type $haystack
	 * @return unknown
	 */
	private function removeFromArray($needle, $haystack){ #funkar inte!!
		#echo "before: ";
		#print_r($haystack);
		foreach ($haystack as $i => $value) {
			if ($value == $needle)
				unset($haystack[$i]);
		}
		#echo "after: ";
		#print_r($haystack);
		return $haystack;
	}

	/**
	 * Enter description here ...
	 * @param unknown_type $idUser
	 * @param unknown_type $blnOwner
	 */
	public function setOwner($idUser, $blnOwner){
		if ($blnOwner){
			# Add this user as an owner
			if (!in_array($idUser, $this->arrOwnerIds)) {
				$this->arrOwnerIds[] = $idUser;
			}
		}
		else{
			$this->arrOwnerIds = $this->removeFromArray($idUser, $this->arrOwnerIds);
		}
	}

	public function setOwnerByUid($uid, $blnOwner){		
		$idUser = getUserIdByUid($uid);
		if($idUser){
			$this->setOwner($idUser, $blnOwner);
		}	
	}

	/**
	 * Enter description here ...
	 * @param unknown_type $uid
	 * @return boolean
	 */
	public function isOwner($idUser){
		return (in_array($idUser, $this->arrOwnerIds));
	}

	/**
	 * Enter description here ...
	 * @param unknown_type $idUser
	 * @param unknown_type $blnManager
	 */
	public function setManager($idUser, $blnManager){
		if ($blnManager){
			# Add this user as a manager
			if (!in_array($idUser, $this->arrManagerIds))
				$this->arrManagerIds[] = $idUser;
		}
		else{
			$this->arrManagerIds = $this->removeFromArray($idUser, $this->arrManagerIds);
		}
	}

	/**
	 * Enter description here ...
	 * @param unknown_type $idUser
	 * @return boolean
	 */
	public function isManager($idUser){
		return (in_array($idUser, $this->arrManagerIds));
	}
	
	public function getRedDayTemplateName(){ # what happens when no template is present? ..fails when recently updated... check out later!
		$q = "SELECT name FROM dbatn_userslist WHERE iduser = $1";
		$rs = mazDb_query_params($q, array($this->idRedDayTemplate));
		if (mazDb_num_rows($rs) > 0){
			while($arr = mazDb_fetch_array($rs)){
				$name = $arr['name'];
			}
		}
		return $name;
	}
	
	public function getIdRedDayTemplate(){
		return $this->idRedDayTemplate;
	}
	
	public function setRedDayTemplate($id){
		$this->idRedDayTemplate = $id;
	}	
	

/**
 * 
 * 
 * Returns an array containing the users in the current department grouped by:
 * checked: users that belong to the current department according to AM and LDAP
 * unchecked: users that belong to the current department according to LDAP but not according to AM
 * external: users that belong to the current department according to AM but not according to LDAP 
 */
	public function getUsersUIDArray(){
		$arrLocalUserData = array();
		$arrLocalUsersData = $this->getUsersComplete();
		
		#---------
		$arrLocalUsersUIDList = array();
		foreach ($arrLocalUsersData as $dummy => $user) {
			$arrLocalUsersUIDList[] = $user['uid'];
		} 
		
		#---------		
		$arrLDAPUsersData = import_from_ldap("(departmentNumber={$this->getName()})", "getusers", true);
		$arrLDAPUsersUIDList = array();
		foreach ($arrLDAPUsersData[$this->getName()] as $dummy => $user) {
			$arrLDAPUsersUIDList[] = $user['uid'];
			#display($user);
		}
		
		#display($arrLocalUsersUIDList, "LocalUsersUIDList");
		#display($arrLDAPUsersUIDList, "LDAPUSersUIDList");
		
		$arrExternalUIDList = array_diff($arrLocalUsersUIDList, $arrLDAPUsersUIDList);
		$arrUncheckedUIDList = array_diff($arrLDAPUsersUIDList, $arrLocalUsersUIDList);
		$arrCheckedUIDList = array_intersect($arrLocalUsersUIDList, $arrLDAPUsersUIDList);
		$arrMergedUIDList = array("checked"=>$arrCheckedUIDList, "unchecked"=>$arrUncheckedUIDList, "external"=>$arrExternalUIDList);
		
		#sort($arrMergedUIDList);
		
		#display($arrExternalUIDList, "External Users in Department");
		#display($arrUncheckedUIDList, "Unchecked Users");
		#display($arrCheckedUIDList, "Checked Users");
		#display($arrMergedUIDList, "Merged List");
		#exit();
		return $arrMergedUIDList;
}

	public function getUsersCompleteArray(){
		$arrLocalUsersData = $this->getUsersComplete();
		#display($arrLocalUsersData);
		#---------
		foreach ($arrLocalUsersData as $dummy => $user) {
			$arrLocalUsers[] = $user;
		} 
		
		#---------		
		$arrLDAPUsersData = import_from_ldap("(departmentNumber={$this->getName()})", "getusers", true);
		$arrUsersUID = $this->getUsersUIDArray();
		foreach ($arrLDAPUsersData[$this->getName()] as $dummy => $user) {
			$arrLDAPUsers[] = $user;
			#display($user);
		}
		#display($arrLDAPUsers, "LDAPUSERS");		
		#display($arrLocalUsers, "LocalUsers");
		
		$arrExternal = array();
		$arrUnchecked = array();
		$arrChecked = array();
		
		foreach ($arrLDAPUsers as $dummy => $user) {
			#echo $user['uid'];		
			if (in_array($user['uid'], $arrUsersUID['unchecked'])){
				$arrUnchecked[] =  $user;
			}
			#else if (in_array($user['uid'], $arrUsersUID['checked'])){
		#		$arrChecked[] =  $user;
	#		}else{
#				echo "user doesn't exist!";
			}			
		
		
		
			
		foreach ($arrLocalUsers as $dummy => $user) {
			if ($user['erelation'] == 'X'){
				$arrExternal[] =  $user;
			}
			#else if (in_array($user['uid'], $arrUsersUID['checked'])){
		#		$arrChecked[] =  $user;
	#		}else{
#				echo "user doesn't exist!";
			}
		
		$arrChecked = array_intersect_assoc($arrLocalUsers, $arrLDAPUsers); #formatted as local users
		$arrMerged = array("checked"=>$arrChecked, "unchecked"=>$arrUnchecked, "external"=>$arrExternal);
		
		#sort($arrMerged);

		#display($arrExternal, "External Users in Department");
		#display($arrUnchecked, "Unchecked Users");
		#display($arrChecked, "Checked Users");
		#display($arrMerged, "Merged");
		#exit();
		return $arrMerged;
}

	/**
	 * Enter description here ...
	 * @param unknown_type $idUser
	 * @return boolean
	 */
	public function isVisibleTo($idUser){
		return true; # TODO: Fix
	}

	/**
	 * Enter description here ...
	 */
	public function getName(){
		return $this->getID();
	}
	
	public function claimUser($user){ 
		$chrQuery = "UPDATE dbatn_userslist
			SET department = '{$this->getName()}', visible = TRUE
			WHERE uid = '{$user->getUserID()}'"; #When a user changes departments, visibility is reset to true. checked.
		$rs = mazDb_query_params($chrQuery, array());
	}
	
	public function checkUser($user){ 
			$this->arrCheckedUsers[] = $user;	
	}
	
	public function unCheckUser($user){ 
			$this->arrUncheckedUsers[] = $user;	
	}
	

	
	
}

/*
	# get current user rights on departments
	$arrRights = getDepartmentRights($objSession->getUid());
	$blnEdit = true;

	# if not admin user, or dont have rights then form will be disabled or not displayed accordingly
	if ($objSession->isAdminUser() == false && !in_array($chrDepartment,$arrRights["manager"]) && !in_array($chrDepartment,$arrRights["owner"])) {
		$blnEdit = false;
	}

	$blnView = true;
	if ($objSession->isAdminUser() == false && !in_array($chrDepartment,$arrRights["view"])) {
		$blnView = false;
	}*/

/**
 * Enter description here ...
 * @param unknown_type $idDept
 * @return Department
 */
function getDepartment($idDept){
	return new Department($idDept);
}

/**
 * Enter description here ...
 * @param unknown_type $chrDeptName
 * @return Department
 */
function importDepartment($chrDeptName){
	return new Department(array($chrDeptName));
}

/**
 * Enter description here ...
 * @param unknown_type $idDept
 */
function deleteDepartment($idDept){
	# TODO: Fix
}

/**
 * Enter description here ...
 * @param unknown_type $chrDeptName
 * @return Department
 */
function getDepartmentByName($chrDeptName) {
	# Right now department id == department name
	$idDept = $chrDeptName;
	return new Department($idDept);
}

	/*
	if ($_REQUEST["chrAction"] == "update_list"){
			$arrADDED = array();
			$arrUPDATED = array();
			$arrDELETED = array();

			# allUsers contain all the user in single string value
			$chrAllUsers = trim($_REQUEST["allUsers"],"#-#-#");

			# seprate user from single string
			$arrAllUsers = explode("#-#-#",$chrAllUsers);

			#get user ids
			$arrAllUsersTrans = array_flip($arrAllUsers);

			$intUserCount = trim($_REQUEST["users_count"]);

			#Search all users if information needs to be updated or added.
			for ($i = 0; $i< $intUserCount; $i++){
				if ($_POST["users_$i"]) {

						#custom unserilize
						$objRecord = json_decode($_POST["users_$i"], true);

						$dn 			= $objRecord["dn"];
						$name 			= safeDatabase($objRecord["name"]);
						$dept 			= $objRecord["department"];
						$city 			= $objRecord["city"];
						$erelation		= $objRecord["relationship"];
						$phone 			= $objRecord["phone"];
						$title 			= $objRecord["title"];
						$email 			= $objRecord["mail"];
						$uid 			= $objRecord["uid"];
						$mdept 			= $objRecord["mdept"];
						$sdept 			= $objRecord["sdept"];


						#Get information about user if he/she already exist.
						$chrQuery = "SELECT uid,department,name,erelation FROM dbatn_userslist WHERE uid='$uid'";
						$rs = mazDb_query($chrQuery);

						#User exist in db.
						if (mazDb_num_rows($rs) > 0 ) {
							#Parse user information
							$arrExist=mazDb_fetch_array($rs);

							#Check if user information has been changed in LDAP. If not, we dont have to update the record.
							$chrExistQuery = "SELECT * from dbatn_userslist WHERE uid='$uid' AND dn='$dn' AND name='$name' AND department='$dept' AND city='$city' AND erelation='$erelation' AND phone='$phone' AND title='$title' AND email='$email' AND mdept='$mdept' AND sdept='$sdept'";
							$exist = mazDb_query($chrExistQuery);

							#Information differ between LDAP and db. We need to update this record
							if (mazDb_num_rows($exist) == 0){
								#If user dont exist at this department display he/she as ADDED
								if($dept != $arrExist["department"]){
									$arrADDED[] = (stripslashes($name));
								}
								else{
									#Else display that the user information has been UPDATED
									$arrUPDATED[] = (stripslashes($name));
								}
								$arrQuery[] = "UPDATE dbatn_userslist SET dn='$dn',name='$name',department='$dept',city='$city',erelation='$erelation',phone='$phone',title='$title',email='$email',mdept='$mdept',sdept='$sdept' WHERE uid='$uid'";
							}
							unset($arrAllUsersTrans[$uid]);
						}
						else{
							$arrADDED[] = (stripslashes($name));
							$arrQuery[] = "INSERT INTO dbatn_userslist(iduser,dn,name,department,city,erelation,phone,title,email,mdept,sdept,uid)
										values(nextval('seq_idlist_lists'),'$dn','$name','$dept','$city','$erelation','$phone','$title','$email','$mdept','$sdept','$uid') ";
							unset($arrAllUsersTrans[$uid]);
						}
					}#if record
			}#end for each users


			$arrIgnoreReason = array();
			$arrDoNotDelete = array();

			#All users left in $arrAllUsersTrans is unmarked in Alter List and should be deleted if no special reason exist. Check this and delete.
			if (sizeof($arrAllUsersTrans) > 0){
					$arrAllUsersTrans2 = array_flip($arrAllUsersTrans);
					$chrDelete = "'".implode("','",$arrAllUsersTrans2)."'";
					$arrUsersInfo = array();

					#search the ids of the user we want to delete
					$chrSQuery = "SELECT iduser,name FROM dbatn_userslist WHERE uid IN ($chrDelete)";

					$rs = mazDb_query($chrSQuery);
					if (mazDb_num_rows($rs) > 0){
							$arrIdUserToDelete = array();
							while($arrS = mazDb_fetch_array($rs)){

								#these users may need deletion
								$arrIdUserToDelete[$arrS["iduser"]] = $arrS["iduser"];

								#this array is keeping name that will be displayed at the end of process who were deleted
								$arrDELETED[$arrS["iduser"]] = ($arrS["name"]);
							}

							#search user that are part of any project,
							# if they are then we will remove them from user to delete list
							# and will add them to the ignored list with the reason they are member of the project etc
							$chrDelete2 = implode(",",$arrIdUserToDelete);
							$chrDQuery = "SELECT iduser,chrproject FROM dbatn_projectlist WHERE iduser IN ($chrDelete2)";
							$rs = mazDb_query($chrDQuery);
							while($arrD= mazDb_fetch_array($rs)){
								unset($arrIdUserToDelete[$arrD["iduser"]]);
								if (!$arrIGNORED[$arrD["iduser"]]){
									$arrIGNORED[$arrD["iduser"]] = $arrDELETED[$arrD["iduser"]];
								}
								$arrIgnoreReason[$arrD["iduser"]] .= "Member of : ".$arrD["chrproject"]."<br>";
								unset($arrDELETED[$arrD["iduser"]]);
							}

							#IGNORING DUE TO REsponsibilities
							# search user that are manager of the department
							# so we will remove that user from the delete list and will add to ignored list
							$chrDQuery = "SELECT iduser,chrdepartment FROM dbatn_department_manager WHERE iduser IN ($chrDelete2)";
							$rs = mazDb_query($chrDQuery);
							while($arrD= mazDb_fetch_array($rs)){
								unset($arrIdUserToDelete[$arrD["iduser"]]);
								if (!$arrIGNORED[$arrD["iduser"]]){
									$arrIGNORED[$arrD["iduser"]] = $arrDELETED[$arrD["iduser"]];
								}
								$arrIgnoreReason[$arrD["iduser"]] .= "Manager of : ".$arrD["chrdepartment"]."<br>";
								unset($arrDELETED[$arrD["iduser"]]);
							}

							# search user that are owner of the department
							# so we will remove that user from the delete list and will add to ignored list
							$chrDQuery = "SELECT iduser,chrdepartment FROM dbatn_department_owner WHERE iduser IN ($chrDelete2)";
							$rs = mazDb_query($chrDQuery);
							while($arrD= mazDb_fetch_array($rs)){
								unset($arrIdUserToDelete[$arrD["iduser"]]);
								if (!$arrIGNORED[$arrD["iduser"]]){
									$arrIGNORED[$arrD["iduser"]] = $arrDELETED[$arrD["iduser"]];
								}
								$arrIgnoreReason[$arrD["iduser"]] .= "Owner of DEP/SEC: ".$arrD["chrdepartment"]."<br>";
								unset($arrDELETED[$arrD["iduser"]]);
							}

							# search user that are owner of the project
							# so we will remove that user from the delete list and will add to ignored list
							$chrDQuery = "SELECT iduser,chrproject FROM dbatn_project_owner,dbatn_projects WHERE iduser IN ($chrDelete2) AND dbatn_projects.idproject=dbatn_project_owner.idproject";
							$rs = mazDb_query($chrDQuery);
							while($arrD= mazDb_fetch_array($rs)){
								unset($arrIdUserToDelete[$arrD["iduser"]]);
								if (!$arrIGNORED[$arrD["iduser"]]){
									$arrIGNORED[$arrD["iduser"]] = $arrDELETED[$arrD["iduser"]];
								}
								$arrIgnoreReason[$arrD["iduser"]] .= "Owner of PROJ: ".$arrD["chrproject"]."<br>";
								unset($arrDELETED[$arrD["iduser"]]);
							}

							#now update the department filed to null for the rest of the users that are not part of any project
							if (sizeof($arrIdUserToDelete) > 0){
								$chrDelete3 = implode(",",$arrIdUserToDelete);
								deleteUserLinksInBulk($chrDelete3);
								$chrDeleteQuery = "UPDATE dbatn_userslist SET department=null WHERE iduser IN ($chrDelete3)";
								mazDb_query($chrDeleteQuery);
							}
					}#end if (the user we think to delete exisit in our system)
			}#if any user is there for deleteion
		for ($i = 0; $i < sizeof($arrQuery); $i++){
				$chrQuery = $arrQuery[$i];
				mazDb_query($chrQuery);
		}
	}#end chrAction if
	*/


/*
<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");

	#  session object and try to load user info (id name etc from session)
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		header("location: ldap_do_login.php");
		exit();
	}

	# requestion action is import user
	$blnChecked = false;
	if ($_REQUEST["chrAction"] == "import_users"){
		$arrDepartments = array();
		for($i = 0; $i < $_POST["intCounter"]; $i++){
			if ($_POST["users_$i"]){
				$blnChecked = true;
				# unserilze info (custom)
				$objRecord = json_decode($_POST["users_$i"], true);
				# display($objRecord);
				$dn 			= safeDatabase($objRecord["dn"]);
				$name 			= safeDatabase($objRecord["name"]);
				$dept 			= safeDatabase($objRecord["department"]);
				$city 			= safeDatabase($objRecord["city"]);
				$erelation		= safeDatabase($objRecord["relationship"]);
				$phone 			= safeDatabase($objRecord["phone"]);
				$title 			= safeDatabase($objRecord["title"]);
				$email 			= safeDatabase($objRecord["mail"]);
				$uid 			= safeDatabase($objRecord["uid"]);
				$mdept 			= safeDatabase($objRecord["mdept"]);
				$sdept 			= safeDatabase($objRecord["sdept"]);
				# check if user already exist in the system
				# behave accordingly update/insert
				$chrQuery = "SELECT 1 FROM dbatn_userslist WHERE uid='$uid'";
				$rs = mazDb_query($chrQuery);
				if (mazDb_num_rows($rs) > 0 ){
					#we need to update this record
					$arrQuery[$uid] = "UPDATE dbatn_userslist SET dn='$dn',name='$name',department='$dept',city='$city',erelation='$erelation',phone='$phone',title='$title',email='$email',mdept='$mdept',sdept='$sdept' WHERE uid='$uid'";
				}
				else{
					$arrQuery[$uid] = "INSERT INTO dbatn_userslist(iduser,dn,name,department,city,erelation,phone,title,email,mdept,sdept,uid)
						values(nextval('seq_idlist_lists'),'$dn','$name','$dept','$city','$erelation','$phone','$title','$email','$mdept','$sdept','$uid') ";
				}
				$arrDepartments[$dept] = $dept;
			}#if record
		}#end for

		# check if current loggedin user is in database or not
		# if not then import him and get his id.
		$idUser = importUserIntoTheSystem($objSession->getUid());

		#adding ownership to department
		$chrMyQuery = $arrQuery[$objSession->getUid()];

		#if mine query is an insert query then ignore it, coz on the above step we have forcefully added current user into system
		if (substr($chrMyQuery,0,6) == "INSERT") {
			unset($arrQuery[$objSession->getUid()]);
		}

		#Validate and insert chosen departments if applicable.
		if ($blnChecked == true){
			#Does any department already exist.
			$deptExistAlready = false;
			#Store departments that already exist
			$departmentThatAlreadyExist = "";
			#Store departments that has been inserted now.
			$newDepartments = "";

			#Search through every department that has been marked to be inserted.
			foreach ($arrDepartments as $chrDepartmentValue){

				#Checks if the department already is in the database
				$chrDoesDepartmentExist = "SELECT * FROM dbatn_department_owner where chrdepartment='$chrDepartmentValue'";
				$msg = $msg . "$chrDoesDepartmentExist";
				$rsDepartmentExist = mazDb_query($chrDoesDepartmentExist);

				#If no rows were found we should insert this new department and assign appropriate message.
				if (mazDb_num_rows($rsDepartmentExist) == 0){
					# insert current user owner of these added departments
					$arrQuery[] = "INSERT INTO dbatn_department_owner(iduser,chrdepartment) values($idUser,'$chrDepartmentValue')";
					#allow these departments to view them self
					$arrQuery[] = "INSERT INTO dbatn_department_department(chrdepartment,chrdepartmentallwoed) values('$chrDepartmentValue','$chrDepartmentValue')";
					#make an default email-setting for this new department
					$arrQuery[] = "INSERT INTO dbatn_department_email_settings(chrdepartment,intemailrequired,chrconfirmationmsg,chrreplymsg,intautoapprove) values('$chrDepartmentValue',1,'Your request is received','Your absence item is updated',0)";

					$newDepartments = $newDepartments . $chrDepartmentValue;
				}
				#The department already exist so display message.
				else{
					if ($deptExistAlready){
						$departmentThatAlreadyExist = $departmentThatAlreadyExist . ", " . $chrDepartmentValue;
					}
					else{
						$departmentThatAlreadyExist = $departmentThatAlreadyExist . $chrDepartmentValue;
						$deptExistAlready = true;
					}
				}
			}

			#Execute all insert queries generated above.
			foreach ($arrQuery as $uid=>$chrQuery){
				#$chrQuery = $arrQuery[$i];
				mazDb_query($chrQuery);
			}

			#If any department was found in the database than display appropriate message.
			if ($deptExistAlready){
				$msg = "The list $departmentThatAlreadyExist already exist.";
				if ($newDepartments != ""){
					$msg = $msg . " The departments $newDepartments have been created.";
				}
				header("location: import_list.php?msg=$msg");
			}
			#All choosen departments was inserted. Go to list department page.
			else {
				header("location: list_departments.php");
				$blnChecked = false;
			}
		}
		else{
				$msg = "No box checked!";
				header("location: import_list.php?msg=$msg");
		}
		exit();
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("Add Department/Section"); ?></title>
		<?php echo generateScripts(); ?>
<script type="text/javascript">

function selectUsers(obj, chrDept){
	var arrChk = document.getElementsByTagName("input");
	blnChecked = false;
	if (obj.checked == true){
		blnChecked = true;
	}
	for (i = 0; i < arrChk.length; i++){
		if (arrChk[i].getAttribute("dept") == chrDept){
			arrChk[i].checked = blnChecked;
		}
	}
}

function getSections(){
	document.frmSearch.chrAction.value = "getsections";
	document.frmSearch.submit();
}

function addTo(i){
	document.frmSubSection.chrAction.value = "addto";
	document.getElementById("chrNewDept").value = document.getElementById("chrNewDept_" + i).value;
	document.frmSubSection.submit();
}
</script>
	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar">
       	  			<img src="media/images/department.png" /> &nbsp;
       	  			<span class="pageheading">Add Department / Section</span>
				</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
	<tr>
    	<td valign="top" bgcolor="#505050" height="100%" >
    		<table cellpadding="0" cellspacing="" width="100%">
        		<tr>
          			<td bgcolor="#505050">&nbsp;</td>
            		<td class="workareaBox" valign="top">
    				<!-- ################################## Working Area START ################################# -->
        				<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="1">
							<!-- InstanceBeginEditable name="subheader section" -->
				  			<!-- InstanceEndEditable -->
      						<tr>
        						<td height="100%">			<!-- _____Contents START_____ -->
				            	<div id="workingDiv" style="width:100%;height:<?php echo CALENDAR_HEIGHT ?>">
                				<table bgcolor="#505050" width="100%" height="100%" >
                    				<tr>
                        				<td style="padding-top:5px;"><!-- InstanceBeginEditable name="working-area" -->
                            			<form name="frmSearch" id="frmSearch" method="post">
                            				<input type="hidden" id="chrAction" name="chrAction" value="getusers" />
											<table width="100%" bgcolor="#FFFFFF" border="0" cellspacing="3" cellpadding="3">
                              					<tr>
                                					<td colspan="2" class="formheading">Add Department / Section</td>
                              					</tr>
                              					<tr>
                              						<td class="critical"><?php
	                    					          	$message = $_GET['msg'];
						                              	if(!is_null($message)){
						                              		echo '<img src="media/images/critical.png" />';
            	        					          		echo $message; '</td>';
						                              		echo '<td></td>';
                    						          	}?>
                              					</tr>
                              					<tr>
                                					<td width="27%" class="caption">Search Department /Section:</td>
                                					<td width="73%"><input type="text" name="chrSearch" id="chrSearch" value="<?php echo $_REQUEST["chrSearch"] ?>" /></td>
                              					</tr>
                              					<tr>
                                					<td>&nbsp;</td>
                                					<td><input type="submit" value="Get Users" />
                                					<input name="Button" type="button" value="Get Section" onclick="getSections()" /></td>
                              					</tr>
                              					<tr>
                                					<td colspan="2">&nbsp;</td>
                              					</tr>
                            				</table>
										</form>
                            			<form name="frmSubSection" id="frmSubSection" method="post">
                            				<table bgcolor="#FFFFFF" width="100%">
                            					<tr>
                                					<td class="formheading">Search Result :                                   </td>
                              					</tr>
                                					<?php
													if ($_REQUEST["chrSearch"]){
														# if some department or section is searched
														# then retrive the records from active directory
														$arrResults = ldap_searchList($_REQUEST["chrSearch"],$_REQUEST["chrAction"]);
														ksort($arrResults);
													}

													$chrDeptOptions = "";
			                                		$arrDepts = get_departments_from_db();
			                                		ksort($arrDepts);
			                                		$mdept = "";
			                                		foreach ($arrDepts as $key => $dept) {
			                                			$arrSubDepts = explode("/", $dept, 2);
			                                			if ((count($arrSubDepts) > 1) && ($arrSubDepts[0] != $mdept)){
			                                				$mdept = $arrSubDepts[0];
			                                				$chrDeptOptions .= "<optgroup label=\"$mdept\"></optgroup>";
			                                			}
			                                			$chrDeptOptions .= "<option>$dept</option>";
			                                		}
													?>
				                                <tr>
                					              	<td>
					                                <?php
                    					            # if search is successfuly and requested action is to display users list then show
					                                # create list button (Button at the top of the list)
                    					            if (sizeof($arrResults) > 0 && $_REQUEST["chrAction"] == "getusers" || $_REQUEST["chrAction"] == "section_users"){
														?>
                    					    	        <input type="submit" value="Create List" />
				                                		<input type="submit" value="Add to" onclick="addTo(0)" />
				                                		<select name="chrNewDept_0" id="chrNewDept_0">
				                                		<?php echo "$chrDeptOptions"; ?>
				                                		</select>
					                            	    <?php
													}
                               				 		if (sizeof($arrResults) > 0 && $_REQUEST["chrAction"] == "getsections"){
														?>
            		                                    <input type="submit" value="Get Users" />
                    			                        <?php
													}
													?></td>
                              					</tr>
                                				<tr>
                                					<td class="text" bgcolor="#FFFFFF">
			                                    	<?php
													#display($_REQUEST["chrAction"],"Search Mode");
													if (!$_REQUEST["chrSearch"]){
														echo "&nbsp;";
													}
													else if (sizeof($arrResults) < 1){
														echo "No record(s) found";
													}
													else{
														$counter = 0;
														$arrSections = array();
														# draw searched user or sections checkboxes
														foreach($arrResults as $chrDpartment=>$arrUsers){
															if ($_REQUEST["chrAction"] == "getsections"){		# sections
																# draw section check boxes
																echo "<input type='checkbox' value='$chrDpartment' name='chk_$counter'> <b>".$chrDpartment."</b><br>";
																$arrSections[] = $chrDpartment;
																$counter++;
															}
															else{												# users
																#draw users check boxes with select all department user check box
																echo "<input type='checkbox' onclick=\"selectUsers(this,'$chrDpartment')\"><b>".$chrDpartment."</b><br>";
																foreach($arrUsers as $idx => $arrRecord){
																	$chrNameSimple = $arrRecord["name"];
																	$chrNameUtf8 = ($chrNameSimple);
																	$arrRecord["name"] = $chrNameUtf8;
																	$arrRecord["city"] = ($arrRecord["city"]);
																	$chrRecord = json_encode($arrRecord);
																	echo " &nbsp; &nbsp;<input type='checkbox' dept='$chrDpartment' value=\"$chrRecord\" name='users_$counter'>".($chrNameUtf8)." <font color=red>(".($arrRecord["uid"]).")</font><br>";
																	$counter++;
																}#foreach user
																echo "<hr>";	# Draw line before last button
															}#endelse
														}#end foreachdept
													}#end else
													?></td>
				                                </tr>
                				                <tr>
                                					<td>	<!-- Button at the bottom of the list -->
			                                    	<?php
													if (sizeof($arrResults) > 0 && $_REQUEST["chrAction"] == "getsections"){
														?>
        	                                    	    <input type="hidden" name="intCounter" id="intCounter" value="<?php echo $counter ?>" />
            	                                    	<input type="hidden"  name="chrSearch" value="<?php echo $_REQUEST["chrSearch"] ?>" />
	                	                                <!-- <input type="text"  name="chrSubSearch" value="<?php echo implode(",",$arrSections) ?>" /> -->
    	                	                            <input type="hidden" name="chrAction" id="chrAction" value="section_users" />
        	                	                        <input type="submit" value="Get Users" />
            	                		                <?php
													}
													else if (sizeof($arrResults) > 0 && $_REQUEST["chrAction"] == "getusers" || $_REQUEST["chrAction"] == "section_users"){
														?>
    	                                            	<input type="hidden"  name="chrSearch" value="<?php echo $_REQUEST["chrSearch"] ?>" />
        	                                            <input type="hidden" name="intCounter" id="intCounter" value="<?php echo $counter ?>" />
            	                                        <input type="hidden" name="chrAction" id="chrAction" value="import_users" />
            	                                        <input type="hidden" name="chrNewDept" id="chrNewDept" value="" />
                	                                    <input type="submit" value="Create List" />
				                                		<input type="submit" value="Add to" onclick="addTo(1)" />
				                                		<select name="chrNewDept_1" id="chrNewDept_1">
				                                		<?php echo "$chrDeptOptions"; ?>
				                                		</select>
                        		                        <?php
													}
													?>
				                                	</td>
				                                </tr>
                				            </table>
			                            </form>
										<!-- InstanceEndEditable --></td>
    		                    	</tr>
                    			</table>
                				</div>			<!-- _____Contents End_____ -->
        						</td>
      						</tr>
    					</table>
        				<!-- ##################################	Working Area END ################################# -->
          			</td>
            		<td bgcolor="#505050">&nbsp;</td>
          		</tr>
          		<tr>
          			<td bgcolor="#505050" colspan="3">&nbsp;</td>
          		</tr>
	  		</table>
    	</td>
  	</tr>
</table>
			</div>
		</div>
		<?php echo generateFooter(); ?>
	</body>
</html>
*/
