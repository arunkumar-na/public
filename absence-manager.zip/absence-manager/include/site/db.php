<?php
	//Testing if svn works

	$dbUser = "absencemanager";
	//$dbUser = "absman_test";
	//$dbPassword="4bsm4nag3rtesting";
	$dbPassword="c0cac0la";
	//$dbPassword="oracle";
	$dbServer = "esessux0089.ss.sw.ericsson.se";
	//$dbServer = "localhost";

	if(preg_match("/\/view\/.*_scripts\//", $_SERVER['SCRIPT_FILENAME']))
	{
 		$developer = $_SERVER[SCRIPT_FILENAME];
		$developer = preg_replace("/.*\/view\/(.*)_scripts\/vobs\/.*/", "$1", $_SERVER[SCRIPT_FILENAME]);
        $_SESSION['developer'] = $developer;
	} else {
	   $_SESSION['developer'] = '';
	}
	$base_db = 'absencemgr';

	if(!is_null($_GET['db'])){
    # Variabel is set in the url!
	    if($_GET['db'] == ''){
	        # If the variabel is set and empty, reset developer
	        # print "variable is set and empty<br>";
	        $_SESSION['database'] = $base_db;
	    }
	    else {
	        # else, the variabel is set and _<string> is added to $SESSION['database']
	        # print "setting to developer mode<br>";
	        $_SESSION['database'] = $base_db . '_' . $_GET['db'];
	    }
	}
	else {
	    if(is_null($_SESSION['database'])){
	        # If no database is set in the session and no variabel is set
	        $_SESSION['database'] = $base_db;
	        # print "setting to default<br>";
	    }
	    else {
	        # print "doing nothing<br>";
	        # the variabel is not set and we already have a databas in the sessionen, don't change anything!
	    }
	}
	//$_SESSION['database'] = 'absencemgr';
	$_SESSION['database'] = 'absencemgr';
	//include_once("include/maz.db.php");
	include_once("./include/maz.db.php");
	mazDb_connect($dbServer,$dbUser,$dbPassword,$_SESSION['database']);
?>
