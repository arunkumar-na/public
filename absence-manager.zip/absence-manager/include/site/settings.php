<?php
error_reporting(E_ALL & ~E_NOTICE);
# all kind of variables etc can come here

define("DEVELOPER",1); # on Production must be zero

define("RELATION_TYPE_E","Ericsson");
define("RELATION_TYPE_N","Non-Ericsson");

define("CALENDAR_HEIGHT", "100%");
define("UTF8_CHARSET",false);
define("UTF8_CONFLICT",true); #on real working server it should be true;

define("LINK_ESS","https://sso.ericsson.se/EricssonLoginForm/?TYPE=33554433&REALMOID=06-876cee46-3948-454e-a722-7dcaae1123a3&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=-SM-86eTriYEoGCMk%2bxQYjwL64UwHAUGerumB2AdSyWzskRYQIlH%2bDkNQp6t72hw1%2f9v&TARGET=-SM-https%3a%2f%2fep6%2eal%2esw%2eericsson%2ese%2firj%2fportal");
define("LINK_PEOPLE_FINDER","http://internal.ericsson.com/wps/portal/yasper/pf");
define("PEOPLE_FINDER_FORMAT", "http://internal.ericsson.com/wps/portal/yasper/?action=search&srchCID=%s");
define("LINK_OUTLOOK","outlook:today");
# define("TUT_START","docs/absencemanager-overview.pdf");
define("TUT_START","docs/TUTORIAL.htm");

# LDAP Configuration
define("IMPORT_FROM_LDAP", true);
define("LDAP_UID_CAPS", true);

$time = $_SERVER['REQUEST_TIME'];

/** Session timeout added by Lakshmi Narasimhan
* for a 30 minute timeout, specified in seconds
*/
$timeout_duration = 1800;

/**
* Here we look for the user's LAST_ACTIVITY timestamp. If
* it's set and indicates our $timeout_duration has passed,
* blow away any previous $_SESSION data and start a new one.
*/
  if (isset($_SESSION['LAST_ACTIVITY']) && 
   ($time - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset();
    session_destroy();
    session_start();
   }

/**
* Finally, update LAST_ACTIVITY so that our timeout is based on it and not the user's login time.
*/
$_SESSION['LAST_ACTIVITY'] = $time;
// end of code updated 5 Aug-2021

#ECD
define("LDAP_ADDRESS","ecd.ericsson.se");
//define("LDAP_ADDRESS","ecd-acc.iam.mgmt.ericsson.se");
define("LDAP_PORT","389");
//define("LDAP_PORT","636");
define("LDAP_CONNECT_USERNAME","uid=EABSCTOOL,ou=users,ou=internal,o=ericsson");

//define("LDAP_CONNECT_PASSWORD","IxaiYFWZixfHvF35");
define("LDAP_CONNECT_PASSWORD","SummerVacation2021-08-04");
define("LDAP_BASE_DN", "ou=Users,ou=Internal,o=ericsson");
define("LDAP_BASE_DN_PARTNER", "ou=partners,ou=external,o=ericsson");

#LDAP attributes
define("LDAP_DN","dn"); #Distinguished Name
define("LDAP_FIRST_NAME","givenname");
define("LDAP_LAST_NAME","sn");
define("LDAP_DEPARTMENTNUMBER","erioporgunitname");
define("LDAP_TELEPHONENUMBER","telephonenumber");
define("LDAP_EMAIL","mail");
define("LDAP_USER_ID","uid");
define("LDAP_JOB_TITLE","title");
define("LDAP_RELATION_FIELD","ericonnection");
define("LDAP_CITY","physicaldeliveryofficename"); #City coded with ISO-8859-1
define("LDAP_DISPLAY_NAME","eridisplayname"); #Full name coded with ISO-8859-1
define("LDAP_MANAGERSIGNUM","erioperationalmanager");
define("LDAP_ISLEGALMANAGER","eriisopmgr");
define("LDAP_UNITNAME","erioporgunitname");
define("LDAP_UNITABBREVIATION","erioporgunitabbreviation");
define("LDAP_UNITIDENTIFIER","erioporgunitidentifier");


# Attributes for external employees are different
define("LDAP_XDISPLAY_NAME","ericn");
define("LDAP_XDEPARTMENTNUMBER","ou");

# Some external partners (for example XJI) has their departmentNumber set to "N/A" and
# their org unit set to what departmentNumber should have been.
# Using this filter together with sprintf when searching the LDAP directory,
# we can get around this.
define("LDAP_DEPARTMENT_FILTER", '(| ('.LDAP_DEPARTMENTNUMBER.'=%1$s) (& ('.LDAP_DEPARTMENTNUMBER.'=N/A) ('.LDAP_XDEPARTMENTNUMBER.'=%1$s)))')
?>
