<?php
/*** ########################################################
*	Get the LDAP search result unregarded to which
*	LDAP_BASE_DN the user has.
*
*	@param string $ds
* 	@param String $searchFilter
* 	@param array $arrSearch
* 	@return array
*____________________________________________________________*/
function ldap_search_with_correct_base_dn($ds, $searchFilter, $arrSearch = array()){
	#Check if the logged in user is internal or partner user.
	$tmpUId=$objSession->getUid;

	#Is the user probably an partner
	if(preg_match("/^X/i",$tmpUId)){
		$ldap_base_dn = LDAP_BASE_DN_PARTNER;
	}
	else {
		$ldap_base_dn = LDAP_BASE_DN;
	}

	#TODO - We need to check agains company aswell. This can be found in LDAP ou

	#Try to find the search user in the chosen LDAP base dn.

	$sr=ldap_search($ds, $ldap_base_dn, $searchFilter, $arrSearch);
	$searchAgain = false;

	#Did we find the user? If not, then we should try to search in the other LDAP_BASE_DN just to be sure.
	if (!$sr){
		$searchAgain = true;
	}
	else {
		$entries=ldap_get_entries($ds, $sr);

		if ($entries["count"] == 0) {
			$searchAgain = true;
		}
	}

	if ($searchAgain) {
		if ($ldap_base_dn == LDAP_BASE_DN){
			$ldap_base_dn = LDAP_BASE_DN_PARTNER;
		}
		else {
			$ldap_base_dn = LDAP_BASE_DN;
		}

		$sr=ldap_search($ds, $ldap_base_dn, $searchFilter, $arrSearch);
		$entries = ldap_get_entries($ds, $sr);
	}

	return $sr;
}
/*** ########################################################
*	Get Records from Ldap against specfic field (Multiple records but single field)
*
* 	@param String $chrField
* 	@return array
*____________________________________________________________*/
function get_field_from_ldap($chrField){
	$ds=ldap_connect(LDAP_ADDRESS,LDAP_PORT) or die("unable to connect ldap"); // must be a valid LDAP server!

	#Not used?
	$arrResult = array();
	if ($ds){
		$bd = ldap_bind($ds,LDAP_CONNECT_USERNAME,LDAP_CONNECT_PASSWORD) or die("Couldn't bind to AD!");

		$filter="($chrField=*)";

		#Search in ECD
		$sr = ldap_search_with_correct_base_dn($ds, $filter, array($chrField));

		$arrData = ldap_get_entries($ds, $sr);
		for($i = 0; $i < $arrData["count"] ; $i++){
			$value = $arrData[$i]["$chrField"][0];
			$arrResultRec[$value] = $value ;
		}
	}
	return $arrResultRec;
}
/*** ########################################################
*	Get Complete Records from Ldap against Search Criteria
*
* 	@param String $chrSearch
* 	@param String $chrAction : Retrive Sections or user list
* 	@param String $blnExtended : Extended search filter, if false will search against departmentNumber
* 	@return array
*____________________________________________________________*/
function import_from_ldap($chrSearch, $chrAction, $blnExtended = false){
	$justthese = array(LDAP_DN, LDAP_FIRST_NAME, LDAP_LAST_NAME, LDAP_DEPARTMENTNUMBER, LDAP_CITY, LDAP_RELATION_FIELD, LDAP_TELEPHONENUMBER, LDAP_JOB_TITLE, LDAP_EMAIL, LDAP_DISPLAY_NAME, LDAP_USER_ID, LDAP_OU, LDAP_XDISPLAY_NAME, LDAP_XDEPARTMENTNUMBER, LDAP_MANAGERSIGNUM, LDAP_ISLEGALMANAGER);
	$justthese = array();
	$ds=ldap_connect(LDAP_ADDRESS,LDAP_PORT) or die("Unable to connect LDAP"); // must be a valid LDAP server!

	$arrResult = array();
	if ($ds){
		$bd = ldap_bind($ds,LDAP_CONNECT_USERNAME,LDAP_CONNECT_PASSWORD) or die("Couldn't bind to AD!");

		$filter = sprintf(LDAP_DEPARTMENT_FILTER, "$chrSearch*");
		if ($blnExtended == true){
			$filter = $chrSearch;
		}

		#Search in ECD
		$sr = ldap_search_with_correct_base_dn($ds, $filter, $justthese);

		$arrData = ldap_get_entries($ds, $sr);
					
		
		for($i = 0; $i < $arrData["count"] ; $i++){
			$external = ($arrData[$i][LDAP_RELATION_FIELD][0] != 'E' ? true : false);
			if ($external){
				$name = $arrData[$i][LDAP_XDISPLAY_NAME][0];
				$dept = $arrData[$i][LDAP_XDEPARTMENTNUMBER][0];
			}
			else {
				$name = $arrData[$i][LDAP_DISPLAY_NAME][0];
				$dept = $arrData[$i][LDAP_DEPARTMENTNUMBER][0];
			}
			if ($name != "" && $arrData[$i][LDAP_EMAIL][0] != "" && ($external || $arrData[$i][LDAP_JOB_TITLE][0] != "")){
				$arrDept = explode("/",$dept);
				if ($chrAction == "getusers" || ($chrAction == "section_users"/* && in_array($dept,$arrSubDepartments)*/)){
					$arrResultRec["dn"] =  $arrData[$i][LDAP_DN][0];
					$arrResultRec["name"] =  $name;
					$arrResultRec["department"] =  $dept;
					$arrResultRec["city"] =  $arrData[$i][LDAP_CITY][0];
					$arrResultRec["relationship"] =  $arrData[$i][LDAP_RELATION_FIELD][0];
					$arrResultRec["phone"] =  $arrData[$i][LDAP_TELEPHONENUMBER][0];
					$arrResultRec["title"] =  $arrData[$i][LDAP_JOB_TITLE][0];
					$arrResultRec["mail"] =  $arrData[$i][LDAP_EMAIL][0];
					$arrResultRec["uid"] =  $arrData[$i][LDAP_USER_ID][0];
					$arrResultRec["legalManager"] = $arrData[$i][LDAP_MANAGERSIGNUM][0];
					$arrResultRec["isLegalManager"] = ($arrData[$i][LDAP_ISLEGALMANAGER][0] == "Y" ? "t" : "f" );
					$arrResultRec["mdept"] =  $arrDept[0];

					if (count($arrDept) > 1){
						$arrResultRec["sdept"] =  $arrDept[1];
					}
					else {
						$arrResultRec["sdept"] = "";
					}
					$arrResult[$dept][] = $arrResultRec;
				}
				else if ($chrAction == "getsections"){
#					if (strtolower($arrDept[0]) == strtolower($chrSearch) && ($external || $arrDept[1])){
					if ($external == false){
						$arrResult[$dept] = array();
					}
				}
			}
		}#endforeach
	}#end ds
	return $arrResult;
}#end function------------------------------------------------

function ldap_get_managers_from_department_below($managerSignum) {
	$justthese = array(LDAP_FIRST_NAME, LDAP_DEPARTMENTNUMBER, LDAP_MANAGERSIGNUM);
	$ds=ldap_connect(LDAP_ADDRESS,LDAP_PORT) or die("Unable to connect LDAP"); // must be a valid LDAP server!

	$arrResult = array();
	if ($ds){
		$bd = ldap_bind($ds,LDAP_CONNECT_USERNAME,LDAP_CONNECT_PASSWORD) or die("Couldn't bind to AD!");
		$filter="(erioperationalmanager=$managerSignum)";
		echo "<br><br>filter: ".$filter."<br><br>";

		#Search in ECD
		$sr = ldap_search_with_correct_base_dn($ds, $filter, $justthese);

		$arrData = ldap_get_entries($ds, $sr);
	}
}

/*** ########################################################
*	Get Complete Records from Ldap against Search Criteria
*
* 	@param String $chrSearch
* 	@param String $chrAction : Retrive Sections or user list
* 	@return array
*____________________________________________________________*/
function ldap_searchList($chrSearch,$chrAction){
	$arrResult = array();
	if (IMPORT_FROM_LDAP == true){
		$arrResult = import_from_ldap($chrSearch,$chrAction);
	}
	else {
		/**
			Other source can also be implementd like a LDAP Exported XML File etc (not implemented yet)
		**/
	}
	return $arrResult;
}

/*** ########################################################
*	Get User credentional from the ldap, who is currently browsing the tool
*
* 	@return array
*____________________________________________________________*/
function ldap_get_user_login($loginid) {
	if (DEVELOPER == 1) {

                                //$chrUser = ($_SERVER["HTTP_SMUNIVERSALID"]) ? $_SERVER["HTTP_SMUNIVERSALID"] : ($_REQUEST["loginid"] ? $_REQUEST["loginid"] : "test1.user");
                                $chrUser = ($_SERVER["HTTP_SMUNIVERSALID"]) ? $_SERVER["HTTP_SMUNIVERSALID"] : ($loginid ? $loginid : "test1.user");

	} else {

                                $chrUser = $_SERVER["HTTP_SMUNIVERSALID"];

	}


	if ($chrUser){
		// when a user is logged in by auto-negotiation, the REMOTE_USER contains signum@DOMAIN.ERICSSON.SE

                                //$chrLdapUID = explode("@",$chrUser);

                                $chrLdapUID = strtoupper($chrUser); #LDAP Contains in CAPS

		if (LDAP_UID_CAPS == true){
			$chrLdapUID = strtolower($chrLdapUID);
		}
		# connect to ldap server
		$ds=ldap_connect(LDAP_ADDRESS,LDAP_PORT) or die("Unable to connect LDAP");  // must be a valid LDAP server!

		#if successful
		if ($ds){
			$bd = ldap_bind($ds,LDAP_CONNECT_USERNAME,LDAP_CONNECT_PASSWORD) or die("Couldn't bind to AD!");

			#Search this user in ldap and get information
			$filter = LDAP_USER_ID . "=$chrLdapUID";

			#Search in ECD
			$sr = ldap_search_with_correct_base_dn($ds, $filter);
			$info = ldap_get_entries($ds, $sr);

			#Check if any records are found
			if (!$info || !is_array($info) || sizeof($info) < 1){
				return array();
			
			}

			#Check if the user is external
			$blnExternal = ($info[0][LDAP_RELATION_FIELD][0] != 'E' ? true : false);

			#populate user records
			if ($blnExternal){
				$name		= safeDatabase($info[0][LDAP_XDISPLAY_NAME][0]);
			}
			else {
				$name		= safeDatabase($info[0][LDAP_DISPLAY_NAME][0]);
			}
			$dn 			= safeDatabase($info[0][LDAP_DN][0]);
			$dept 			= safeDatabase($info[0][LDAP_DEPARTMENTNUMBER][0]);
			$city 			= safeDatabase($info[0][LDAP_CITY][0]);
			$erelation		= safeDatabase($info[0][LDAP_RELATION_FIELD][0]);
			$phone 			= safeDatabase($info[0][LDAP_TELEPHONENUMBER][0]);
			$title 			= safeDatabase($info[0][LDAP_JOB_TITLE][0]);
			$email 			= safeDatabase($info[0][LDAP_EMAIL][0]);
			$uid 			= safeDatabase($info[0][LDAP_USER_ID][0]);
			$legalManager 	= $info[0][LDAP_MANAGERSIGNUM][0];
			$isLegalManager = ($info[0][LDAP_ISLEGALMANAGER][0] == "Y" ? "t" : "f" );

			$x = explode("/",$dept);

			$mdept 			= safeDatabase($x[0]);
			$sdept 			= safeDatabase($x[1]);

#			$name = utf8_decode($name);

			# check if the user exist in our database, if not then insert him in local database as well, as we will be requiring id user from applying
			# his holidays
			$chrQuery = "SELECT * FROM dbatn_userslist where uid=$1";
			$rs = mazDb_query_params($chrQuery, array($uid));
			$arrInfo = array();
			$blnNewUser = false;
			if (mazDb_num_rows($rs) > 0){
				# Do Nothing, if already exist
			}
			else{
				#insert this user in database
				$arrQuery2 = "INSERT INTO dbatn_userslist(iduser,dn,name,department,city,erelation,phone,title,email,mdept,sdept,uid, \"isLegalManager\", \"legalManager\")
							values(nextval('seq_idlist_lists'),'$dn','$name','$dept','$city','$erelation','$phone','$title','$email','$mdept','$sdept','$uid', '$isLegalManager', '$legalManager') ";

				mazDb_query_params($arrQuery2, array());
#				$rs = mazDb_query($chrQuery);
				$blnNewUser = true;
			}

			#retrive information of inserted user, specially we require his inserted iduser as well as other information
			# to create object of our session.
			$chrQuery = "SELECT * FROM dbatn_userslist where uid=$1";
			$rs = mazDb_query_params($chrQuery, array($uid));
			$arr = mazDb_fetch_array($rs);

			$arrInfo["idUser"] = $arr["iduser"];
			$arrInfo["chrFullName"] = $arr["name"];
			$arrInfo["uid"] = $arr["uid"];
			$arrInfo["chrEmailAddress"] = $arr["email"];
			$arrInfo["chrDepartment"] = $arr["department"];
			$arrInfo["chrCity"] = $arr["city"];
			$arrInfo["legalManager"] = $arr["legalManager"];
			$arrInfo["isLegalManager"] = $arr["isLegalManager"];

			if ($blnNewUser == true){
				include_once("department.php");
				$deptName = $arrInfo["chrDepartment"];
		 		$objDept = getDepartmentByName(strtoupper($deptName));
		 		$arrDeptUsers = $objDept->getUsers();

		 		//If department needs to be imported 		
		 		if (sizeof($arrDeptUsers) <= 1){
					$objDept = importDepartment($deptName);
					$objDept->syncDepartment(true); //true means that it is an import
					$objDept->save();
				}

				#mark holidays from admin against this new user
				$rx = mazDb_query_params("SELECT * FROM dbatn_userdays WHERE \"idUser\"=0", array());
				$arrRedQuries = array();
				while($arrDay = mazDb_fetch_array($rx)){
					$intDay = $arrDay["intDay"];
					$intMonth = $arrDay["intMonth"];
					$intYear = $arrDay["intYear"];
					$chrCharacter = $arrDay["chrCharacter"];
					$chrComments = safeDatabase(safeHTML($arrDay["chrComments"]));
					$inttime	= $arrDay["inttime"];
					$idUser		= $arr["iduser"];

					$arrRedQuries[] = "INSERT INTO dbatn_userdays(\"idUser\",\"intDay\",\"intMonth\",\"intYear\",\"chrCharacter\",\"chrComments\",inttime) values ($idUser,$intDay,$intMonth,$intYear,'$chrCharacter','$chrComments',$inttime)";
				}
				foreach($arrRedQuries as $chrRedQuery){
					mazDb_query_params($chrRedQuery, array());
				}
			}
			
			#check LDAP user details are different from absence manager details, if true then update local database
			if($dept != $arr["department"] || $city != $arr["city"] || $title != $arr["title"] || $phone != $arr["phone"]) {
				$chrUpQuery = "UPDATE dbatn_userslist SET department = '$dept' , city = '$city' , title = '$title' , phone = '$phone' , mdept = '$mdept', sdept = '$sdept' WHERE iduser = '$arr[iduser]'";
				mazDb_query_params($chrUpQuery, array());
			}
		}
	}
	else {
		die("Unable to perform authentication! Please contact your system administrator.");
		# if REMOTE_USER does not work, then load a default user from database that we may have inserted for testing purpose
		#$chrQuery = "SELECT * FROM dbatn_userslist where iduser=1"; #load default test user
		#$rs = mazDb_query($chrQuery);
		#$arrInfo = array();
		#if (mazDb_num_rows($rs)){
		#	$arr = mazDb_fetch_array($rs);
		#	$arrInfo["idUser"] = $arr["iduser"];
		#	$arrInfo["chrFullName"] = $arr["chrfullname"];
		#	$arrInfo["uid"] = $arr["uid"];
		#	$arrInfo["chrEmailAddress"] = $arr["chremailaddress"];
		#	$arrInfo["chrDepartment"] = $arr["chrdepartment"];
		#}
	}
	return $arrInfo;
}
?>