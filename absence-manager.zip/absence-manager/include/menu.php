<?php
/**
 * *Display side menu with option
 */

# Admin Settings menu option
$arrMenu["admin_settings.php"] = 0;
$arrMenu["admin_create_template.php"] = 0;
$arrMenu["admin_logout.php"] = 0;

# My Calendar menu option
$arrMenu["index.php"] = 1;

# Member Of menu option
$arrMenu["memberof.php"] = 2;

# Personal Setting menu option
$arrMenu["personal_settings.php"] = 3;

# Search menu option
$arrMenu["search.php"] = 5;

# View menu option
$arrMenu["list_departments.php"] = 6;			#### View DEP/SEC List
$arrMenu["list_projects.php"] = 6;				#### View PROJ List
$arrMenu["view_calendar.php"] = 6;				#### View DEP/SEC Calendar
$arrMenu["view_project_calendar.php"] = 6;		#### View PROJ Calendar
$arrMenu["peopleManagedCalendar.php"] = 6;		#### View People Managed
$arrMenu["peopleManagedList.php"] = 6;		#### View People Managed
# Add menu option

  $arrMenu["create_project.php"] = 4;
  $arrMenu["edit_ownership.php"] = 4;
  $arrMenu["edit_department.php"] = 4;
  $arrMenu["edit_project.php"] = 4;
  $arrMenu["edit_project_choose.php"] = 4;

# TODO: Conform to code standard, function documentation

function generateUserInfo($objSession) {
	$fullName = $objSession->getFullName();
	$uid = $objSession->getUid();
	$dept = $objSession->getDepartment();
	return $fullName."<br />".$uid."<br />".$dept."<br />\n";
}

function generateMenu($objSession){
	# get current php file name, so that a selction will be made in
	# the menu, opend pane
	global $arrMenu;
	$chrOption = basename($_SERVER['PHP_SELF']);
	$menuItems  = "<ul>\n";

	# TODO: Use icons.css instead of ids in menu.css

	# Admin Settings
	$adminMenu .= '<li class="'.($arrMenu[$chrOption] == 0 ? 'selectedItem': '').'">';
	$adminMenu .= '<a id="adminMenu" class="menuHeading" href="javascript:toggleMenu(\'adminItems\');">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Admin Settings</a>';
	$adminMenu .= "</li>\n";
	$adminMenu .= '<li class="subMenu adminItems" '.($arrMenu[$chrOption] == 0 ? '' : 'style="display:none;"').'>';
	$adminMenu .= '<a id="adminRedDaysItem" href="admin_reddays.php">Admin Holidays</a>';
	$adminMenu .= "</li>\n";
	$adminMenu .= '<li class="subMenu adminItems" '.($arrMenu[$chrOption] == 0 ? '' : 'style="display:none;"').'>';
	$adminMenu .= '<a id="adminRedDaysItem" href="admin_create_template.php">Manage Templates</a>';
	$adminMenu .= "</li>\n";
	$adminMenu .= '<li class="subMenu adminItems" '.($arrMenu[$chrOption] == 0 ? '' : 'style="display:none;"').'>';
	$adminMenu .= '<a id="adminSettingsItem" href="admin_settings.php">Clean Up Database</a>';
	$adminMenu .= "</li>\n";
	$adminMenu .= '<li class="subMenu adminItems" '.($arrMenu[$chrOption] == 0 ? '' : 'style="display:none;"').'>';
	$adminMenu .= '<a id="adminLogOutItem" href="admin_logout.php">Log Out</a>';
	$adminMenu .= "</li>\n";

	if ($objSession->isAdminUser()){	# Shall only be visible if user is logged in as administrator
		$menuItems .= $adminMenu;
	}

	$menuItems .= '<li class="'.($arrMenu[$chrOption] == 1 ? 'selectedItem' : '').'">'; # My Calendar
	$menuItems .= '<a id="myCalendarItem" href="index.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;My Calendar</a>';
	$menuItems .= "</li>\n";
	$menuItems .= '<li class="'.($arrMenu[$chrOption] == 2 ? 'selectedItem' : '').'">'; # Member of
	$menuItems .= '<a id="memberOfItem" href="memberof.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Memberships</a>';
	$menuItems .= "</li>\n";
	$menuItems .= '<li class="'.($arrMenu[$chrOption] == 3 ? 'selectedItem' : '').'">'; # Personal Settings
	$menuItems .= '<a id="settingsItem" href="personal_settings.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Personal Settings</a>';
	$menuItems .= "</li>\n";
	$menuItems .= '<li class="'.($arrMenu[$chrOption] == 5 ? 'selectedItem' : '').'">'; # Search
	$menuItems .= '<a id="searchItem" href="search.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Search</a>';
	$menuItems .= "</li>\n";

	# View
	$menuItems .= '<li class="'.($arrMenu[$chrOption] == 6 ? 'selectedItem': '').'">';
	$menuItems .= '<a id="viewMenu" class="menuHeading" href="javascript:toggleMenu(\'viewItems\');">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;View</a>';
	$menuItems .= "</li>\n";
	$menuItems .= '<li class="subMenu viewItems" '.($arrMenu[$chrOption] == 6 ? '' : 'style="display:none;"').'>';
	$menuItems .= '<a id="listDeptsItem" href="list_departments.php">DEP/SEC Lists</a>';
	$menuItems .= "</li>\n";
	$menuItems .= '<li class="subMenu viewItems" '.($arrMenu[$chrOption] == 6 ? '' : 'style="display:none;"').'>';
	$menuItems .= '<a id="viewCalendarItem" href="view_calendar.php?chrAction=direct">DEP/SEC Calendars</a>';
	$menuItems .= "</li>\n";
	$menuItems .= '<li class="subMenu viewItems" '.($arrMenu[$chrOption] == 6 ? '' : 'style="display:none;"').'>';
	$menuItems .= '<a id="listProjectsItem" href="list_projects.php">Group Lists</a>';
	$menuItems .= "</li>\n";
	$menuItems .= '<li class="subMenu viewItems" '.($arrMenu[$chrOption] == 6 ? '' : 'style="display:none;"').'>';
	$menuItems .= '<a id="viewProjCalendarItem" href="view_project_calendar.php?chrAction=direct">Group Calendars</a>';
	$menuItems .= "</li>\n";
	if($objSession->getIsLegalManager() == 't') {
		$menuItems .= '<li class="subMenu viewItems" '.($arrMenu[$chrOption] == 6 ? '' : 'style="display:none;"').'>';
		$menuItems .= '<a id="viewPeopleManagedCalendarItem" href="peopleManagedCalendar.php">People Managed Calendar</a>';
		$menuItems .= "</li>\n";
		$menuItems .= '<li class="subMenu viewItems" '.($arrMenu[$chrOption] == 6 ? '' : 'style="display:none;"').'>';
		$menuItems .= '<a id="viewPeopleManagedListItem" href="peopleManagedList.php">People Managed List</a>';
		$menuItems .= "</li>\n";
	}


	# Add
	$addMenu = '<li class="'.($arrMenu[$chrOption] == 4 ? 'selectedItem': '').'">';
	$addMenu .= '<a id="addMenu" class="menuHeading" href="javascript:toggleMenu(\'addItems\');">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Add/Edit</a>';
	$addMenu .= "</li>\n";
	$addMenu .= '<li class="subMenu addItems" '.($arrMenu[$chrOption] == 4 ? '' : 'style="display:none;"').'>';
	$addMenu .= '<a id="createDeptItem" href="edit_department.php">Department / Section</a>';
	$addMenu .= "</li>\n";
	$addMenu .= '<li class="subMenu addItems" '.($arrMenu[$chrOption] == 4 ? '' : 'style="display:none;"').'>';
	$addMenu .= '<a id="createProjectItem" href="create_project.php">Add Group/Project</a>';
	$addMenu .= "</li>\n";
	$addMenu .= '<li class="subMenu addItems" '.($arrMenu[$chrOption] == 4 ? '' : 'style="display:none;"').'>';
	$addMenu .= '<a id="editProjectItem" href="edit_project_choose.php">Edit Group/Project</a>';
	$addMenu .= "</li>\n";

	if ($objSession->isAdvanceUser() == true){
		$menuItems .= $addMenu;
	}

	# Useful Links
	$menuItems .= '<li>';
	$menuItems .= '<a id="usefulLinksMenu" class="menuHeading" href="javascript:toggleMenu(\'linkItems\');">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Useful Links</a>';
	$menuItems .= "</li>\n";
	$menuItems .= '<li class="subMenu linkItems" style="display:none;">';
	$menuItems .= '<a class="newWindow" id="essItem" href="'.safeHTML(LINK_ESS).'">ESS</a>';
	$menuItems .= "</li>\n";
	$menuItems .= '<li class="subMenu linkItems" style="display:none;">';
	$menuItems .= '<a class="newWindow" id="peopleFinderItem" href="'.safeHTML(LINK_PEOPLE_FINDER).'">People Finder</a>';
	$menuItems .= "</li>\n";
	$menuItems .= '<li class="subMenu linkItems" style="display:none;">';
	$menuItems .= '<a class="newWindow" id="outlookItem" href="'.safeHTML(LINK_OUTLOOK).'">Outlook Calendar</a>';
	$menuItems .= "</li>\n";

	# Help
	$menuItems .= '<li class="helpItemBg"><a  class="newWindow" href="'."https://wiki.lmera.ericsson.se/wiki/Absence_Manager"."\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Help</a></li>\n";
	$menuItems .= "</ul>\n";

	$html  = "<div id=\"menu\"><div id=\"menuHeader\"><div id=\"userInfo\">\n";
	$html .= '<p>'.generateUserInfo($objSession)."</p>\n";
	$html .= "</div></div>\n";
	$html .= '<div id="menuBody">'.$menuItems."</div>\n";
	$html .= '<div id="menuFooter">&nbsp;</div></div>'."\n";
	$html .= "<div id='idUserDiv' style='visibility:hidden; height:0px; width:0px;'>".$objSession->getIdUser()."</div>";
	$html .= "<div id='isLegalManagerDiv' style='visibility:hidden; height:0px; width:0px;'>".$objSession->getIsLegalManager()."</div>";

	return $html;
}

?>
