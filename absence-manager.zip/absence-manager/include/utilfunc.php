<?php
define("FORMAT_INPUTBOX",1);
define("FORMAT_JS",2);

/**
 * This is custom function to convert lower case to upper case
 * and ignores the accented characters
 *
 * @param String $strInput
 * @return String
 */
function myUpper($strInput){
	$chrNewInput = "";
	for($i = 0; $i < strlen($strInput); $i++) {
		if ($strInput[$i] >="a" && $strInput[$i] <="z"){
			$chrNewInput .= chr(ord($strInput[$i]) - 32);
		}
		else {
			$chrNewInput .= $strInput[$i];
		}
	}
	return $chrNewInput;
}

/**
 * This is custom function for converting (serilazing) the
 * object into string (our pre-defined format for our predefined object)
 *
 * @param Object $mixData
 * @return String
 */
function cString($mixData) {
	#return htmlentities(serialize($mixData));
	$chrNewString = "";
	$arrP = array();
	foreach($mixData as $key=>$value){
		$arrP[] = $key.")-(".$value;
	}
	$chrNewString = implode("(=)",$arrP);
	return str_replace(array("'","\""),array("[squote]","[dquote]"),$chrNewString);
}

/**
 * This function act as unserilaze function for CString
 *
 * @param String $chrString
 * @return Object
 */
function cObject($chrString){
	$chrNewString = str_replace(array("[squote]","[dquote]"),array("'","\""),$chrString);
	$arrAttributes = explode("(=)",$chrNewString);
	$arrResult = array();
	foreach ($arrAttributes as $chrKeyValue){
		$info = explode(")-(",$chrKeyValue);
		$arrResult[$info[0]] = $info[1];
	}
	if (sizeof($arrResult) > 0){
		return $arrResult;
	}
	return "";
}
$indexDisplay = 0;

/**
 * This function will return true or false if record exist in database
 *
 * @param String $colName : Database field name in table
 * @param String $value	: Value that will searched in table
 * @param String $tableName : Table name in which record will be searched
 * @return Boolean
 */
function isLinked($colName,$value,$tableName="fht_tblreport"){
		$query = "select 1 from $tableName WHERE $colName='$value'";
		$rs = mysql_query($query) or die(mysql_error());
		if (mysql_num_rows($rs) > 0){
			return true;
		}
		else{
			return false;
		}
}

/*####################################################################*/
/**        UTILITY  FUNCTIONS        **/
/**
 * Return a safe text that can be come easly in textbox etc
 *
 */
function makeRequestSafe(){
	foreach($_REQUEST as $key => $value){
		$_REQUEST[$key] = mysql_escape_string(stripslashes($value));
	}
}

function safeTextBox($str){
	return(htmlentities($str));
}

/**
 * Returns safe text that will be going to be part of html text
 *
 * @param String $str
 * @return String
 */
function safeHTML($str){
	return(htmlentities($str, ENT_COMPAT, 'UTF-8'));
}

/**
 * Convert all values of an array into a safe format according to the passed Format
 *
 * @param Array $arr
 * @param int $format
 * @return Array
 */
function safeArray($arr,$format = FORMAT_INPUTBOX){
	foreach($arr as $key => $value){
		if ($format == FORMAT_INPUTBOX){
			$arr[$key] = htmlentities($value);
		}
		else if ($format == FORMAT_JS){
			$arr[$key] = addslashes($value);
		}
	}
	return $arr;
}

/**
 * Check if server has enabled auto slashing, will strip them,
 *
 * @param Array $arrValues
 * @return Array
 */
function HandleGPC($arrValues){
	if(get_magic_quotes_gpc()){
		$arrValues = is_array($arrValues) ? array_map( "HandleGPC", $arrValues) : stripslashes($arrValues);
	}
	return $arrValues;
}

/**
 * Return a safe text value that can be stored in database witout any query or db error
 * like if value conatin single quote etc
 *
 * @param String $str
 * @return String
 */
function safeDatabase($str){
	if(get_magic_quotes_gpc()){
		$str = stripslashes($str);
	}

	return (pg_escape_string($str));
}

/**
 * A custom message display funciton
 *
 * @param String $chrMsg
 * @param String $chrIcon
 */
function msg($chrMsg,$chrIcon="media/images/notify.gif"){
	if ($chrMsg){
		$str = "<table border=0><tr><td class='notification'>";
		if ($chrIcon){
			$str .= "<img src='$chrIcon' / ></td><td class='notification'>";
		}
		$str .= "$chrMsg </td></tr></table>";
		echo $str;
	}
}

/**
 * Return a safe value that can be concatinated or set to any element in javascript etc.
 *
 * @param String $chrVale
 * @return String
 */
function script_safe( $chrVale){
	return htmlentities(addslashes($chrVale));
}

/**
 * Return safe text that can be inseted into an input bpx
 *
 * @param String $chrValue
 * @return String
 */
function input_safe( $chrValue ){
	return htmlentities($chrValue);
}

/**
 * Print the REQUEST varaible
 *
 */
function printRequest(){
	foreach($_REQUEST as $key => $value){
			echo "\$".$key."=\$_REQUEST['".$key."']; <br>";
	}
}

/**
 * Abbrivate the text, if text is greater than specified length.
 *
 * @param String $chrText
 * @param String $intCount : minimum length
 * @return String
 */
function smalltxt($chrText, $intCount=10){
	if (strlen($chrText) > $intCount){
		return substr($chrText,0,$intCount)."...";
	}
	else if (strlen($chrText) == 0){
		return "&nbsp;";
	}
	return $chrText;
}

/**
 * Displays object/String/Number with full reffrence from where it is called
 * used for developer testing.
 *
 * @param mix $var
 * @param String $caption
 */
function display($var,$caption = -1){
	global $user,$indexDisplay;
	$indexDisplay++;
	$R = createColor(rand(0,15),rand(0,15));
	$G = createColor(rand(0,15),rand(0,15));
	$B = createColor(rand(0,15),rand(0,15));
	$color = "#".$R.$G.$B;
	$info  = debug_backtrace();
	?>
	<fieldset style="border: 2px solid <?php echo $color; ?>;width: 100%;
			font-family: Verdana, Arial, Helvetica, sans-serif;
			font-size: 10px;"><legend><?php echo $indexDisplay; ?> -  <?php echo ($caption != -1) ? " : $caption" : ""; ?> </legend>
			<pre style="font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px; color:#000000;">
	<?php
	print_r($var);
	?>
	</pre>
	<?php
	echo "<br>Line # ".$info[0]["line"]."<br><b>".$info[0]["file"]."</b><br>";
	?>
	</fieldset><?php
}

function createColor($c1,$c2){
	$color[10] = "A";
	$color[11] = "B";
	$color[12] = "C";
	$color[13] = "D";
	$color[14] = "E";
	$color[15] = "F";
	$C = "";
	if ($c1 < 10){
		$C = $c1;
	}
	else{
		$C = $color[$c1];
	}
	if ($c2 < 10){
		$C .= $c2;
	}
	else{
		$C .= $color[$c2];
	}
	return $C;
}

/**
 * Used for throwing output as html comment
 * Developer function for testing
 *
 * @param mix $mix
 * @param String $caption
 */

function htmlComment($mix, $caption=null) {
	echo "Eakh<!--\n\n===========================================================================================\n";
		if ($caption){
			echo "--------[$caption]---------\n";
		}
		print_r($mix);
	echo "\n===============================================================================================\n-->\n\n";
}

/**
 * Create a javascript alert statement
 *
 * @param unknown_type $str
 */
function dalert($str) {
	echo "<script>alert(\"$str\");</script>";
}

/**
 * Display a dropdown box for integer values
 *
 * @param String $ctlName : Name of the selectbox (control)
 * @param int $intStart : Starting value
 * @param int $intEnd: Ending value
 * @param int $intSelected : By defualt selected option
 */
function counterDropDown($ctlName, $intStart, $intEnd, $intSelected = 0){
	echo '<select name="'.$ctlName.'" id="'.$ctlName.'">';
	for($counter = $intStart; $counter <= $intEnd; $counter ++){
		$chrSelected = "";
		if ($counter == $intSelected) {
			$chrSelected = "selected";
		}
		echo '<option '.$chrSelected.' value="'.$counter.'">'.$counter.'</option>';
	}
	echo '</select>';
}

/**
 * fills a combox from database value, you have to provide select tag youself
 * this function will only write <options> section
 *
 * @param String $table : table name
 * @param String $value	: column name that will be used as value
 * @param String $caption : column name that will be shown on front end in drop down
 * @param String $selectoption : Default selection value
 * @param String $where : If where clause is requred
 */
function dbFillList($table,$value,$caption,$selectoption=null,$where=null){
		$rs = mysql_query("select $value,$caption from $table $where") or die(mysql_error());
		$myopt = "";
		$firstSelect = ($selectoption == null) ? " selected " : "";
		if (mysql_num_rows($rs) > 0 ){
			while($arr = mysql_fetch_array($rs)){
				if ($arr[$value] == $selectoption)
					$myopt = "selected";
				else
					$myopt = "";
				echo "<option value=".$arr[$value]." $myopt $firstSelect>";
				echo safeTextBox(stripslashes($arr[$caption]));
				echo "</option>\r";
				$firstSelect = "";
			}
		}
}

/**
 * Custom select box, with checkboxes instead
 *
 * @param String $name
 * @param String $table
 * @param String $value
 * @param String $caption
 * @param String $selectoption
 * @param String $where
 */
function customSelectBox($name,$table,$value,$caption,$selectoption=array(),$where=null){
		$rs = mysql_query("select $value,$caption from $table $where") or die(mysql_error());
		$myopt = "";
		$firstSelect = ($selectoption == null) ? " selected " : "";
		$chrCustomSelect = "<div class='customselect'>\n";
		if (mysql_num_rows($rs) > 0 ){
			$count = 0;
			while($arr = mysql_fetch_array($rs)){
				if (is_array($selectoption) && in_array($arr[$value],$selectoption))
					$myopt = "checked";
				else
					$myopt = "";
				$chrCustomSelect.= "<input name='".$name.$count."' id='".$name.$count."' type='checkbox' $myopt value='".$arr[$value]."' />".safeTextBox($arr[$caption])."<br />\n";
				$firstSelect = "";
				$count++;
			}
		}
		$chrCustomSelect .= "<input type='hidden' id='{$name}_count' name='{$name}_count' value='{$count}' /></div>
		<input type='checkbox' name='{$name}_checkall' id='{$name}_checkall' onclick=\"mazCustomSelectCheckUnCheck(this,'{$name}')\" />Select All \n";
		echo $chrCustomSelect;
}

/**
 * Create a directory with forced path
 *
 * @param String $chrPath
 */

function createDir($chrPath){
	$dirs = explode("/",$chrPath);
	$path = "";
	foreach ($dirs as $i =>  $dir){
		if ($dir != "." && $dir != ".."){
			$path.= $dir."/";
			if (!is_dir($path)){
				mkdir($path);
			}
		}
	}
}

/**
 * Upload a file
 *
 * @param Object $objFile : $_FILE type object
 * @param String $destination
 * @param String $prefixFilename : any custom prefix
 * @return int : 1 = No upload request, 2 = uploaded Successfuly, 3 = error
 */
function uploadfile($objFile,$destination, $prefixFilename = ""){
	$filename = $objFile['name'];
	if ($filename){
		if (strrchr($destination,".") !== false) {
			$filename = ""; #file name is provided in the destination, so clear this as it will be concatinated
		}
		else if ($prefixFilename != ""){
			$ext = strrchr($filename,".");
			$filename = str_replace(" ","_",$prefixFilename) . $ext;
			$destination = trim($destination,"/")."/";
		}
		else{
			#file name is mentioned
			$filename = str_replace(" ","_",$filename);
			$destination = trim($destination,"/")."/";
		}
		if(!copy($objFile['tmp_name'],$destination.$filename)) {
			//display("Unable to upload file",$destination.$filename); exit();
			return 3; # unable to copy file
		}
		return 2; # successful
	}
	else{
		return 1; # file was not meant to be upload
	}
}#end func

/**
 * Return an icon image depending upon the filename extension
 *
 * @param String $chrFile
 * @return String
 */
function getIcon($chrFile){
	$ext = explode(".",$chrFile);
	$ext = strtolower($ext[1]);
	if ($ext == "gif" || $ext == "bmp"){
		return "img.jpg";
	}
	else if ($ext == "htm" || $ext == "html"){
		return "html.jpg";
	}
	else if ($ext == "doc" || $ext == "docx"){
		return "doc.jpg";
	}
	else if ($ext == "xls"){
		return "xls.jpg";
	}
	else if ($ext == "xml"){
		return "xml.jpg";
	}
	else if ($ext == "jpg" || $ext == "jpeg" || $ext == "png"){
		return "jpg.jpg";
	}
	else if ($ext == "rar" || $ext == "zip"){
		return "zip.jpg";
	}
	return "txt.jpg";
}# end func

function createDateTimeStamp($chrDate){
	# $chrDate :: Formate is yyyy-mm-dd
	$dtX = explode("-",$chrDate);
	return mktime(0,0,0,intval($dtX[1]),intval($dtX[2]),intval($dtX[0]));
}#end func

/**
 * Returns current URL as a parameter whos value will be encded
 *
 * @return String
 */
function getCurrentLink(){
	$qry = explode("&bkLink=",$_SERVER["QUERY_STRING"]);
	if (sizeof($qry) > 1){
		$qryString = $qry[0];
	}
	else{
		$qry = explode("?bkLink=",$_SERVER["QUERY_STRING"]);
	}
	$qryString = $qry[0];
	$link = "index.php";
	if (strpos($_SERVER["PHP_SELF"],"add_to_cart.php") === false){
		$link = $_SERVER['PHP_SELF']."?".$qryString;
	}
	else{
		$link = "index.php";
	}
	return base64_encode($link);
}

/**
	 * Returns Image tag after applying a sclae factor
	 *
	 * @param String $filename
	 * @param int $scale
	 * @return String
	 */

function GetImageDim($filename,$scale = 150){
	if (file_exists($filename) && $filename != "img/"){
		$img_size = getimagesize($filename);
		$img_width = $img_size[0];
		$img_height = $img_size[1];
		$biger = $img_width;
		if ($img_height > $biger){
			$biger = $img_height;
		}
		if ($biger > $scale){
			$flt = $biger / $scale;
			$img_width = $img_width / $flt;
			$img_height = $img_height / $flt;
		}
		return "<img src='$filename' width=$img_width height=$img_height border=0>";
	}
	else{
		$filename = "media/images/noimage.gif";
	}
	return "<img src='$filename' border=0>";
}

/*********************************/

/*************************************
	 method for making 12 month combo box
	 argument will be the selected month
	 *************************************/
function monthsCombo($name,$month=-1){
	$html = "";
	if ($month == -1){
		$month = date("m",time());
	}
	$html .= "<select name='$name' id='$name'>";
	for ($i=1; $i<=12; $i++){
		if($i != $month)
			$html .= "<option value=".$i.">".date("F", mktime(0, 0, 0, $i, 1, 0000))."</option>\n";
		else
			$html .= "<option value=".$i." selected>".date("F", mktime(0, 0, 0, $i, 1, 0000))."</option>\n";
		}
	$html .= "</select>";
	return $html;
}

/*************************************
 method for making 31 DAYS combo box
 argument will be the selected day
 *************************************/

function daysCombo($day = ""){
	for ($i=1; $i<=31; $i++){
		if($i != $day){
			echo "<option value=".$i.">".$i."</option>";
		}
		else{
			echo "<option value=".$i." selected>".$i."</option>";
		}
	}
}

/**
 * print Options for selectbox for next 10 years
 * you have to write your own select tags, this will only print the <option>
 *
 * @param int $selyear
 */

function nxtyearsCombo($selyear){
	$currentyear = date("Y");
	$lastyear = date("Y") + 10;
	while($currentyear < $lastyear){
		if($currentyear != $selyear){
			echo "<option value=".$currentyear.">".$currentyear."</option>";
		}
		else{
			echo "<option value=".$currentyear." selected>".$currentyear."</option>";
		}
		$currentyear++;
	}
	 /*for ($i=currentyear; $i<(currentyear+10); $i++){
		if($i != $selyear){
			echo "<option value=".$i.">".$i."</option>";
		}
		else{
			echo "<option value=".$i." selected>".$i."</option>";
		}*/
}
	/*************************************************
	 method for making years combo box from 1940
	 to current year+1 perameter is selected year
	 *************************************************/

/**
 * 	method for making years combo box from specified year
 *  to current year+1
 *
 * @param int $selectYear : bydefault selected year
 * @param int $intFromYears
*/

function yearsCombo($selectYear = -1, $intFromYears = 1940){
	for ($i=$intFromYears; $i< date("Y")+1; $i++){
		if($i != $selectYear){
			echo "<option value=".$i.">".$i."</option>";
		}
		else{
			echo "<option value=".$i." selected>".$i."</option>";
		}
	}
}
/**
* method for making years combo box
*
* @param String $name : Combobox name
* @param int $intStart	: Starting Year
* @param int $intEnd	: Ending year
* @param int $selectYear : Selected year
*/

function yearsComboX($name, $intStart=0,$intEnd=0, $selectYear=0){
	$html = "";
	$html .= "<select name='$name' id='$name'>";
	$intCurrent = date("Y",time());
	if ($intStart == 0){
		$intStart = $intCurrent-5;
	}
	if ($intEnd == 0){
		$intEnd = $intCurrent;
	}
	if ($selectYear==0) {
		$selectYear=$intCurrent;
	}
	for ($i=$intStart; $i< $intEnd+1; $i++){
		if($i != $selectYear){
			$html .= "<option value=".$i.">".$i."</option>";
		}
		else{
			$html .= "<option value=".$i." selected>".$i."</option>";
		}
	}
	$html .= "</select>";
	return $html;
}

/**
 * Hide portion of the text (code)
 */
/*********************************/

function hideCode($intCount,$chrCode){
	$intLen = strlen(substr($chrCode,$intCount));
	return str_pad( substr($chrCode,0,$intCount)."-" ,10,"X");
}

/**
 * Custom select box control, checkbox enabled selection
 *
 * @param String $name : name of the control
 * @param String $arrKeyValue : multiple values to be displayed in the selectbox
 * @param String $selectoption	: Bydefault selected values
 * @param Boolean $blnCanEdit : checkboxes are readonly or not
 */

function mazSelectControl($name,$arrKeyValue,$selectoption=array(), $blnCanEdit = true, $blnBIG = false, $ovr_style = NULL, $display = "All"){
	# blnBIG chooses between small and large checkboxes. The Checkboxes are defined in customselect in media/css/absence_manager.css
	$chrDisabled =  ($blnCanEdit == true) ? "" : "disabled='disabled'";
	$myopt = "";
	$firstSelect = ($selectoption == null) ? " selected " : "";
	#<table cellpadding=\"0\" cellspacing=\"0\">
	$chrCustomSelect = " 
			
			<input type=\"checkbox\" name=\"{$name}_checkall\" id=\"{$name}_checkall\" __CHECKED-ALL-TRUE__ onclick=\"mazCustomSelectCheckUnCheck(this,'{$name}')\">".$display."</input>
		<div>";
			if ($blnBIG){		# If BIG is true a longer selsection box is chosen
				$chrCustomSelect .= "<div class=\"customselect2\" {$ovr_style}>\n";
			}
			else{
				$chrCustomSelect .= "<div class=\"customselect\" {$ovr_style}>\n";
			}
			if (sizeof($arrKeyValue) > 0 ){
				$count = 0;
				$blnCheckedAll = true;
				foreach($arrKeyValue as $key=>$value){
					if (is_array($selectoption) && in_array($key,$selectoption)){
						$myopt = "checked";
					}
					else{
						$myopt = "";
						$blnCheckedAll = false;
					}
					$chrCustomSelect.= '<input class="'.$name.'" name="'.$name.$count.'" id="'.$name.$count.'" '.$chrDisabled.' type="checkbox" '.$myopt.' value="'.$key.'" />'.$value."<br />\n";
					$firstSelect = "";
					$count++;
				}
			}
			$chrCustomSelect .= "<input type=\"hidden\" id=\"{$name}_count\" name=\"{$name}_count\" value=\"{$count}\" />
			</div>
		
	</div> \n";
	$chrCheckedAttribute = ($blnCheckedAll == true) ? "checked='checked'" : "";
	$chrCustomSelect = str_replace("__CHECKED-ALL-TRUE__",$chrCheckedAttribute,$chrCustomSelect);
	echo $chrCustomSelect;
}

function mazSelectControlSearch($name, $arrKeyValue,$selectoption=array(), $blnCanEdit = true, $blnBIG = false, $ovr_style = NULL, $display = "All"){
	# blnBIG chooses between small and large checkboxes. The Checkboxes are defined in customselect in media/css/absence_manager.css
	$chrDisabled =  ($blnCanEdit == true) ? "" : "disabled='disabled'";
	$myopt = "";
	$firstSelect = ($selectoption == null) ? " selected " : "";

	$divClass = "";
	if($blnBIG) {
		$divClass = "customselect2";
	} else {
		$divClass = "customselect";
	}
	$chrCustomSelect = " 
			
			<input type=\"text\" autocomplete=\"off\" name=\"{$name}_searchField\" id=\"{$name}_searchSelectBox\" onKeyUp=\"searchInSelectBox('"."{$name}_checkBoxArea"."','"."{$name}_searchSelectBox"."')\">
			<div>";

			$chrCustomSelect .= "<div class=\"$divClass\" id=\"{$name}_checkBoxArea\" {$ovr_style}>\n";
			if (sizeof($arrKeyValue) > 0 ){
				$count = 0;
				$blnCheckedAll = true;
				foreach($arrKeyValue as $key=>$value){
					if (is_array($selectoption) && in_array($key,$selectoption)){
						$myopt = "checked";
					}
					else{
						$myopt = "";
						$blnCheckedAll = false;
					}
					$chrCustomSelect.= '<div id="'.$key.'"><input class="'.$name.'" name="'.$name.$count.'" id="'.$name.$count.'" '.$chrDisabled.' type="checkbox" '.$myopt.' value="'.$key.'" />'.$value."<br />\n</div>";
					$firstSelect = "";
					$count++;
				}
			}
			$chrCustomSelect .= "				
			</div>
			<input type=\"hidden\" id=\"{$name}_count\" name=\"{$name}_count\" value=\"{$count}\" />
			<input type=\"button\" onClick=\"uncheckAll('".$name."');\" value=\"Uncheck All\" class=\"clearCheckBoxesBtn\">	
		
	</div> \n";
	$chrCheckedAttribute = ($blnCheckedAll == true) ? "checked='checked'" : "";
	$chrCustomSelect = str_replace("__CHECKED-ALL-TRUE__",$chrCheckedAttribute,$chrCustomSelect);
	echo $chrCustomSelect;
}