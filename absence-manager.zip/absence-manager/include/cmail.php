<?php
	include_once("include/user.php");#MAILTASK: this inclusion can be removed when testing has stopped.
/**
 * This calss is responisble for sending emails
 *
 */
	class cMail
	{
		private $errorMessage;

		/**
		 * Constructor of cMail
		 *
		 * @return cMail
		 */
		function cMail(){
			$this->errorMessage = "";
		}
		/**
		 * This function will retrun the last error occured while send an email
		 *
		 * @return String
		 */
		function getLastError(){
			return $this->errorMessage;
		}

		/**
		 * This function will Send Email to the user
		 *
		 * @param String $chrTo
		 * @param String $chrFrom
		 * @param String $chrSubject
		 * @param String $chrBody
		 * @return Boolean : success or failure
		 */
		function sendEmail($chrTo, $chrFrom, $chrSubject, $chrBody, $objSession){
				if (!$chrTo){
					$this->errorMessage = "No recipeient specified";
					return false;
				}
				else if (!$chrFrom){
						$this->errorMessage = "From not specified";
						return false;
				}
				else if (!$chrSubject){
						$this->errorMessage = "Error: subject not specified";
						return false;
				}
				else if (!$chrBody){
						$this->errorMessage = "Error: body not specified";
						return false;
				}


				// To send HTML mail, the Content-type header must be set
				$headers = "MIME-Version: 1.0" . "\n";
				$headers .= "Content-type:text/html;charset=utf-8" . "\n";

				$headers .= "From: no-reply@absencemanager.internal.ericsson.com " . "\n";


				// Additional headers
				$headers .= $chrFrom . "\r\n";
				// Mail it
				$this->saveMail($chrTo, $chrSubject, safeDatabase($chrBody), $headers, $objSession); #MAILTASK: comment this line out 						
				$chrBody = "<html><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
								<body>
									<p>$chrBody</p>
								</body>
							</html>";
						
				$blnSent = @mail($chrTo, $chrSubject, $chrBody, $headers); #MAILTASK:renenable this
				#$blnSent = $this->fakeMail($chrTo, $chrSubject, $chrBody, $headers); #MAILTASK: remove this
				if ($blnSent == false){					
					$this->errorMessage = "Warning: Email can not be sent";
					//echo "Mail Sending Function Failed"."<a href='https://absencemanager-uat.internal.ericsson.com'>Click Here to GO Home Page</a>"; exit;
				}
				else{
					//echo "Mail Sent Successfully"."<a href='https://absencemanager-uat.internal.ericsson.com'>Click Here to GO Home Page</a>"; exit;
				}
					
				return $blnSent;
		}
		/*** ########################################################
		*	This function will Save Email for testing only
		*	inorder to disable saving option, comment line # 52 in above function
		*	$this->saveMail
		*/
		/**
		 * This function will Save Email for testing only,
		 * inorder to disable saving option,
		 * comment line # 52 in above function $this->saveMail
		 *
		 * @param String $chrTo
		 * @param String $chrSubject
		 * @param String $chrBody
		 * @param String $headers
		 */
		#MAILTASK: remove function
		function fakeMail ($to, $subject, $message, $additional_headers = null, $additional_parameters = null) {
			echo "____Fakemail!____";
			#display($_SERVER);
			echo "<p>To: $to</p>";
			echo "Subject______________________________________________";
			echo "<p>$subject</p>";
			echo "Message______________________________________________";
			echo "<p>$message</p>";
			echo "_________________________________/Message____________";
			echo "<p>AH: $additional_headers</p>";
			echo "<p>AP: $additional_parameters</p>";
			exit();
		}
		#MAILTASK: comment this function out when testing is done		
		function saveMail($chrTo, $chrSubject, $chrBody, $headers, $objSession){
			$safeName = safeDatabase($objSession->getFullName());
			$safeSubject = safeDatabase($chrSubject);
			$safeBody = safeDatabase($chrBody);
			$safeHeaders = safeDatabase($headers);
			$chrQuery = "INSERT INTO tmp_sent_email_log(chrto,chrfrom,chrsubject,chrbody,chrheader,intdate) values ('$chrTo', '$safeName', '$safeSubject', '$safeBody', '$safeHeaders', ".time().")";
			#echo $chrQuery . "SLUT";
			mazDb_query_params($chrQuery, array());
		}

		/**
		 * This function will generate mail content and send it
		 *
		 * @param String $chrDaysApplied
		 * @param String $objSession
		 * @param String $arrSettings
		 * @param String $chrMessage
		 */
		
		function explodeAppliedDays($chrDaysApplied, $datesModified){
			$arrParam = explode("===_===",$chrDaysApplied);
			$arrDays = array();
			$arrDays["fromMonth"] = 12;
			$arrDays["toMonth"]=0;
			$arrDays["fromYear"]=99999;
			$arrDays["toYear"]=0;

			if($datesModified) {
				$arrDays["fromMonth"] = $datesModified[0]["month"];
				$arrDays["toMonth"] = $datesModified[count($datesModified)-1]["month"];
				$arrDays["fromYear"] = $datesModified[0]["year"];
				$arrDays["toYear"] = $datesModified[count($datesModified)-1]["year"];
			} else {
				foreach($arrParam as $eachRec){
				if ($eachRec){
					# seprate marked days (as clear days) information , from single day param
						$arrDay = explode("-_-",$eachRec);
						if($arrDay[1] < $arrDays["fromMonth"]){
							$arrDays["fromMonth"] = $arrDay[1];
						}
						if($arrDay[1] > $arrDays["toMonth"]) {
							$arrDays["toMonth"] = $arrDay[1];
						}
						if($arrDay[2] < $arrDays["fromYear"]) {
							$arrDays["fromYear"] = $arrDay[2];
						}
						if($arrDay[2] > $arrDays["toYear"]){
							$arrDays["toYear"] = $arrDay[2];
						}
					}
				}
			}
			return $arrDays;
		}
		/**
		* sends a mail to user if manager clears
		**/
		function sendClearMailToUser($objSession, $arrUserDays, $idUser) {
			$objMail = new cMail();
			$tmpUserArray[] = $idUser;
			$arrEmails = getEmailFromLoginId($tmpUserArray);
			$arrUsersEmailSettings  = getUsersBulkEmailSettings($tmpUserArray);
			$arrDepartmentsUsed = array();
			foreach($arrUsersEmailSettings as $idSelectedUser=>$arrHisSettings){
				$arrDepartmentsUsed[$arrHisSettings["department"]] = $arrHisSettings["department"];
			}
			#get these departments email settings that need to be sent to the user
			$arrDepartmentEmailSettings = getDepartmentBulkMailSettings($arrDepartmentsUsed);
				if ($arrUsersEmailSettings[$idUser]["blnResponse"] == true){
					$chrTo = $arrEmails[$idUser]["name"]." <".$arrEmails[$idUser]["email"].">";
					$chrSubject = "Absence Manager - Item Updated (". safeDatabase($objSession->getFullName()).")";
					# append mail body as per his department email settings
					$chrBody = "<pre>"."Your absence item has been cleared"."</pre>";
					# append what days approved with comments etc
					$chrBody .= "<br>\n".$arrUserDays;
					$chrFrom = "FROM : ".safeDatabase($objSession->getFullName())." <".$objSession->getEmailAddress().">";
					$blnSent = $objMail->sendEmail($chrTo,$chrFrom,$chrSubject,$chrBody,$objSession);
					if ($blnSent != true){
						$chrMessage = "Some of the mails could not be sent, ".$objMail->getLastError();
					}
				}
		}
		/**
		 * Creates a link to the calendar belonging to the requesting user's department
		 **/
		
		function createCalendarLink($objSession, $dept = null, $datesModified = null){			
			if(!$dept) {
				$chrDepartment = "{$objSession->getDepartment()}";
			} else {
				$chrDepartment = $dept;
			}
			$arrDates = $this->explodeAppliedDays($_REQUEST['chrParam'], $datesModified);
			$fromMonth = $arrDates["fromMonth"];
			$intYear = $arrDates["fromYear"];
			//$endDate = end($arrDates);
			$toMonth = $arrDates["toMonth"];
			$intYear2 = $arrDates["toYear"];			
			$host = $_SERVER['HTTP_HOST'];
			$target = $_SERVER['SCRIPT_NAME'];
			$arrParams = array(	"chrDepartment"=>$chrDepartment, 
						"fromMonth"=>$fromMonth, 
						"toMonth"=>$toMonth, 
						"intYear"=>$intYear, 
						"intYear2"=>$intYear2);		
			$chrParams = http_build_query($arrParams);
			$target = str_replace(array("index","view_project_calendar"), "view_calendar", $target);#replaces index.php with view_calendar.php 
			$href = "https://{$host}{$target}?$chrParams";
			$link = "<a href=\"".$href."\" target=\"_blank\">Calendar</a>";
			return $link;
		}

		/**
		 * Creates a link for the approval of the latest leave-request 
		 **/		
		function createApprovalLink($objSession, $datesModified) {
			$host = $_SERVER['HTTP_HOST'];
			$target = $_SERVER['SCRIPT_NAME'];
			$days = explode("===_===",$_REQUEST["chrParam"]);

			$linkdata = '';

			 #outlook has a 'feature' that inserts a newline and a space in urls longer than somewhere around 990 characters.
			 #if a user applies for approx 9 weeks of vacancy in one application, the url created below will become too
			 #long and days will be missed if the vacation is approved through the email.
			if($datesModified){
				foreach($datesModified as $eachRec){#for every day off requested
				 	if ($eachRec){
				 		if($eachRec["chrCharacter"] != "D" && $eachRec["chrCharacter"] != "A"){
					 		/*$linkdata .= $eachRec["day"] . '�';
					 		$linkdata .= $eachRec["month"] . '�';
					 		$linkdata .= $eachRec["year"] . '�';*/
							$linkdata .= $eachRec["day"] . '~';
					 		$linkdata .= $eachRec["month"] . '~';
					 		$linkdata .= $eachRec["year"] . '~';
					 		$linkdata .= $eachRec["chrCharacter"];
					 	}
				 	}
				 	$linkdata .= '|';
				}
			} else {
				foreach($days as $eachRec){#for every day off requested
					if ($eachRec){
						$arrDay = explode("-_-",$eachRec);
						/*$linkdata .= $arrDay[0] . '�';
						$linkdata .= $arrDay[1] . '�';
						$linkdata .= $arrDay[2] . '�';*/
						$linkdata .= $eachRec["day"] . '~';
						$linkdata .= $eachRec["month"] . '~';
						$linkdata .= $eachRec["year"] . '~';
						$linkdata .= $arrDay[3];
					}
					$linkdata .= '|';
				}
			}
			$arrParams = array(	"chrAction"=>"mail_approve", 
								"idUser"=>$objSession->getIdUser(), 
								"chrParam"=>$linkdata,
								"chrDepartment"=>$objSession->getDepartment());
			$chrParams = http_build_query($arrParams);
			$href = "https://{$host}{$target}?$chrParams";
			$href = "https://{$host}{$target}?$chrParams";
			$link = "<a href=\"".$href."\" target=\"_blank\">Approve entire request</a>";

			return $link;
		}
		
		function prepareAndSendMail($chrDaysApplied, $objSession, $arrSettings, $chrMessage, $datesModified = null){
			#Check that at least one day has been marked
			if ($chrDaysApplied != ""){
				# if mails are required by user settings
				#$arrSettings["blnEmailRequired"] = true; #MAILTASK: remove when testing has finished
	
				if ($arrSettings["blnEmailRequired"] == true){
					$mixManagers = getUserManager($objSession->getUid());

					#Check if user is part of system
					if (sizeof($mixManagers) > 0) {
						
						//Prepare message with links
						$chrApprovalLink = $this->createApprovalLink($objSession, $datesModified);
						$chrCalendarLink = $this->createCalendarLink($objSession);
						
						$chrFromName = $objSession->getFullName()." ({$objSession->getUid()})";
						if ($chrFromName == " ()") {
							$chrFromName = 'Someone';
						}
						$chrComment = safeDatabase("Kommentar");
						$chrMessage = "<P>Absence Request from <b>$chrFromName:</b></P>";
						$chrMessage .= "<P>$chrDaysApplied</P>";
						$chrMessage .= "<pre>$chrApprovalLink \r\nor visit the $chrCalendarLink</pre>";

						//If there are managers for the users department, send email to them
						if (sizeof($mixManagers) > 0 && $mixManagers != NOTICE_NO_DEPARTMENT_MANAGER) {

							$chrTo = "";
							foreach($mixManagers as $chrEmail=>$chrName){
								$chrTo .= "$chrName <{$chrEmail}> ,";
							}
							$chrTo = trim($chrTo,",");
							# Send email to those managers from me
							$chrFrom = "FROM : ".$objSession->getFullName()." <".$objSession->getEmailAddress().">";
							$blnSent = $this->sendEmail($chrTo,$chrFrom,"Absence Manager - User request (".$objSession->getFullName().")",$chrMessage, $objSession);

							if ($blnSent != true){
								$chrMessage = $this->getLastError();
							}
						}					
					}
					
				}
				
				else {
					# if auto approved option is set for current logged in user department by his manager, and manager has also set the option email not requierd
					if ($arrSettings["blnAutoApprove"] == 1  && $arrSettings["blnEmailRequired"] == 0){
						$chrMessage = "Auto approved. Email not sent to Manager. Check email for details";
					}
					else{
						$chrMessage = "Email not sent to Manager. Check your email for details";
					}
				}
				# load currently logged in user email settings
				$arrUserSettings = getUserOwnEmailSettings( $objSession->getIdUser() );

				#if user require confirmation
				if ($arrUserSettings["blnConfirmation"] == true){

					$chrCalendarLink = $this->createCalendarLink($objSession);
					
					$chrFromName = safeDatabase($objSession->getFullName())." ({$objSession->getUid()})";
					if ($chrFromName == " ()")  $chrFromName = 'Someone';						
					
					$chrComment = safeDatabase("Kommentar");#get this comment from user input
						
					$chrMessage = "<P><h3>Absence Request:</h3></P> </P>from $chrFromName:</P>";
					$chrMessage .= "<P>$chrDaysApplied</P>";
					#$chrMessage .= "<P><B>User comment:</B> $chrComment</P>";
					$chrMessage .= "<P>Visit $chrCalendarLink</P>";
					
					$blnSent = $this->sendEmail($objSession->getEmailAddress(),"FROM: Absence Manager <no-reply@absencemanager.internal.ericsson.com>","Absence Manager - Request Confirmation","<pre>".$arrSettings["chrConfirmationMsg"]."</pre>"."\n".$chrMessage,$objSession);
					if ($arrUserSettings["blnResponse"] == false){
						$chrMessage = "As you have not subscribed for response you will not receive approval notification email";
					}
				}
				else {
					$chrMessage = "As you have not subscribed for confirmation you will not receive an email";
					if ($arrUserSettings["blnResponse"] == false){
						$chrMessage = "As you have not subscribed for confirmation or response you will not receive confirmation email or approval notification email";
					}

				}
			}
			return $chrMessage;
		}
	}

	//This fuction sends absence request to the users legal manager (If he has those settings)
	function sendRequestToLegalManager($objSession, $daysModified, $chrBody, $fromMyCal = false) {		
		$user_id = $objSession->getUid();				
		$objMail2 = new cMail();			
		$legalManager = getUserLegalManagerEmail($objSession->getUid());
		
		//If legal manager has set that he/she wants email, send mail
		if($legalManager) {
			$chrManagerName = $legalManager["name"];
			$chrManagerEmail = $legalManager["email"];	
			$chrTo .= "$chrManagerName <{$chrManagerEmail}>";
			# Send email to those managers from me
			$chrFrom = "FROM : ".$objSession->getFullName()." <".$objSession->getEmailAddress().">";	

			#$chrFromName = safeDatabase($objSession->getFullName())." ({$objSession->getUid()})";
			$chrFromName = $objSession->getFullName()." ({$objSession->getUid()})";
			if ($chrFromName == " ()")  $chrFromName = 'Someone';						
			
			#TODO: Get the user's comment from input somewhere, is any other comment than the ones used for
			#activate the comment in the mail 4 rows below. 
			//$chrComment = safeDatabase("Kommentar");
			$eMessage = "<P>Request from $chrFromName:</P>";
			if(!$fromMyCal) {
				$chrApprovalLink = $objMail2->createApprovalLink($objSession, $daysModified[$objSession->getIdUser()]);
				$chrCalendarLink = $objMail2->createCalendarLink($objSession, null, $daysModified[$objSession->getIdUser()]);
				$eMessage .= "<P>$chrBody</P>";
				$eMessage .= "<pre><br>$chrApprovalLink \r\nor visit $chrCalendarLink</pre>";
			} else {
				$eMessage = $chrBody;

			}		
			$blnSent = $objMail2->sendEmail($chrTo,$chrFrom,"Absence Manager - User request (".$objSession->getFullName().")",$eMessage, $objSession);			
			if ($blnSent != true){
				return false;						
			}
		}
		return false;
	}
?>
