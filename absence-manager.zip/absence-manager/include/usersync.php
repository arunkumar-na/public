<?php
	/**
	 * syncs the users in the current department from LDAP to keep information updated.
	 */
	function syncUsers($department, $isImport = false){
		$chrMessage = "";
		$chrMessageCount = 0;
		#updates $department to contain current AM-data
		$arrLocalUsersData = $department->getUsersComplete();#gets all users DATA from AM
		$arrLocalMAO = $department->getManagersAndOwners(); #gets all Managers and Owners OBJECTS from AM
		
		foreach ($arrLocalMAO as $localMAOUser){#update managers and owners if necessary
			$arrLocalMAOData = getUserComplete($localMAOUser->getUserID());
			$arrLDAPMAOData = import_from_ldap("(uid=$arrLocalMAOData[uid])", "getusers", true);
			foreach ($arrLDAPMAOData as $dept => $usr) { #reduces unnecessary strucure within the LDAPgenerated-array
				$d = $usr;
			}
			$arrLDAPMAOData = $d[0];
			$blnExternal = ($arrLDAPMAOData['relationship'] == 'X')? true : false;
			
			$blnInternalUpdateCriteria = $arrLocalMAOData['dn'] == $arrLDAPMAOData['dn'] &&
			 	$arrLocalMAOData['name'] == $arrLDAPMAOData['name'] &&
			 	$arrLocalMAOData['department'] == $arrLDAPMAOData['department'] &&
 				$arrLocalMAOData['city'] == $arrLDAPMAOData['city'] &&
 				$arrLocalMAOData['erelation'] == $arrLDAPMAOData['relationship'] &&
 				$arrLocalMAOData['phone'] == $arrLDAPMAOData['phone'] &&
 				trim($arrLocalMAOData['title'], " ") == $arrLDAPMAOData['title'] && 
 				trim($arrLocalMAOData['email'], " ") == $arrLDAPMAOData['mail'] &&
 				$arrLocalMAOData['uid'] == $arrLDAPMAOData['uid'] &&
 				$arrLocalMAOData['legalManager'] == $arrLDAPMAOData['legalManager'] &&
 				$arrLocalMAOData['isLegalManager'] == $arrLDAPMAOData['isLegalManager'] &&
 				$arrLocalMAOData['mdept'] == $arrLDAPMAOData['mdept'] &&
 				$arrLocalMAOData['sdept'] == $arrLDAPMAOData['sdept'];
			#for external users, department does differ, so dont check that. 
 			$blnExternalUpdateCriteria = $arrLocalMAOData['dn'] == $arrLDAPMAOData['dn'] &&
			 	$arrLocalMAOData['name'] == $arrLDAPMAOData['name'] &&
			 	#$arrLocalMAOData['department'] == $arrLDAPUserData[$arrLocalUserData[department]][0]['department'] &&
 				$arrLocalMAOData['city'] == $arrLDAPMAOData['city'] &&
 				$arrLocalMAOData['erelation'] == $arrLDAPMAOData['relationship'] &&
 				$arrLocalMAOData['phone'] == $arrLDAPMAOData['phone'] &&
 				trim($arrLocalMAOData['title'], " ") == $arrLDAPMAOData['title'] && 
 				trim($arrLocalMAOData['email'], " ") == $arrLDAPMAOData['mail'] &&
 				$arrLocalMAOData['uid'] == $arrLDAPMAOData['uid'] &&
 				$arrLocalMAOData['legalManager'] == $arrLDAPMAOData['legalManager'] &&
 				$arrLocalMAOData['isLegalManager'] == $arrLDAPMAOData['isLegalManager'] &&
 				$arrLocalMAOData['mdept'] == $arrLDAPMAOData['mdept'] &&
 				$arrLocalMAOData['sdept'] == $arrLDAPMAOData['sdept'];
 			
 				$blnUpdateCriteria = ($blnExternal) ? $blnExternalUpdateCriteria : $blnInternalUpdateCriteria;
			
			if ($blnUpdateCriteria){
 					$chrMessage = 'No update necessary'; #will be overwritten later on so acts mostly informative..
			}else{
				$localMAOUser->syncUser($localMAOUser->isExternal());	
				$chrMessageCount++;	
			}
		} #END #update managers and owners if necessary
		
		foreach ($arrLocalUsersData as $arrLocalUserData) {#update all users existing in $department in AM
			$uid = $arrLocalUserData['uid'];
		
			$arrLDAPUserData = import_from_ldap("(uid=$uid)", "getusers", true);
			$blnExternal = ($arrLocalUserData['erelation'] == 'X')? true : false;			
			
			$userDept = "";
			foreach ($arrLDAPUserData as $dept => $usr) {#the returned array from LDAP has the department as root node, so need to descend into that first
				$userDept = $dept;
				$userData= $usr;
			}
			$arrLDAPUserData = $userData[0]; #the array only contains one post since the uid is unique
			$blnInternalUpdateCriteria = $arrLocalUserData['dn'] == $arrLDAPUserData['dn'] &&
			 	$arrLocalUserData['name'] == $arrLDAPUserData['name'] &&
			 	$arrLocalUserData['department'] == $arrLDAPUserData['department'] &&
 				$arrLocalUserData['city'] == $arrLDAPUserData['city'] &&
 				$arrLocalUserData['erelation'] == $arrLDAPUserData['relationship'] &&
 				$arrLocalUserData['phone'] == $arrLDAPUserData['phone'] &&
 				trim($arrLocalUserData['title'], " ") == $arrLDAPUserData['title'] && 
 				trim($arrLocalUserData['email'], " ") == $arrLDAPUserData['mail'] &&
 				$arrLocalUserData['uid'] == $arrLDAPUserData['uid'] &&
 				$arrLocalUserData['legalManager'] == $arrLDAPUserData['legalManager'] &&
 				$arrLocalUserData['isLegalManager'] == $arrLDAPUserData['isLegalManager'] &&
 				$arrLocalUserData['mdept'] == $arrLDAPUserData['mdept'] &&
 				$arrLocalUserData['sdept'] == $arrLDAPUserData['sdept'];

 			$blnExternalUpdateCriteria = $arrLocalUserData['dn'] == $arrLDAPUserData['dn'] &&
			 	$arrLocalUserData['name'] == $arrLDAPUserData['name'] &&
			 	#$arrLocalUserData['department'] == $arrLDAPUserData[$arrLocalUserData[department]][0]['department'] &&
 				$arrLocalUserData['city'] == $arrLDAPUserData['city'] &&
 				$arrLocalUserData['erelation'] == $arrLDAPUserData['relationship'] &&
 				$arrLocalUserData['phone'] == $arrLDAPUserData['phone'] &&
 				trim($arrLocalUserData['title'], " ") == $arrLDAPUserData['title'] && 
 				trim($arrLocalUserData['email'], " ") == $arrLDAPUserData['mail'] &&
 				$arrLocalUserData['uid'] == $arrLDAPUserData['uid'] &&
 				$arrLocalUserData['legalManager'] == $arrLDAPUserData['legalManager'] &&
 				$arrLocalUserData['isLegalManager'] == $arrLDAPUserData['isLegalManager'] &&
 				$arrLocalUserData['mdept'] == $arrLDAPUserData['mdept'] &&
 				$arrLocalUserData['sdept'] == $arrLDAPUserData['sdept'];
 			
 				$blnUpdateCriteria = ($blnExternal) ? $blnExternalUpdateCriteria : $blnInternalUpdateCriteria;

 			#Set the users legal manager as owner manager for the department
 			if(/*$isImport &&*/ $arrLDAPUserData['isLegalManager'] == 'f' && !$blnExternal && $arrLDAPUserData['legalManager']){
 				$department->setOwnerByUid($arrLDAPUserData['legalManager'], true); 				
 			}


			#for all regular users: that is users that according to AM belongs to $department
			if ($blnUpdateCriteria){
				$chrMessage = 'All posts already up to date. No updates necessary.';
 			}
			else{
				$user = getUserByName($uid);
				$visible = $user->isVisible();
				if($arrLocalUserData['department'] != $arrLDAPUserData['department'] && $user->isExternal() == false){#if internal user has changed departments,reset visibility
					$visible = true;
				}
				$user->syncUser($blnExternal, $visible); #sync user in line with rules set by external and visible-flags
				$chrMessageCount++;
			}
		}#END #update all users existing in $department in AM		

		#all users that belong to the department according to LDAP, 
		#but not according to AM, i.e. switched to this department or users in a newly created department

		/******************added by offshore************/
		$chrSearch = "{$department->getName()}";
		$chrAction = "getusers"; 
		$blnExtended = false;

		$justthese = array(LDAP_DN, LDAP_FIRST_NAME, LDAP_LAST_NAME, LDAP_DEPARTMENTNUMBER, LDAP_CITY, LDAP_RELATION_FIELD, LDAP_TELEPHONENUMBER, LDAP_JOB_TITLE, LDAP_EMAIL, LDAP_DISPLAY_NAME, LDAP_USER_ID, LDAP_OU, LDAP_XDISPLAY_NAME, LDAP_XDEPARTMENTNUMBER, LDAP_MANAGERSIGNUM, LDAP_ISLEGALMANAGER);
		$justthese = array();
		$ds=ldap_connect(LDAP_ADDRESS,LDAP_PORT) or die("Unable to connect LDAP"); // must be a valid LDAP server!
		$arrResult = array();
		if ($ds){
		$bd = ldap_bind($ds,LDAP_CONNECT_USERNAME,LDAP_CONNECT_PASSWORD) or die("Couldn't bind to AD!");
		

		$filter = sprintf(LDAP_DEPARTMENT_FILTER, "$chrSearch");
		
		if ($blnExtended == true){
			$filter = $chrSearch;
		}
		
		
		#Search in ECD
		$sr = ldap_search_with_correct_base_dn($ds, $filter, $justthese);
		
		$arrData = ldap_get_entries($ds, $sr);
		#echo 'array:'.$arrData["count"];		
		
		for($i = 0; $i < $arrData["count"] ; $i++){
			$external = ($arrData[$i][LDAP_RELATION_FIELD][0] != 'E' ? true : false);
			if ($external){
				$name = $arrData[$i][LDAP_XDISPLAY_NAME][0];
				$dept = $arrData[$i][LDAP_XDEPARTMENTNUMBER][0];
			}
			else {
				$name = $arrData[$i][LDAP_DISPLAY_NAME][0];
				$dept = $arrData[$i][LDAP_DEPARTMENTNUMBER][0];
			}
			
			if ($name != "" && $arrData[$i][LDAP_EMAIL][0] != "" && ($external || $arrData[$i][LDAP_JOB_TITLE][0] != "")){
				$arrDept = explode("/",$dept);
				if ($chrAction == "getusers" || ($chrAction == "section_users")){
					$arrResultRec["dn"] =  $arrData[$i][LDAP_DN][0];
					$arrResultRec["name"] =  $name;
					$arrResultRec["department"] =  $dept;
					$arrResultRec["city"] =  $arrData[$i][LDAP_CITY][0];
					$arrResultRec["relationship"] =  $arrData[$i][LDAP_RELATION_FIELD][0];
					$arrResultRec["phone"] =  $arrData[$i][LDAP_TELEPHONENUMBER][0];
					$arrResultRec["title"] =  $arrData[$i][LDAP_JOB_TITLE][0];
					$arrResultRec["mail"] =  $arrData[$i][LDAP_EMAIL][0];
					$arrResultRec["uid"] =  $arrData[$i][LDAP_USER_ID][0];
					$arrResultRec["legalManager"] = $arrData[$i][LDAP_MANAGERSIGNUM][0];
					$arrResultRec["isLegalManager"] = ($arrData[$i][LDAP_ISLEGALMANAGER][0] == "Y" ? "t" : "f" );
					$arrResultRec["mdept"] =  $arrDept[0];

					if (count($arrDept) > 1){
						$arrResultRec["sdept"] =  $arrDept[1];
					}
					else {
						$arrResultRec["sdept"] = "";
					}
					$arrResult[$dept][] = $arrResultRec;
				}
				else if ($chrAction == "getsections"){
				#if (strtolower($arrDept[0]) == strtolower($chrSearch) && ($external || $arrDept[1])){
					if ($external == false){
						$arrResult[$dept] = array();
					}
				}
			}
			}#endforeach
		}#end ds
		/***************OFFSHORE *********/
		$arrLDAPUsersData = $arrResult; #import_from_ldap_oudata("(departmentNumber={$department->getName()})", "getusers", true); #get all users that belong to department in LDAP
		foreach ($arrLDAPUsersData as $arrLDAPUsersDept) {	#this is done for all LDAPdepartments that contain users within this LOCALdepartment
			foreach ($arrLDAPUsersDept as $arrLDAPUserData){#for each user within this department
				$uid = $arrLDAPUserData[uid]; #extract user uid for later use			
				$user = getUserByName($uid); #get a handle for the actual user
				if ($user != NULL){ #if user exists, update needs to be done, so create new query for update
					$arrLocalUserData = getUserComplete($uid); #collecting local data for comparison
					$blnExternal = ($arrLocalUserData['erelation'] == 'X')? true : false;

		 			$blnUpdateCriteria = $arrLocalUserData['dn'] == $arrLDAPUserData['dn'] &&
					 	$arrLocalUserData['name'] == $arrLDAPUserData['name'] &&
					 	$arrLocalUserData['department'] == $department->getName() && #note the deviating comparator
		 				$arrLocalUserData['city'] == $arrLDAPUserData['city'] &&
		 				$arrLocalUserData['erelation'] == $arrLDAPUserData['relationship'] &&
		 				$arrLocalUserData['phone'] == $arrLDAPUserData['phone'] &&
		 				trim($arrLocalUserData['title'], " ") == $arrLDAPUserData['title'] && 
		 				trim($arrLocalUserData['email'], " ") == $arrLDAPUserData['mail'] &&
		 				$arrLocalUserData['uid'] == $arrLDAPUserData['uid'] &&
		 				$arrLocalUserData['legalManager'] == $arrLDAPUserData['legalManager'] &&
		 				$arrLocalUserData['isLegalManager'] == $arrLDAPUserData['isLegalManager'] &&
		 				$arrLocalUserData['mdept'] == $arrLDAPUserData['mdept'] &&
		 				$arrLocalUserData['sdept'] == $arrLDAPUserData['sdept'];
	 			
					if($blnUpdateCriteria){#if all data is up to date
		 					$chrMessage = 'All posts already up to date. No updates necessary.';
		 			}
					else{#users needs updating, all LDAP-info is correct (hold the department)
						$user->syncUser($blnExternal);
						#since department data can be found in several places, setting the department is better done manually
						$department->claimUser($user);
						$chrMessageCount++;
	 				}
				}
				else {#user doesn't exist in AM
					$user = importUser($uid); #if imported, all data should be ok and updated
					$department->claimUser($user);
					$chrMessageCount++;
				}
			}	
		}
			
		if ($chrMessageCount > 0){
			$chrMessagePlural = " has";
			if ($chrMessageCount > 1) $chrMessagePlural = "s have";
			return "$chrMessageCount post$chrMessagePlural been updated with information from HRMS";
		} 
		else {
			return $chrMessage;
		}

		$department->save();
	}
