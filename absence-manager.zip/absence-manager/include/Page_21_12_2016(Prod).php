<?php

function generateTitle($subtitle){
	$title = "Absence Manager - ".$subtitle;
	return safeHTML($title);
}

function generateTopBar() {
	$db = $_SESSION['database'];
	$developer = $_SESSION['developer'];
	$topbar = "";
	
	
	if ($_SESSION['developer'] != ''){
		$topbar .= ('$db' == 'absencemanager') ? '<p class="debug">' : '<p>';
		$topbar .= '(developer=' . $developer . '/db=' . $db . ')</p>';
	}
	$topbar .= '<a id="adminLogin" href="admin_login.php">Admin Login</a>';
	return $topbar;
}

function generateHeader() {
	$html  = "<div id=\"container\"><div id=\"header\"><a href=\"\"><div id=\"logo\">&nbsp;</div></a><div id=\"pageHeading\">\n";
	$html .= '<div id="headingBody">'.generateTopBar()."</div>\n";
	$html .= "</div></div>\n";
	return $html;
}

function generateFooter() {
	$html = "";
	$html = "</div>";
	$html .= "<div id=\"footer\">\n";
	$html .= "<p>v. ".VERSION." &copy; Copyright Ericsson AB 2009. All rights reserved.</p>\n";
	$html .= "</div>\n";
	$html .= "<div id=\"pageBlock\" class=\"blayer\">\n";
	$html .= "<a href=\"javascript:unblockPage()\">Close</a>\n";
	$html .= "</div>\n";
	
	return $html;
}

function generateScripts(){
	$html  = "<link rel=\"stylesheet\" href=\"media/css/common_v1.0.8.css\" type=\"text/css\" />\n";
	$html .= "<link rel=\"stylesheet\" href=\"media/css/absence_manager_v1.0.8.css\" type=\"text/css\" />\n";
	$html .= "<link rel=\"stylesheet\" href=\"media/css/menu_v1.0.8.css\" type=\"text/css\" />\n";
	$html .= "<link rel=\"stylesheet\" href=\"media/css/form_v1.0.8.css\" type=\"text/css\" />\n";
	$html .= "<link rel=\"stylesheet\" href=\"media/css/icons.css\" type=\"text/css\" />\n";
	$html .= "<link rel=\"stylesheet\" href=\"media/css/calendar_v1.0.8.css\" type=\"text/css\" />\n";
	$html .= "<link rel=\"shortcut icon\" href=\"media/favicon.ico\" type=\"image/x-icon\" />\n";
	//$html .= "<script type=\"text/javascript\" src=\"media/js/jquery-1.5.min.js\" charset=\"UTF-8\"></script>\n";
	$html .= "<script type=\"text/javascript\" src=\"media/js/jquery-1.9.1.js\" charset=\"UTF-8\"></script>\n";
	$html .= "<script type=\"text/javascript\" src=\"media/js/jquery.metadata.js\" charset=\"UTF-8\"></script>\n";
	$html .= "<script type=\"text/javascript\" src=\"media/js/jquery.tablesorter.min.js\" charset=\"UTF-8\"></script>\n";
	$html .= "<script type=\"text/javascript\" src=\"media/js/jquery.sprintf.js\" charset=\"UTF-8\"></script>\n";
	$html .= "<script type=\"text/javascript\" src=\"media/js/common.js\" charset=\"UTF-8\"></script>\n";
	$html .= "<script type=\"text/javascript\" src=\"media/js/form.js\" charset=\"UTF-8\"></script>\n";
	$html .= "<script type=\"text/javascript\" src=\"media/js/search.js\" charset=\"UTF-8\"></script>\n";	
	$html .= "<script type=\"text/javascript\" src=\"media/js/calendar.js\" charset=\"UTF-8\"></script>\n";
	//$html .= "<script type=\"text/javascript\" src=\"media/js/jquery.tinyscrollbar.js\" charset=\"UTF-8\"></script>\n";

	$html .= "<!--[if lt IE 7.]>\n";
	$html .= "	<script defer type=\"text/javascript\" src=\"media/js/pngfix.js\"></script>\n";
	$html .= "<![endif]-->\n";
	return $html;
}

function printUserList($chrId, $arrUsers, $objDept, $blnEdit){
  $table  = '<table cellspacing="0" cellpadding="0" id="'.$chrId.'" class="userTable">';
  $table .= '	<thead><tr>';
  $table .= '		<th>Name</th>';
  $table .= '		<th>User-id</th>';
  if ($chrId == 'ownerTable'){
    $table .= '		<th>Owner</th>';
    $table .= '		<th>Manager</th>';
  }
  if ($chrId == 'userTable'){
    $table .= '		<th>Visible</th>';
  }
  $table .= '		<th>Remove</th>';
  $table .= '	</tr></thead>'; 
      $table .= '	<tbody>';
  if (!$blnEdit){
    $chrDisabled = 'disabled="disabled"';
  }
	if (count($arrUsers) > 0){
    foreach ($arrUsers as $user) {
      $userIsVisible = $user->isVisible();
      if ($userIsVisible || $blnEdit || $chrId == 'ownerTable'){
        $id = $user->getID();
        $uid = safeHTML($user->getUserID()); # eaaaaa
        $pf = safeHTML(sprintf(PEOPLE_FINDER_FORMAT, $user->getUserID()));
        $visible = ($userIsVisible) ? ' checked="checked"' : ''; #check this?
        $visibilitybox = '<input class="visibility" name="'.$chrId.'['.$id.'][visible]" type="checkbox" '.$chrDisabled.' '.$visible.'/>';
        if ((($user->isExternal()) && $blnEdit) || $chrId == 'ownerTable'){
          $visibilitybox = '';
        }		
        if ($chrId == 'ownerTable'){
          $owner = ($objDept->isOwner($id) ? ' checked="checked"' : '');
          $manager = ($objDept->isManager($id) ? ' checked="checked"' : '');
          $userIsVisible = TRUE;
        }
        $table .= '<tr class="userRow" id="'.$chrId.'_row_'.$id.'">';
        #name
        $table .= '<td><a class="newWindow" href="'.$pf.'">'.safeHTML($user->getFullName()).'</a></td>'; 
        #User-id & possible X-notation
        $table .= '<td class="fixedWidthUid"><a class="newWindow" href="'.$pf.'">'.$uid.'</a><input name="'.$chrId.'['.$id.'][uid]" value="'.$uid.'" type="hidden" />'.(($user->isExternal()) ? " (X)" : "" ).'</td>';
        #Owner & Manager-checkboxes
        if ($chrId == 'ownerTable'){
          $table .= '<td class="fixedWidth"><input name="'.$chrId.'['.$id.'][owner]" type="checkbox" '.$chrDisabled.' '.$owner.'/></td>';
          $table .= '<td class="fixedWidth"><input name="'.$chrId.'['.$id.'][manager]" type="checkbox" '.$chrDisabled.' '.$manager.'/></td>';
        }
        if (($chrId == 'userTable')){
          $table .= '<td class="fixedWidth">'.$visibilitybox.'</td>';
        }
        $table .= '<td class="fixedWidth"><input class="deleted" name="'.$chrId.'['.$id.'][deleted]" id="'.$chrId.'_deleted_'.$id.'" type="hidden" value="0" />';
        if ((($user->isExternal()) && $blnEdit) || ($chrId == 'ownerTable' && $blnEdit)) {#hide owners' trashbin (switch with next row to toggle)
          $table .= '<a href="javascript:deleteUser('.$id.',\''. $chrId .'\');" class="deleteIcon">&nbsp;</a>';
        }
        $table .= '</td>';
        $table .= "</tr>\n";
      }
    }
    $table .= '</tbody>';
    $table .= '</table>';
    return $table;
	} else {
      $table .= '<tr>
                  <td></td>
                  <td class="fixedWidthUid"></td>
                  <td class="fixedWidth"></td>
                  <td class="fixedWidth"></td>
                  <td class="fixedWidth"></td>
                  </tr>';
      $table .= '</tbody>';
      $table .= '</table>';
      return $table;
	}
}

?>
