<?php

	/*** ########################################################
	*	This function is used when qurery fails, this will show the
	*	query as well as line number/File from where that query was issued
	*____________________________________________________________*/
	function dbError($chrQuery)
	{
		$info  = debug_backtrace();
		echo "<b>Query Failed<b> <br>".$chrQuery."<br>";
		echo "<br>Line # ".$info[1]["line"]." <b>".$info[1]["file"]."</b><br>";

		if (DEVELOPER == 1){
			exit();
		}
	}
	/*** ########################################################
	*	For Database Connection (Generic function)
	*	Can alter this function to provide support for MYSQL etc
	*____________________________________________________________*/
	function mazDb_connect($dbServer,$dbUser,$dbPassword,$dbDatabase){
		$chrConnectionString = "host=$dbServer port=5432 dbname=$dbDatabase user=$dbUser password=$dbPassword";
		$dbconn3 = pg_connect($chrConnectionString) or die("unable to connect");
	}

	/*** ########################################################
	*	For Database Query (Generic function)
	*	Can alter this function to provide support for MYSQL etc
	*____________________________________________________________*/
	function mazDb_query($chrQuery){
		$result = pg_query($chrQuery) or (dbError($chrQuery));

		trigger_error($chrQuery, E_USER_WARNING);
		trigger_error("Use mazDb_query_params instead of mazDb_query", E_USER_WARNING);
		return $result;
	}

	/*** ########################################################
	*	For Database Query with parameters (Generic function)
	*	Can alter this function to provide support for MYSQL etc
	*____________________________________________________________*/
	#changed input value to a safeDatabase-modded input..
	function mazDb_query_params($chrQuery, $arrParams){
		foreach ($arrParams as &$param){
			$param = safeDatabase($param);
		}
		$result = pg_query_params($chrQuery, $arrParams) or dbError($chrQuery);
		unset($param);#to break the reference between $param and $arrParams
		return $result;
	}

	/*** ########################################################
	*	Fetch Array (Generic function)
	*	Can alter this function to provide support for MYSQL etc
	*____________________________________________________________*/
	#changed return value to a safeHTML-modded result..
	function mazDb_fetch_array($input){
		$result = pg_fetch_array($input);
		#foreach ($result as &$resultItem){
			#$resultItem = safeHTML($resultItem);
		#}
		#unset($resultItem);#to break the reference between $resultItem and $result
		return $result;
	}
	

	/*** ########################################################
	*	return number of rows (Generic function)
	*	Can alter this function to provide support for MYSQL etc
	*____________________________________________________________*/
	function mazDb_num_rows($result){
		return pg_num_rows($result);
	}

	/*** ########################################################
	*	Retrives the next sequence number by passed (Generic function)
	*	Can alter this function to provide support for XXX etc
	*____________________________________________________________*/
	function getNextNumber($chrSequenceName){
		$chrQuery = "SELECT nextval('$chrSequenceName') as idnext";
		$rs = mazDb_query_params($chrQuery, array());#recently changed, tisdag
		if (mazDb_num_rows($rs)){
			$arr = mazDb_fetch_array($rs);
			return $arr["idnext"];
		}
		return -1;
	}
?>
