<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");
	include_once("include/template.php");
	include_once("include/cmail.php");
	
	/** Create session object and try to load user info (id name etc from session) **/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
		exit();
	}

	#get user rights for projects
	$arrRights = getProjectRights($objSession->getUid());

	# get user rights for departments
	$arrDepartmentRights = getDepartmentRights($objSession->getUid());

	#get projects from db
	$arrProjs = get_projects_from_db();
	ksort($arrProjs);

	$settings = getProjectSettings($objSession->getIdUser(),$objSession->getUid());
	$arrProjsFromDB = $settings["proj"];

	$arrSearchProjs = array();
	if (!isset($_REQUEST["chrAction"]) || $_REQUEST["chrAction"] == "direct"){ #on entry, the settings are applied and the suggested departments are shown
		$arrSearchProjs = $arrProjsFromDB;
	}

	if ($_REQUEST["chrAction"] == "save_days"){
		# split marked days(might be for approval) from single string to into array of days
		$arrParam = explode("===_===",$_POST["chrParam"]);
		
		//Save user days in db and return array with info regarding the saving
		$saveDaysResult = saveUserDays($arrParam, $objSession, $arrDepartmentRights);
		$arrUserDaysApproved = $saveDaysResult['arrUserDaysApproved'];
		$daysModified = $saveDaysResult['daysModified'];
		$userIsManager = $saveDaysResult['isManager'];

		if (sizeof($arrUserDaysApproved) > 0){
			/* 
			For email sent to the User whose days has been clicked. 
			If a manager is accessing then the email goes to the members whose days are selected. And if a non-manager is accesssing the mail goes to that non-manager as he can't select anyone else days, but only his days.
			*/
			$arrUserIds = array_keys($arrUserDaysApproved);
			# Get Email address of these ids with names
			$arrEmails = getEmailFromLoginId($arrUserIds);
			# Get users email settings, whos days are approved
			$arrUsersEmailSettings  = getUsersBulkEmailSettings($arrUserIds);
			#find out department whos reponse needs to retived
			$arrDepartmentsUsed = array();
			#display($arrUsersEmailSettings,"user email settings");
			# here we will get the departments from the list of users
			# whos days are approved, we get their departmentes
			# because afterward we will load their department settings for emails
			# and response text message for email body.
			foreach($arrUsersEmailSettings as $idSelectedUser=>$arrHisSettings){
				$arrDepartmentsUsed[$arrHisSettings["department"]] = $arrHisSettings["department"];
			}
			#display($arrDepartmentsUsed,"Used Departments");
			#get these departments email settings that need to be sent to the user
			$arrDepartmentEmailSettings = getDepartmentBulkMailSettings($arrDepartmentsUsed);
			#display($arrDepartmentEmailSettings,"Department Email Settings");
			#exit();
			if (sizeof($arrEmails) > 0 ) {
				include_once("include/cmail.php");
				#create mail object
				$objMail = new cMail();
				#if there are some approved days then loop on them
				#coz this array will contain the userinfo and his days info as well
				foreach($arrUserDaysApproved as $idUser=>$chrDaysApproved){
					
					$chrTo = $arrEmails[$idUser]["name"]." <".$arrEmails[$idUser]["email"].">";
					$chrSubject = "Absence Manager - Item Updated (". safeDatabase($objSession->getFullName()).")";
					# append mail body as per his department email settings
					$chrBody = "<h3>Absence Request:</h3></P>";
					$chrBody .= $arrDepartmentEmailSettings[$arrUsersEmailSettings[$idUser]["department"]]["chrReplayMsg"];
					# append what days approved with comments etc
					$chrCalendarLink = $objMail->createCalendarLink($objSession,$arrUsersEmailSettings[$idUser]["department"], $daysModified[$objSession->getIdUser()]);
					$chrBody .= "<br>\n".$chrDaysApproved;
					$chrBody .= "<br>\n".$chrCalendarLink;
					$chrFrom = "FROM : ".safeDatabase($objSession->getFullName())." <".$objSession->getEmailAddress().">";
					#if user has subscribed for approvel notification then send him email otherwise not
					if ($arrUsersEmailSettings[$idUser]["blnResponse"] == true){
						$blnSent = $objMail->sendEmail($chrTo,$chrFrom,$chrSubject,$chrBody,$objSession);
						if ($blnSent != true){
							$chrMessage = "Some of the mails could not be sent, ".$objMail->getLastError();
						}# if
					}# if
				} #foreach
			} #if
			else {
				$chrMessage = "No Emails found";
			}			

			$idsModified = array_keys($daysModified);
			$modifiedSelf = in_array($objSession->getIdUser(), $idsModified);

			#Send a mail to update the manager

			#If the user is manager, no need to send
			$arrSettings = getUserDepartmentMailSettings($objSession->getUid());
			$user_id = $objSession->getUid();				
			$objMail2 = new cMail();			
			if ($arrSettings["blnEmailRequired"] == true){ 
				$mixManagers = getUserManager($objSession->getUid(), $userIsManager, $modifiedSelf);						
				#If user is in system and has some manager
				if (sizeof($mixManagers) > 0) {
					$chrTo = "";
					foreach($mixManagers as $chrEmail=>$chrName){
						$chrTo .= "$chrName <{$chrEmail}> ,";
					}
					$chrTo = trim($chrTo,",");
					# Send email to those managers from me
					$chrFrom = "FROM : ".$objSession->getFullName()." <".$objSession->getEmailAddress().">";
					#Send mail to managers with request
					$chrApprovalLink = $objMail2->createApprovalLink($objSession, $daysModified[$objSession->getIdUser()]);
					$chrCalendarLink = $objMail2->createCalendarLink($objSession, null, $daysModified[$objSession->getIdUser()]);
			
					#$chrFromName = safeDatabase($objSession->getFullName())." ({$objSession->getUid()})";
					$chrFromName = $objSession->getFullName()." ({$objSession->getUid()})";
					if ($chrFromName == " ()")  $chrFromName = 'Someone';						
					
					#TODO: Get the user's comment from input somewhere, is any other comment than the ones used for
					#activate the comment in the mail 4 rows below. 
					//$chrComment = safeDatabase("Kommentar");
					$eMessage = "<P>from <b>$chrFromName:</b></P>";
					$eMessage .= "<P>$chrBody</P>";								
					$eMessage .= "<pre><br>$chrApprovalLink \r\nor visit the $chrCalendarLink</pre>";										
					$blnSent = $objMail2->sendEmail($chrTo,$chrFrom,"Absence Manager - User request (".$objSession->getFullName().")",$eMessage, $objSession);			
					if ($blnSent != true){
						$chrMessage = $objMail2->getLastError();						
					}										
				}
			}
			else {
				# if auto approved option is set for current logged in user department by his manager, and manager has also set the option email not requierd
				if ($arrSettings["blnAutoApprove"] == 1  && $arrSettings["blnEmailRequired"] == 0){
					$chrMessage = "Auto approved. Email not sent to Manager. Check email for details";
				}
				else{
					$chrMessage = "Email not sent to Manager. Check your email for details";
				}
			}
		}
		# now send user back to the same calendar view page from where he came with same
		# params that he was viewing
		$chrParam = "";		
		foreach($_REQUEST as $key=>$value){
			if ($key != "chrParam" && $key != "chrAction" && $key != "chrDepartment") {
				$chrParam .= $key."=".str_replace("/","_X_",$value)."&";
			}
		}
		
		header("location: view_project_calendar.php?".$chrParam."chrAction=single");
		exit();
	} else if ($_REQUEST["chrAction"] == "clear_days"){
		#if clear days request has been made
		#split user days into array, from a simple plain string
		$chrDaysApplied = "";
		$arrSettings = getUserDepartmentMailSettings($objSession->getUid());
		$arrParam = explode("===_===",$_POST["chrParam"]);
		$arrQueries = array();
		foreach($arrParam as $eachRec){
			if ($eachRec){
				$arrDay = explode("-_-",$eachRec);
				$intDay = $arrDay[0];
				$intMonth = $arrDay[1];
				$intYear = $arrDay[2];
				$idUser = $arrDay[3];
				$approved = $arrDay[4];
				$arrQueries[] = "DELETE FROM dbatn_userdays WHERE \"idUser\"=$idUser AND \"intDay\"=$intDay  AND \"intYear\"=$intYear  AND \"intMonth\"=$intMonth";
				if($approved == 'approved'){
					$chrDaysApplied .= "[removed]".date("d M,Y",mktime(0,0,0,$intMonth,$intDay,$intYear))."<br>\n";
				}
			}#if there is record
		}#endforeach
		$userDepartment = getUserDepartment($idUser);
		$arrDepartmentRights = getDepartmentRights($objSession->getUid());
		if ($chrDaysApplied != ""){
			$objMail = new cMail();
			#if the user is clearing his own days
			if(!in_array($userDepartment,$arrDepartmentRights["manager"])) {
				$objMail->prepareAndSendMail($chrDaysApplied, $objSession, $arrSettings, $chrMessage);
			} else { #if the manager is clearing a users days TODO -> create Calendar Link
				$objMail->sendClearMailToUser($objSession, $chrDaysApplied, $idUser);
			}
		}

		foreach($arrQueries as $chrQuery){
			mazDb_query_params($chrQuery, array());			
		}
		$chrParam = "";
		foreach($_REQUEST as $key=>$value){
			if ($key != "chrParam" && $key != "chrAction" && $key != "chrDepartment") {
				$chrParam .= $key."=".str_replace("/","_X_",$value)."&";
			}
		}
		header("location: view_project_calendar.php?".$chrParam."chrAction=single&msg=".urlencode($chrMessage));
		exit();
	} else if ($_REQUEST["chrProject"] && $_REQUEST["chrAction"] == "single"){
		$projects = explode(",", $_REQUEST["chrProject"]);
		for($i=0 ; $i<sizeof($projects) ; $i++){
			$arrSearchProjs[] = str_replace("_X_","/",$projects[$i]);
		}														
	} else if ($_REQUEST["chrAction"] == "view_new_list") { #if View List has been clicked
		if ($_REQUEST['projsSelected'] != ''){
			foreach ($_REQUEST['projsSelected'] as $pr){
				$arrSearchProjs[$pr] = $pr;
			}
		}
	} else if ($_REQUEST["chrAction"] == "save_settings"){
		$arrQueries = array();
		# first delete old settings
		$arrQueries[0] = "DELETE FROM dbatn_project_settings1 WHERE iduser=".$objSession->getIdUser();
		# Add new user settings, for department
		if($_REQUEST["projsSelected"] != ''){
			foreach ($_REQUEST["projsSelected"] as $ps){
				$arrSearchProjs[$ps] = $ps;
				$arrQueries[] = "INSERT INTO dbatn_project_settings1(iduser,project) values(".$objSession->getIdUser().",'".$ps."') ";
			}			
		}
		foreach ($arrQueries as $chrQuery){
			mazDb_query_params($chrQuery, array());
		}header("location: view_project_calendar.php?msg=".urlencode("User settings updated successfully"));
		exit();
	} else{		
		$intCount = $_REQUEST["proj_count"];
		for ($i = 0; $i< $intCount; $i++){
			if ($_REQUEST["proj".$i]){
				$arrSearchProjs[$_REQUEST["proj".$i]] = $_REQUEST["proj".$i];
			}			
		}
	}
	header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("Group Calendar"); ?></title>
		<?php echo generateScripts(); ?>
<script type="text/javascript">

$(document).ready(function () {
	pageInit();
	var arrAllProjs = <?php echo createJSArray($arrProjs); ?>;
	var arrProjsFromDB = <?php echo createJSArray($arrProjsFromDB); ?>;
	var arrProjsToView = <?php echo createJSArray($arrSearchProjs); ?>;

	$("#menu").css("height", '100%');
	$("#container").css("height", '100%');
	populateList('projsAll', arrAllProjs);
	
	<?php #Display the right department-selections in the selection box 
	if ($_REQUEST['chrAction'] != 'direct'){ 
		echo "populateList('projsSelected', arrProjsToView);";
	} else {
		echo "populateList('projsSelected', arrProjsFromDB);";
	}
	?>
	connectFilterToList('projFilter', 'projsAll', arrAllProjs);	
});


function saveSettings(){
	var intCount = document.getElementById("proj_count").value;
	//var intSubProjCount = document.getElementById("subproj_count").value;
	var intSelected = 0;
	for (i = 0; i < intCount; i++){
		if (document.getElementById("proj"+i).checked == true){
			intSelected++;
		}
	}
	if (intSelected < 1) {
		alert("Please select atleast 1 group for search");
		return false;
	}
	else {
		document.viewProjsForm.submit();
		return true;
	}
}

/*******************************/
N = (document.all) ? 0 : 1;
var ob;
var btnDown = false;

function MD(e){
	if (window.event.srcElement.tagName != "HTML") {
	 btnDown = true;
	}
}

document.oncontextmenu=new Function("return false");

function MM(){
	if (btnDown == true && document.getElementById("divComments").style.display != ""){
		//document.getElementById("tselect").focus();
		//document.focus();
		return false;
	}
}
function MU() {
	btnDown = false;
}

if (N) {
document.captureEvents(Event.MOUSEDOWN | Event.MOUSEMOVE | Event.MOUSEUP);
}
document.onmousedown = MD;
document.onmousemove = MM;
document.onmouseup = MU;

function mouseMoveSelection( obj ){
	if (btnDown == true) {
		//selectbox(obj);
	}
}

/*******************************/
var selectedOption = "";
var intBoxSelected = 0;
function closeDiv(){
	document.getElementById("divComments").style.display = "none";
}

function hideProject(projectId){
	if($('span.'+projectId).attr('title') == "hide"){
		$('tr.'+projectId+' *').hide();
		$('span.'+projectId).attr('title', 'show');
		$('span.'+projectId).html('&#9650;');
	} else {
		$('tr.'+projectId+' *').show();
		$('span.'+projectId).attr('title', 'hide');
		$('span.'+projectId).html('&#9660;');
	}
}

function saveComments(){
	document.getElementById("divComments").style.display = "none";
	arrTds = document.getElementsByTagName("td");
	for(i=0; i<arrTds.length; i++) {
		if (arrTds[i].className == "selectedbox"){
			if (selectedOption != "edit_comments") {				
				arrTds[i].innerHTML = arrTds[i].getAttribute("dayValue")+"<br>"+selectedOption;
				arrTds[i].setAttribute("chrCharacter",selectedOption);				
			}
			arrTds[i].setAttribute("chrComments",document.getElementById("chrComments").value);
			arrTds[i].setAttribute("title",document.getElementById("chrComments").value);
			if (document.getElementById("chrComments").value == ""){
				arrTds[i].className = "dirty";
			}
			else{
				arrTds[i].className = "dirtyi";
			}
			//alert(arrTds[i].getAttribute("chrCharacter"));
		}
	}	
	applySettings(); /* auto matically apply settings */
}

/* ---------------------- */
function clearSelectedDays(){
	arrTds = document.getElementsByTagName("td");
	var str = "";
	for(i=0; i<arrTds.length; i++){
		if (arrTds[i].className == "selectedbox"){
			arrTds[i].className = "dirty";
			str += arrTds[i].getAttribute("dayValue")+"-_-"+arrTds[i].getAttribute("monthValue")+"-_-"+arrTds[i].getAttribute("yearValue")+"-_-"+arrTds[i].getAttribute("iduser")+"-_-"+arrTds[i].getAttribute("class2")+"===_===";
		}
	}

	var items = document.getElementById("projsSelected").getElementsByTagName("option");
	var i=0;
	var calString = '';	
	if (items.length >= 1) {
		for(i=0;i<items.length;i++)
		{
			//var l = items[i].firstChild.value;
			calString = calString + items[i].value + ',';
		}
	}
	document.viewProjsForm.chrAction.value = "clear_days";
	document.getElementById("chrProject").value=calString;
	document.getElementById("chrParam").value=str;
	document.viewProjsForm.submit();
}

function applySettings(){
	arrTds = document.getElementsByTagName("td");
	var str = "";
	for(i=0; i<arrTds.length; i++){
		if (arrTds[i].className == "dirty" || arrTds[i].className=="dirtyi"){
			str += arrTds[i].getAttribute("dayValue")+"-_-"+arrTds[i].getAttribute("monthValue")+"-_-"+arrTds[i].getAttribute("yearValue")+"-_-"+arrTds[i].getAttribute("chrCharacter")+"-_-"+arrTds[i].getAttribute("chrComments")+"-_-"+arrTds[i].getAttribute("iduser")+"===_===";
		}
		if (arrTds[i].className == "noteadded" || arrTds[i].className=="noteaddedi"){
			str += arrTds[i].getAttribute("dayValue")+"-_-"+arrTds[i].getAttribute("monthValue")+"-_-"+arrTds[i].getAttribute("yearValue")+"-_-"+arrTds[i].getAttribute("chrCharacter")+"-_-"+arrTds[i].getAttribute("chrComments")+"-_-"+arrTds[i].getAttribute("iduser")+"===_===";
		}
	}

	var items = document.getElementById("projsSelected").getElementsByTagName("option");
	var i=0;
	var calString = '';	
	if (items.length >= 1) {
		for(i=0;i<items.length;i++)
		{
			//var l = items[i].firstChild.value;
			calString = calString + items[i].value + ',';
		}
	}
	document.getElementById("chrParam").value=str;
	document.getElementById("chrProject").value=calString;
	document.viewProjsForm.chrAction.value = "save_days";

	document.viewProjsForm.submit();
}

function saveBoxes(chrType) {
	var chrComments = "";
	if (chrType == "edit_comments" || chrType == "A" || chrType == "D"){
		arrTds = document.getElementsByTagName("td");
		for(i=0; i< arrTds.length; i++){
			if (arrTds[i].className == "selectedbox"){
				chrComments = arrTds[i].getAttribute("chrComments");
				break;
			}
		}
	}
	if (intBoxSelected > 0){
		document.getElementById("chrComments").value = chrComments;
		document.getElementById("divComments").style.display = "";
		selectedOption = chrType;
	}
	else{
		alert("Please select a day");
	}
}

function selectbox(objTd){
	//If onClick is set user is allowed to mark day
	if (objTd.onclick != null) {
		//Get duplicate dayboxes if the same user is in more than one project
		var allCommonDayboxes = $("[name='"+objTd.getAttribute('name')+"']"),
			className = objTd.className;

		if (className == "daybox" || className == "noteadded" || className == "noteaddedi" || className == "redday" || className == "reddayi" || className == "approved"){
			//set all duplicate/common boxes to selected aswell
			for(var i=0 ; i<allCommonDayboxes.length ; i++){
				allCommonDayboxes[i].setAttribute("class", "selectedbox common");
			}
			//set the original box to selected
			objTd.setAttribute("class", "selectedbox");
			intBoxSelected++;
		}
		else if (className == "selectedbox" || className == "selectedbox common"){
			for(var i=0 ; i<allCommonDayboxes.length ; i++){
				allCommonDayboxes[i].setAttribute("class", objTd.getAttribute("class2"));
			}
			intBoxSelected--;
		}
	}
}


function findPos(obj){
    var curleft = curtop = 0;
    if (obj.offsetParent){
        do{
            curleft += obj.offsetLeft;
            curtop += obj.offsetTop;
        } while (obj = obj.offsetParent);
	}
	var offset = 0;
	if (navigator.appName == "Microsoft Internet Explorer"){
		offset = document.getElementById("workingDiv").scrollTop;
	}
	else{
		offset = document.getElementById("workingDiv").pageYOffset;
	}
	curtop -= offset;
    return [curleft,curtop];
}

function showToolTip(obj){
	var pos = findPos(obj);
	document.getElementById("manager_tool_tip").style.left = pos[0]+"px";
	document.getElementById("manager_tool_tip").style.top = pos[1]+"px";
	document.getElementById("manager_tool_tip").style.display = "";
}

function hideToolTip(obj){
	document.getElementById("manager_tool_tip").style.display = "none";
}

// To limit the number of input characters in the text field.
function limitText(limitField, limitNum) {
    if (limitField.value.length > limitNum) {
        limitField.value = limitField.value.substring(0, limitNum);
    }
	var charleft = limitNum - limitField.value.length;
	document.getElementById('charleft').innerHTML ='<strong>'+ charleft +'</strong>';
}
/*****************************************************************/

function setNewHeightAndWidth(tab) {
	$(".firstTd").css("padding-left", tab+"px");

	var calendarWidth = $('#toolbar').width()-50+'px';
	$('.outer').css("width", calendarWidth);
	$('.inner').css("width", calendarWidth);
	//$('.calendarTable').css("width", calendarWidth);

	//Make the fixed scroll control the tablescroll
	$(".outerScrollDiv").css("max-width", calendarWidth);
	$(".scrollDiv").css("width", $('.calendartable').width());
	$(".outerScrollDiv").scroll(
		function(){
			$(".inner").scrollLeft($(".outerScrollDiv").scrollLeft());
			btnDown = false;
		});

	//Change html height to fit the new height (after calendar has been generated)
	$("html").css("height", $('#contentInner').height()+400);
}

function toggleSettingsArea(){
	$('#settingsArea').toggle();
}

function saveNewList(){
	document.viewProjsForm.chrAction.value = "save_settings";
	$('#projsSelected *').attr('selected', 'selected');
	document.viewProjsForm.submit();
}

function viewNewList(){
	document.viewProjsForm.chrAction.value = "view_new_list";
	$('#projsSelected *').attr('selected', 'selected');
	document.viewProjsForm.submit();
}

function copyToClipboard() {
	var projects = document.getElementById("projsSelected").getElementsByTagName("option");
	var calString = '';
	var url = document.URL;
	if (projects.length >= 1) {
		for(i=0;i<projects.length;i++)
		{
			calString = calString + encodeURIComponent(projects[i].value) + ',';
		}
		calString = calString.slice(0, - 1); //remove last comma
	}
	if(!(url.indexOf("?") > -1)) { // add chrAction if url lacks content
			url += "?chrAction=direct";
	}
  	window.prompt("Copy to clipboard: Ctrl+C, Enter", url+"&chrProject="+calString);
}
</script>
	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar">
					<img src="media/images/TabNavigator2.png" />&nbsp;
					<span class="pageheading"><span class="ericssonHeading">Group Calendar</span>
						&nbsp; &nbsp; &nbsp; &nbsp;

						<input type="button" onclick="saveBoxes('V')" value="FL" title="Full Day Leave" />
						<input type="button" onclick="saveBoxes('H')" value="1-8" title="Few Hours" />
						<input type="button" onclick="saveBoxes('B')" value="B" title="Business Trip" />
						<input type="button" onclick="saveBoxes('C')" value="C" title="Course" />
			<!--			<input type="button" onclick="saveBoxes('P')" value="PL" title="Parental Leave"/>-->						
						<input type="button" onclick="clearSelectedDays()" value="Clear Days" title="Clear Days"/>
						<input type="button" onclick="saveBoxes('edit_comments')" value="Edit Comments" title="Edit Comments" />												
						<?php
							if(!empty($arrDepartmentRights["manager"]) || $objSession->getIsLegalManager() == 't') {
								echo '<input type="button" onclick="saveBoxes(\'A\')" value="Approve" title="Approve Request" />&nbsp;';
								echo '<input type="button" onclick="saveBoxes(\'D\')" value="Deny" title="Deny Request" />';
							}
						?>
					</span>
				</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  	<tr>
    	<td valign="top" bgcolor="#505050" height="100%" >
    		<table cellpadding="0" cellspacing="" width="100%">
        		<tr>
            		<td class="workareaBox" valign="top">
    				<!-- ################################## Working Area START ################################# -->
        				<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="1" class="contentTable">
        					<!-- InstanceBeginEditable name="subheader section" -->
	  						<!-- InstanceEndEditable -->
      						<tr>
        						<td height="100%">				<!-- _____Contents START_____ -->
        		            	<div id="workingDiv" style="width:100%;height:<?php echo CALENDAR_HEIGHT ?>">
                				<table bgcolor="#505050" width="100%" height="100%">
                    				<tr>
                        				<td style="padding-top:5px;">
                        				<!-- InstanceBeginEditable name="working-area" -->
                          				<div id="manager_tool_tip" class="msnuserbox" style="display:inline;position:absolute;width:300px;height:30px;left:-200px;top:-200px" onmouseout='hideToolTip(this)'>
                            			<table>
                            				<tr>
                                				<td class="critical">Only Managers can approve it</td>
                                			</tr>
                             			</table>
                             			</div>
                             			<div id="divComments" style="display:none;position:absolute;width:400px;left:200px;top:200px;">
                            			<table width="100%" bgcolor="#FEFBF3" style="border:1px solid #000000">
                                			<tr>
                                    			<td class="monthname">Add Comments</td>
                                			</tr>
                                			<tr>
                                    			<td><div style="font-size:10px;">Characters Left:<font size="2px" color="red"><span id="charleft">249(Max)</span></font></div>
													<textarea id="chrComments" name="chrComments" cols="40" rows="5" onKeyDown="limitText(this,249);" onKeyUp="limitText(this,249);"></textarea>
                                        			<br />
                                        			<input type="button" onclick="saveComments()" value="Save" /> <input type="button" onclick="closeDiv()" value="Cancel" />
                                        		</td>
                                			</tr>
                            			</table>
                            			</div>

                            			<div id="rightClickMenu" class="rightClickMenu">                           				
                            			</div>

                            			<div id="chooseAbsence" class="chooseAbsence">
											<div class="chooseAlt chooseAltTop" onClick="saveBoxes('V')">Full Day Leave</div>
											<div class="chooseAlt chooseAltRight" onClick="saveBoxes('H')">Few Hours</div>
											<div class="chooseAlt chooseAltLeft" onClick="saveBoxes('B')">Business Trip</div>
											<div class="chooseAlt chooseAltRight" onClick="saveBoxes('C')">Course</div>
										<!--	<div class="chooseAlt chooseAltLeft" onClick="saveBoxes('P')">Parental Leave</div>-->
										</div>

                            			<div id="contentBody">
	                            			<?php

	                            				$today = date("Y-m-d");

												if($_REQUEST["fromMonth"] && $_REQUEST["toMonth"] && $_REQUEST["intYear"] && $_REQUEST["intYear2"]) {
													$intFromMonth = $_REQUEST["fromMonth"];
													$intToMonth = $_REQUEST["toMonth"];
													$intYear = $_REQUEST["intYear"];
													if($intFromMonth <= $intToMonth) {
														$intYear2 = $_REQUEST["intYear2"];
													} else {
														$intYear2 = $_REQUEST["intYear"]+1;
													}
												} else {
													$intFromMonth = date("m",time());
													$intToMonth = date("m",strtotime("$today +1 month"));
													$intYear = date("Y",time());
													if($intFromMonth <= $intToMonth) {
														$intYear2 = date("Y",time());
													} else {
														$intYear2 = date("Y", strtotime("$today +1 year"));
													}
												}
												#if to year(end year) is less that from year(start year)
												# then make them same as Start year
												if ($intYear2 < $intYear){
													$intYear2 = $intYear;
													$intToMonth = $intFromMonth;
												}
												else if ($intYear2 > $intYear+1) {
													#if ending year is not next year make it next year
													# as we are allowed only one year accross the current year
													$intYear2 = $intYear+1;
												}

												$self = 'view_project_calendar.php';
												echo getViewProjectsForm($self, $objSession, "calendar", $intYear, $intYear2, $intFromMonth, $intToMonth);
											?>

	        								<!-- Start, calendar part -->
	        								<form id="frmCSV" name="frmCSV" method="post" action="generate_csv.php" target="_blank">
												<div id="scrollingarea">
												<!--div class="scrollbar"><div class="track"><div class="thumb"><div class="end"></div></div></div></div>
												<!-- two div for seperate scrolling of calendar, username should not disappear while scrolling months-->
												<div class="outerScrollDiv"><div class='scrollDiv'>.</div></div>
												<div class='outer' bgcolor="#FFFFFF">											
													<div class='inner' bgcolor="#FFFFFF">


														<table class="calendartable" cellspacing="1" cellpadding="1" width="100%" bgcolor="#FFFFFF">

															<?php
															if (is_array($arrSearchProjs) && sizeof($arrSearchProjs) > 0){
																$chrProjects = "'".implode("','",$arrSearchProjs)."'";
															}
															else {
																$chrProjects = "'XXXXaXXXX'"; #do not search any thing, will only come here if no filter matches at all
															}
															$chrOrderBy = "name, department";
															$iduser =  $objSession->getIdUser();
													
															//Prepare varaibles for creating table
															$counter=0;
															$chrOld = "";
															$tabSize = 30;
															$deepestTab = 0;
															$csvData = "";

															$intColSpan = getTotalDays($intFromMonth,$intYear,$intToMonth,$intYear2) + 2;
															//--------------------------

															function createProjectHtml($id) {
																global $objSession, $arrRights;
																$html = "";

																//Get project id, name and isGroup flag
																$chrQuery = "SELECT dbatn_projects.idproject, dbatn_projects.chrproject, dbatn_projects.isGroup FROM dbatn_projects
																			WHERE dbatn_projects.idproject = $id;";
																$rs = mazDb_query_params($chrQuery, array());

																//If there were any results
																if(mazDb_num_rows($rs) > 0) {
																	$arr = mazDb_fetch_array($rs);

																	//Array containing all parent id's
																	$parentProjects[] = $arr["idproject"];

																	$permissionToView = ( ($objSession->isAdminUser() == true) || (in_array($arr['idproject'], $arrRights["view"])));
																	$html.=getProjectHeader($arr["chrproject"], $parentProjects, $arr["isgroup"], $permissionToView, true, 0);
																	
																	//if project, create html for subprojects/groups
																	if($arr["isgroup"] == "f") {
																		$html.=createSubProjectsHtml($parentProjects, 1);
																	} else { // create html for the group
																		//Check if user can view group
																		if( $permissionToView == 1 ) {
																			$html.=createGroupHtml($parentProjects, 0);
																		}
																	}
																} else { //If no records found
																	$html .= '
																			<tr >
																				<td colspan="'.$intColSpan.'" class="gridDataSelected">No record found</td>
																			</tr>';
																}
																return $html;
															}

															//Create all subprojects and groups for a project
															function createSubProjectsHtml($parentProjects, $nrOfTabs){
																global $objSession, $arrRights;

																$ParentProjectId = end($parentProjects);
																$permissionToView = false;

																//Query for getting all subprojects from $ParentProjectId
																$chrQuery = "SELECT dbatn_projects.idproject, dbatn_projects.chrproject, dbatn_projects.isgroup FROM dbatn_projects
																			inner join dbatn_project_subprojects 
																			on 
																			dbatn_projects.idproject = dbatn_project_subprojects.idsubproject
																			where dbatn_project_subprojects.idproject = $ParentProjectId;";
																$rs = mazDb_query_params($chrQuery, array());
																
																//If there were any results
																if(mazDb_num_rows($rs) > 0) {
																	//While there is a new sub project
																	while($arr = mazDb_fetch_array($rs)){
																		if(!in_array($arr['idproject'], $parentProjects)){ //prevent infinite loop
																			$subProjectParents = $parentProjects;
																			$subProjectParents[] = $arr['idproject'];

																			$permissionToView = ( ($objSession->isAdminUser() == true) || (in_array($arr['idproject'], $arrRights["view"])));

																			//Add header for project with name and nr of tabs (to vizualize hierarchy)
																			$html.=getProjectHeader($arr['chrproject'], $subProjectParents, $arr["isgroup"], $permissionToView, true, $nrOfTabs);

																			if($arr["isgroup"] == "f") {
																				//Create html for this projects subprojects 
																				$subprojectsHtml = createSubProjectsHtml($subProjectParents, $nrOfTabs+1);																	
																				if($subprojectsHtml != null){
																					$html .= $subprojectsHtml;
																				}
																			} else {
																				//Check if user has permission to view the project
																				if($permissionToView==1) {
																					$html .= createGroupHtml($subProjectParents, $nrOfTabs);
																				}
																			}
																		}
																	}
																	return $html;
																}												
															}

															//Create html for group
															function createGroupHtml($parentProjects, $nrOfTabs){															
																global $arrUserDays, $intYear, $intYear2, $intToMonth,
																		$arrDepartmentRights ,$arrThisMonth, $chrExtraParams,
																		$intSelectedMonth, $intSelectedYear, $intFromMonth, $objSession,
																		$arrRights, $tabSize, $deepestTab, $csvData;
																
																$groupId = end($parentProjects);
																$hierarchyClass = "";//Class name with all parent project id's. Separated with spaces
																for($i = 0 ; $i<sizeof($parentProjects) ; $i++) {
																	$hierarchyClass .= $parentProjects[$i]." ";
																}
																$hasAddedHeaderCsv = false;

																							

																$chrQuery = "SELECT * FROM dbatn_userslist
																			INNER JOIN
																			dbatn_projectlist
																			ON
																			dbatn_projectlist.iduser = dbatn_userslist.iduser
																			WHERE
																			dbatn_projectlist.idproject = $groupId";
																$rs = mazDb_query_params($chrQuery, array());

																if(mazDb_num_rows($rs) > 0) {
																	//Get html for the date rows (above the user rows)

																	$intEndMonth = ($intYear == $intYear2) ? $intToMonth : $intToMonth+12;																

																	$tabbedInStyle = "margin-left:".($nrOfTabs*$tabSize+10)."px;";
																	while($arr = mazDb_fetch_array($rs)){
																		if(!$hasAddedHeaderCsv) {
																			//Add project header to csv string
																			$csvData .= "\n"."Project ".$arr["chrproject"]. " (". str_replace(",","-",getAllProjectsOwnerString($groupId)) .")\n";
																			//Add date rows to group html
																			$html = createDateRowsHtml($groupId, $intFromMonth, $intEndMonth, $intYear, $intYear2, $nrOfTabs, $hierarchyClass);
																			$hasAddedHeaderCsv = true;
																		}																		
																		$html .= '<tr class="'.$hierarchyClass.'" id="m" bgcolor="#FFFFFF">';
																		$html .= '<td class="fixedTd" title="' . $arr["uid"] . '"><div class="personname" style="'.$tabbedInStyle.'">'. $arr["name"].' <i>('.$arr["department"].')</i></div></td>';
																		$html .= "<td class='firstTd'></td>";
																		
																																			
																		$arrUserDays[$intYear] = getUserAndTemplateDays( $arr["iduser"], $intYear );
																		$arrUserDays[$intYear2] = getUserAndTemplateDays( $arr["iduser"], $intYear2 );
																		
																		$csvUserDays = "";
																		
																		for($i = $intFromMonth; $i <= $intEndMonth ; $i++){
																			$intSelectedMonth = $i;
																			$intSelectedYear = $intYear;
																			if ($i > 12) {
																				$intSelectedMonth = $i-12;
																				$intSelectedYear = $intYear2;
																			}
																			$month = date("M",time(1,1,1,$intSelectedMonth,1,$intSelectedYear));
																			$arrThisMonth = $arrUserDays[$intSelectedYear][intval($intSelectedMonth)];
																			$chrExtraParams = "iduser=".$arr["iduser"];
																			$blnAllowEditing = false;
																			if ($objSession->isAdminUser() == true || in_array($arr["department"],$arrDepartmentRights["manager"])||$objSession->getIdUser()==$arr["iduser"] || $arr['legalManager'] == $objSession->getUid()){
																				$blnAllowEditing = true;
																			}
																			# draw month
																			$arrData = drawMonthUserDays($arr["iduser"], $intSelectedMonth, $intSelectedYear, $arrThisMonth, $chrExtraParams, $blnAllowEditing, $hierarchyClass);
																			$html .= $arrData["html"];
																			$csvUserDays .= $arrData["csv"];
																		}#endfor month loop
																		$csvData .= $arr["name"].",".$csvUserDays."\n";
																		$html .= "</tr>"; //End user table row
																	}
																}

																//In order to tab all rows so that you can see them
																if ($nrOfTabs > $deepestTab) {
																	$deepestTab = $nrOfTabs;
																}

																return $html;
															}


															//Get checked projects
															$chrQuery = "SELECT idproject FROM dbatn_projects
																		WHERE
																		chrProject IN ($chrProjects)";
															$rs = mazDb_query_params($chrQuery, array());
															
															//If there were any results, create projects html and print it
															if(mazDb_num_rows($rs) > 0) {
																//While there is a new sub project
																while($arr = mazDb_fetch_array($rs)){
																	echo createProjectHtml($arr['idproject']);

																	echo "<tr style='margin-top: 10px; line-height: 50px; background: #FFF;'><td colspan='".$intColSpan."''> &nbsp; </td></tr>";																
																}

																//Tab in calendar rows so it is not covered by the fixed names
																echo '<script type="text/javascript">';
																echo 'setNewHeightAndWidth('.(($deepestTab+7)*$tabSize).');';															
																echo '</script>';
															}														

															?>
															<input type="hidden" name="csvData" value="<?php echo trim($csvData) ?>" />
														</table>											
													</div>
													</div>
												</div>
	                            				<input type="submit" value="Generate CSV" />
	                            				<button type="button" onclick="copyToClipboard()">Generate Link</button>
	                            			</form>
	                            		</div>
                        				<!-- InstanceEndEditable --></td>
                        			</tr>
                    			</table>
                			</div>										<!-- _____Contents End_____ -->
						</td>
      				</tr>
    			</table>
        		<!-- ##################################	Working Area END ################################# -->
          	</td>
          </tr>
	  </table>
    </td>
  </tr>
</table>
			</div>
		</div>
		<?php echo generateFooter(); ?>
	</body>
</html>
