--
-- PostgreSQL database dump
--

-- Dumped from database version 8.4.1
-- Dumped by pg_dump version 9.0.1
-- Started on 2011-08-26 16:35:48

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 1537 (class 1259 OID 7847558)
-- Dependencies: 6
-- Name: dbatn_admin; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_admin (
    idadmin integer NOT NULL,
    uid character varying(50),
    pwd character varying,
    email character varying(250)
);

COPY dbatn_admin (idadmin, uid, pwd, email) FROM stdin;
1	admin	adminpassword	admin@ericsson.com
\.

--
-- TOC entry 1538 (class 1259 OID 7847564)
-- Dependencies: 6
-- Name: dbatn_department_department; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_department_department (
    chrdepartment character varying(250) NOT NULL,
    chrdepartmentallwoed character varying(250) NOT NULL
);


--
-- TOC entry 1539 (class 1259 OID 7847567)
-- Dependencies: 1838 1839 6
-- Name: dbatn_department_email_settings; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_department_email_settings (
    chrdepartment character varying(250) NOT NULL,
    intemailrequired integer DEFAULT 1 NOT NULL,
    chrconfirmationmsg text,
    chrreplymsg text,
    intautoapprove integer DEFAULT 0
);


--
-- TOC entry 1560 (class 1259 OID 9428552)
-- Dependencies: 6
-- Name: dbatn_department_holidaytemplate; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_department_holidaytemplate (
    chrdepartment character varying(250) NOT NULL,
    iduser integer NOT NULL
);


--
-- TOC entry 1540 (class 1259 OID 7847575)
-- Dependencies: 6
-- Name: dbatn_department_manager; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_department_manager (
    iduser integer,
    chrdepartment character varying(250)
);


--
-- TOC entry 1541 (class 1259 OID 7847578)
-- Dependencies: 6
-- Name: dbatn_department_owner; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_department_owner (
    iduser integer NOT NULL,
    chrdepartment character varying(250) NOT NULL
);


--
-- TOC entry 1542 (class 1259 OID 7847581)
-- Dependencies: 6
-- Name: dbatn_department_project; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_department_project (
    chrdepartment character varying(250),
    chrprojectallowed character varying(250)
);


--
-- TOC entry 1543 (class 1259 OID 7847584)
-- Dependencies: 6
-- Name: dbatn_department_settings1; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_department_settings1 (
    iduser integer,
    department character varying(100)
);


--
-- TOC entry 1544 (class 1259 OID 7847587)
-- Dependencies: 6
-- Name: dbatn_department_settings2; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_department_settings2 (
    iduser integer,
    intcol integer
);


--
-- TOC entry 1545 (class 1259 OID 7847590)
-- Dependencies: 1840 1841 1842 1843 1844 6
-- Name: dbatn_personal_settings; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_personal_settings (
    blnconfirm integer DEFAULT 0,
    blnresponse integer DEFAULT 0,
    blnadvanceuser smallint DEFAULT 0,
    iduser integer DEFAULT 0,
    intstartpage smallint DEFAULT 1
);


--
-- TOC entry 1546 (class 1259 OID 7847598)
-- Dependencies: 6
-- Name: dbatn_project_department; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_project_department (
    idproject integer,
    chrdepartmentallwoed character varying(250)
);


--
-- TOC entry 1547 (class 1259 OID 7847601)
-- Dependencies: 6
-- Name: dbatn_project_owner; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_project_owner (
    iduser integer,
    idproject integer
);


--
-- TOC entry 1548 (class 1259 OID 7847604)
-- Dependencies: 6
-- Name: dbatn_project_project; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_project_project (
    idproject integer,
    chrprojectallowed character varying(250)
);


--
-- TOC entry 1549 (class 1259 OID 7847607)
-- Dependencies: 6
-- Name: dbatn_project_settings1; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_project_settings1 (
    iduser integer,
    project character varying(100)
);


--
-- TOC entry 1550 (class 1259 OID 7847610)
-- Dependencies: 6
-- Name: dbatn_project_settings2; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_project_settings2 (
    iduser integer,
    intcol integer
);


--
-- TOC entry 1551 (class 1259 OID 7847613)
-- Dependencies: 6
-- Name: dbatn_projectlist; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_projectlist (
    idproject integer,
    iduser integer,
    chrproject character varying(50)
);


--
-- TOC entry 1552 (class 1259 OID 7847616)
-- Dependencies: 6
-- Name: dbatn_projects; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_projects (
    idproject integer NOT NULL,
    chrproject character varying(50),
    idcreatedby integer,
    intdate integer,
    idupdatedby integer,
    intdateupdated integer
);


--
-- TOC entry 1553 (class 1259 OID 7847619)
-- Dependencies: 1845 1846 6
-- Name: dbatn_userdays; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_userdays (
    "idUser" integer NOT NULL,
    "intDay" integer NOT NULL,
    "intMonth" integer NOT NULL,
    "intYear" integer NOT NULL,
    "chrCharacter" character varying(2),
    "chrComments" character varying(250),
    "intApproved" integer DEFAULT 0,
    "chrComments2" character varying(250),
    inttime integer,
    blnapproved integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 1554 (class 1259 OID 7847627)
-- Dependencies: 1847 6
-- Name: dbatn_userslist; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dbatn_userslist (
    iduser integer NOT NULL,
    dn character varying(250),
    name character varying(250),
    department character varying(250),
    city character varying(250),
    erelation character varying(250),
    phone character varying(50),
    title character(100),
    email character varying(100),
    mdept character varying(100),
    sdept character varying(100),
    uid character varying(100),
    visible boolean DEFAULT true NOT NULL
);


--
-- TOC entry 1555 (class 1259 OID 7847633)
-- Dependencies: 6
-- Name: seq_iddepartment_departments; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_iddepartment_departments
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 1556 (class 1259 OID 7847635)
-- Dependencies: 6
-- Name: seq_idlist_lists; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_idlist_lists
    START WITH 139
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 1557 (class 1259 OID 7847637)
-- Dependencies: 6
-- Name: seq_idproject_projects; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_idproject_projects
    START WITH 93
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 1558 (class 1259 OID 7847639)
-- Dependencies: 6
-- Name: seq_iduser_userinfo; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_iduser_userinfo
    START WITH 13
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 1886 (class 0 OID 0)
-- Dependencies: 1558
-- Name: SEQUENCE seq_iduser_userinfo; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON SEQUENCE seq_iduser_userinfo IS 'hi man';


--
-- TOC entry 1559 (class 1259 OID 7847641)
-- Dependencies: 1848 6
-- Name: tmp_sent_email_log; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tmp_sent_email_log (
    chrto text,
    chrfrom text,
    chrsubject text,
    chrbody text,
    intdate bigint DEFAULT 0,
    chrheader text
);


--
-- TOC entry 1887 (class 0 OID 0)
-- Dependencies: 1559
-- Name: TABLE tmp_sent_email_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE tmp_sent_email_log IS 'This table is only for testing purpose, and will be deleted, once application is complete';


--
-- TOC entry 1866 (class 2606 OID 7847649)
-- Dependencies: 1553 1553 1553 1553 1553
-- Name: composite_primary_key_userdays; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY dbatn_userdays
    ADD CONSTRAINT composite_primary_key_userdays PRIMARY KEY ("idUser", "intDay", "intMonth", "intYear");


--
-- TOC entry 1850 (class 2606 OID 7847651)
-- Dependencies: 1537 1537
-- Name: pk_admin_idadmin; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY dbatn_admin
    ADD CONSTRAINT pk_admin_idadmin PRIMARY KEY (idadmin);


--
-- TOC entry 1870 (class 2606 OID 9443074)
-- Dependencies: 1560 1560
-- Name: pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY dbatn_department_holidaytemplate
    ADD CONSTRAINT pkey PRIMARY KEY (chrdepartment);


--
-- TOC entry 1868 (class 2606 OID 7847653)
-- Dependencies: 1554 1554
-- Name: primary_idlistuser_userslist; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY dbatn_userslist
    ADD CONSTRAINT primary_idlistuser_userslist PRIMARY KEY (iduser);


--
-- TOC entry 1864 (class 2606 OID 7847655)
-- Dependencies: 1552 1552
-- Name: project_idproject_pk; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY dbatn_projects
    ADD CONSTRAINT project_idproject_pk PRIMARY KEY (idproject);


--
-- TOC entry 1856 (class 1259 OID 7847656)
-- Dependencies: 1546
-- Name: FKI_IDPROJECT; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX "FKI_IDPROJECT" ON dbatn_project_department USING btree (idproject);


--
-- TOC entry 1862 (class 1259 OID 7847657)
-- Dependencies: 1551
-- Name: FKI_IDPROJECT_PROJECTLIST; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX "FKI_IDPROJECT_PROJECTLIST" ON dbatn_projectlist USING btree (idproject);


--
-- TOC entry 1857 (class 1259 OID 7847658)
-- Dependencies: 1547
-- Name: FKI_IDPROJECT_PROJECT_OWNER; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX "FKI_IDPROJECT_PROJECT_OWNER" ON dbatn_project_owner USING btree (idproject);


--
-- TOC entry 1859 (class 1259 OID 7847659)
-- Dependencies: 1548
-- Name: FKI_IDPROJECT_PROJECT_PROJECT; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX "FKI_IDPROJECT_PROJECT_PROJECT" ON dbatn_project_project USING btree (idproject);


--
-- TOC entry 1855 (class 1259 OID 7847660)
-- Dependencies: 1545
-- Name: FKI_IDUSER; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX "FKI_IDUSER" ON dbatn_personal_settings USING btree (iduser);


--
-- TOC entry 1851 (class 1259 OID 7847661)
-- Dependencies: 1540
-- Name: FKI_IDUSER_DEPARTMENT_MANAGER; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_DEPARTMENT_MANAGER" ON dbatn_department_manager USING btree (iduser);


--
-- TOC entry 1852 (class 1259 OID 7847662)
-- Dependencies: 1541
-- Name: FKI_IDUSER_DEPARTMENT_OWNER; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_DEPARTMENT_OWNER" ON dbatn_department_owner USING btree (iduser);


--
-- TOC entry 1853 (class 1259 OID 7847663)
-- Dependencies: 1543
-- Name: FKI_IDUSER_DEPARTMENT_SETTINGS1; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_DEPARTMENT_SETTINGS1" ON dbatn_department_settings1 USING btree (iduser);


--
-- TOC entry 1854 (class 1259 OID 7847664)
-- Dependencies: 1544
-- Name: FKI_IDUSER_DEPARTMENT_SETTINGS2; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_DEPARTMENT_SETTINGS2" ON dbatn_department_settings2 USING btree (iduser);


--
-- TOC entry 1858 (class 1259 OID 7847665)
-- Dependencies: 1547
-- Name: FKI_IDUSER_PROJECT_OWNER; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_PROJECT_OWNER" ON dbatn_project_owner USING btree (iduser);


--
-- TOC entry 1860 (class 1259 OID 7847666)
-- Dependencies: 1549
-- Name: FKI_IDUSER_PROJECT_SETTINGS1; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_PROJECT_SETTINGS1" ON dbatn_project_settings1 USING btree (iduser);


--
-- TOC entry 1861 (class 1259 OID 7847667)
-- Dependencies: 1550
-- Name: FKI_IDUSER_PROJECT_SETTINGS2; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX "FKI_IDUSER_PROJECT_SETTINGS2" ON dbatn_project_settings2 USING btree (iduser);


--
-- TOC entry 1876 (class 2606 OID 7847668)
-- Dependencies: 1552 1546 1863
-- Name: FK_IDPROJECT; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dbatn_project_department
    ADD CONSTRAINT "FK_IDPROJECT" FOREIGN KEY (idproject) REFERENCES dbatn_projects(idproject);


--
-- TOC entry 1882 (class 2606 OID 7847673)
-- Dependencies: 1552 1551 1863
-- Name: FK_IDPROJECT_PROJECTLIST; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dbatn_projectlist
    ADD CONSTRAINT "FK_IDPROJECT_PROJECTLIST" FOREIGN KEY (idproject) REFERENCES dbatn_projects(idproject);


--
-- TOC entry 1877 (class 2606 OID 7847678)
-- Dependencies: 1863 1552 1547
-- Name: FK_IDPROJECT_PROJECT_OWNER; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dbatn_project_owner
    ADD CONSTRAINT "FK_IDPROJECT_PROJECT_OWNER" FOREIGN KEY (idproject) REFERENCES dbatn_projects(idproject);


--
-- TOC entry 1879 (class 2606 OID 7847683)
-- Dependencies: 1548 1552 1863
-- Name: FK_IDPROJECT_PROJECT_PROJECT; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dbatn_project_project
    ADD CONSTRAINT "FK_IDPROJECT_PROJECT_PROJECT" FOREIGN KEY (idproject) REFERENCES dbatn_projects(idproject);


--
-- TOC entry 1875 (class 2606 OID 7847688)
-- Dependencies: 1867 1545 1554
-- Name: FK_IDUSER; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dbatn_personal_settings
    ADD CONSTRAINT "FK_IDUSER" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- TOC entry 1871 (class 2606 OID 7847693)
-- Dependencies: 1554 1540 1867
-- Name: FK_IDUSER_DEPARTMENT_MANAGER; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dbatn_department_manager
    ADD CONSTRAINT "FK_IDUSER_DEPARTMENT_MANAGER" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- TOC entry 1872 (class 2606 OID 7847698)
-- Dependencies: 1554 1541 1867
-- Name: FK_IDUSER_DEPARTMENT_OWNER; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dbatn_department_owner
    ADD CONSTRAINT "FK_IDUSER_DEPARTMENT_OWNER" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- TOC entry 1873 (class 2606 OID 7847703)
-- Dependencies: 1867 1543 1554
-- Name: FK_IDUSER_DEPARTMENT_SETTINGS1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dbatn_department_settings1
    ADD CONSTRAINT "FK_IDUSER_DEPARTMENT_SETTINGS1" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- TOC entry 1874 (class 2606 OID 7847708)
-- Dependencies: 1554 1867 1544
-- Name: FK_IDUSER_DEPARTMENT_SETTINGS2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dbatn_department_settings2
    ADD CONSTRAINT "FK_IDUSER_DEPARTMENT_SETTINGS2" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- TOC entry 1878 (class 2606 OID 7847713)
-- Dependencies: 1867 1547 1554
-- Name: FK_IDUSER_PROJECT_OWNER; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dbatn_project_owner
    ADD CONSTRAINT "FK_IDUSER_PROJECT_OWNER" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- TOC entry 1880 (class 2606 OID 7847718)
-- Dependencies: 1867 1549 1554
-- Name: FK_IDUSER_PROJECT_SETTINGS1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dbatn_project_settings1
    ADD CONSTRAINT "FK_IDUSER_PROJECT_SETTINGS1" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


--
-- TOC entry 1881 (class 2606 OID 7847723)
-- Dependencies: 1554 1867 1550
-- Name: FK_IDUSER_PROJECT_SETTINGS2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dbatn_project_settings2
    ADD CONSTRAINT "FK_IDUSER_PROJECT_SETTINGS2" FOREIGN KEY (iduser) REFERENCES dbatn_userslist(iduser);


-- Completed on 2011-08-26 16:35:48

--
-- PostgreSQL database dump complete
--

