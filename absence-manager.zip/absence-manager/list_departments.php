<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");

	/** Create session object and try to load user info (id name etc from session) */
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();
	


	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
		exit();
	}

	# get rights of the user for departments
	$arrRights = getDepartmentRights($objSession->getUid());
#Save Settings

	$arrDepts = get_departments_from_db();
	ksort($arrDepts);
	
	$settings = getDepartmentSettings($objSession->getIdUser(),$objSession->getUid());
	$arrDeptsFromDB = $settings["dept"];
	
	$arrSearchDepts = array();
	if (!isset($_REQUEST["chrAction"])){ #on entry, the settings are applied and the suggested departments are shown
		$arrSearchDepts = $arrDeptsFromDB;
	}
	
	if ($_REQUEST["chrAction"] == "view_new_list") { #if View List has been clicked
		foreach ($_REQUEST['deptsSelected'] as $dp){
			$arrSearchDepts[$dp] = $dp;
		}
	}
	
	else if ($_REQUEST["chrAction"] == "save_settings"){
		$arrQueries = array();
		# first delete old settings
		$arrQueries[0] = "DELETE FROM dbatn_department_settings1 WHERE iduser=".$objSession->getIdUser();
		# Add new user settings, for department
    if($_REQUEST["deptsSelected"] != ''){
      foreach ($_REQUEST["deptsSelected"] as $ds){ 
        $arrSearchDepts[$ds] = $ds;	
        $arrQueries[] = "INSERT INTO dbatn_department_settings1(iduser,department) values(".$objSession->getIdUser().",'".$ds."') ";
      }
    }
		#if (sizeof($arrQueries) > 1 ){ # >2
			foreach ($arrQueries as $chrQuery){
				mazDb_query_params($chrQuery, array());
			}
		#}
		header("location: list_departments.php?msg=".urlencode("User settings updated successfully"));
		exit();
	}
#/Save Settings
#Delete list?! 
	else if ($_REQUEST["chrAction"] == "delete_list"){
		$intCount = $_REQUEST["dept_count"];
		$chrDepartment = "";
		for ($i = 0; $i < $intCount; $i++){
			if ($_REQUEST["dept".$i]){
				$chrDepartment = $_REQUEST["dept".$i];
			}
		}
		# if he do not have rights then give him error message
		if ($objSession->isAdminUser() == false && !in_array($chrDepartment,$arrRights["owner"]) && !in_array($chrDepartment,$arrRights["manager"])){
			header("location: list_departments.php?msg=".urlencode("Deletion Failed, Only Manager or Owner can delete this department"));
			exit();
		}

		# get all users of this departments
		$arrAllUsers = getMemebersOfDepartment($chrDepartment);

		$chrQuery = "SELECT iduser,uid,name FROM dbatn_userslist WHERE department=$1"; 
		$rs = mazDb_query_params($chrQuery, array($chrDepartment));
		$arrUsers = array();
		while($arr = mazDb_fetch_array($rs)){
			$arrUsers[$arr["iduser"]] = array($arr["uid"],$arr["name"]);
		}
		$arrNotDelete = array();

		#check for responsibilities
		foreach ($arrUsers as $idSelectedUser=>$arrInfo){
			#check member ownership of project
			$arrProjectOwners = getProjectWhosOwnerIam($idSelectedUser);
			if (sizeof($arrProjectOwners) > 0) {
				#$arrNotDelete[$arrInfo[0]]["project"] = array($arrInfo[1]=>$arr["name"],"owner"=>$arrProjectOwners);
				$arrNotDelete[$idSelectedUser] = $idSelectedUser;
				continue;
			}
			# check ownership of department
			$arrDepartmentOwners = getDepartmentsWhosOwnerIam($idSelectedUser);
			if (sizeof($arrDepartmentOwners) > 0) {
				#$arrNotDelete[$arrInfo[0]]["project"] = array($arrInfo[1]=>$arr["name"],"owner"=>$arrProjectOwners);
				$arrNotDelete[$idSelectedUser] = $idSelectedUser;
				continue;
			}
			# check manager of dept
			$arrDepartmentManager = getDepartmentsWhosManagerIam($idSelectedUser);
			if (sizeof($arrDepartmentManager) > 0) {
				#$arrNotDelete[$arrInfo[0]]["project"] = array($arrInfo[1]=>$arr["name"],"owner"=>$arrProjectOwners);
				$arrNotDelete[$idSelectedUser] = $idSelectedUser;
				continue;
			}
		}

		# delete those users which are not responsible for any thing
		$arrUsersToDelete = array_diff($arrAllUsers,$arrNotDelete);
		if (sizeof($arrUsersToDelete) > 0){
			$chrUsersToDelete = implode(",",$arrUsersToDelete);
			$chrQuery = "UPDATE dbatn_userslist SET department=null WHERE iduser IN ($chrUsersToDelete)";
			mazDb_query_params($chrQuery, array());
			if (sizeof($arrNotDelete) > 0){
				$msg = "Partial Deletion, some user(s) can not be deleted due to dependencies.";
			}
			else{
				$msg = "Full Deletion, successfull.";

				#delete associated dependencies to the department.
				$chrQuery = "DELETE FROM dbatn_department_manager WHERE chrdepartment=$1";
				mazDb_query_params($chrQuery, array($chrDepartment));

				$chrQuery = "DELETE FROM dbatn_department_owner WHERE chrdepartment=$1";
				mazDb_query_params($chrQuery, array($chrDepartment));
			}

		}
		else {
			$msg = "Cannot delete, due to user(s) dependencies.";
		}
		header("location: list_departments.php?msg=".urlencode($msg));
		exit();
	}
	#/Delete list
	header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("Department/Section List"); ?></title>
		<?php echo generateScripts(); ?>
<script type="text/javascript">

function changeSorter(value){
	$('#deptsSelected *').attr('selected', 'selected');
	$('#orderBy').attr('value', value);
	document.viewDeptsForm.submit();
}
function saveNewList(){
	document.viewDeptsForm.chrAction.value = "save_settings";
	$('#deptsSelected *').attr('selected', 'selected');
	document.viewDeptsForm.submit();
}

function viewNewList(){
	document.viewDeptsForm.chrAction.value = "view_new_list";
	$('#deptsSelected *').attr('selected', 'selected');
	if ($('#deptsSelected *').length > 0){
		document.viewDeptsForm.submit();
	} else {
		alert("You need to select at least one department.");
	}
}

function toggleSettingsArea(){
	$('#settingsArea').toggle();
}

	$(document).ready(function () {
		pageInit();
		var arrAllDepts = <?php echo createJSArray($arrDepts); ?>;
				var arrDeptsFromDB = <?php echo createJSArray($arrDeptsFromDB); ?>;
				var arrDeptsToView = <?php echo createJSArray($arrSearchDepts); ?>;
				
				populateList('deptsAll', arrAllDepts);
 
				<?php #Display the right department-selections in the selection box 
				if ($_REQUEST['chrAction'] == 'view_new_list'){ 
					echo "populateList('deptsSelected', arrDeptsToView);";
				} else {
					echo "populateList('deptsSelected', arrDeptsFromDB);";
				}
				?>
				connectFilterToList('deptFilter', 'deptsAll', arrAllDepts); //
   	});
   	

</script>
	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar">
					<img src="media/images/TextArea2.png" />&nbsp;
					<span class="pageheading"><span class="ericssonHeading">Department/Section List</span></span>
				</div>
				<div id="contentBody">
					
							<?php $self = 'list_departments.php'; ?>
							<form id="viewDeptsForm" name="viewDeptsForm" action="<?php echo $self ?>" method="post">
							<!-- Forts�tt p� det h�r sp�ret med $_POST .. -->
							<input type="button" value="Show/Hide Settings" name="settingsButton" onclick="toggleSettingsArea()" />
							<div id ="settingsArea">
								
								<h2>Departments/Sections</h2>
								<?php #added tuesday ?>
								<div class="chooseBox">
									<div class="left">
										<input type="hidden" name="chrAction" id="chrAction" value="view_new_list" />
										<label for="deptFilter">Available departments:</label>
										<input type="text" id="deptFilter" autocomplete="off" />
										<select id="deptsAll" multiple="multiple" size="6">
											<option value="-1">Loading...</option>
										</select>
									</div>
									<div class="center">
										<input type="button" value="&gt;" onclick="javascript:addItems('deptsAll', 'deptsSelected');" /><br />
										<br />
										<input type="button" value="&lt;" onclick="javascript:removeItems('deptsSelected');"/><br />
										<input type="button" value="&lt;&lt;" onclick="javascript:removeAll('deptsSelected');"/><br />
									</div>
									<div class="right">
										<label for="deptsSelected">Departments to view:</label><br />
										<select name="deptsSelected[]" id="deptsSelected" multiple="multiple" size="8">
											<option value="-1">Loading...</option>
										</select>
									</div>
									<!-- <br class="hard" /> -->
									<div class="formfooter">
										<input type="button" value="Save as Default" onclick="saveNewList()" /> <br /><br />
										<input type="button" class="viewSelectedBtn" value="View Selected Departments" onclick="viewNewList()" />
										<input type="hidden" name="orderBy" id="orderBy" value="name" />
									</div>
								</div>
							</div>
							</form>
							<?php #--------------------------------------------------------------------------------------------------- ?>
                            					<?php
												$nameSpan = "";#(sizeof($settings["col"]) == 0) ? "colspan=2" : ""; 
												#show columns headings as per user selection
												?>
    	                        				<table cellspacing="0" cellpadding="4" width="100%">        	                      					
                              						<?php
							  						$chrDepartmentList = "'".implode("','",$arrSearchDepts)."'";
							  						#$chrDepartmentList = "'FJG/DN'"; #Get found departments here!
											  		#sorting selection
												  	$chrOrderBy = "department,mdept,sdept";
												  	switch($_REQUEST["orderBy"]){
												  		case "name":
															$chrOrderBy = "department,mdept,sdept,name";
														break;
														case "uid":
															$chrOrderBy = "department,mdept,sdept,uid";
														break;
														case "email":
															$chrOrderBy = "department,mdept,sdept,email";
														break;
														case "city":
															$chrOrderBy = "department,mdept,sdept,city";
														break;
														case "erelation":
															$chrOrderBy = "department,mdept,sdept,erelation";
														break;
													}
												  	$arrDeptOwners = getAllDepartmentOwners();
													# Get users accroding to search criteria and sorting etc

													$chrQuery = "SELECT * FROM dbatn_userslist WHERE department IN ($chrDepartmentList) AND visible = TRUE ORDER BY $chrOrderBy"; #get all the users!
													$rs = mazDb_query_params($chrQuery, array());
													if (mazdb_num_rows($rs) > 0 && $chrDepartmentList != "''") {
														$counter=0;
														$chrOld = "";
														$blnCanView = true;
														while($arr = mazDb_fetch_array($rs)){
															$counter++;
															$arrTmp = $arrDeptOwners[$arr["department"]];
															$chrOwners = "";
															if (is_array($arrTmp)){
																foreach($arrTmp as $idx=>$chrName){
																	$arrTmp[$idx] = ($chrName); # utf8 encoding was applied
																}
																$chrOwners = "(".implode(",",$arrTmp).")";
															}
															$chrClass = "gridData1";
															if ($counter % 2 == 0){
																$chrClass = "gridData2";
															}
															if ($chrOld != $arr["department"]){
																$chrOld = $arr["department"];
																#calendar link is made here
																$chrEditLink = "<a href=\"edit_department.php?deptId=".urlencode($chrOld)."\"><img src=\"media/images/Tree.png\" border=\"0\" /></a>";
																$chrCalLink = "<a href=\"view_calendar.php?chrDepartment=".urlencode($chrOld)."\"><img src=\"media/images/cal.jpg\" border=0 /></a>";
																if ($objSession->isAdminUser() == false && !in_array($arr["department"],$arrRights["view"]) && !freeAccess($arr["department"])){
																	$blnCanView = false;
																	$chrCalLink = "&nbsp;";
																	$chrEditLink = "&nbsp;";
																}

																else {
																	$blnCanView = true;
																}
																?>
    		                                    				<tr>
	    		                                    				<td class="tableHeading2" colspan="5"> &nbsp; <?php echo $arr["department"]." &nbsp;&nbsp;&nbsp;Owner(s): ".$chrOwners ?></td>
    	    		                                				<td align="right" class="tableHeading2"><?php echo $chrCalLink; echo $chrEditLink; ?></td>
        	    		                            			</tr>
        	    		                            			<tr> <?php #gridHead ?>
		            	                    					<td class="gridHead" <?php #echo $nameSpan ?>>Display Name
		                	                						<img src="media/images/sort.png" border="0" onClick="changeSorter('name')" />
		                    	            					</td>
		                        	        					<?php
		                        	        						$intColumns = 5;
		                        	        					#if ( sizeof($settings["col"]) > 0 && in_array(0,$settings["col"])) { $intColumns++ 
			                                						?>	<td class="gridHead"> UID <img src="media/images/sort.png" border="0" onClick="changeSorter('uid')" /></td> <?php
		                                						 #} 
		                                						#if ( sizeof($settings["col"]) > 0 && in_array(1,$settings["col"])) { $intColumns++ 
		                	                						?> <td class="gridHead"> Email <img src="media/images/sort.png" border="0" onClick="changeSorter('email')" /></td> <?php
			                                					 #} 	
			                                					#if ( sizeof($settings["col"]) > 0 && in_array(2,$settings["col"])) { $intColumns++
		                    	            						?> <td class="gridHead"> City <img src="media/images/sort.png" border="0" onClick="changeSorter('city')" /></td> <?php
																#}
		                                						#if ( sizeof($settings["col"]) > 0 && in_array(3,$settings["col"])){ $intColumns++
		                                							?> <td class="gridHead"> Relation <img src="media/images/sort.png" border="0" onClick="changeSorter('erelation')" /></td> <?php
																#}
		            	                    					#if ( sizeof($settings["col"]) > 0 && in_array(4,$settings["col"])){ $intColumns++
		                	                						?> <td class="gridHead"> Department <img src="media/images/sort.png" border="0" onClick="changeSorter('department')" /></td> <?php
																#}
																?>
		                              						</tr>
            	    		                        			<?php
																if ($blnCanView == false) {
																	?>
                        	    		                			<tr>
                            	    		            				<td class="<?php echo $chrClass ?>" align="center" colspan="6"><span class="critical">Cannot view this department/section</span></td>
                                	    		        			</tr>
                                    	    		    			<?php
																}
															}
															if ($blnCanView == false) {
																continue;
															}
															?>
													  		<tr>
																<td class="<?php echo $chrClass ?>" <?php echo $nameSpan ?>><?php echo ($arr["name"]) ?></td>
																
															<?php #if ( sizeof($settings["col"]) > 0 && in_array(0,$settings["col"])) { ?>
                    	       			            				<td class="<?php echo $chrClass ?>"><?php echo $arr["uid"] ?></td>
                       			        	        				<?php
																#}
																?>
		                                        				<?php
	                                        					#if ( sizeof($settings["col"]) > 0 && in_array(1,$settings["col"])) {
	                                        						?>
																	<td class="<?php echo $chrClass ?>"><?php echo $arr["email"] ?></td>
	                    		                    				<?php
	            		                            			#}
	        		                                			?>
		            	                            			<?php
	        	        	                        			#if ( sizeof($settings["col"]) > 0 && in_array(2,$settings["col"])) {
	    	                	                    				?>
																	<td class="<?php echo $chrClass ?>"><?php echo ($arr["city"]) ?></td>
	                            	            					<?php
	                                	        				#}
	                                    	    				?>
	                                        					<?php
	                                        					#if ( sizeof($settings["col"]) > 0 && in_array(3,$settings["col"])) {
	                                        						?>
																	<td class="<?php echo $chrClass ?>"><?php echo $arr["erelation"] ?></td>
	                                	        					<?php
		                        	                			#}
	    	                	                    			?>
	        	        	                        			<?php
					                                			#if ( sizeof($settings["col"]) > 0 && in_array(4,$settings["col"])) {
	                	               								?>
																	<td class="<?php echo $chrClass ?>"><?php echo $arr["department"] ?></td>
	                	        	                				<?php
					                   	            			#}
	                       	        							?>
	                       	        						</tr>
														<?php
														}
																												
													}
													else{
														?>
			            	                  			<tr >
                	                						<td class="gridData2" colspan="6"> No Record found </td>
                    	          						</tr>
                	       				      			<?php
											  		}
										  			?>
			                            		</table>
                        					</div>							<!-- InstanceEndEditable -->
</table>
			</div>
		</div>
		<?php
			echo generateFooter();
			//Change html height to fit the new height (after calendar has been generated)
			echo '<script>';
			echo '$("html").css("height", $("#contentInner").height()+200);';
			echo '</script>';
		?>
</body>
</html>
