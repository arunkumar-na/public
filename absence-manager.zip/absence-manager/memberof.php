<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/menu.php");
	include_once("include/page.php");
	include_once("include/common.php");

	//print_r($_REQUEST);

	/** Create session object and try to load user info (id name etc from session) **/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
		exit();
	}

	if($_REQUEST['chrAction'] == "delete_proj"){
		$msg = deleteProject($_REQUEST['chrDeleteProj'], $objSession);
		header("location: memberof.php?msg=".$msg);
		exit();	
	}
	header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("Show Memberships"); ?></title>
		<?php echo generateScripts(); ?>
<script type="text/javascript">

function setOptions(fileName,chrAction,chrPrefix,intCount){
	blnCheckedAny = false;
	for (i = 0; i < intCount; i++){
		if (document.getElementById(chrPrefix+i).checked == true){
			blnCheckedAny = true;
			break;
		}
	}
	if (blnCheckedAny == true){
		document.frmList.action  = fileName;
		document.frmList.chrAction.value = chrAction;
		document.frmList.submit();
	}
	else{
		alert("Please select an option");
	}
}
function deleteProj(chrProj, type){
	if (confirm("Are you sure you want to delete this "+type))
	{
		document.frmList.action  = "memberof.php";
		document.frmList.chrAction.value = "delete_proj";
		document.frmList.chrDeleteProj.value = chrProj;
		document.frmList.submit();
	}
	else {
		return false;
	}
}
</script>
	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar">
					<img src="media/images/memberof2.png" />&nbsp;
					<span class="pageheading"><span class="ericssonHeading">Memberships</span></span>
				</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
	<tr>
    	<td valign="top" bgcolor="#505050" height="100%" >
    	<table cellpadding="0" cellspacing="" width="100%">
    		<tr>
       	  		<td colspan="3" valign="middle" class="mainToolbar">
       	  		<!-- InstanceBeginEditable name="toolbar-area" -->
       	  		<!-- InstanceEndEditable -->
       	  		</td>
        	</tr>
        	<tr>
          		<td bgcolor="#505050">&nbsp;</td>
            	<td class="workareaBox" valign="top">
    			<!-- ##################################	Working Area START ################################# -->
        			<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="1">
        				<!-- InstanceBeginEditable name="subheader section" -->
				  		<!-- InstanceEndEditable -->
      					<tr>
        					<td height="100%">		<!-- _____Contents START_____ -->
        	            		<div id="workingDiv" style="width:100%;height:<?php echo CALENDAR_HEIGHT ?>">
                				<table bgcolor="#505050" width="100%" height="100%" >
                    				<tr>
                        				<td style="padding-top:5px;">
                        				<!-- InstanceBeginEditable name="working-area" -->
                          				<form name="frmList" id="frmList" method="post" action="view_list.php">
                          					<input type="hidden" name="chrAction" id="chrAction" value="" />
                          					<input type="hidden" name="chrDeleteProj" id="chrDeleteProj" value="" />
					  						<?php
											/**
							 				* Get list of projects and department whos member is currently logged in user
							 				*/
					  						$iduser = $objSession->getIdUser();		# Read the department that the user is a member of

					  						$nrProjects=0;
					  						$nrDepartments = 0;
					  						$arrProjects = array();
						  					
					  						$chrQuery = "SELECT department,iduser FROM dbatn_userslist WHERE iduser=$1";
											$rs = mazDb_query_params($chrQuery, array($iduser));
											$blnDepartment = false;

											if (mazDb_num_rows($rs) > 0) {			# Prepare table row for Show Calendar button
												$departmentHTML='
																<tr>
				                            						<td class="gridHead">Department/Section</td>
									                            </tr>
				                    					        <tr>
									                            	<td class="text">';
												$arr = mazDb_fetch_array($rs);
												if ($arr["department"] == ""){
													$departmentHTML .= "You are not listed in any department.";
												}else{
													$departmentHTML .= "<input type='checkbox' value='".$arr["department"]."' id='dept0' name='dept0'> ".$arr["department"];													
													//$departmentHTML .= "<br><input type='button' value='Show Calendar' onClick=\"setOptions('view_calendar.php','view_list','dept',1)\" />";
													$nrDepartments = 1;
												}
												$departmentHTML .="</td>
																</tr>";
												$iduser = $arr["iduser"];
												$blnDepartment = true;
											}
											else {
												$departmentHTML = "not in system";
											}											
											if ($iduser > 0){
												//Read the groups that the user is a member of and add all groups parents to $arrProjects
												$groupHTML = "";
												$chrQuery = "SELECT chrproject, idproject, isgroup FROM dbatn_projects 
															WHERE idproject IN (SELECT idproject FROM dbatn_projectlist WHERE iduser=$1);";
												$rs = mazDb_query_params($chrQuery, array($iduser));
												if (mazDb_num_rows($rs) > 0) {
													$groupHTML .= "<tr>
																	<td class='gridHead'>Groups</td>
																</tr>
																<tr>
																	<td class='text'>";
													while($arr = mazDb_fetch_array($rs)){														
														$groupHTML .= "<input type='checkbox' value='".$arr['chrproject']."' id='proj".$nrProjects."' name='proj".$nrProjects."'>".$arr['chrproject']."<br><hr>";
														$arrProjects = array_merge($arrProjects, getParentProjects($arr['idproject'], array())); //add parents in $arrProjects
														$nrProjects++;
													}
													$groupHTML .= "</td>
																</tr>";
												} else {
													$groupHTML .= "<tr>
																	<td class='gridHead'>Groups</td>
																</tr>
																<tr>
																	<td class='text'> You are not member of any groups </td>
																</tr>";
												}

												//Create projects html
												$projectHTML = "";
												if(count($arrProjects)>0){
													$projectHTML =  "<tr>
																	<td class='gridHead'>Projects</td>
																</tr>
																<tr>
																	<td class='text'>";
													$addedProjects = array();
													for($i=0 ; $i<count($arrProjects) ; $i++) {
														if(!in_array($arrProjects[$i]['idproject'], $addedProjects)) {
															$projectHTML .= "<input type='checkbox' value='".$arrProjects[$i]['chrproject']."' id='proj".$nrProjects."' name='proj".$nrProjects."'>".$arrProjects[$i]['chrproject']."<br><hr>";
															$addedProjects[] = $arrProjects[$i]['idproject'];
															$nrProjects++;
														}
													}
													$projectHTML .= "</td>
																</tr>";
												} else {
													$projectHTML .= "<tr>
																	<td class='gridHead'>Projects</td>
																</tr>
																<tr>
																	<td class='text'> You are not member of any projects </td>
																</tr>";
												}

												//Read the groups/projects
												$projOwnerHTML = "";
												$chrQuery = "SELECT dbatn_projects.chrproject, dbatn_projects.idproject, dbatn_projects.isgroup FROM dbatn_projects INNER JOIN dbatn_project_owner
															ON
															dbatn_project_owner.idproject=dbatn_projects.idproject
															WHERE iduser=$1;";
												$rs = mazDb_query_params($chrQuery, array($iduser));												
												if (mazDb_num_rows($rs) > 0) {
													$projOwnerHTML = "<tr>
																		<td class='gridHead'>Groups/Projects</td>
																	</tr>
																	<tr>
																		<td class='text'>";
													while($arr = mazDb_fetch_array($rs)){
														if($arr['isgroup'] == 't') {
															$type = "group";
														} else {
															$type = "project";
														}
														$projOwnerHTML .= "<input type='checkbox' value='".$arr['chrproject']."' id='proj".$nrProjects."' name='proj".$nrProjects."'>".$arr['chrproject']." (".$type.")";
														//add edit links
														$projOwnerHTML .= "<span style='position:absolute;left:600px;'>";
														$projOwnerHTML .= "<a style='color:blue;' href='edit_project.php?chrProject=".urlencode($arr["chrproject"])."&chrAction=edit_list'>Edit</a>";
														$projOwnerHTML .= "&nbsp | &nbsp<a style='color:blue;' href='edit_ownership.php?chrProject=".urlencode($arr["chrproject"])."&chrAction=edit_ownership'>Ownership / Read access</a>";
														$projOwnerHTML .= "&nbsp | &nbsp<span class='pointerHand' style='color:blue;' onClick='deleteProj(\"".urlencode($arr["chrproject"])."\",\"".$type."\")'>Delete</span>";
														$projOwnerHTML .= "</span>";
														$projOwnerHTML .= "<br><hr>";
														$nrProjects++;
													}
													//$projOwnerHTML .= "<br><input type='button' value='Show Calendar' onClick=\"setOptions('view_project_calendar.php','search','proj',$nrOwnProjects)\" />";
													$projOwnerHTML .= "</td>
																	</tr>";
												}


												//Read the department that the user owns
												$arrDepartmentsOwnerManager = array();
												$depOwnerHTML="";											
												$chrQuery = "SELECT chrdepartment FROM dbatn_department_owner where iduser=$1";
												$rs = mazDb_query_params($chrQuery, array($iduser));
												if (mazDb_num_rows($rs) > 0) {
													while($arr = mazDb_fetch_array($rs)){
														if(!in_array($arr["chrdepartment"], $arrDepartmentsOwnerManager)){
															$depOwnerHTML .= "<input type='checkbox' value='".$arr["chrdepartment"]."' id='dept".$nrDepartments."' name='dept".$nrDepartments."'> ".$arr["chrdepartment"];
															//add edit links
															$depOwnerHTML .= "<span style='position:absolute;left:600px;'>";
															$depOwnerHTML .= "<a style='color:blue;' href='edit_department.php?deptId=".urlencode($arr["chrdepartment"])."'>Edit</a>";
															$depOwnerHTML .= "</span>";
															$depOwnerHTML .= "<br><hr>";
															$arrDepartmentsOwnerManager[] = $arr["chrdepartment"];
															$nrDepartments++;
														}
														
													}
												}
												//Read the departments that the user is manager over
												$depManagerHTML="";											
												$chrQuery = "SELECT chrdepartment FROM dbatn_department_manager where iduser=$1";
												$rs = mazDb_query_params($chrQuery, array($iduser));
												if (mazDb_num_rows($rs) > 0) {
													while($arr = mazDb_fetch_array($rs)){
														if(!in_array($arr["chrdepartment"], $arrDepartmentsOwnerManager)){
															$depManagerHTML .= "<input type='checkbox' value='".$arr["chrdepartment"]."' id='dept".$nrDepartments."' name='dept".$nrDepartments."'> ".$arr["chrdepartment"];
															//add edit links
															$depManagerHTML .= "<span style='position:absolute;left:600px;'>";
															$depManagerHTML .= "<a style='color:blue;' href='edit_department.php?deptId=".urlencode($arr["chrdepartment"])."'>Edit</a>";
															$depManagerHTML .= "</span>";
															$depManagerHTML .= "<br><hr>";
															$arrDepartmentsOwnerManager[] = $arr["chrdepartment"];
															$nrDepartments++;
														}
														
													}
												}

												//Put owner and manager together under the same tr
												$depManagerOwnerHTML = "";
												if($depOwnerHTML != "" || $depManagerHTML != ""){
													$depManagerOwnerHTML = "<tr>
																				<td class='gridHead'>Departments/ Sections</td>
																			</tr>
																			<tr><td class='text'>";
													$depManagerOwnerHTML .= $depOwnerHTML;
													$depManagerOwnerHTML .= $depManagerHTML;
													$depManagerOwnerHTML .= "</td></tr>";
												}
											}
											?>
                          					<table width="100%" cellpadding="4px" cellspacing="10px" bgcolor="#FFFFFF">                            
                            					<?php
                            						echo '<tr><td><span class="ericssonHeading">Member of:</span></td></tr>';
                            						echo $departmentHTML;
                            						echo $groupHTML;
                            						echo $projectHTML;
                            						if($depManagerOwnerHTML || $projOwnerHTML) {
	                            						echo '<tr><td><br><br><span class="ericssonHeading">Owner/Manager of:</span></td></tr>';
	                            						echo $depManagerOwnerHTML;
	                            						echo $projOwnerHTML;
	                            					}

                            						echo "<tr>
	                            							<td>
	                            								<input type='button' value='Show selected projects/groups' onClick=\"setOptions('view_project_calendar.php','search','proj',".($nrProjects).")\" />
	                            								<input type='hidden' value='".($nrProjects)."' id='proj_count' name='proj_count'>
	                            								<input type='hidden' value='".($nrDepartments)."' id='dept_count' name='dept_count'>
	                            								<input type='button' value='Show selected departments' onClick=\"setOptions('view_calendar.php','view_list','dept',$nrDepartments)\" />
	                            							</td>
                            							</tr>";

                            					?>
            								</table>
			                        	</form>
									  	<!-- InstanceEndEditable --></td>
            						</tr>
			                    </table>
            				    </div>			<!-- _____Contents End_____ -->
	        					</td>
      						</tr>
    					</table>
        				<!-- ##################################	Working Area END ################################# -->
          			</td>
            		<td bgcolor="#505050">&nbsp;</td>
          		</tr>
          	<tr>
          		<td bgcolor="#505050" colspan="3">&nbsp;</td>
          	</tr>
	  		</table>
  		</td>
	</tr>
</table>
			</div>
		</div>
		<?php echo generateFooter(); ?>
	</body>
</html>
