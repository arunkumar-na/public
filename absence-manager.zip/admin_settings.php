<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");

	/** Create session object and try to load user info (id name etc from session) **/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	#check user is logged in?
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		header("location: admin_login.php");
		exit();
	}
	#if not admin user then, dont display this page
	if ($objSession->isAdminUser() == false){
		echo "Access denied!";
		exit();
	}

	# if admin has requested for db deletion
	if ($_REQUEST["chrAction"] == "delete_database"){
	#	display($_REQUEST);
		$intDay 	= $_POST["intDay"];
		$intMonth 	= $_POST["intMonth"];
		$intYear 	= $_POST["intYear"];
       #         $intYear        = 2014;
		$inttime    = mktime(0,0,0,$intMonth,$intDay,$intYear);
#      display($intYear); 
		$CHRqUERY = "delete from DBATN_USERDAYS where INTTIME < $1";
       #         $CHRqUERY = "delete from DBATN_USERDAYS where intDay <= $intDay and intMonth <= $intMonth and intYear <= $intYear"; 
              # $CHRqUERY = "delete from DBATN_USERDAYS where intDay <= $1  and intMonth <= $2  and intYear <= $3 ";
#              $CHRqUERY = "delete from DBATN_USERDAYS where intYear =2014";
# $chrQuery = "Delete from  dbatn_userdays where "intDay" <= $intDay and "intMonth" <= $intMonth and "intYear" <= $intYear";
		mazDb_query_params($CHRqUERY, array($inttime));
#                mazDb_query($chrQuery);	
#                mazDb_query_params($CHRqUERY, array($intYear)); 
   #         mazDb_query_params($CHRqUERY, $intDay, $intMonth, $intYear);
#                 $arrdeleteUserDays = array();
# $arrdeleteUserDays[] = "DELETE FROM DBATN_USERDAYS WHERE "intDay" = $intDay and "intMonth" = $intMonth and "intYear" = $intYear;";
# foreach ($arrdeleteUserDays as $chrQuery) {
#                        mazDb_query_params($chrQuery, array());
#                }
	header("location: admin_settings.php?msg=".urlencode("Records deleted successfully"));
		exit();
	}
	header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("Admin Settings"); ?></title>
		<?php echo generateScripts(); ?>
		<script type="text/javascript">
			function confirmDelete(){
				if (confirm("Are you sure you want to delete records.")){
					return true;
				}
				return false;
			}
		</script>
	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar"><span class="pageheading">Admin Settings</span></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  	<tr>
    	<td valign="top" bgcolor="#505050" height="100%" >
    		<table cellpadding="0" cellspacing="" width="100%">
        		<tr>
          			<td bgcolor="#505050">&nbsp;</td>
            		<td class="workareaBox" valign="top">
    					<!-- ##################################	Working Area START ################################# -->
        				<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="1">
        					<!-- InstanceBeginEditable name="subheader section" -->
        					<!-- InstanceEndEditable -->
      						<tr>
        						<td height="100%">						<!-- _____Contents START_____ -->
            						<div id="workingDiv" style="width:100%;height:<?php echo CALENDAR_HEIGHT ?>">
                					<table bgcolor="#505050" width="100%" height="100%" >
                    					<tr>
                        					<td style="padding-top:1px;"><!-- InstanceBeginEditable name="working-area" -->
                           						<form name="frm1" method="post" action="admin_settings.php" onsubmit="return confirmDelete()">
                            						<input type="hidden" name="chrAction" id="chrAction" value="delete_database" />
                            						<table cellspacing="0" width="100%" bgcolor="#FFFFFF" cellpadding="5">
                            							<tr>
                            								<td>
                                  								<p>&nbsp;</p>
                                								<p>&nbsp;</p>
                            								</td>
                            							</tr>
                             							<tr>
                               								<td class="caption">&nbsp;</td>
                               								<td colspan="2" class="critical"><?php echo $_REQUEST["msg"] ?></td>
                              							</tr>
                             							<tr>
                               								<td class="caption">&nbsp;</td>
                             								<td colspan="2" class="caption">Delete Database before</td>
                              							</tr>
                                						<tr>
                                  							<td class="caption">&nbsp;</td>
                             								<td class="caption">date</td>
                                							<td>
																<select id="intDay" name="intDay"><?php daysCombo(date("d",time())); ?></select>
																
<select id="intMonth" name="intMonth">
<option value='1'>January</option>
<option value='2'>February</option>
<option value='3'>March</option>
<option value='4'>April</option>
<option value='5'>May</option>
<option value='6'>June</option>
<option value='7'>July</option>
<option value='8'>August</option>
<option value='9'>September</option>
<option value='10'>October</option>
<option value='11'>November</option>
<option value='12'>December</option></select>
<select id="intYear" name="intYear"><?php yearsCombo(date("Y",time()),2009); ?></select>
                                    						</td>
                             							</tr>
                             							<tr>
                               								<td width="24%">&nbsp;</td>
                              								<td width="11%">&nbsp;</td>
                              								<td width="65%"><input type="submit" value="Delete" /></td>
                              							</tr>
                              							<tr>
                                							<td></td>
                              								<td>
								                                <p>&nbsp;</p>
								                                <p>&nbsp;</p>
								                                <p>&nbsp;</p>
								                            </td>
                              							</tr>
                            						</table>
                            					</form>							<!-- InstanceEndEditable -->
                            				</td>
                        				</tr>
                    				</table>
                					</div>				<!-- _____Contents End_____ -->
        						</td>
      						</tr>
    					</table>
        				<!-- ##################################	Working Area END ################################# -->
          			</td>
            		<td bgcolor="#505050">&nbsp;</td>
          		</tr>
          		<tr>
          			<td bgcolor="#505050" colspan="3">&nbsp;</td>
          		</tr>
	  		</table>
    	</td>
  	</tr>
</table>
			</div>
		</div>
		<?php echo generateFooter(); ?>
	</body>
</html>
