<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");
	include_once("include/template.php");
	include_once("include/user.php");
	
	/** Create session object and try to load user info (id name etc from session) **/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
		exit();
	}
	# if user is not a legal manager
	if($objSession->getIsLegalManager() == 'f'){
		header("location: index.php");
		exit();
	}
	if ($_REQUEST["chrAction"] == "save_days"){
		# split marked days(might be for approval) from single string to into array of days
		$arrParam = explode("===_===",$_POST["chrParam"]);
		
		//Save user days in db and return array with info regarding the saving
		$saveDaysResult = saveUserDays($arrParam, $objSession, array());
		$arrUserDaysApproved = $saveDaysResult['arrUserDaysApproved'];
		$daysModified = $saveDaysResult['daysModified'];
		$userIsManager = $saveDaysResult['isManager'];

		if (sizeof($arrUserDaysApproved) > 0){
			/* 
			For email sent to the User whose days has been clicked. 
			If a manager is accessing then the email goes to the members whose days are selected. And if a non-manager is accesssing the mail goes to that non-manager as he can't select anyone else days, but only his days.
			*/
			$arrUserIds = array_keys($arrUserDaysApproved);
			# Get Email address of these ids with names
			$arrEmails = getEmailFromLoginId($arrUserIds);
			# Get users email settings, whos days are approved
			$arrUsersEmailSettings  = getUsersBulkEmailSettings($arrUserIds);
			#find out department whos reponse needs to retived
			$arrDepartmentsUsed = array();
			#display($arrUsersEmailSettings,"user email settings");
			# here we will get the departments from the list of users
			# whos days are approved, we get their departmentes
			# because afterward we will load their department settings for emails
			# and response text message for email body.
			foreach($arrUsersEmailSettings as $idSelectedUser=>$arrHisSettings){
				$arrDepartmentsUsed[$arrHisSettings["department"]] = $arrHisSettings["department"];
			}
			#display($arrDepartmentsUsed,"Used Departments");
			#get these departments email settings that need to be sent to the user
			$arrDepartmentEmailSettings = getDepartmentBulkMailSettings($arrDepartmentsUsed);
			#display($arrDepartmentEmailSettings,"Department Email Settings");
			#exit();
			if (sizeof($arrEmails) > 0 ) {
				include_once("include/cmail.php");
				#create mail object
				$objMail = new cMail();
				#if there are some approved days then loop on them
				#coz this array will contain the userinfo and his days info as well
				foreach($arrUserDaysApproved as $idUser=>$chrDaysApproved){
					
					$chrTo = $arrEmails[$idUser]["name"]." <".$arrEmails[$idUser]["email"].">";
					$chrSubject = "Absence Manager - Item Updated (". safeDatabase($objSession->getFullName()).")";
					# append mail body as per his department email settings
					$chrBody = "<P><h3>Absence Request:</h3></P>";
					$chrBody .= $arrDepartmentEmailSettings[$arrUsersEmailSettings[$idUser]["department"]]["chrReplayMsg"];
					# append what days approved with comments etc
					$chrCalendarLink = $objMail->createCalendarLink($objSession,$arrUsersEmailSettings[$idUser]["department"], $daysModified[$objSession->getIdUser()]);
					$chrBody .= "<br>\n".$chrDaysApproved;
					$chrBody .= "<br>\n".$chrCalendarLink;
					$chrFrom = "FROM : ".safeDatabase($objSession->getFullName())." <".$objSession->getEmailAddress().">";
					#if user has subscribed for approval notification then send him email otherwise not
					if ($arrUsersEmailSettings[$idUser]["blnResponse"] == true){
						$blnSent = $objMail->sendEmail($chrTo,$chrFrom,$chrSubject,$chrBody,$objSession);
						if ($blnSent != true){
							$chrMessage = "Some of the mails could not be sent, ".$objMail->getLastError();
						}# if
					}# if
				} #foreach
			} #if
			else {
				$chrMessage = "No Emails found";
			}			
		}
		$chrParam = "";		
		foreach($_REQUEST as $key=>$value){
			if ($key != "chrParam" && $key != "chrAction") {
				$chrParam .= $key."=".str_replace("/","_X_",$value)."&";
			}
		}
		header("location: peopleManagedCalendar.php?".$chrParam);
		exit();
	} else if ($_REQUEST["chrAction"] == "clear_days"){
		#if clear days request has been made
		#split user days into array, from a simple plain string
		$arrParam = explode("===_===",$_POST["chrParam"]);
		$arrQueries = array();
		foreach($arrParam as $eachRec){
			if ($eachRec){
				$arrDay = explode("-_-",$eachRec);
				$intDay = $arrDay[0];
				$intMonth = $arrDay[1];
				$intYear = $arrDay[2];
				$idUser = $arrDay[3];
				$arrQueries[] = "DELETE FROM dbatn_userdays WHERE \"idUser\"=$idUser AND \"intDay\"=$intDay  AND \"intYear\"=$intYear  AND \"intMonth\"=$intMonth";
			}#if there is record
		}#endforeach
		foreach($arrQueries as $chrQuery){
			mazDb_query_params($chrQuery, array());			
		}
		$chrParam = "";		
		foreach($_REQUEST as $key=>$value){
			if ($key != "chrParam" && $key != "chrAction") {
				$chrParam .= $key."=".str_replace("/","_X_",$value)."&";
			}
		}
		header("location: peopleManagedCalendar.php?".$chrParam);
		exit();
	}
	header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("People Managed Calendar"); ?></title>
		<?php echo generateScripts(); ?>
<script type="text/javascript">
$(document).ready(function () {
	setNewHeightAndWidth(225);
});

/*******************************/
N = (document.all) ? 0 : 1;
var ob;
var btnDown = false;

function MD(e){
	if (window.event.srcElement.tagName != "HTML") {
	 btnDown = true;
	}
}

document.oncontextmenu=new Function("return false");

function MM(){
	if (btnDown == true && document.getElementById("divComments").style.display != ""){
		//document.getElementById("tselect").focus();
		//document.focus();
		return false;
	}
}
function MU() {
	btnDown = false;
}

if (N) {
document.captureEvents(Event.MOUSEDOWN | Event.MOUSEMOVE | Event.MOUSEUP);
}
document.onmousedown = MD;
document.onmousemove = MM;
document.onmouseup = MU;

function mouseMoveSelection( obj ){
	if (btnDown == true) {
		//selectbox(obj);
	}
}

/*******************************/
var selectedOption = "";
var intBoxSelected = 0;
function closeDiv(){
	document.getElementById("divComments").style.display = "none";
}

function saveComments(){
	document.getElementById("divComments").style.display = "none";
	arrTds = document.getElementsByTagName("td");
	for(i=0; i<arrTds.length; i++) {
		if (arrTds[i].className == "selectedbox"){
			if (selectedOption != "edit_comments") {				
				arrTds[i].innerHTML = arrTds[i].getAttribute("dayValue")+"<br>"+selectedOption;
				arrTds[i].setAttribute("chrCharacter",selectedOption);				
			}
			arrTds[i].setAttribute("chrComments",document.getElementById("chrComments").value);
			arrTds[i].setAttribute("title",document.getElementById("chrComments").value);
			if (document.getElementById("chrComments").value == ""){
				arrTds[i].className = "dirty";
			}
			else{
				arrTds[i].className = "dirtyi";
			}
			//alert(arrTds[i].getAttribute("chrCharacter"));
		}
	}	
	applySettings(); /* auto matically apply settings */
}

/* ---------------------- */
function clearSelectedDays(){
	arrTds = document.getElementsByTagName("td");
	var str = "";
	for(i=0; i<arrTds.length; i++){
		if (arrTds[i].className == "selectedbox"){
			arrTds[i].className = "dirty";
			str += arrTds[i].getAttribute("dayValue")+"-_-"+arrTds[i].getAttribute("monthValue")+"-_-"+arrTds[i].getAttribute("yearValue")+"-_-"+arrTds[i].getAttribute("iduser")+"===_===";
		}
	}
	document.peopleManagedForm.chrAction.value = "clear_days";
	document.getElementById("chrParam").value=str;
	document.peopleManagedForm.submit();
}

function applySettings(){
	arrTds = document.getElementsByTagName("td");
	var str = "";
	for(i=0; i<arrTds.length; i++){
		if (arrTds[i].className == "dirty" || arrTds[i].className=="dirtyi"){
			str += arrTds[i].getAttribute("dayValue")+"-_-"+arrTds[i].getAttribute("monthValue")+"-_-"+arrTds[i].getAttribute("yearValue")+"-_-"+arrTds[i].getAttribute("chrCharacter")+"-_-"+arrTds[i].getAttribute("chrComments")+"-_-"+arrTds[i].getAttribute("iduser")+"===_===";
		}
		if (arrTds[i].className == "noteadded" || arrTds[i].className=="noteaddedi"){
			str += arrTds[i].getAttribute("dayValue")+"-_-"+arrTds[i].getAttribute("monthValue")+"-_-"+arrTds[i].getAttribute("yearValue")+"-_-"+arrTds[i].getAttribute("chrCharacter")+"-_-"+arrTds[i].getAttribute("chrComments")+"-_-"+arrTds[i].getAttribute("iduser")+"===_===";
		}
	}

	document.getElementById("chrParam").value=str;
	document.peopleManagedForm.chrAction.value = "save_days";

	document.peopleManagedForm.submit();
}

function saveBoxes(chrType) {
	var chrComments = "";
	if (chrType == "edit_comments" || chrType == "A" || chrType == "D"){
		arrTds = document.getElementsByTagName("td");
		for(i=0; i< arrTds.length; i++){
			if (arrTds[i].className == "selectedbox"){
				chrComments = arrTds[i].getAttribute("chrComments");
				break;
			}
		}
	}
	if (intBoxSelected > 0){
		document.getElementById("chrComments").value = chrComments;
		document.getElementById("divComments").style.display = "";
		selectedOption = chrType;
	}
	else{
		alert("Please select a day");
	}
}

function selectbox(objTd){
	//Get duplicate dayboxes if the same user is in more than one project
	var allCommonDayboxes = $("[name='"+objTd.getAttribute('name')+"']");

	if (objTd.className == "daybox" || objTd.className == "noteadded" || objTd.className == "noteaddedi" || objTd.className == "redday" || objTd.className == "reddayi" || objTd.className == "approved"){
		//set all duplicate/common boxes to selected aswell
		for(var i=0 ; i<allCommonDayboxes.length ; i++){
			allCommonDayboxes[i].setAttribute("class", "selectedbox common");
		}
		//set the original box to selected
		objTd.setAttribute("class", "selectedbox");
		intBoxSelected++;
	}
	else if (objTd.className == "selectedbox" || objTd.className == "selectedbox common"){
		for(var i=0 ; i<allCommonDayboxes.length ; i++){
			allCommonDayboxes[i].setAttribute("class", objTd.getAttribute("class2"));
		}
		intBoxSelected--;
	}
}


function findPos(obj){
    var curleft = curtop = 0;
    if (obj.offsetParent){
        do{
            curleft += obj.offsetLeft;
            curtop += obj.offsetTop;
        } while (obj = obj.offsetParent);
	}
	var offset = 0;
	if (navigator.appName == "Microsoft Internet Explorer"){
		offset = document.getElementById("workingDiv").scrollTop;
	}
	else{
		offset = document.getElementById("workingDiv").pageYOffset;
	}
	curtop -= offset;
    return [curleft,curtop];
}

function showToolTip(obj){
	var pos = findPos(obj);
	document.getElementById("manager_tool_tip").style.left = pos[0]+"px";
	document.getElementById("manager_tool_tip").style.top = pos[1]+"px";
	document.getElementById("manager_tool_tip").style.display = "";
}

function hideToolTip(obj){
	document.getElementById("manager_tool_tip").style.display = "none";
}

// To limit the number of input characters in the text field.
function limitText(limitField, limitNum) {
    if (limitField.value.length > limitNum) {
        limitField.value = limitField.value.substring(0, limitNum);
    }
	var charleft = limitNum - limitField.value.length;
	document.getElementById('charleft').innerHTML ='<strong>'+ charleft +'</strong>';
}
/*****************************************************************/

function setNewHeightAndWidth(tab) {
	$(".firstTd").css("padding-left", tab+"px");

	var calendarWidth = $('#toolbar').width()-50+'px';
	$('.outer').css("width", calendarWidth);
	$('.inner').css("width", calendarWidth);
	//$('.calendarTable').css("width", calendarWidth);

	//Make the fixed scroll control the tablescroll
	$(".outerScrollDiv").css("max-width", calendarWidth);
	$(".scrollDiv").css("width", $('.calendartable').width());
	$(".outerScrollDiv").scroll(
		function(){
			$(".inner").scrollLeft($(".outerScrollDiv").scrollLeft());
			btnDown = false;
		});

	//Change html height to fit the new height (after calendar has been generated)
	$("html").css("height", $('#contentInner').height()+400);
}
</script>
	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>

		<div id="rightClickMenu" class="rightClickMenu">                           				
		</div>

		<div id="chooseAbsence" class="chooseAbsence">
			<div class="chooseAlt chooseAltTop" onClick="saveBoxes('FL')">Full Day Leave</div>
			<div class="chooseAlt chooseAltRight" onClick="saveBoxes('H')">Few Hours</div>
			<div class="chooseAlt chooseAltLeft" onClick="saveBoxes('B')">Business Trip</div>
			<div class="chooseAlt chooseAltRight" onClick="saveBoxes('C')">Course</div>
		<!--	<div class="chooseAlt chooseAltLeft" onClick="saveBoxes('P')">Parental Leave</div>-->
		</div>
		
		<div id="content">
			<div id="contentInner">
				<div id="toolbar">
					<img src="media/images/TabNavigator2.png" />&nbsp;
					<span class="pageheading"><span class="ericssonHeading">People Managed</span>
						&nbsp; &nbsp; &nbsp; &nbsp;
						<input type="button" onclick="saveBoxes('FL')" value="FL" title="Full Day Leave" />
						<input type="button" onclick="saveBoxes('H')" value="1-8" title="Few Hours" />
						<input type="button" onclick="saveBoxes('B')" value="B" title="Business Trip" />
						<input type="button" onclick="saveBoxes('C')" value="C" title="Course" />
					<!--	<input type="button" onclick="saveBoxes('P')" value="PL" title="Parental Leave"/>-->						
						<input type="button" onclick="clearSelectedDays()" value="Clear Days" title="Clear Days"/>
						<input type="button" onclick="saveBoxes('edit_comments')" value="Edit Comments" title="Edit Comments" />												
						<?php
							if($objSession->getIsLegalManager() == 't') {
								echo '<input type="button" onclick="saveBoxes(\'A\')" value="Approve" title="Approve Request" />&nbsp;';
								echo '<input type="button" onclick="saveBoxes(\'D\')" value="Deny" title="Deny Request" />';
							}
						?>
					</span>
				</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  	<tr>
    	<td valign="top" bgcolor="#505050" height="100%" >
    		<table cellpadding="0" cellspacing="" width="100%">
        		<tr>
            		<td class="workareaBox" valign="top">
    				<!-- ################################## Working Area START ################################# -->
        				<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="1" class="contentTable">
        					<!-- InstanceBeginEditable name="subheader section" -->
	  						<!-- InstanceEndEditable -->
      						<tr>
        						<td height="100%">				<!-- _____Contents START_____ -->
        		            	<div id="workingDiv" style="width:100%;height:<?php echo CALENDAR_HEIGHT ?>">
                				<table bgcolor="#505050" width="100%" height="100%">
                    				<tr>
                        				<td style="padding-top:5px;">
                        				<!-- InstanceBeginEditable name="working-area" -->
                          				<div id="manager_tool_tip" class="msnuserbox" style="display:inline;position:absolute;width:300px;height:30px;left:-200px;top:-200px" onmouseout='hideToolTip(this)'>
                            			<table>
                            				<tr>
                                				<td class="critical">Only Managers can approve it</td>
                                			</tr>
                             			</table>
                             			</div>
                             			<div id="divComments" style="display:none;position:absolute;width:400px;left:200px;top:200px;">
                            			<table width="100%" bgcolor="#FEFBF3" style="border:1px solid #000000">
                                			<tr>
                                    			<td class="monthname">Add Comments</td>
                                			</tr>
                                			<tr>
                                    			<td><div style="font-size:10px;">Characters Left:<font size="2px" color="red"><span id="charleft">249(Max)</span></font></div>
													<textarea id="chrComments" name="chrComments" cols="40" rows="5" onKeyDown="limitText(this,249);" onKeyUp="limitText(this,249);"></textarea>
                                        			<br />
                                        			<input type="button" onclick="saveComments()" value="Save" /> <input type="button" onclick="closeDiv()" value="Cancel" />
                                        		</td>
                                			</tr>
                            			</table>
                            			</div>
                            			<div id="contentBody">
	                            			<?php

	                            				$today = date("Y-m-d");
	                            				$intFromMonth = null;
	                            				$intToMonth = NULL;
	                            				$intYear = null;
	                            				$intYear2 = null;

												if($_REQUEST["fromMonth"] && $_REQUEST["toMonth"] && $_REQUEST["intYear"] && $_REQUEST["intYear2"]) {
													$intFromMonth = $_REQUEST["fromMonth"];
													$intToMonth = $_REQUEST["toMonth"];
													$intYear = $_REQUEST["intYear"];
													if($intFromMonth <= $intToMonth) {
														$intYear2 = $_REQUEST["intYear2"];
													} else {
														$intYear2 = $_REQUEST["intYear"]+1;
													}
												} else {
													$intFromMonth = date("m",time());
													$intToMonth = date("m",strtotime("$today +1 month"));
													$intYear = date("Y",time());
													if($intFromMonth <= $intToMonth) {
														$intYear2 = date("Y",time());
													} else {
														$intYear2 = date("Y", strtotime("$today +1 year"));
													}
												}
												#if to year(end year) is less that from year(start year)
												# then make them same as Start year
												if ($intYear2 < $intYear){
													$intYear2 = $intYear;
													$intToMonth = $intFromMonth;
												}
												else if ($intYear2 > $intYear+1) {
													#if ending year is not next year make it next year
													# as we are allowed only one year accross the current year
													$intYear2 = $intYear+1;
												}
												$datePickerHTML = '
												<form id="peopleManagedForm" name="peopleManagedForm" action="peopleManagedCalendar.php" method="post">
													<div class="'.$datePickerClass.'">
														<div class="caption">From:</div>
														<div>'
															.monthsCombo("fromMonth", $intFromMonth)
															.yearsComboX("intYear",2000,date("Y",time())+10,$intYear)
														.'</div>
														<div class="caption">To:</div>
														<div>'
															.monthsCombo("toMonth", $intToMonth)
															.yearsComboX("intYear2",2000,date("Y",time())+10,$intYear2)
														.'</div>																		
													</div>
													<div><input type="submit" value="Search"/></div>
													<input type="hidden" name="chrAction" id="chrAction" value="" />
													<input type="hidden" name="chrParam" id="chrParam" value="" />	
												</form>';
												echo $datePickerHTML;
											?>

	        								<!-- Start, calendar part -->
	        								<form id="frmCSV" name="frmCSV" method="post" action="generate_csv.php" target="_blank">
												<div id="scrollingarea">
												<div class="outerScrollDiv"><div class='scrollDiv'>.</div></div>
												<div class='outer' bgcolor="#FFFFFF">											
													<div class='inner' bgcolor="#FFFFFF">
														<table class="calendartable" cellspacing="1" cellpadding="1" width="100%" bgcolor="#FFFFFF">

															<?php

															$iduser =  $objSession->getIdUser();							
															//Prepare varaibles for creating table
															$counter=0;
															$chrOld = "";
															$tabSize = 30;
															$deepestTab = 0;
															$csvData = "";

															$intColSpan = getTotalDays($intFromMonth,$intYear,$intToMonth,$intYear2) + 2;

															//Create html for people managed
															function createPeopleManagedHtml($managerUid){													
																global $objSession, $csvData, $intFromMonth, $intToMonth, $intYear, $intYear2;

																$hasAddedHeaderCsv = false;
																$chrQuery = "SELECT * FROM dbatn_userslist WHERE \"legalManager\" = '$managerUid'";
																$rs = mazDb_query_params($chrQuery, array());

																if(mazDb_num_rows($rs) > 0) {
																	//Get html for the date rows (above the user rows)

																	$intEndMonth = ($intYear == $intYear2) ? $intToMonth : $intToMonth+12;	

																	while($arr = mazDb_fetch_array($rs)){
																		if(!$hasAddedHeaderCsv) {
																			//Add project header to csv string
																			//$csvData .= "\n".$arr["chrproject"]. " (". str_replace(",","-",getAllProjectsOwnerString($groupId)) .")\n";
																			//Add date rows to group html
																			$html = createDateRowsHtml(null, $intFromMonth, $intEndMonth, $intYear, $intYear2);
																			$hasAddedHeaderCsv = true;
																		}									
																		$html .= '<tr id="m" bgcolor="#FFFFFF">';
																		$html .= '<td class="fixedTd" title="' . $arr["uid"] . '">
																			<div class="personname" style="margin-left: 10px;">'. str_replace(" ","&nbsp;",($arr["name"])." (<span><i>".$arr["department"].")") .'</div></td>';
																		$html .= "</i></span><td class='firstTd'></td>";
																		
																																			
																		$arrUserDays[$intYear] = getUserAndTemplateDays( $arr["iduser"], $intYear );
																		$arrUserDays[$intYear2] = getUserAndTemplateDays( $arr["iduser"], $intYear2 );
																		
																		$csvUserDays = "";
																		
																		for($i = $intFromMonth; $i <= $intEndMonth ; $i++){
																			$intSelectedMonth = $i;
																			$intSelectedYear = $intYear;
																			if ($i > 12) {
																				$intSelectedMonth = $i-12;
																				$intSelectedYear = $intYear2;
																			}
																			$month = date("M",time(1,1,1,$intSelectedMonth,1,$intSelectedYear));
																			$arrThisMonth = $arrUserDays[$intSelectedYear][intval($intSelectedMonth)];
																			$chrExtraParams = "iduser=".$arr["iduser"];
																			$blnAllowEditing = false;
																			if ($arr['legalManager'] == $objSession->getUid()){
																				$blnAllowEditing = true;
																			}
																			# draw month
																			$arrData = drawMonthUserDays($arr["iduser"], $intSelectedMonth, $intSelectedYear, $arrThisMonth, $chrExtraParams, $blnAllowEditing);
																			$html .= $arrData["html"];
																			$csvUserDays .= $arrData["csv"];
																		}#endfor month loop
																		$csvData .= $arr["name"].",".$csvUserDays."\n";
																		$html .= "</tr>"; //End user table row
																	}
																}
																return $html;
															}

															//Get people managed
															if($objSession->getUid()) {
																echo createPeopleManagedHtml($objSession->getUid());
															}										

															?>
															<input type="hidden" name="csvData" value="<?php echo trim($csvData) ?>" />
														</table>											
													</div>
													</div>
												</div>
	                            				<input type="submit" value="Generate CSV" />
	                            			</form>
	                            		</div>
                        				<!-- InstanceEndEditable --></td>
                        			</tr>
                    			</table>
                			</div>										<!-- _____Contents End_____ -->
						</td>
      				</tr>
    			</table>
        		<!-- ##################################	Working Area END ################################# -->
          	</td>
          </tr>
	  </table>
    </td>
  </tr>
</table>
			</div>
		</div>
		<?php echo generateFooter(); ?>
	</body>
</html>
