<?php
	/**
 	 * List of department and projects displayed to user
 	 * when he selects from the memberof page
 	 */
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/menu.php");
	include_once("include/page.php");

	/** Create session object and try to load user info (id name etc from session) **/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
		exit();
	}

	header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("View List"); ?></title>
		<?php echo generateScripts(); ?>
	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar">
					<img src="media/images/TextArea2.png" /> &nbsp;
					<span class="pageheading"><span class="ericssonHeading">View List</span></span>
       	  		</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  	<tr>
    	<td valign="top" bgcolor="#505050" height="100%" >
    		<table cellpadding="0" cellspacing="" width="100%">
        		<tr>
          			<td bgcolor="#505050">&nbsp;</td>
            		<td class="workareaBox" valign="top">
	    				<!-- ##################################	Working Area START ################################# -->
        				<table width="100%" height="100%" border="0" cellspacing="5" cellpadding="5">
        					<!-- InstanceBeginEditable name="subheader section" -->
	  						<!-- InstanceEndEditable -->
      						<tr>
        						<td height="100%">		<!-- _____Contents START_____ -->
            						<div id="workingDiv" style="width:100%;height:<?php echo CALENDAR_HEIGHT ?>">
                					<table bgcolor="#505050" width="100%" height="100%" >
                    					<tr>
                        					<td style="padding-top:5px;"><!-- InstanceBeginEditable name="working-area" -->
                            					<table cellspacing="0" width="98%" cellpadding="2">
                              						<tr>
                        						        <td class="gridHead">Name</td>
						                                <td class="gridHead">UID</td>
                        						        <td class="gridHead">Email</td>
						                                <td class="gridHead">City</td>
                        						        <td class="gridHead">Relation</td>
						                                <td class="gridHead">Department</td>
						                                <td class="gridHead">Phone</td>
                              						</tr>
                              						<tr>
                             							<td class="formheading" bgcolor="#FFFFFF" style="height:20px" colspan="7">Departments/Sections</td>
                             						</tr>
                              						<?php
                              						#$_POST["dept0"] = 'FJG/DN';
													if ($_POST["dept0"]){
														# get list of users for his department
														$dept = $_POST["dept0"];
														$chrQuery = "SELECT * FROM dbatn_userslist where department=$1 AND visible = TRUE ORDER BY department";
														$rs = mazDb_query_params($chrQuery, array($dept));
														if (mazDb_num_rows($rs) > 0){
															$oldName = "";
															# show all users in his department
															while($arr = mazDb_fetch_array($rs)){
																$counter++;
																$chrClass = "gridData1";
																if ($counter % 2 == 0){
																	$chrClass = "gridData2";
																}
																if ($oldName != $arr["department"]){
																	$chrCalLink = "<a href='view_calendar.php?chrDepartment=".$arr["department"]."'><img src=\"media/images/cal.jpg\" border=0 /></a>";
																	?>
                				                                	<tr>
                                						                <td class="gridDataSelected" style="height:20px" colspan="6"> &nbsp;<?php echo $arr["department"] ?></td>
                                                 						<td class="gridDataSelected" align="right"><?php echo $chrCalLink ?></td>
                                                					</tr>
                                                					<?php
																	$oldName = $arr["department"];
																}
																?>
                                             					<tr>
                                                					<td class="<?php echo $chrClass ?>"><?php echo ($arr["name"]) ?></td>
					                                                <td class="<?php echo $chrClass ?>"><?php echo $arr["uid"] ?></td>
                    					                            <td class="<?php echo $chrClass ?>"><?php echo $arr["email"] ?></td>
                                        					        <td class="<?php echo $chrClass ?>"><?php echo ($arr["city"]) ?></td>
					                                                <td class="<?php echo $chrClass ?>"><?php echo $arr["erelation"] ?></td>
                    					                            <td class="<?php echo $chrClass ?>"><?php echo $arr["department"] ?></td>
                                        					        <td class="<?php echo $chrClass ?>"><?php echo $arr["phone"] ?></td>
				                                              </tr>
                					                          <?php

															}#wend
														}
														else{
															echo "No Records for department";
														}
													}
							  						?>
                              						<tr >
                                						<td  colspan="7" class="gridEmpty" align="center"> - </td>
                              						</tr>
                               						<tr>
                             							<td class="formheading" bgcolor="#FFFFFF" style="height:20px" colspan="7"> Project Groups </td>
                             						</tr>
                              						<?php
                              						if ($_POST["proj_count"] > 0){
														# if any projects were selected
														$arrProjects = array();
														for ($x = 0; $x < $_POST["proj_count"]; $x++){
															if ($_POST["proj$x"]){
																$arrProjects[] = $_POST["proj$x"];
															}
														}
														if (sizeof($arrProjects) > 0 ){
															# get list of users project(for which he is member)
															# and retrives the user lists in those projects
															$chrProjects = "'".implode("', '",$arrProjects)."'";
															$chrQuery = "SELECT dbatn_userslist.*,dbatn_projectlist.chrproject FROM dbatn_userslist,dbatn_projectlist
																WHERE dbatn_userslist.iduser=dbatn_projectlist.iduser
																AND chrproject IN ($chrProjects) ORDER BY dbatn_projectlist.chrproject";
															$rs = mazDb_query_params($chrQuery, array());
															if (mazDb_num_rows($rs) > 0){
																$oldName = "";
																while($arr = mazDb_fetch_array($rs)){
																	$counter++;
																	$chrClass = "gridData1";
																	if ($counter % 2 == 0){
																		$chrClass = "gridData2";
																	}
																	#detect if project is changed then, insert project name bar
																	if ($oldName != $arr["chrproject"]){
																		#show calendar link
																		$chrCalLink = "<a href='view_project_calendar.php?chrAction=single&chrProject=".$arr["chrproject"]."'><img src=\"media/images/cal.jpg\" border=0 /></a>";
																		?>
                        						                        <tr>
                                                							<td class="gridDataSelected" style="height:20px" colspan="6"> &nbsp;<?php echo $arr["chrproject"] ?></td>
                                                 							<td class="gridDataSelected" align="right"><?php echo $chrCalLink ?></td>
                                                						</tr>
                                                						<?php
																		$oldName = $arr["chrproject"];
																		$counter = 1;
																	}
																	?>
                                             						<tr>
					                                                	<td class="<?php echo $chrClass ?>"><?php echo ($arr["name"]) ?></td>
	                    					                            <td class="<?php echo $chrClass ?>"><?php echo $arr["uid"] ?></td>
    	                                    					        <td class="<?php echo $chrClass ?>"><?php echo $arr["email"] ?></td>
						                                                <td class="<?php echo $chrClass ?>"><?php echo ($arr["city"]) ?></td>
            	        					                            <td class="<?php echo $chrClass ?>"><?php echo $arr["erelation"] ?></td>
                	                        					        <td class="<?php echo $chrClass ?>"><?php echo $arr["department"] ?></td>
						                                                <td class="<?php echo $chrClass ?>"><?php echo $arr["phone"] ?></td>
                    						                        </tr>
                            	            					    <?php
																}#wend
																
															}
															else {
																echo "No Records for department";
															}
								  						}#end if project count								  						
													}# end if is there any project													
													?>
							 						<tr >
                                						<td bgcolor="#569633" colspan="7" class="gridData2"> - </td>
                              						</tr>
                            					</table>
                        						<!-- InstanceEndEditable --></td>
                        					</tr>
                    				</table>
                					</div>
							    </td>		<!-- _____Contents End_____ -->
      						</tr>
    					</table>
    					<!-- ##################################	Working Area END ################################# -->
          			</td>
            		<td bgcolor="#505050">&nbsp;</td>
          		</tr>
          		<tr>
          			<td bgcolor="#505050" colspan="3">&nbsp;</td>
          		</tr>
	  		</table>
    	</td>
  	</tr>
</table>
			</div>
		</div>
		<?php echo generateFooter(); ?>
	</body>
</html>
