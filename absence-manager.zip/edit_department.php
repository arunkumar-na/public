<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");
	include_once("include/model.php");
	include_once("include/usersync.php");
	include_once("include/template.php");

	/** Create session object and try to load user info (id name etc from session) **/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();

	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		header("location: ldap_do_login.php?requrl=".$_SERVER['REQUEST_URI']);
		#redirect('ldap_do_login.php');
	}

	$objDept = NULL;
	$chrMessage = NULL; // TODO: Should have different types of messages (and different backgrounds): error, warning, info

	if (isset($_POST['action'])){
		$chrAction = $_POST['action'];
	 	if ($chrAction == 'import'){
	 		$deptName = $_POST['deptName'];

	 		$objDept = getDepartmentByName(strtoupper($deptName));
	 		$arrDeptUsers = $objDept->getUsers();	 		
	 		if (sizeof($arrDeptUsers) > 0){
				$chrMessage = "Department already exists.";
			}
			else{
				$objDept = importDepartment($_POST['deptName']);
				$objDept->syncDepartment(true);
				$objDept->save();
				$chrMessage = 'Department imported successfully. Please check that the managers and owners are set correctly.';
			}
		}
		else { # save
			# These functions are only available to department owners and admins
			$idDept = $_POST['deptId'];
			$objDept = getDepartment($idDept);

			if ($objSession->isAdminUser() || $objDept->isOwner($objSession->getIdUser()) || $objDept->isManager($objSession->getIdUser())){
				if ($chrAction == 'update'){
					

					$query = "DELETE FROM dbatn_department_free_access WHERE chrDepartment = $1";
					$rs = mazDb_query_params($query, array($objDept->getID()));
								
					if(isset($_POST['freeaccess'])){
						$query = "INSERT INTO dbatn_department_free_access(chrDepartment,freeaccess)VALUES($1,true)";
						$rs = mazDb_query_params($query, array($objDept->getID()));
					}

					# Update users & managers & owners
					$arrOwners = (isset($_POST['ownerTable']) ? $_POST['ownerTable'] : array());
					$arrUsers = (isset($_POST['userTable']) ? $_POST['userTable'] : array());
					//print_r($_POST['ownerTable']);
					foreach ($arrOwners as $idUser => $arrUser) {
							$chrUserID = $arrUser['uid'];
							$user = getOrImportUser($chrUserID); #either gets existing user or imports a new one
							$objDept->setOwner($user->getID(), ((isset($arrUser['owner']) && ($arrUser['owner'] == 'on')) ? true : false));
							$objDept->setManager($user->getID(), ((isset($arrUser['manager']) && ($arrUser['manager'] == 'on')) ? true : false));
							if (isset($arrUser['deleted']) && $arrUser['deleted'] != 0){
								$objDept->setOwner($idUser, false);
								$objDept->setManager($idUser, false);
							}
					}
					$pluralUser = " was";
					$notAddedUsers = array();
					$chrMessage = 'Department saved successfully';
					# Update regular users
					foreach ($arrUsers as $idUser => $arrUser){
						$chrUserID = $arrUser['uid'];
						$user = getOrImportUser($chrUserID);

						#update visibilities
						if($user->isVisible() && isset($arrUser['visible']) == false && !$user->isExternal()){ #internal users that have been checked
							$objDept->unCheckUser($user);
						}
						else if (!$user->isVisible() && isset($arrUser['visible'])) { #internal users that have been unchecked
							$objDept->checkUser($user);
						}
						
						if (isset($arrUser['deleted']) && $arrUser['deleted'] != 0){
							# The user shall be removed from the department
							$objDept->removeUser($idUser);
						}
						
						else if (is_string($idUser) && (substr($idUser, 0, 3) == 'new')){
							# Create a new user
							$chrUserID = $arrUser['uid'];
							#display($arrUser,"arrUser");
							$user = getOrImportUser($chrUserID);
							#echo "external: ".$user->isExternal();
							#echo "visible: ".$user->isVisible();
							
							if ($user->isExternal()){ #only external users can be added
								$objDept->addUser($user); #adds the user with idUser to $arrAddedUsers[] in objDept.
								$objDept->claimUser($user); #sets the department for the external user to $objDept
								
							}
							else {#if not external user, prepare error message
								$notAddedUsers[] = safeHTML($user->getFullName());
								
							}
							if (sizeof($notAddedUsers)>0){#if any internal users, set new message
								if (sizeof($notAddedUsers)>1){
									$pluralUser = "s were";
								}
								$chrMessage = 'Only external users can be added. The following user'.$pluralUser.' not added: ';	
								$chrMessage .= implode(", ",$notAddedUsers);
							}

						}
					}
					# Update read access
					$arrAllowedDepts = (isset($_POST['deptsSelected']) ? $_POST['deptsSelected'] : array());
					$arrAllowedGroups = (isset($_POST['groupsSelected']) ? $_POST['groupsSelected'] : array());
					$objDept->setAllowedDepts($arrAllowedDepts);
					$objDept->setAllowedGroups($arrAllowedGroups);

					# Update email settings
					$objDept->setRequireEmail(isset($_POST['emailRequired']));
					$objDept->setAutoApprove(isset($_POST['autoApprove']));
					$objDept->setConfirmationMessage($_POST['confirmationMessage']);
					$objDept->setReplyMessage($_POST['replyMessage']);
					
					# Update holiday template
					$objDept->setRedDayTemplate($_POST['redDayTemplate']);

				}
				else if (isset($_POST['reload'])){
					# Update with information from LDAP
					$chrMessage = syncUsers($objDept);
					#$chrMessage = 'The department has been updated with information from HRMS';
				}
				else if (isset($_POST['delete'])){
					# Delete the department
					deleteDepartment($idDept);
					redirect('edit_department.php');
				}

				if ($objDept){
					$objDept->save();
				}
			}
		}
	}
	else if (isset($_GET['deptId']) && $_GET['deptId'] != ''){
		# Display the editing page for the specified department
		$idDept = $_GET['deptId'];
		$objDept = getDepartment($idDept);
	}

	# Check user permissions
	$blnView = false;
	$blnEdit = false;
	$chrDisabled = 'disabled="disabled"';

	if ($objDept){
		$idUser = $objSession->getIdUser();
		if ($objSession->isAdminUser() || $objDept->isOwner($idUser) || $objDept->isManager($idUser)){
			$blnView = true;
			$blnEdit = true;
			$chrDisabled = '';
		}
		else if ($objDept->isVisibleTo($idUser)){ #isVisibleTo always returns true at the moment.
			$chrMessage .= ' Only owners and administrators can edit department settings';
			$blnView = true;
		}
		else {
			$chrMessage = 'You are not allowed to view this department';
			$objDept = NULL; # Do not display an editing page
		}
	}

	$arrDepts = get_departments_from_db();
	ksort($arrDepts);

	$self = 'edit_department.php';
	$title = 'Edit Department';
	if ($objDept){
		$self .= '?deptId='.safeHTML($objDept->getID());
		$title .= (' ' . $objDept->getName());
		$arrAllowedDepts = $objDept->getAllowedDepts();
		$arrAllowedGroups = $objDept->getAllowedGroups();
		$arrGroups = get_projects_from_db();
		ksort($arrGroups);
	}

	header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle($title); ?></title>
		<?php echo generateScripts(); ?>
		<script type="text/javascript">
			var arrDepts = <?php echo createJSArray($arrDepts); ?>;

			<?php if (!$objDept){ ?>

		   	$(document).ready(function () {
				populateList('departments', arrDepts);
				connectFilterToList('deptFilter', 'departments', arrDepts);
				setTimeout(function (){
					$('#message[display!="none"]').fadeOut(2*1000);
				}, 6*1000);
		   	});

		   	function findDepartment() {
				searchDepartments(function (arrSelected){
					if (arrSelected.length > 0){
						$('#deptName').val(arrSelected[0].department);
            $('#deptNameGui').val(arrSelected[0].department);
					}
				});
		   	}

		   	<?php } else { ?>

		   	var arrGroups = <?php echo createJSArray($arrGroups); ?>;
		   	var arrAllowedGroups = <?php echo createJSArray($arrAllowedGroups); ?>;
			var arrAllowedDepts = <?php echo createJSArray($arrAllowedDepts); ?>;

			$(document).ready(function () {
				pageInit();
				$('.visibility').change(updateColors);
				$('form').bind('reset', function () {
					setTimeout(function () {
						$('.deleted').val('0');
						populateList('deptsSelected', arrAllowedDepts);
						populateList('groupsSelected', arrAllowedGroups);
						updateColors();
					}, 1);
				});
				$('#contentBody form').submit(function () {
					$('#deptsSelected *').attr('selected', 'selected');
					$('#groupsSelected *').attr('selected', 'selected');
				});
				$('#emailRequired').click(function (){
					if ($(this).is(':checked')) {
						$('#autoApprove').removeAttr('checked');
					}
					else {
						$('#autoApprove').attr('checked', 'checked');
					}
					showHideAutoApprove();
				});
				showHideAutoApprove();

				$('.userTable').each(function (){
					$(this).tablesorter({
						headers: {
							2: { sorter: false },
							3: { sorter: false },
							4: { sorter: false }
						},
						cssAsc: 'tableHeaderSortUp',
						cssDesc: 'tableHeaderSortDown',
						cssHeader: 'tableHeader',
						sortList: [[0, 0], [1, 0]]
					});
					$(this).bind('sortEnd', updateColors);
				});
				updateColors();

				populateList('deptsAll', arrDepts);
				populateList('deptsSelected', arrAllowedDepts);
				connectFilterToList('deptFilter', 'deptsAll', arrDepts);

				populateList('groupsAll', arrGroups);
				populateList('groupsSelected', arrAllowedGroups);
				connectFilterToList('groupFilter', 'groupsAll', arrGroups);

				$('#btnDelete').click(function (){
					if (!confirm('Are you sure you want to delete this department?')){
						return false;
					}
				});
			});

			function showHideAutoApprove(){
				var emailRequired = $('#emailRequired');
				if (emailRequired.is(':checked')) {
					$('#autoApproveContainer').hide();
				}
				else {
					$('#autoApproveContainer').show();
				}
			}

			function updateColors() {
				$('.userTable tbody tr:even').css('background-color', '#d0dff0');
				$('.userTable tbody tr:odd').css('background-color', 'white');
				$('.visibility:not(:checked)').parents('.userRow').css('background-color', '#a0afc0');
				$('.deleted[value="1"]').parents('.userRow').css('background-color', 'red');
			}

			var newUserCount = 0;
			var NEW_PREFIX = 'new';

			function deleteUser(index, tableType) {
					//these are users that have been imported to the database already
					var input = $('#'+tableType+'_deleted_'+index);
					var wasDeleted = parseInt(input.val());
					input.val(wasDeleted == 0 ? 1 : 0);

					updateColors();

					//This user was added to the UI, but not yet to the database
					if (index.substr(0, NEW_PREFIX.length) === NEW_PREFIX) $('#'+tableType+'_row_'+index).remove();
			}

			function findUsers() {
				searchUsers(function (arrSelected) {
					var pfURL = "<?php echo safeHTML(PEOPLE_FINDER_FORMAT); ?>";
					for (var i = 0; i < arrSelected.length; i++) {
						var user = arrSelected[i];
						
						if ($('#userTable > input[type="hidden"][value="'+user.uid+'"]').length > 0){
							// This user is already a member of the department
							continue;
						}

						var url = $.sprintf(pfURL, user.uid);
						var id = NEW_PREFIX + (++newUserCount);
						
						$('#userTable > tbody').append($('<'+'tr><'+'/tr>').attr({'class': 'userRow', 'id': 'userTable_row_'+id})
							.append($('<'+'td><'+'/td>')
									.append($('<'+'a><'+'/a>').attr({'class': 'newWindow', 'href': url}).text(user.name)))
							.append($('<'+'td><'+'/td>')
								.append($('<'+'a><'+'/a>').attr({'class': 'newWindow', 'href': url}).text(user.uid))
								.append($('<'+'input><'+'/input>').attr({'name': 'userTable['+id+'][uid]', 'value': user.uid, 'type': 'hidden'})))
								//.append($('<'+'input><'+'/input>').attr({'name': 'userTable['+id+'][owner]', 'type': 'checkbox'})))
							//.append($('<'+'td><'+'/td>')
									//.append($('<'+'input><'+'/input>').attr({'name': 'userTable['+id+'][manager]', 'type': 'checkbox'})))
							.append($('<'+'td><'+'/td>'))
							.append($('<'+'td><'+'/td>')
									.append($('<'+'a><'+'/a>').attr({'class': 'deleteIcon', 'href': 'javascript:deleteUser(\''+id+'\',\'userTable\')'}).text(' ')))
						);
					}
					$('#userTable').trigger('update');
				});
			}

			function findOwners() {
			// 	reuse code by merging with findUsers 
				searchUsers(function (arrSelected) {
					var pfURL = "<?php echo safeHTML(PEOPLE_FINDER_FORMAT); ?>";
					for (var i = 0; i < arrSelected.length; i++) {
						var user = arrSelected[i];
						
						if ($('#ownerTable > input[type="hidden"][value="'+user.uid+'"]').length > 0){
							// This user is already a member of the department
							continue;
						}
						var url = $.sprintf(pfURL, user.uid);
						var id = NEW_PREFIX + (++newUserCount);
						$('#ownerTable > tbody').append($('<'+'tr><'+'/tr>').attr({'class': 'userRow', 'id': 'ownerTable_row_'+id})
							.append($('<'+'td><'+'/td>')
									//.append($('<'+'input><'+'/input>').attr({'class':'visibility', 'name':'ownerTable['+id+'][visible]','type':'checkbox','checked':'checked'}))
									.append($('<'+'a><'+'/a>').attr({'class': 'newWindow', 'href': url}).text(user.name)))
							.append($('<'+'td><'+'/td>')
								.append($('<'+'a><'+'/a>').attr({'class': 'newWindow', 'href': url}).text(user.uid))
								.append($('<'+'input><'+'/input>').attr({'name': 'ownerTable['+id+'][uid]', 'value': user.uid, 'type': 'hidden'})))
							.append($('<'+'td><'+'/td>')
								.append($('<'+'input><'+'/input>').attr({'name': 'ownerTable['+id+'][owner]', 'type': 'checkbox', 'checked':'checked'})))
							.append($('<'+'td><'+'/td>')
									.append($('<'+'input><'+'/input>').attr({'name': 'ownerTable['+id+'][manager]', 'type': 'checkbox', 'checked':'checked'})))
							.append($('<'+'td><'+'/td>')
								.append($('<'+'a><'+'/a>').attr({'class': 'deleteIcon', 'href': 'javascript:deleteUser(\''+id+'\',\'ownerTable\')'}).text(' ')))
						);
					}
					$('#ownerTable').trigger('update');
				});
			}
			<?php } ?>
		</script>
	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar">
					<img src="media/images/edit.png" />&nbsp;
					<span class"pageHeading">
						<span class="ericssonHeading"><?php echo $title; ?></span>
					</span>
					<?php if ($objDept) { ?>
					<form action="<?php echo $self ?>" method="post">
						<div>
							<input type="hidden" name="action" value="toolbar" />
							<input type="hidden" name="deptId" value="<?php echo $objDept->getID(); ?>" />
							<input name="reload" type="submit" value="Update from HRMS" <?php echo $chrDisabled; ?>/>
							<input type="button" value="Add external users..." <?php echo $chrDisabled ?> onclick="javascript:findUsers()" />
							<input type="button" value="Add managers/owners..." <?php echo $chrDisabled ?> onclick="javascript:findOwners()" />
							<!--  <input name="delete" id="btnDelete" type="submit" value="Delete department" <?php #echo $chrDisabled; ?>/> -->
						</div>
					</form>
					<?php } ?>
				</div>
				<div id="contentBody">
					<?php
					# Display any error/info messages
					if ($chrMessage){
						$chrDisplay = '';
					echo '<div id="message" '.$chrDisplay.'><p>'.safeHTML($chrMessage).'</p></div>';
					}
					

					if (!$objDept) {
						#### Select department to edit/Import department ####
					?>
					<h2>Edit Existing Department</h2>
					<form action="edit_department.php" method="get">
						<div>
							<div class="left">
								<label for="deptFilter">Department name:</label>
								<small>Description</small>
							</div>
							<div class="right">
								<input type="text" id="deptFilter" autocomplete="off"/><br />
								<select name="deptId" id="departments" size="10" >
									<option>Loading...</option>
								</select><br />
								<input type="submit" value="Edit" />
							</div>
							<div class="left">
								<label for="deptFilter" title="Change these at 'View'->'View DEP/SEC Lists'">My default departments:</label>	
							</div>
							<div class="right">		
							<?php 
								$depts = getDepartmentSettings($objSession->getIdUser());
								foreach ($depts["dept"] as $chrDept) {
									echo "<small><a href=\"edit_department.php?deptId=",urlencode($chrDept),"\">{$chrDept}</a></small>";
								}
								
								
								?>
							</div>
							<br />
						</div>
					</form>
					<h2>Import Department</h2>
					<form action="edit_department.php" method="post">
						<div>
							<div class="left">
								<label for="deptName">Department name:</label>
								<small>Use the 'Find Department' button to select a department</small>
							</div>
							<div class="right">
								<input type="hidden" name="action" value="import" />
								<input type="hidden" id="deptName" name="deptName" />
                <input type="text" id="deptNameGui" name="deptName" disabled="disabled" />
								<input type="button" value="Find department..." onclick="javascript:findDepartment()" /><br />
								<input type="submit" value="Import" />
							</div>
							<br />
						</div>
					</form>
					<?php
					} else if ($blnView) {
						#### Editing mode ####
					?>
					<form action="<?php echo $self ?>" method="post">
						<div>
							<input type="hidden" name="action" value="update" />
							<input type="hidden" name="deptId" value="<?php echo $objDept->getID(); ?>" />
							<div class="leftColumnContainer">
								<div class="leftColumn">
									<!-- 
									<fieldset>
										<legend>Add users</legend>
										<input type="button" value="Add external users..." <?php echo $chrDisabled ?> onclick="javascript:findUsers()" />
										<input type="button" value="Add managers/owners..." <?php echo $chrDisabled ?> onclick="javascript:findOwners()" />
									</fieldset>
									 -->
								
									<?php
                  #display($objDept->getManagersAndOwners());
                  
									echo '<h2 style="margin-top:20px;">Managers and Owners</h2>'.printUserList('ownerTable', $objDept->getManagersAndOwners(), $objDept, $blnEdit);
									echo '<h2>Members</h2>'.printUserList('userTable', $objDept->getUsers(), $objDept, $blnEdit);
									/*
										<table cellspacing="0" cellpadding="0" id="userTable" class="userTable">
										<thead><tr>
											<th>Visible</th>
											<th>Name</th>
											<th>User-id</th>
											<th>Owner</th>
											<th>Manager</th>
											<th>Delete</th>
											  th>&nbsp;&nbsp;&nbsp;&nbsp;</th
										</tr></thead>
										<tbody>
										<?php
										$users = $objDept->getUsers();
										$table = '';
										foreach ($users as $user) {
											$id = $user->getID();
											$uid = safeHTML($user->getUserID()); # eaaaaa
											$pf = safeHTML(sprintf(PEOPLE_FINDER_FORMAT, $user->getUserID()));
											$visible = ($objDept->isUserVisible($id) ? ' checked="checked"' : '');
											$owner = ($objDept->isOwner($id) ? ' checked="checked"' : '');
											$manager = ($objDept->isManager($id) ? ' checked="checked"' : '');

											$table .= '<tr class="userRow" id="row_'.$id.'">';
											$table .= '<td><input class="visibility" name="users['.$id.'][visible]" type="checkbox" '.$chrDisabled.' '.$visible.'/></td>';
											$table .= '<td><a class="newWindow" href="'.$pf.'">'.safeHTML($user->getFullName()).'</a></td>';
											$table .= '<td><a class="newWindow" href="'.$pf.'">'.$uid.'</a><input name="users['.$id.'][uid]" value="'.$uid.'" type="hidden" /></td>';
											$table .= '<td><input name="users['.$id.'][owner]" type="checkbox" '.$chrDisabled.' '.$owner.'/></td>';
											$table .= '<td><input name="users['.$id.'][manager]" type="checkbox" '.$chrDisabled.' '.$manager.'/></td>';
											if ($user->isExternal()){
												$table .= '<td><input class="deleted" name="users['.$id.'][deleted]" id="deleted_'.$id.'" type="hidden" value="0" />';
												if ($blnEdit) {
													$table .= '<a href="javascript:deleteUser('.$id.');" class="deleteIcon">&nbsp;</a>';
												}
												$table .= '</td>';
											}
											else {
												$table .= '<td>&nbsp;</td>';
											}
											$table .= "</tr>\n";
										}
										echo $table;
										?>-->
										</tbody>
									</table> */?>
								</div>
							</div>
							<div class="rightColumn">
								<h2>Read access to Calendar</h2>
								<div>
								<input id="freeaccess" name="freeaccess" type="checkbox" <?php if(freeAccess($objDept->getID())){ echo 'checked="checked"'; } echo $chrDisabled ?>/>
								<label for="freeaccess">Read access for everyone</label>
								</div>
								<?php /* TODO: Refactor these two into one php function */ ?>
								<div class="chooseBox">
									<div class="left">
										<label for="deptFilter">Available departments:</label>
										<input type="text" id="deptFilter" />
										<select id="deptsAll" multiple="multiple" size="6">
											<option value="-1">Loading...</option>
										</select>
									</div>
									<div class="center">
										<input type="button" value="&gt;&gt;" onclick="javascript:addAll('deptsAll', 'deptsSelected');" <?php echo $chrDisabled ?>/><br />
										<input type="button" value="&gt;" onclick="javascript:addItems('deptsAll', 'deptsSelected');" <?php echo $chrDisabled ?>/><br />
										<br />
										<input type="button" value="&lt;" onclick="javascript:removeItems('deptsSelected');" <?php echo $chrDisabled ?>/><br />
										<input type="button" value="&lt;&lt;" onclick="javascript:removeAll('deptsSelected');" <?php echo $chrDisabled ?>/><br />
									</div>
									<div class="right">
										<label for="deptsSelected">Allowed departments:</label>
										<select name="deptsSelected[]" id="deptsSelected" multiple="multiple" size="8" <?php echo $chrDisabled ?>>
											<option value="-1">Loading...</option>
										</select>
									</div>
									<br class="hard" />
								</div>
								<div class="chooseBox">
									<div class="left">
										<label for="groupFilter">Available Groups:</label>
										<input type="text" id="groupFilter" />
										<select id="groupsAll" multiple="multiple" size="6">
											<option value="-1">Loading...</option>
										</select>
									</div>
									<div class="center">
										<input type="button" value="&gt;&gt;" onclick="javascript:addAll('groupsAll', 'groupsSelected');" <?php echo $chrDisabled ?>/><br />
										<input type="button" value="&gt;" onclick="javascript:addItems('groupsAll', 'groupsSelected');" <?php echo $chrDisabled ?>/><br />
										<br />
										<input type="button" value="&lt;" onclick="javascript:removeItems('groupsSelected');" <?php echo $chrDisabled ?>/><br />
										<input type="button" value="&lt;&lt;" onclick="javascript:removeAll('groupsSelected');" <?php echo $chrDisabled ?>/><br />
									</div>
									<div class="right">
										<label for="groupsSelected">Allowed groups:</label>
										<select name="groupsSelected[]" id="groupsSelected" multiple="multiple" size="8">
											<option value="-1">Loading...</option>
										</select>
									</div>
									<br class="hard" />
								</div>
								<h2>Email Settings</h2>
								<input id="emailRequired" name="emailRequired" type="checkbox" <?php echo $chrDisabled; if ($objDept->isEmailRequired()){ echo 'checked="checked"'; } ?>/>
								<label for="emailRequired">Send email on approval/updates of vacancy</label>
								<br />
								<div id="autoApproveContainer">
									<input id="autoApprove" name="autoApprove" type="checkbox" <?php echo $chrDisabled; if ($objDept->isAutoApproved()){ echo 'checked="checked"'; } ?>/>
									<label for="autoApprove">Auto approve</label><br />
								</div>
								<br />
								<label for="confirmationMessage">Confirmation message:</label><br />
								<textarea id="confirmationMessage" name="confirmationMessage" rows="4" cols="40" <?php echo $chrDisabled ?>><?php echo safeHTML($objDept->getConfirmationMessage()); ?></textarea>
								<br /><br />
								<label for="replyMessage">Reply message:</label><br />
								<textarea id="replyMessage" name="replyMessage" rows="4" cols="40" <?php echo $chrDisabled ?>><?php echo safeHTML($objDept->getReplyMessage()); ?></textarea>
	
								
								<h2>Holidays Template</h2>
								<?php 
								$idCurrentTemplate = $objDept->getIdRedDayTemplate();
								$chrNoSelected = "";
								if ($idCurrentTemplate == -1){
									$chrNoSelected = "selected = 'selected'";
								}
								echo "<label for=\"redDayTemplate\">Template: </label><br />"; ?>
								<select id="redDayTemplate" name="redDayTemplate"<?php echo $chrDisabled ?>>
									<option value = -1<?php $chrNoSelected?>>--- No Template Selected ---</option>
									<?php 
									foreach (getArrTemplates() as $arrTemplate) {
										$chrSelected = "";
										if ($objDept->getIdRedDayTemplate() == $arrTemplate['iduser']) {
											$chrSelected = " selected = 'selected'"; 
										}
										echo "<option value=\"".$arrTemplate['iduser']."\"".$chrSelected.">".$arrTemplate['name']."</option>";
									}
									?>
								</select>
								<br />
							<div id="template_management_description">
							<small>Is your template missing or out of date? Please contact admin to get a template updated or created.</small>
							</div> 
							</div>
							<br />
							<div class="formFooter">
								<input type="reset" value="Reset" <?php echo $chrDisabled ?>/>
								<input type="submit" value="Save" <?php echo $chrDisabled ?>/>
							</div>
							<br />
						</div>
					</form>
					<?php } ?>
				</div>
			</div>
			<br class="clear" />
		</div>
		<?php echo generateFooter(); ?>
	</body>
</html>
