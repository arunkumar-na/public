<?php
/**
 * * This file is used to automatically logged user by validating him from
 * the active directory
 */
	session_start();

	include_once("../include/site/settings.php");
	include_once("../include/site/db.php");
	include_once("../include/ldapfunc.php");
	include_once("../include/utilfunc.php");
	include_once("../include/common.php");

	# get credentional from the active directory of the browsing user
	$arrUserInfo = ldap_get_user_login();
	if (sizeof($arrUserInfo) < 1){
		echo "Account can not be confirmed";
		exit();
	}
	# if any check need to be made
	print_r($arrUserInfo);
	print(utf8_decode($arrUserInfo["chrFullName"]));
	print("Hello world!");
#	$arrToken["idUser"] 			= $arrUserInfo["idUser"];
#	$arrToken["blnAdmin"] 			= false;
#	$arrToken["blnLogin"] 			= true;
#	$arrToken["chrEmailAddress"]	= $arrUserInfo["chrEmailAddress"];
#	$arrToken["chrFullName"]		= $arrUserInfo["chrFullName"];
#	$arrToken["uid"]				= $arrUserInfo["uid"];
#	$arrToken["chrDepartment"]		= $arrUserInfo["chrDepartment"];

?>