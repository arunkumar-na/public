<?php
	session_start();

	include_once("include/site/settings.php");
	include_once("include/site/db.php");
	include_once("include/ldapfunc.php");
	include_once("include/utilfunc.php");
	include_once("include/cmazsession.php");
	include_once("include/common.php");
	include_once("include/menu.php");
	include_once("include/page.php");
	include_once("include/user.php"); #only used to set default template the wrong way.
	include_once("include/department.php");
	include_once("include/template.php");

	/** Create session object and try to load user info (id name etc from session) **/
	$objSession = new cMazSession();
	$objSession->loadFromSessionToken();
	

	# check if user is logged in
	if ($objSession->isValidUserLogin() === false && $objSession->isValidAdminLogin() === false){
		if ($_REQUEST["ldaplogin"]==1){
			echo "Authorization Failed or session timed out. 
			Return to <a href=\"admin_login.php\">Admin Login</a> or <a href=\"\">Start page</a> to try again.";
			#header("location: admin_login.php");
			exit();
		}
		header("location: admin_login.php");#ldap_do_login.php?loginid=".$_REQUEST["loginid"]);#."&requrl=".$_SERVER['REQUEST_URI']);
		exit();
	}
	if ($objSession->isAdminUser() == false){
		echo "Access denied! Return to <a href=\"admin_login.php\">Admin Login</a> to try again.";
		header("location: admin_login.php");
		exit();
	}
	$idUser = 0; // its an admin user
	$idCurrentTemplate = -1; //default value indicating that "create new template" is selected
	$blnEditTemplate = false;
	if (isset($_REQUEST['editTemplate'])) { //but change to edit template if any template is selected for editing
		$idCurrentTemplate = $_REQUEST['editTemplate'];
		if ($idCurrentTemplate != -1) {
			$blnEditTemplate = true;
		}
	}
	
	if ($_REQUEST["chrAction"] == "save_template"){
		$idTemplate = $_REQUEST['templateID'];
		$arrSaveData = array(
			"name" => $_REQUEST['name'] , 
			# "uid" => $_REQUEST['abbr'] ,
			"erelation" => $_REQUEST['countryCode']); 
		
		if ($idTemplate == -1){
			$templateDummy = new Template($idTemplate ,$arrSaveData);
		}
		else if($idTemplate > 10 && $idTemplate < 101){
			$templateDummy = updateTemplate($idTemplate, $arrSaveData);		
		}
		unset($_REQUEST['name']);
		unset($_REQUEST['countryCode']);
		unset($_REQUEST['chrAction']);
		
	}
	header('Content-Type: text/html; charset=utf-8');
	
	$self = 'admin_create_template.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo generateTitle("Create Template"); ?></title>
		<?php echo generateScripts(); ?>

	</head>
	<body>
		<?php
			echo generateHeader();
			echo generateMenu($objSession);
		?>
		<div id="content">
			<div id="contentInner">
				<div id="toolbar">
					<span class="pageheading">Manage Templates</span>
					&nbsp; &nbsp; &nbsp;
				</div>
				<div id="contentBody">
					<form action="<?php echo $self ?>" method="get">
						<h2>Create or Edit Template</h2>
						
						
						<label for="editTemplate">Select a template for editing, or select <u><i>create new template</i></u> to create a new template: </label><br />
						
						
						<select title="Edit Template" id="editTemplate" name="editTemplate">					
							<?php	
								$tName = "";
								$tCCode = "";
								$tAbbr = "";
								if ($blnEditTemplate == false){
									$chrNoSelected = "selected = 'selected'";
								}
								else {
									$template = getTemplate($idCurrentTemplate);
									$tName = "value=\"{$template->getTemplateName()}\"";
									$tCCode = "value=\"{$template->getTemplateCountryCode()}\"";
									$tAbbr = "value=\"{$template->getTemplateAbbr()}\"";
								}				
								echo "<option value = -1 $chrNoSelected>--- Create New Template ---</option>";
								foreach (getArrTemplates() as $arrTemplate) {
									$chrSelected = "";
									if ($idCurrentTemplate == $arrTemplate['iduser']) {
										$chrSelected = " selected = 'selected'"; 
									}
									echo "<option value=\"".$arrTemplate['iduser']."\"".$chrSelected.">".$arrTemplate['name']."</option>";
								}
							?>
						</select>
						<input type="submit" value="Go!" />
						
						
					</form>
					
					<?php 
					if ($blnEditTemplate == false && isset($_REQUEST['editTemplate'])){
						echo "<h2>Create new template</h2>";
						?>
						<form action="<?php echo $self ?>" method="post">
							<div>
								<label for="name">New Template Name: </label><br />
								<input type="text" name="name" id="name" <?php echo $tName; ?>/><br />
								<label for="countryCode">Country Code: </label><br />
								<input type="text" name="countryCode" id="countryCode" <?php echo $tCCode; ?>/><br />
							</div>
							<div>
								<!-- <input type="text" name="abbr" id="abbr" <?php echo $tAbbr; ?>/><br />  -->
								<input type="hidden" name="templateID" id="templateID" value="<?php echo $idCurrentTemplate; ?>" />
								<input type="hidden" name="chrAction" id="chrAction" value="save_template" />
								<?php 
								if ($_REQUEST['editTemplate'] == -1){
								?>
								<input type="submit" value="Save New" />								
								<input type="reset" value="Reset" />
								<?php 
								}
								else {
								?>
								<input type="submit" value="Save Changes" />
								<?php 
								}
								?>
							</div>
						</form>

						<h2>Existing Templates (For Reference)</h2>
						<form>
								<label for="tName">Template Name</label>
								<label for="tCCode">(Country Code)</label>

									<?php 
								#get all existing templates and list them for overview.
								foreach (getArrTemplates() as $arrTemplate) {
									$template2 = getTemplate($arrTemplate['iduser']);
									$tName2 = $template2->getTemplateName();
									$tCCode2 = $template2->getTemplateCountryCode();
									#$tAbbr2 = $template2->getTemplateAbbr();

									echo "<small>$tName2 <b>($tCCode2)</b></small>";

								}
								?> 
						</form>
						<?php 
					}
					else if ($blnEditTemplate == true && isset($_REQUEST['editTemplate'])){
						echo "<h2>Edit template</h2>";
						?>
						<form action="<?php echo $self ?>" method="post">
							<div>
								<label for="name">Template Name: </label><br />
								<input type="text" name="name" id="name" <?php echo $tName; ?>/><br />
								<label for="countryCode">Country Code: </label><br />
								<input type="text" name="countryCode" id="countryCode" <?php echo $tCCode; ?>/><br />
							</div>
							<div>
								<!-- <input type="text" name="abbr" id="abbr" <?php echo $tAbbr; ?>/><br />  -->
								<input type="hidden" name="templateID" id="templateID" value="<?php echo $idCurrentTemplate; ?>" />
								<input type="hidden" name="chrAction" id="chrAction" value="save_template" />
								<?php 
								if ($_REQUEST['editTemplate'] == -1){
								?>
								<input type="submit" value="Save New" />								
								<input type="reset" value="Reset" />
								<?php 
								}
								else {
								?>
								<input type="submit" value="Save Changes" />
								<?php 
								}
								?>
							</div>
						</form>

						<h2>Existing Templates</h2>
						<form>
									<label for="tName">Template Name</label>
								<label for="tCCode">(Country Code)</label>

									<?php 
								#get all existing templates and list them for overview.
								foreach (getArrTemplates() as $arrTemplate) {
									$template2 = getTemplate($arrTemplate['iduser']);
									$tName2 = $template2->getTemplateName();
									$tCCode2 = $template2->getTemplateCountryCode();
									#$tAbbr2 = $template2->getTemplateAbbr();

									echo "<small>$tName2 <b>($tCCode2)</b></small>";

								}
								?> 
						</form>
						<?php 
					}
					?>


				</div>
			</div>
		</div>
		<?php echo generateFooter(); ?>
	</body>
</html>
